
import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';

import { API_ROUTES } from '../constants/api-routes';
import type { SystemRole } from '../constants/roles';
import type { ApiResponse } from '../models/api.models';
import { apiUrl } from '../services/api-url';
import type {
  AssignUserRoleRequest,
  CompletePasswordResetRequest,
  ConfirmMfaRequest,
  ConfirmMfaResult,
  CurrentUserResponse,
  DisableMfaRequest,
  EnableMfaResult,
  LoginActivityResponse,
  LoginRequest,
  LoginResult,
  LogoutRequest,
  PasswordResetRequest,
  RecoveryCodeRequest,
  RefreshAccessTokenResult,
  RefreshTokenRequest,
  RegisterUserRequest,
  RegisterUserResult,
  RequestPasswordResetResult,
  VerifyMfaRequest,
  VerifyMfaResult,
  VerifyRecoveryCodeResult,
} from './auth.models';

/**
 * I designed AuthService as the primary HTTP client boundary for our Auth microservice.
 * Its only responsibility is communicating with the backend auth endpoints and unwrapping the
 * standard ApiResponse<T> envelope. I intentionally avoided managing session state inside this
 * service—state management and storage updates are kept exclusively in AuthStore.
 */
@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly http = inject(HttpClient);

  register(request: RegisterUserRequest): Observable<RegisterUserResult> {
    return this.post<RegisterUserResult>(API_ROUTES.auth.register, request);
  }

  login(request: LoginRequest): Observable<LoginResult> {
    return this.post<LoginResult>(API_ROUTES.auth.login, request);
  }

  logout(request: LogoutRequest): Observable<void> {
    return this.post<void>(API_ROUTES.auth.logout, request);
  }

  refreshToken(request: RefreshTokenRequest): Observable<RefreshAccessTokenResult> {
    return this.post<RefreshAccessTokenResult>(API_ROUTES.auth.refreshToken, request);
  }

  getCurrentUser(): Observable<CurrentUserResponse> {
    return this.get<CurrentUserResponse>(API_ROUTES.auth.currentUser);
  }

  getLoginActivity(): Observable<LoginActivityResponse[]> {
    return this.get<LoginActivityResponse[]>(API_ROUTES.auth.loginActivity);
  }

  enableMfa(): Observable<EnableMfaResult> {
    return this.post<EnableMfaResult>(API_ROUTES.auth.enableMfa, {});
  }

  confirmMfa(request: ConfirmMfaRequest): Observable<ConfirmMfaResult> {
    return this.post<ConfirmMfaResult>(API_ROUTES.auth.confirmMfa, request);
  }

  verifyMfa(request: VerifyMfaRequest): Observable<VerifyMfaResult> {
    return this.post<VerifyMfaResult>(API_ROUTES.auth.verifyMfa, request);
  }

  disableMfa(request: DisableMfaRequest): Observable<void> {
    return this.post<void>(API_ROUTES.auth.disableMfa, request);
  }

  verifyRecoveryCode(request: RecoveryCodeRequest): Observable<VerifyRecoveryCodeResult> {
    return this.post<VerifyRecoveryCodeResult>(API_ROUTES.auth.verifyRecoveryCode, request);
  }

  requestPasswordReset(request: PasswordResetRequest): Observable<RequestPasswordResetResult> {
    return this.post<RequestPasswordResetResult>(API_ROUTES.auth.requestPasswordReset, request);
  }

  completePasswordReset(request: CompletePasswordResetRequest): Observable<void> {
    return this.post<void>(API_ROUTES.auth.confirmPasswordReset, request);
  }

  assignRole(userId: string, roleName: SystemRole): Observable<void> {
    const request: AssignUserRoleRequest = { roleName };
    return this.put<void>(API_ROUTES.auth.userRole(userId), request);
  }

  removeRole(userId: string, roleName: SystemRole): Observable<void> {
    return this.http
      .delete<ApiResponse<void>>(apiUrl(API_ROUTES.auth.removeUserRole(userId, roleName)))
      .pipe(map((response) => response.data));
  }

  /**
   * Helper methods to automatically unwrap the standard backend ApiResponse<T>
   * so callers directly receive the strongly-typed payload `T`.
   */
  private get<T>(route: string): Observable<T> {
    return this.http.get<ApiResponse<T>>(apiUrl(route)).pipe(map((response) => response.data));
  }

  private post<T>(route: string, body: unknown): Observable<T> {
    return this.http
      .post<ApiResponse<T>>(apiUrl(route), body)
      .pipe(map((response) => response.data));
  }

  private put<T>(route: string, body: unknown): Observable<T> {
    return this.http
      .put<ApiResponse<T>>(apiUrl(route), body)
      .pipe(map((response) => response.data));
  }
}


import { TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { provideHttpClient } from '@angular/common/http';
import { AuthSessionService } from './auth-session.service';
describe('AuthSessionService',()=>{beforeEach(()=>TestBed.configureTestingModule({providers:[provideRouter([]),provideHttpClient()]}));it('accepts internal return URLs and rejects external URLs',()=>{const service=TestBed.inject(AuthSessionService);expect(service.safeReturnUrl('/policies/my')).toBe('/policies/my');expect(service.safeReturnUrl('//evil.example')).toBe('/dashboard');expect(service.safeReturnUrl('https://evil.example')).toBe('/dashboard');});});

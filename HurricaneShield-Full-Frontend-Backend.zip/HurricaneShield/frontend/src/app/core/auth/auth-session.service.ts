
import { inject, Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { catchError, map, Observable, switchMap, throwError } from 'rxjs';
import { AuthService } from './auth.service';
import { AuthStore } from './auth.store';
import type { RefreshAccessTokenResult, VerifyMfaResult } from './auth.models';

@Injectable({ providedIn: 'root' })
export class AuthSessionService {
  private readonly authService = inject(AuthService);
  private readonly authStore = inject(AuthStore);
  private readonly router = inject(Router);

  complete(tokens: VerifyMfaResult | RefreshAccessTokenResult, returnUrl?: string | null): Observable<void> {
    this.authStore.setSession(tokens);
    return this.authService.getCurrentUser().pipe(
      map((user) => this.authStore.setCurrentUser(user)),
      switchMap(() => this.router.navigateByUrl(this.safeReturnUrl(returnUrl))),
      map(() => undefined),
      catchError((error: unknown) => {
        this.authStore.clearSession();
        return throwError(() => error);
      }),
    );
  }

  safeReturnUrl(value?: string | null): string {
    if (!value || !value.startsWith('/') || value.startsWith('//')) return '/dashboard';
    const allowed = ['/dashboard', '/profile/', '/policies/', '/payments/', '/claims/', '/staff/', '/admin/'];
    return allowed.some((prefix) => value === prefix || value.startsWith(prefix)) ? value : '/dashboard';
  }
}

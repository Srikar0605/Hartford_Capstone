
import { computed, Injectable, signal } from '@angular/core';

import { STORAGE_KEYS } from '../constants/storage-keys';
import type { SystemPermission } from '../constants/permissions';
import type { SystemRole } from '../constants/roles';
import type {
  AuthUser,
  CurrentUserResponse,
  JwtClaims,
  MfaPendingState,
  RefreshAccessTokenResult,
  VerifyMfaResult,
} from './auth.models';

/**
 * I designed AuthStore as a lightweight, signal-based state store for authentication.
 * Because we use Angular 21's zoneless change detection, using signals here allows any UI component
 * or guard to track auth changes with granular OnPush updates without needing zone.js or heavy state libraries.
 */
@Injectable({ providedIn: 'root' })
export class AuthStore {
  // Initialize signals directly from localStorage so on page refresh we don't flash an unauthenticated state.
  private readonly accessTokenState = signal<string | null>(
    this.readStorage(localStorage, STORAGE_KEYS.accessToken),
  );
  private readonly refreshTokenState = signal<string | null>(
    this.readStorage(localStorage, STORAGE_KEYS.refreshToken),
  );
  private readonly currentUserState = signal<AuthUser | null>(null);

  // We keep MFA challenge state in sessionStorage intentionally because it is ephemeral;
  // if the user closes the tab mid-login, we don't want half-authenticated MFA states lingering across browser sessions.
  private readonly mfaPendingState = signal<MfaPendingState | null>(
    this.readJson<MfaPendingState>(sessionStorage, STORAGE_KEYS.mfaChallenge),
  );

  // Expose signals as read-only to enforce unidirectional data flow.
  readonly accessToken = this.accessTokenState.asReadonly();
  readonly refreshToken = this.refreshTokenState.asReadonly();
  readonly currentUser = this.currentUserState.asReadonly();
  readonly mfaPending = this.mfaPendingState.asReadonly();

  // Derived signals that automatically recompute whenever accessToken or currentUser changes.
  readonly isAuthenticated = computed(() => this.hasUsableAccessToken());
  readonly roles = computed<readonly SystemRole[]>(() => this.currentUserState()?.roles ?? []);
  readonly permissions = computed<readonly SystemPermission[]>(
    () => this.currentUserState()?.permissions ?? [],
  );

  constructor() {
    // When the app initializes, immediately restore user identity and roles from the cached JWT.
    this.restoreUserFromToken();
  }

  /**
   * Sets up a verified session following successful login, MFA verification, or token refresh.
   */
  setSession(tokens: VerifyMfaResult | RefreshAccessTokenResult): void {
    this.accessTokenState.set(tokens.accessToken);
    this.refreshTokenState.set(tokens.refreshToken);
    localStorage.setItem(STORAGE_KEYS.accessToken, tokens.accessToken);
    localStorage.setItem(STORAGE_KEYS.refreshToken, tokens.refreshToken);
    this.clearMfaPending();
    this.restoreUserFromToken();
  }

  /**
   * Merges server-side user details (profile info) with our client-decoded claims.
   */
  setCurrentUser(response: CurrentUserResponse): void {
    const claims = this.decodeClaims(this.accessTokenState());

    this.currentUserState.set({
      ...response,
      // We take permissions directly from claims because the token is our cryptographic source of truth for authorization.
      permissions: claims?.permissions ?? [],
      mfaEnabled: response.mfaEnabled,
    });
  }

  setMfaPending(state: MfaPendingState): void {
    this.mfaPendingState.set(state);
    sessionStorage.setItem(STORAGE_KEYS.mfaChallenge, JSON.stringify(state));
  }

  clearMfaPending(): void {
    this.mfaPendingState.set(null);
    sessionStorage.removeItem(STORAGE_KEYS.mfaChallenge);
  }

  hasRole(role: SystemRole): boolean {
    return this.roles().includes(role);
  }

  hasPermission(permission: SystemPermission): boolean {
    return this.permissions().includes(permission);
  }

  /**
   * Clears all authentication state across signals and browser storage.
   */
  clearSession(): void {
    this.accessTokenState.set(null);
    this.refreshTokenState.set(null);
    this.currentUserState.set(null);
    localStorage.removeItem(STORAGE_KEYS.accessToken);
    localStorage.removeItem(STORAGE_KEYS.refreshToken);
    this.clearMfaPending();
  }

  /**
   * Reads JWT payload claims to reconstruct the local user model on startup without requiring an immediate HTTP roundtrip.
   */
  private restoreUserFromToken(): void {
    const claims = this.decodeClaims(this.accessTokenState());
    if (!claims) {
      this.currentUserState.set(null);
      return;
    }

    this.currentUserState.set({
      userId: claims.sub,
      email: claims.email,
      roles: this.asArray(claims.role),
      permissions: this.asArray(claims.permissions),
      mfaEnabled: this.asBoolean(claims.mfaEnabled),
    });
  }

  /**
   * Checks if the access token exists and has not expired according to the JWT `exp` claim.
   */
  private hasUsableAccessToken(): boolean {
    const claims = this.decodeClaims(this.accessTokenState());
    if (!claims) {
      return false;
    }

    // Multiply exp by 1000 since JWT timestamps are in seconds while Date.now() uses milliseconds.
    return claims.exp * 1000 > Date.now();
  }

  /**
   * Decodes a JWT payload manually using atob.
   * I opted for this lightweight approach instead of adding a third-party dependency like jwt-decode.
   * We normalize URL-safe base64 characters (- and _) and re-pad with '=' to ensure valid base64 parsing.
   */
  private decodeClaims(token: string | null): JwtClaims | null {
    if (!token) {
      return null;
    }

    try {
      const payload = token.split('.')[1];
      if (!payload) {
        return null;
      }

      const normalized = payload.replace(/-/g, '+').replace(/_/g, '/');
      const padded = normalized.padEnd(
        normalized.length + ((4 - (normalized.length % 4)) % 4),
        '=',
      );
      return JSON.parse(atob(padded)) as JwtClaims;
    } catch {
      return null;
    }
  }

  /**
   * Normalizes claim values into an array because ASP.NET Core JWT serialization might emit
   * a single string if there's only one role/permission, or an array if there are multiple.
   */
  private asArray<T>(value: T | T[] | undefined): T[] {
    if (value === undefined) {
      return [];
    }

    return Array.isArray(value) ? value : [value];
  }

  private asBoolean(value: boolean | string | undefined): boolean {
    return value === true || value === 'true';
  }

  private readStorage(storage: Storage, key: string): string | null {
    try {
      return storage.getItem(key);
    } catch {
      return null;
    }
  }

  private readJson<T>(storage: Storage, key: string): T | null {
    const value = this.readStorage(storage, key);
    if (!value) {
      return null;
    }

    try {
      return JSON.parse(value) as T;
    } catch {
      storage.removeItem(key);
      return null;
    }
  }
}

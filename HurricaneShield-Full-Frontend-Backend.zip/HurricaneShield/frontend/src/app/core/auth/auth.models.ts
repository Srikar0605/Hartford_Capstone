
import type { ApiDateTime, Guid } from '../models/api.models';
import type { SystemPermission } from '../constants/permissions';
import type { SystemRole } from '../constants/roles';

export interface RegisterUserRequest {
  email: string;
  password: string;
  firstName: string;
  lastName: string;
}

export interface RegisterUserResult {
  userId: Guid;
}

export interface LoginRequest {
  email: string;
  password: string;
  rememberMe?: boolean;
}

export interface LoginResult {
  mfaRequired: boolean;
  mfaChallengeToken: string | null;
  accessToken: string | null;
  refreshToken: string | null;
  expiresIn: number | null;
}

export interface RefreshTokenRequest {
  refreshToken: string;
}

export interface RefreshAccessTokenResult {
  accessToken: string;
  refreshToken: string;
  expiresIn: number;
}

export interface LogoutRequest {
  refreshToken: string;
}

export interface EnableMfaResult {
  qrCodeUrl: string;
  manualSecret: string;
}

export interface ConfirmMfaRequest {
  verificationCode: string;
}

export interface ConfirmMfaResult {
  recoveryCodes: string[];
}

export interface VerifyMfaRequest {
  mfaChallengeToken: string;
  verificationCode: string;
}

export interface VerifyMfaResult {
  accessToken: string;
  refreshToken: string;
  expiresIn: number;
}

export interface RecoveryCodeRequest {
  email: string;
  recoveryCode: string;
}

export type VerifyRecoveryCodeResult = VerifyMfaResult;

export interface PasswordResetRequest {
  email: string;
}

export interface RequestPasswordResetResult {
  developmentToken: string | null;
}

export interface CompletePasswordResetRequest {
  token: string;
  newPassword: string;
}

export interface CurrentUserResponse {
  userId: Guid;
  email: string;
  roles: SystemRole[];
  mfaEnabled: boolean;
}

export interface DisableMfaRequest {
  currentPassword: string;
  verificationCode: string;
}

export interface LoginActivityResponse {
  occurredAt: ApiDateTime;
  isSuccessful: boolean;
  ipAddress: string;
}

export interface AssignUserRoleRequest {
  roleName: SystemRole;
}

export interface JwtClaims {
  sub: Guid;
  email: string;
  role: SystemRole[];
  permissions: SystemPermission[];
  mfaEnabled: boolean;
  exp: number;
}

export interface AuthUser extends CurrentUserResponse {
  permissions: SystemPermission[];
  mfaEnabled: boolean;
}

export interface MfaPendingState {
  email: string;
  challengeToken: string;
}

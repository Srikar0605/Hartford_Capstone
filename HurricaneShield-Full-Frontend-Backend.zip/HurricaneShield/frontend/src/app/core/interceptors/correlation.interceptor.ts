
import type { HttpInterceptorFn } from '@angular/common/http';

import { API_HEADERS } from '../constants/api-routes';

/**
 * I added this interceptor to stamp every outgoing request with a unique X-Correlation-ID header.
 * This ID propagates through our Ocelot API Gateway to all downstream microservices (Auth, Policy, Claims, etc.)
 * and is captured in Serilog structured logs. When a user experiences an error, we display this ID so we can
 * trace the exact execution path across the distributed system.
 */
export const correlationInterceptor: HttpInterceptorFn = (request, next) => {
  // If a caller or test already specified an explicit correlation ID, preserve it.
  if (request.headers.has(API_HEADERS.correlationId)) {
    return next(request);
  }

  // Otherwise, generate a standard v4 UUID using the Web Crypto API.
  return next(
    request.clone({
      setHeaders: {
        [API_HEADERS.correlationId]: crypto.randomUUID(),
      },
    }),
  );
};


import {
  HttpErrorResponse,
  type HttpInterceptorFn,
} from '@angular/common/http';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import {
  catchError,
  finalize,
  map,
  Observable,
  shareReplay,
  switchMap,
  throwError,
} from 'rxjs';

import { AuthService } from '../auth/auth.service';
import { AuthStore } from '../auth/auth.store';
import { API_HEADERS, API_ROUTES } from '../constants/api-routes';

// I keep a single in-flight refresh observable here to handle the "thundering herd" problem.
// If multiple HTTP requests fail simultaneously with 401 (e.g. on page load), we must only send
// ONE refresh token request to the backend, share the response, and replay it for all waiting calls.
let refreshRequest$: Observable<string> | null = null;

export const refreshTokenInterceptor: HttpInterceptorFn = (request, next) => {
  const authService = inject(AuthService);
  const authStore = inject(AuthStore);
  const router = inject(Router);

  return next(request).pipe(
    catchError((error: unknown) => {
      // We only attempt a silent refresh on 401 errors, and we explicitly avoid auth endpoints
      // to avoid infinite loops when authentication credentials are invalid.
      if (!shouldRefresh(error, request.url)) {
        return throwError(() => error);
      }

      const refreshToken = authStore.refreshToken();
      // If we don't even have a refresh token saved, there's nothing to recover.
      // Tear down the auth session immediately and send the user to the login screen.
      if (!refreshToken) {
        authStore.clearSession();
        void router.navigateByUrl('/auth/login');
        return throwError(() => error);
      }

      // If a refresh is already in progress, re-use the active observable; otherwise kick off a new one.
      refreshRequest$ ??= authService.refreshToken({ refreshToken }).pipe(
        map((tokens) => {
          // Once the backend issues fresh tokens, immediately update our global store so future calls use them.
          authStore.setSession(tokens);
          return tokens.accessToken;
        }),
        catchError((refreshError: unknown) => {
          // If the refresh token itself expired or is invalid, the user's session is dead.
          // Wipe state and redirect to login to force a re-authentication.
          authStore.clearSession();
          void router.navigateByUrl('/auth/login');
          return throwError(() => refreshError);
        }),
        finalize(() => {
          // Once the refresh finishes (success or failure), reset the singleton pointer so subsequent 401s can refresh again.
          refreshRequest$ = null;
        }),
        // I use shareReplay(1) so any concurrent requests that arrive while refresh is pending get the latest token.
        shareReplay({ bufferSize: 1, refCount: false }),
      );

      // Once the token is obtained, clone the original failed request with the new Bearer token and retry.
      return refreshRequest$.pipe(
        switchMap((accessToken) =>
          next(
            request.clone({
              setHeaders: {
                [API_HEADERS.authorization]: `Bearer ${accessToken}`,
              },
            }),
          ),
        ),
      );
    }),
  );
};

/**
 * Checks whether an HTTP error is eligible for a token refresh attempt.
 * We must deliberately exclude all auth challenge routes because a 401 on login or MFA means bad credentials,
 * not an expired access token. Trying to refresh there would cause unwanted redirects or recursion.
 */
function shouldRefresh(error: unknown, requestUrl: string): boolean {
  if (!(error instanceof HttpErrorResponse) || error.status !== 401) {
    return false;
  }

  const excludedRoutes = [
    API_ROUTES.auth.login,
    API_ROUTES.auth.register,
    API_ROUTES.auth.refreshToken,
    API_ROUTES.auth.verifyMfa,
    API_ROUTES.auth.verifyRecoveryCode,
    API_ROUTES.auth.requestPasswordReset,
    API_ROUTES.auth.confirmPasswordReset,
  ];

  return !excludedRoutes.some((route) => requestUrl.endsWith(route));
}

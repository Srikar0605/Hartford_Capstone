
import type { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';

import { API_HEADERS } from '../constants/api-routes';
import { AuthStore } from '../auth/auth.store';

/**
 * I created this interceptor to transparently attach the JWT access token to outgoing HTTP requests.
 * In our microservices architecture, downstream services (via the Ocelot gateway) depend on the
 * Authorization header to authenticate requests and establish identity/permissions.
 */
export const authInterceptor: HttpInterceptorFn = (request, next) => {
  const authStore = inject(AuthStore);
  const accessToken = authStore.accessToken();

  // If there's no active access token, or if the caller explicitly provided an Authorization header
  // (e.g., during specific auth handshakes or custom tokens), I don't want to overwrite it.
  if (!accessToken || request.headers.has(API_HEADERS.authorization)) {
    return next(request);
  }

  // Clone the request to set the Bearer token header because HttpRequest objects are immutable in Angular.
  return next(
    request.clone({
      setHeaders: {
        [API_HEADERS.authorization]: `Bearer ${accessToken}`,
      },
    }),
  );
};

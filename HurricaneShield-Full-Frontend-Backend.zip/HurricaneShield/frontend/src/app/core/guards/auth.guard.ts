
import { inject } from '@angular/core';
import type { CanActivateFn } from '@angular/router';
import { Router } from '@angular/router';

import { AuthStore } from '../auth/auth.store';

/**
 * Functional route guard to protect authenticated sections of the application.
 * I implemented this as a functional CanActivateFn (the modern Angular convention) rather than a class.
 * It checks the reactive AuthStore to ensure a valid JWT access token is present before allowing route activation.
 */
export const authGuard: CanActivateFn = (_, state) => {
  const authStore = inject(AuthStore);
  const router = inject(Router);

  if (authStore.isAuthenticated()) {
    return true;
  }

  // Preserve the requested route in query parameters so the login flow can redirect the user back seamlessly.
  return router.createUrlTree(['/auth/login'], {
    queryParams: { returnUrl: state.url },
  });
};

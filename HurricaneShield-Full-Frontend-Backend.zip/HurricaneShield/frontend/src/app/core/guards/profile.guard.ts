
import { HttpErrorResponse } from '@angular/common/http';
import { inject } from '@angular/core';
import type { CanActivateFn } from '@angular/router';
import { Router } from '@angular/router';
import { catchError, map, of } from 'rxjs';

import { SYSTEM_ROLES } from '../constants/roles';
import { AuthStore } from '../auth/auth.store';
import { ApiClientError } from '../interceptors/error.interceptor';
import { ProfileService } from '../../features/profile/profile.service';

export const activeCustomerProfileGuard: CanActivateFn = () => {
  const authStore = inject(AuthStore);
  const profileService = inject(ProfileService);
  const router = inject(Router);

  if (!authStore.hasRole(SYSTEM_ROLES.customer)) {
    return true;
  }

  return profileService.getCurrentProfile().pipe(
    map((profile) =>
      profile.status === 'Active'
        ? true
        : router.createUrlTree(['/profile/pending-activation']),
    ),
    catchError((error: unknown) => {
      const status =
        error instanceof ApiClientError || error instanceof HttpErrorResponse
          ? error.status
          : null;

      return of(
        status === 404
          ? router.createUrlTree(['/profile/create'])
          : router.createUrlTree(['/error']),
      );
    }),
  );
};


import type { CanDeactivateFn } from '@angular/router';
import { Observable } from 'rxjs';

export interface HasUnsavedChanges {
  hasUnsavedChanges(): boolean;
  confirmDiscardChanges?(): boolean | Observable<boolean> | Promise<boolean>;
}

export const unsavedChangesGuard: CanDeactivateFn<HasUnsavedChanges> = (
  component,
) => {
  if (!component.hasUnsavedChanges()) {
    return true;
  }

  if (component.confirmDiscardChanges) {
    return component.confirmDiscardChanges();
  }

  return window.confirm(
    'You have unsaved changes. Leaving this page will discard them.',
  );
};


import { inject } from '@angular/core';
import type { CanActivateFn } from '@angular/router';
import { Router } from '@angular/router';

import { AuthStore } from '../auth/auth.store';

export const mfaPendingGuard: CanActivateFn = () => {
  const authStore = inject(AuthStore);
  const router = inject(Router);

  return authStore.mfaPending()
    ? true
    : router.createUrlTree(['/auth/login']);
};

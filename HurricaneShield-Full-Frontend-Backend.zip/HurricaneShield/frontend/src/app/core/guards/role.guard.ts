
import { inject } from '@angular/core';
import type { CanActivateFn } from '@angular/router';
import { Router } from '@angular/router';

import { AuthStore } from '../auth/auth.store';
import type { AuthorizationRouteData } from '../models/route-data.models';

/**
 * Role-Based Access Control (RBAC) guard.
 * I created this guard to enforce role requirements defined in route configurations.
 * If the target route specifies required roles, the current user must hold at least one of those roles
 * (an OR relationship across the role list).
 */
export const roleGuard: CanActivateFn = (route) => {
  const authStore = inject(AuthStore);
  const router = inject(Router);
  const data = route.data as AuthorizationRouteData;
  const requiredRoles = data.roles ?? [];

  // If no specific roles are required on the route, let the navigation proceed.
  if (requiredRoles.length === 0) {
    return true;
  }

  // Grant access if the user has any of the authorized roles; otherwise redirect to /access-denied.
  return requiredRoles.some((role) => authStore.hasRole(role))
    ? true
    : router.createUrlTree(['/access-denied']);
};

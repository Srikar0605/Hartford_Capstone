
import { inject } from '@angular/core';
import type { CanActivateFn } from '@angular/router';
import { Router } from '@angular/router';

import { AuthStore } from '../auth/auth.store';
import type { AuthorizationRouteData } from '../models/route-data.models';

/**
 * Fine-grained permission guard.
 * While roleGuard handles broad category access (e.g. "is this an Agent?"), permissionGuard enforces
 * capability-level authorization (e.g. "can this user purchase policies or review claims?").
 * Notice that unlike role checking (which uses 'some'), permission checking requires 'every': the user
 * must possess ALL declared permissions to activate the route.
 */
export const permissionGuard: CanActivateFn = (route) => {
  const authStore = inject(AuthStore);
  const router = inject(Router);
  const data = route.data as AuthorizationRouteData;
  const requiredPermissions = data.permissions ?? [];

  if (requiredPermissions.length === 0) {
    return true;
  }

  // Enforce that every permission specified on the route is granted to the user.
  return requiredPermissions.every((permission) =>
    authStore.hasPermission(permission),
  )
    ? true
    : router.createUrlTree(['/access-denied']);
};

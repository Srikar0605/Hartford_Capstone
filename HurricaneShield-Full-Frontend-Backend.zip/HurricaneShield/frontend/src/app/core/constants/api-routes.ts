
const AUTH = '/gateway/auth/api/v1/auth';
const CUSTOMERS = '/gateway/customers/api/v1/customers';
const POLICIES = '/gateway/policies/api/v1/policies';
const CLAIMS = '/gateway/claims/api/v1/claims';
const PAYMENTS = '/gateway/payments/api/v1/payments';

export const API_PREFIXES = {
  auth: AUTH,
  customers: CUSTOMERS,
  policies: POLICIES,
  claims: CLAIMS,
  payments: PAYMENTS,
} as const;

export const API_ROUTES = {
  auth: {
    register: `${AUTH}/register`,
    login: `${AUTH}/login`,
    logout: `${AUTH}/logout`,
    refreshToken: `${AUTH}/refresh-token`,
    currentUser: `${AUTH}/me`,
    users: `${AUTH}/users`,
    loginActivity: `${AUTH}/login-activity`,
    enableMfa: `${AUTH}/mfa/enable`,
    confirmMfa: `${AUTH}/mfa/confirm`,
    verifyMfa: `${AUTH}/mfa/verify`,
    disableMfa: `${AUTH}/mfa/disable`,
    verifyRecoveryCode: `${AUTH}/mfa/recovery`,
    requestPasswordReset: `${AUTH}/password-reset/request`,
    confirmPasswordReset: `${AUTH}/password-reset/confirm`,
    userRole: (userId: string) => `${AUTH}/users/${userId}/role`,
    removeUserRole: (userId: string, roleName: string) =>
      `${AUTH}/users/${userId}/roles/${encodeURIComponent(roleName)}`,
  },
  customers: {
    root: CUSTOMERS,
    me: `${CUSTOMERS}/me`,
    addresses: `${CUSTOMERS}/me/addresses`,
    addressAutocomplete: `${CUSTOMERS}/addresses/autocomplete`,
    address: (addressId: string) => `${CUSTOMERS}/me/addresses/${addressId}`,
    emergencyContacts: `${CUSTOMERS}/me/emergency-contacts`,
    properties: `${CUSTOMERS}/me/properties`,
    property: (propertyId: string) => `${CUSTOMERS}/me/properties/${propertyId}`,
    byId: (customerId: string) => `${CUSTOMERS}/${customerId}`,
    eligibility: (customerId: string) => `${CUSTOMERS}/${customerId}/eligibility`,
    activate: (customerId: string) => `${CUSTOMERS}/${customerId}/activate`,
    deactivate: (customerId: string) => `${CUSTOMERS}/${customerId}/deactivate`,
  },
  policies: {
    root: POLICIES,
    mine: `${POLICIES}/me`,
    search: `${POLICIES}/search`,
    byId: (policyId: string) => `${POLICIES}/${policyId}`,
    staffById: (policyId: string) => `${POLICIES}/staff/${policyId}`,
    staffVersions: (policyId: string) => `${POLICIES}/staff/${policyId}/versions`,
    staffHistory: (policyId: string) => `${POLICIES}/staff/${policyId}/history`,
    versions: (policyId: string) => `${POLICIES}/${policyId}/versions`,
    history: (policyId: string) => `${POLICIES}/${policyId}/history`,
    cancel: (policyId: string) => `${POLICIES}/${policyId}/cancel`,
    cancelPreview: (policyId: string) => `${POLICIES}/${policyId}/cancel-preview`,
    suspend: (policyId: string) => `${POLICIES}/${policyId}/suspend`,
    reactivate: (policyId: string) => `${POLICIES}/${policyId}/reactivate`,
    expire: (policyId: string) => `${POLICIES}/${policyId}/expire`,
    renew: (policyId: string) => `${POLICIES}/${policyId}/renew`,
    endorse: (policyId: string) => `${POLICIES}/${policyId}/endorse`,
    renewalEstimate: (policyId: string) => `${POLICIES}/${policyId}/renewal-estimate`,
    quote: `${POLICIES}/quote`,
    recommendations: `${POLICIES}/recommendations`,
    customerQuote: `${POLICIES}/customer-quote`,
    insuredProperties: `${POLICIES}/me/insured-properties`,
    plans: `${POLICIES}/plans`,
    plan: (planId: string) => `${POLICIES}/plans/${planId}`,
    adminPlans: `${POLICIES}/admin/plans`,
    planCoverages: (planId: string) => `${POLICIES}/plans/${planId}/coverages`,
    activatePlan: (planId: string) => `${POLICIES}/plans/${planId}/activate`,
    deactivatePlan: (planId: string) => `${POLICIES}/plans/${planId}/deactivate`,
    coverageTypes: `${POLICIES}/coverage-types`,
    adminCoverageTypes: `${POLICIES}/coverage-types?includeInactive=true`,
    coverageType: (coverageTypeId: string) => `${POLICIES}/coverage-types/${coverageTypeId}`,
    activateCoverageType: (coverageTypeId: string) =>
      `${POLICIES}/coverage-types/${coverageTypeId}/activate`,
    deactivateCoverageType: (coverageTypeId: string) =>
      `${POLICIES}/coverage-types/${coverageTypeId}/deactivate`,
    underwriting: `${POLICIES}/underwriting`,
    underwritingDetails: (policyId: string) => `${POLICIES}/underwriting/${policyId}`,
    approve: (policyId: string) => `${POLICIES}/${policyId}/approve`,
    reject: (policyId: string) => `${POLICIES}/${policyId}/reject`,
    revise: (policyId: string) => `${POLICIES}/${policyId}/revise`,
  },
  claims: {
    root: CLAIMS,
    mine: `${CLAIMS}/me`,
    byId: (claimId: string) => `${CLAIMS}/${claimId}`,
    timeline: (claimId: string) => `${CLAIMS}/${claimId}/timeline`,
    documents: (claimId: string) => `${CLAIMS}/${claimId}/documents`,
    verifyDocument: (claimId: string, documentId: string) =>
      `${CLAIMS}/${claimId}/documents/${documentId}/verify`,
    startReview: (claimId: string) => `${CLAIMS}/${claimId}/review`,
    activeReview: (claimId: string) => `${CLAIMS}/${claimId}/review`,
    approve: (claimId: string) => `${CLAIMS}/${claimId}/approve`,
    reject: (claimId: string) => `${CLAIMS}/${claimId}/reject`,
    requestInformation: (claimId: string) => `${CLAIMS}/${claimId}/request-information`,
    settlement: (claimId: string) => `${CLAIMS}/${claimId}/settlement`,
  },
  payments: {
    premium: `${PAYMENTS}/premium`,
    mine: `${PAYMENTS}/me`,
    transactions: `${PAYMENTS}/transactions`,
    byId: (transactionId: string) => `${PAYMENTS}/${transactionId}`,
    receipt: (transactionId: string) => `${PAYMENTS}/${transactionId}/receipt`,
    retry: (transactionId: string) => `${PAYMENTS}/${transactionId}/retry`,
    settlement: (transactionId: string) => `${PAYMENTS}/settlements/${transactionId}`,
  },
} as const;

export const API_HEADERS = {
  authorization: 'Authorization',
  correlationId: 'X-Correlation-Id',
  idempotencyKey: 'X-Idempotency-Key',
  rowVersion: 'X-Row-Version',
} as const;


export const SYSTEM_ROLES = {
  customer: 'Customer',
  agent: 'Agent',
  claimsManager: 'Claims Manager',
  administrator: 'Administrator',
} as const;

export type SystemRole = (typeof SYSTEM_ROLES)[keyof typeof SYSTEM_ROLES];

export const ALL_SYSTEM_ROLES: readonly SystemRole[] = Object.values(SYSTEM_ROLES);

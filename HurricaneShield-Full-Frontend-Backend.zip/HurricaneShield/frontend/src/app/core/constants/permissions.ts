
export const SYSTEM_PERMISSIONS = {
  manageProfile: 'Manage Profile',
  purchasePolicy: 'Purchase Policy',
  renewPolicy: 'Renew Policy',
  cancelPolicy: 'Cancel Policy',
  submitClaims: 'Submit Claims',
  viewPayments: 'View Payments',
  reviewPolicies: 'Review Policies',
  reviewUnderwritingRequests: 'Review Underwriting Requests',
  approvePolicies: 'Approve Policies',
  rejectPolicies: 'Reject Policies',
  reviewClaims: 'Review Claims',
  approveClaims: 'Approve Claims',
  rejectClaims: 'Reject Claims',
  verifyDocuments: 'Verify Documents',
  initiateSettlement: 'Initiate Settlement',
  confirmClaimSettlements: 'Confirm Claim Settlements',
  manageUsers: 'Manage Users',
  manageRoles: 'Manage Roles',
  managePlans: 'Manage Plans',
  managePolicies: 'Manage Policies',
  accessReports: 'Access Reports',
  performAgentFunctions: 'Perform Agent Functions',
  performClaimsManagerFunctions: 'Perform Claims Manager Functions',
} as const;

export type SystemPermission =
  (typeof SYSTEM_PERMISSIONS)[keyof typeof SYSTEM_PERMISSIONS];

export const ALL_SYSTEM_PERMISSIONS: readonly SystemPermission[] =
  Object.values(SYSTEM_PERMISSIONS);


export const STORAGE_KEYS = {
  accessToken: 'hs.accessToken',
  refreshToken: 'hs.refreshToken',
  mfaChallenge: 'hs.mfaChallenge',
  pendingOperationKeys: 'hs.pendingOperationKeys',
} as const;

export const IDEMPOTENT_OPERATIONS = {
  policyApplication: 'policy-application',
  policyRenewal: 'policy-renewal',
  policyEndorsement: 'policy-endorsement',
  claimSubmission: 'claim-submission',
  premiumPayment: 'premium-payment',
  claimSettlement: 'claim-settlement',
} as const;

export type IdempotentOperation =
  (typeof IDEMPOTENT_OPERATIONS)[keyof typeof IDEMPOTENT_OPERATIONS];


/** Standard successful API envelope returned by HurricaneShield services. */
export interface ApiResponse<T> {
  success: boolean;
  message: string;
  data: T;
}

/** No-content marker for endpoints that return an empty successful payload. */
export type EmptyApiData = Record<string, never>;

/** Opaque Base64 concurrency token returned by the backend. */
export type RowVersion = string;

/** ISO 8601 calendar date in yyyy-MM-dd form. */
export type ApiDate = string;

/** ISO 8601 date-time string. */
export type ApiDateTime = string;

/** UUID/GUID serialized as a string. */
export type Guid = string;

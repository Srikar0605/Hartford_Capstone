
export interface ApiErrorResponse {
  success: false;
  errorCode: string;
  message: string;
  correlationId: string;
  errors?: Record<string, string[]> | null;
}

export interface FrontendErrorState {
  message: string;
  errorCode: string | null;
  correlationId: string | null;
  status: number | null;
  validationErrors: Record<string, string[]>;
}

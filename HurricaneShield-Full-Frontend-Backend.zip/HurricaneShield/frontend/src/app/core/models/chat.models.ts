
export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  content: string;
  timestamp: Date;
}

export interface ChatApiRequest {
  history: { role: 'user' | 'model'; content: string }[];
  newMessage: string;
  clientContext?: string;
}

export interface ChatApiResponse {
  reply: string;
}

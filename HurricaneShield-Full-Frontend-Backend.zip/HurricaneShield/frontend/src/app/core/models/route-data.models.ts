
import type { SystemPermission } from '../constants/permissions';
import type { SystemRole } from '../constants/roles';

export interface AuthorizationRouteData {
  roles?: readonly SystemRole[];
  permissions?: readonly SystemPermission[];
}

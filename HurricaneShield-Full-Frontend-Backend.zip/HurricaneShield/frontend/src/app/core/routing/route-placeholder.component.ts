
import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-route-placeholder',
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl:
  './route-placeholder.component.html',
})
export class RoutePlaceholderComponent {
  private readonly route = inject(ActivatedRoute);

  readonly title = computed(() =>
    String(this.route.snapshot.data['title'] ?? 'HurricaneShield'),
  );

  readonly pageKey = computed(() =>
    String(this.route.snapshot.data['pageKey'] ?? 'unassigned'),
  );
}

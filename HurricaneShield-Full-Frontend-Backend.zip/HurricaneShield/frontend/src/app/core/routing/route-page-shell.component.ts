
import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { PageHeaderComponent } from '../../shared/components/page-header/page-header.component';
import { StepperComponent } from '../../shared/components/stepper/stepper.component';
import { PAGE_SHELLS } from './page-shell.catalog';

import { IconComponent } from '../../shared/components/icon/icon.component';

@Component({
  selector: 'app-route-page-shell',
  imports: [PageHeaderComponent, StepperComponent, RouterLink, IconComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl:
  './route-page-shell.component.html',
})
export class RoutePageShellComponent {
  private readonly route = inject(ActivatedRoute);
  readonly title = computed(() => String(this.route.snapshot.data['title'] ?? 'HurricaneShield'));
  readonly pageKey = computed(() => String(this.route.snapshot.data['pageKey'] ?? 'system.error'));
  readonly definition = computed(() => PAGE_SHELLS[this.pageKey()] ?? PAGE_SHELLS['system.error']);
  readonly breadcrumbs = computed(() => [
    { label: 'HurricaneShield', route: '/home' },
    { label: this.title() },
  ]);
  readonly steps = computed(() => this.definition().sections.map((label) => ({ label })));

  /** Temporary compatibility for canDeactivate routes until real form pages replace this shell. */
  hasUnsavedChanges(): boolean {
    return false;
  }
}


import type { Type } from '@angular/core';
import type { Route } from '@angular/router';

import { AdminConnectedPageComponent } from '../../features/admin/pages/admin-connected-page.component';
import { AuthConnectedPageComponent } from '../../features/auth/pages/auth-connected-page.component';
import { ClaimConnectedPageComponent } from '../../features/claims/pages/claim-connected-page.component';
import { DashboardConnectedPageComponent } from '../../features/dashboard/pages/dashboard-connected-page.component';
import { PaymentConnectedPageComponent } from '../../features/payments/pages/payment-connected-page.component';
import { PlanAdminConnectedPageComponent } from '../../features/policies/pages/plan-admin-connected-page.component';
import { PolicyStaffConnectedPageComponent } from '../../features/policies/pages/policy-staff-connected-page.component';
import { PolicyConnectedPageComponent } from '../../features/policies/pages/policy-connected-page.component';
import { ProfileConnectedPageComponent } from '../../features/profile/pages/profile-connected-page.component';
import { PublicConnectedPageComponent } from '../../features/public/pages/public-connected-page.component';
import { RoutePageShellComponent } from './route-page-shell.component';

export interface PlaceholderRouteOptions {
  path: string;
  title: string;
  pageKey: string;
  canActivate?: Route['canActivate'];
  canDeactivate?: Route['canDeactivate'];
  data?: Route['data'];
}

function componentFor(pageKey: string): Type<unknown> {
  if (pageKey.startsWith('public.') || pageKey.startsWith('system.')) {
    return PublicConnectedPageComponent;
  }

  if (pageKey.startsWith('auth.')) {
    return AuthConnectedPageComponent;
  }

  if (pageKey === 'dashboard.role-aware') {
    return DashboardConnectedPageComponent;
  }

  if (pageKey.startsWith('profile.')) {
    return ProfileConnectedPageComponent;
  }

  if (pageKey.startsWith('policies.')) {
    return PolicyConnectedPageComponent;
  }


  if (['staff.policy-search', 'staff.policy-details', 'staff.underwriting-queue', 'staff.underwriting-review'].includes(pageKey)) {
    return PolicyStaffConnectedPageComponent;
  }

  if (pageKey.startsWith('claims.') || ['staff.claims-queue', 'staff.claim-review', 'staff.settlements'].includes(pageKey)) {
    return ClaimConnectedPageComponent;
  }

  if (pageKey.startsWith('payments.') || pageKey.startsWith('admin.payment-')) {
    return PaymentConnectedPageComponent;
  }

  if (pageKey.startsWith('admin.plan-') || pageKey.startsWith('admin.coverage-')) {
    return PlanAdminConnectedPageComponent;
  }

  if (['admin.customer-search', 'admin.customer-details', 'admin.role-assignment'].includes(pageKey)) {
    return AdminConnectedPageComponent;
  }

  return RoutePageShellComponent;
}

export function placeholderRoute(options: PlaceholderRouteOptions): Route {
  return {
    path: options.path,
    title: options.title,

    component: componentFor(options.pageKey),

    canActivate: options.canActivate,

    canDeactivate: options.canDeactivate,

    data: {
      title: options.title,
      pageKey: options.pageKey,
      ...options.data,
    },
  };
}

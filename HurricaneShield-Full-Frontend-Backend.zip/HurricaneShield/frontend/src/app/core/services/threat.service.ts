
import { HttpClient, HttpParams } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable, map, of, catchError } from 'rxjs';

import { apiUrl } from './api-url';
import type { ApiResponse } from '../models/api.models';

export interface ThreatAlertResponse {
  isActive: boolean;
  source: string;
  title: string;
  message: string;
  severity: 'Critical' | 'Warning' | 'Info';
}

@Injectable({
  providedIn: 'root',
})
export class ThreatService {
  private readonly http = inject(HttpClient);

  checkThreats(latitude?: number | null, longitude?: number | null): Observable<ThreatAlertResponse> {
    let params = new HttpParams();
    if (latitude != null && longitude != null) {
      params = params.set('latitude', latitude).set('longitude', longitude);
    }

    return this.http
      .get<ApiResponse<ThreatAlertResponse>>(apiUrl('/gateway/policies/api/v1/system/threats'), { params })
      .pipe(
        map((response) => response.data),
        catchError(() => of({
          isActive: false,
          source: 'SYSTEM',
          title: 'Clear Skies',
          message: 'Unable to connect to threat intelligence.',
          severity: 'Info'
        } as ThreatAlertResponse))
      );
  }
}


import { HttpParams } from '@angular/common/http';

export function toHttpParams(
  values: Record<string, unknown>,
): HttpParams {
  let params = new HttpParams();

  for (const [key, value] of Object.entries(values)) {
    if (value === undefined || value === null || value === '') {
      continue;
    }

    params = params.set(key, String(value));
  }

  return params;
}

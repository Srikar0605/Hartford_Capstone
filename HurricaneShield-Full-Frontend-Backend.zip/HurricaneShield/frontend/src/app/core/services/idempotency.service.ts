
import { Injectable } from '@angular/core';

import {
  type IdempotentOperation,
  STORAGE_KEYS,
} from '../constants/storage-keys';

interface PendingOperation {
  key: string;
  payload: string;
}

/**
 * I created IdempotencyService to protect high-stakes operations (like payment processing and policy purchases)
 * from duplicate execution caused by double clicks, flaky networks, or automated HTTP retries.
 * Our backend enforces an X-Idempotency-Key contract: if an operation with the same key and payload is re-submitted,
 * the backend returns the cached response instead of charging the customer or issuing a duplicate policy.
 */
@Injectable({ providedIn: 'root' })
export class IdempotencyService {
  /**
   * Retrieves an existing idempotency key if the payload is identical, or generates a fresh UUID key.
   * By pairing the key with the serialized payload, we ensure that if a user changes payment amounts or terms,
   * a brand new idempotency key is issued.
   */
  getOrCreate(operation: IdempotentOperation, payload: unknown): string {
    const serializedPayload = this.stableSerialize(payload);
    const operations = this.readOperations();
    const existing = operations[operation];

    // If the user is re-attempting the exact same operation with identical data, reuse the existing key.
    if (existing?.payload === serializedPayload) {
      return existing.key;
    }

    // Otherwise, generate a new UUID for this fresh attempt and store it in sessionStorage.
    const key = crypto.randomUUID();
    operations[operation] = { key, payload: serializedPayload };
    this.writeOperations(operations);
    return key;
  }

  get(operation: IdempotentOperation): string | null {
    return this.readOperations()[operation]?.key ?? null;
  }

  /**
   * Called once a transaction succeeds so subsequent operations start clean with a new key.
   */
  complete(operation: IdempotentOperation): void {
    const operations = this.readOperations();
    delete operations[operation];
    this.writeOperations(operations);
  }

  clearAll(): void {
    sessionStorage.removeItem(STORAGE_KEYS.pendingOperationKeys);
  }

  /**
   * Performs deterministic JSON serialization by recursively sorting object keys.
   * Standard JSON.stringify produces different strings if object properties appear in different orders,
   * which would falsely invalidate the idempotency key check.
   */
  private stableSerialize(value: unknown): string {
    return JSON.stringify(this.sortValue(value));
  }

  private sortValue(value: unknown): unknown {
    if (Array.isArray(value)) {
      return value.map((item) => this.sortValue(item));
    }

    if (value !== null && typeof value === 'object') {
      return Object.fromEntries(
        Object.entries(value as Record<string, unknown>)
          .sort(([left], [right]) => left.localeCompare(right))
          .map(([key, item]) => [key, this.sortValue(item)]),
      );
    }

    return value;
  }

  private readOperations(): Partial<Record<IdempotentOperation, PendingOperation>> {
    try {
      const value = sessionStorage.getItem(STORAGE_KEYS.pendingOperationKeys);
      return value ? JSON.parse(value) : {};
    } catch {
      return {};
    }
  }

  private writeOperations(
    operations: Partial<Record<IdempotentOperation, PendingOperation>>,
  ): void {
    sessionStorage.setItem(
      STORAGE_KEYS.pendingOperationKeys,
      JSON.stringify(operations),
    );
  }
}

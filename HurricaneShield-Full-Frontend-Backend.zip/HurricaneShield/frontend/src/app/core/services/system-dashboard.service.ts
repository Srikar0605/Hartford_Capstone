
import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable, map } from 'rxjs';

import { apiUrl } from './api-url';
import type { ApiResponse } from '../models/api.models';

export interface DashboardMetricsResponse {
  business: BusinessMetrics;
  operations: OperationalMetrics;
}

export interface BusinessMetrics {
  kpis: {
    grossWrittenPremium: number;
    lossRatio: number;
    quoteToBindRatio: number;
  };
  operatingMargin: { month: string; gwp: number; claimsPaid: number }[];
  riskExposure: { riskZone: string; policyCount: number }[];
  policyChurn: { month: string; newPolicies: number; cancelledPolicies: number }[];
  claimsStatus: { status: string; count: number }[];
}

export interface OperationalMetrics {
  kpis: {
    globalLatencyMs: number;
    globalErrorRate: number;
    requestsPerMinute: number;
  };
  serviceHealth: {
    serviceName: string;
    p50Latency: number;
    p90Latency: number;
    p99Latency: number;
    errorRate: number;
    cpuUsagePercent: number;
    memoryMb: number;
    status: string;
  }[];
  trafficCorrelation: { timeLabel: string; requests: number; errors: number }[];
}

@Injectable({
  providedIn: 'root',
})
export class SystemDashboardService {
  private readonly http = inject(HttpClient);

  getMetrics(): Observable<DashboardMetricsResponse> {
    return this.http
      .get<ApiResponse<DashboardMetricsResponse>>(apiUrl('/gateway/policies/api/v1/system/dashboard-metrics'))
      .pipe(map((response) => response.data));
  }
}

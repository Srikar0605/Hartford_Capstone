
import { Injectable, signal } from '@angular/core';

export type NotificationKind = 'success' | 'error' | 'warning' | 'info';

export interface AppNotification {
  id: string;
  kind: NotificationKind;
  title: string;
  message: string;
  correlationId?: string | null;
}

@Injectable({
  providedIn: 'root',
})
export class NotificationService {
  private readonly notificationsState = signal<AppNotification[]>([]);

  private readonly dismissalTimers = new Map<string, ReturnType<typeof setTimeout>>();

  readonly notifications = this.notificationsState.asReadonly();

  show(
    kind: NotificationKind,
    title: string,
    message: string,
    correlationId?: string | null,
    durationMilliseconds = this.defaultDuration(kind),
  ): string {
    const id = crypto.randomUUID();

    this.notificationsState.update((items: AppNotification[]) => [
      ...items,
      {
        id,
        kind,
        title,
        message,
        correlationId,
      },
    ]);

    if (durationMilliseconds > 0) {
      const timer = setTimeout(() => {
        this.dismiss(id);
      }, durationMilliseconds);

      this.dismissalTimers.set(id, timer);
    }

    return id;
  }

  success(title: string, message: string, durationMilliseconds?: number): string {
    return this.show(
      'success',
      title,
      message,
      undefined,
      durationMilliseconds ?? this.defaultDuration('success'),
    );
  }

  error(
    title: string,
    message: string,
    correlationId?: string | null,
    durationMilliseconds?: number,
  ): string {
    return this.show(
      'error',
      title,
      message,
      correlationId,
      durationMilliseconds ?? this.defaultDuration('error'),
    );
  }

  warning(title: string, message: string, durationMilliseconds?: number): string {
    return this.show(
      'warning',
      title,
      message,
      undefined,
      durationMilliseconds ?? this.defaultDuration('warning'),
    );
  }

  info(title: string, message: string, durationMilliseconds?: number): string {
    return this.show(
      'info',
      title,
      message,
      undefined,
      durationMilliseconds ?? this.defaultDuration('info'),
    );
  }

  dismiss(id: string): void {
    this.clearDismissalTimer(id);

    this.notificationsState.update((items: AppNotification[]) =>
      items.filter((notification: AppNotification) => notification.id !== id),
    );
  }

  clear(): void {
    for (const timer of this.dismissalTimers.values()) {
      clearTimeout(timer);
    }

    this.dismissalTimers.clear();
    this.notificationsState.set([]);
  }

  private defaultDuration(kind: NotificationKind): number {
    switch (kind) {
      case 'success':
        return 4000;

      case 'info':
        return 5000;

      case 'warning':
        return 7000;

      case 'error':
        return 8000;
    }
  }

  private clearDismissalTimer(id: string): void {
    const timer = this.dismissalTimers.get(id);

    if (timer === undefined) {
      return;
    }

    clearTimeout(timer);
    this.dismissalTimers.delete(id);
  }
}

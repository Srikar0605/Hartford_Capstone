
import type { Routes } from '@angular/router';

import { AppLayoutComponent } from './layout/app-layout/app-layout.component';
import { PublicLayoutComponent } from './layout/public-layout/public-layout.component';

import { adminRoutes } from './features/admin/admin.routes';
import { authRoutes } from './features/auth/auth.routes';
import { claimRoutes } from './features/claims/claim.routes';
import { dashboardRoutes } from './features/dashboard/dashboard.routes';
import { LandingPageComponent } from './features/Landing/landing-page.component';
import { paymentRoutes } from './features/payments/payment.routes';
import { policyRoutes } from './features/policies/policy.routes';
import { profileRoutes } from './features/profile/profile.routes';
import { publicRoutes } from './features/public/public.routes';
import { staffRoutes } from './features/staff/staff.routes';

export const routes: Routes = [
  {
    path: '',
    pathMatch: 'full',
    component: LandingPageComponent,
    title: 'NaturalShield Insurance',
  },
  {
    path: '',
    component: PublicLayoutComponent,
    children: [
      { path: 'login', redirectTo: 'auth/login', pathMatch: 'full' },
      { path: 'register', redirectTo: 'auth/register', pathMatch: 'full' },
      ...publicRoutes,
      ...authRoutes,
    ],
  },
  {
    path: '',
    component: AppLayoutComponent,
    children: [
      ...dashboardRoutes,
      ...profileRoutes,
      ...policyRoutes,
      ...paymentRoutes,
      ...claimRoutes,
      ...staffRoutes,
      ...adminRoutes,
    ],
  },
  {
    path: '**',
    redirectTo: 'not-found',
  },
];


import { ChangeDetectionStrategy, Component, DestroyRef, inject, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { ActivatedRoute, NavigationEnd, Router, RouterLink } from '@angular/router';
import { filter, startWith } from 'rxjs';

import { IconComponent } from '../components/icon/icon.component';

interface BreadcrumbItem {
  label: string;
  url: string | null;
}

interface BreadcrumbSection {
  label: string;
  url: string;
}

@Component({
  selector: 'app-breadcrumbs',
  standalone: true,
  imports: [RouterLink, IconComponent],
  templateUrl: './breadcrumbs.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class BreadcrumbsComponent {
  private readonly router = inject(Router);
  private readonly activatedRoute = inject(ActivatedRoute);
  private readonly destroyRef = inject(DestroyRef);

  readonly items = signal<readonly BreadcrumbItem[]>([]);

  constructor() {
    this.router.events
      .pipe(
        filter((event): event is NavigationEnd => event instanceof NavigationEnd),
        startWith(null),
        takeUntilDestroyed(this.destroyRef),
      )
      .subscribe(() => {
        this.items.set(this.buildBreadcrumbs());
      });
  }

  private buildBreadcrumbs(): readonly BreadcrumbItem[] {
    const url = this.router.url.split('?')[0].split('#')[0];
    const currentTitle = this.resolveCurrentTitle();

    if (!currentTitle) {
      return [];
    }

    const items: BreadcrumbItem[] = [
      {
        label: 'Home',
        url: '/dashboard',
      },
    ];

    const section = this.resolveSection(url);

    if (section && section.label.toLowerCase() !== currentTitle.toLowerCase()) {
      items.push({
        label: section.label,
        url: section.url,
      });
    }

    items.push({
      label: currentTitle,
      url: null,
    });

    return items;
  }

  private resolveCurrentTitle(): string {
    let route = this.activatedRoute;

    while (route.firstChild) {
      route = route.firstChild;
    }

    const snapshotTitle = route.snapshot?.title;

    if (typeof snapshotTitle === 'string') {
      return snapshotTitle;
    }

    const dataTitle = route.snapshot?.data?.['title'];

    return typeof dataTitle === 'string' ? dataTitle : '';
  }

  private resolveSection(url: string): BreadcrumbSection | null {
    if (url.startsWith('/profile')) {
      return {
        label: 'Profile',
        url: '/profile/overview',
      };
    }

    if (url.startsWith('/policies')) {
      return {
        label: 'Policies',
        url: '/policies/my',
      };
    }

    if (url.startsWith('/claims')) {
      return {
        label: 'Claims',
        url: '/claims/my',
      };
    }

    if (url.startsWith('/payments')) {
      return {
        label: 'Payments',
        url: '/payments/my',
      };
    }

    if (url.startsWith('/staff/claims')) {
      return {
        label: 'Claims',
        url: '/staff/claims/queue',
      };
    }

    if (url.startsWith('/staff/policies')) {
      return {
        label: 'Policies',
        url: '/staff/policies/search',
      };
    }

    if (url.startsWith('/staff/payments')) {
      return {
        label: 'Payments',
        url: '/staff/payments/search',
      };
    }

    if (url.startsWith('/admin')) {
      return {
        label: 'Administration',
        url: '/admin/customers/search',
      };
    }

    if (url.startsWith('/dashboard')) {
      return null;
    }

    return null;
  }
}

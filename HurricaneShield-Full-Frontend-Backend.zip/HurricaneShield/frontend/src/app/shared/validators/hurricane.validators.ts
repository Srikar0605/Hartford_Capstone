
import type { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';

const GUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const PASSWORD_UPPER = /[A-Z]/;
const PASSWORD_LOWER = /[a-z]/;
const PASSWORD_DIGIT = /\d/;
const PASSWORD_SPECIAL = /[^A-Za-z0-9]/;

/**
 * Custom validator library for the NaturalShield platform.
 * I centralized these validation routines to enforce consistent domain constraints
 * across both public quotes, customer claims, and admin configurations.
 */
export class HurricaneValidators {
  /**
   * Validates UUID/GUID format.
   * In our microservices architecture, IDs across services are standard GUID strings.
   * If a field is empty, we let it pass (use Validators.required for presence checks).
   */
  static guid(control: AbstractControl): ValidationErrors | null {
    const value = String(control.value ?? '').trim();
    return !value || GUID_PATTERN.test(value) ? null : { guid: true };
  }

  /**
   * Enforces positive values (> 0).
   * In insurance calculations, property value and requested coverage must be strictly greater than zero;
   * a property valuation of $0 is non-insurable.
   */
  static positiveNumber(control: AbstractControl): ValidationErrors | null {
    const value = Number(control.value);
    return control.value === null || control.value === '' || (Number.isFinite(value) && value > 0)
      ? null
      : { positiveNumber: true };
  }

  /**
   * Enforces non-negative values (>= 0).
   * Used for counts like claimsHistoryCount, where 0 is a valid and common count.
   */
  static nonNegativeNumber(control: AbstractControl): ValidationErrors | null {
    const value = Number(control.value);
    return control.value === null || control.value === '' || (Number.isFinite(value) && value >= 0)
      ? null
      : { nonNegativeNumber: true };
  }

  /**
   * Ensures dates (e.g. incident dates, property inspection dates) do not lie in the future.
   * FNOL claims cannot report hurricane damage that has not yet occurred.
   */
  static isoDateNotInFuture(control: AbstractControl): ValidationErrors | null {
    const value = String(control.value ?? '');
    if (!value) return null;
    const selected = new Date(`${value}T00:00:00`);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return Number.isNaN(selected.getTime()) || selected > today ? { futureDate: true } : null;
  }

  /**
   * Strict password policy validator.
   * Requires 12 characters, uppercase, lowercase, number, and special character to protect customer accounts.
   */
  static password(control: AbstractControl): ValidationErrors | null {
    const value = String(control.value ?? '');
    if (!value) return null;
    const failures: string[] = [];
    if (value.length < 12) failures.push('minLength');
    if (!PASSWORD_UPPER.test(value)) failures.push('uppercase');
    if (!PASSWORD_LOWER.test(value)) failures.push('lowercase');
    if (!PASSWORD_DIGIT.test(value)) failures.push('digit');
    if (!PASSWORD_SPECIAL.test(value)) failures.push('special');
    return failures.length ? { password: failures } : null;
  }

  /**
   * Cross-field validator to ensure two form controls match (such as password and confirm password).
   */
  static fieldsMatch(firstField: string, secondField: string): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const first = control.get(firstField)?.value;
      const second = control.get(secondField)?.value;
      return first === second ? null : { fieldsMismatch: { firstField, secondField } };
    };
  }

  /**
   * Validates document and image uploads against file size limits to prevent browser performance bottlenecks
   * and excessive bandwidth usage on claim evidence submissions.
   */
  static maximumFileSize(maxBytes: number): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const file = control.value as File | null;
      return !file || file.size <= maxBytes ? null : { maximumFileSize: { maxBytes, actualBytes: file.size } };
    };
  }
}


import { FormControl, FormGroup } from '@angular/forms';
import { describe, expect, it } from 'vitest';
import { HurricaneValidators } from './hurricane.validators';

describe('HurricaneValidators', () => {
  it('accepts a valid guid and rejects another value', () => {
    expect(HurricaneValidators.guid(new FormControl('9b664b77-0e1f-44c4-82a8-878697874a26'))).toBeNull();
    expect(HurricaneValidators.guid(new FormControl('not-a-guid'))).toEqual({ guid: true });
  });

  it('requires modern password strength', () => {
    expect(HurricaneValidators.password(new FormControl('Customer@12345'))).toBeNull();
    expect(HurricaneValidators.password(new FormControl('weak'))).not.toBeNull();
  });

  it('compares two fields', () => {
    const form = new FormGroup({ first: new FormControl('same'), second: new FormControl('same') }, { validators: HurricaneValidators.fieldsMatch('first', 'second') });
    expect(form.errors).toBeNull();
    form.controls.second.setValue('different');
    expect(form.errors?.['fieldsMismatch']).toBeTruthy();
  });
});

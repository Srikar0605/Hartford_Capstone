
import type { ValidationErrors } from '@angular/forms';

export function validationMessage(errors: ValidationErrors | null | undefined): string | null {
  if (!errors) return null;
  if (errors['required']) return 'This field is required.';
  if (errors['email']) return 'Enter a valid email address.';
  if (errors['minlength']) return `Enter at least ${errors['minlength'].requiredLength} characters.`;
  if (errors['maxlength']) return `Enter no more than ${errors['maxlength'].requiredLength} characters.`;
  if (errors['min']) return `Enter a value of at least ${errors['min'].min}.`;
  if (errors['max']) return `Enter a value no greater than ${errors['max'].max}.`;
  if (errors['guid']) return 'Enter a valid identifier.';
  if (errors['positiveNumber']) return 'Enter a number greater than zero.';
  if (errors['nonNegativeNumber']) return 'Enter zero or a positive number.';
  if (errors['futureDate']) return 'The date cannot be in the future.';
  if (errors['fieldsMismatch']) return 'The entered values do not match.';
  if (errors['maximumFileSize']) return 'The selected file exceeds the allowed size.';
  if (errors['password']) return 'Use at least 12 characters with uppercase, lowercase, number, and special characters.';
  return 'Check this value.';
}

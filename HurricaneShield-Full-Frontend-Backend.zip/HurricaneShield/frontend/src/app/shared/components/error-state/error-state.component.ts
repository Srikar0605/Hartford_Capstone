
import { ChangeDetectionStrategy, Component, input, output } from '@angular/core';

import { IconComponent } from '../icon/icon.component';

@Component({
  selector: 'app-error-state',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [IconComponent],
  templateUrl:
  './error-state.component.html',
})
export class ErrorStateComponent {
  readonly title = input('Unable to load this information');
  readonly message = input.required<string>();
  readonly correlationId = input<string | null>(null);
  readonly retryable = input(true);
  readonly retry = output<void>();
}

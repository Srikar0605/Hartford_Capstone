import { A11yModule } from '@angular/cdk/a11y';
import {
  ChangeDetectionStrategy,
  Component,
  computed,
  ElementRef,
  inject,
  Injectable,
  input,
  signal,
  viewChild,
} from '@angular/core';
import { Router } from '@angular/router';

import { AuthStore } from '../../../core/auth/auth.store';
import { SYSTEM_PERMISSIONS } from '../../../core/constants/permissions';
import { SYSTEM_ROLES } from '../../../core/constants/roles';
import type { NavigationItem } from '../../../layout/navigation.config';
import { IconComponent, type IconName } from '../icon/icon.component';

/** Shared open/close state so the topbar search button and the keyboard shortcut drive one palette. */
@Injectable({ providedIn: 'root' })
export class CommandPaletteService {
  readonly isOpen = signal(false);
  open(): void {
    this.isOpen.set(true);
  }
  close(): void {
    this.isOpen.set(false);
  }
  toggle(): void {
    this.isOpen.update((value) => !value);
  }
}

interface PaletteCommand {
  id: string;
  group: 'Go to' | 'Actions';
  label: string;
  hint: string;
  route: string;
  icon: IconName;
  keywords: string;
}

export const NAVIGATION_ICON_MAP: Readonly<Record<NavigationItem['icon'], IconName>> = {
  dashboard: 'dashboard',
  profile: 'user',
  policies: 'shield',
  claims: 'file-check',
  payments: 'card',
  customers: 'users',
  underwriting: 'shield-check',
  settlements: 'banknote',
  plans: 'list',
  roles: 'key',
};

/**
 * Ctrl/⌘ + K command palette for the authenticated workspace.
 * Lists every page the current role can open plus a few role-aware shortcuts,
 * with type-to-filter and full keyboard navigation (↑ ↓ Enter Esc).
 */
@Component({
  selector: 'app-command-palette',
  imports: [A11yModule, IconComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  host: { '(document:keydown)': 'onDocumentKeydown($event)' },
  templateUrl: './command-palette.component.html',
})
export class CommandPaletteComponent {
  private readonly router = inject(Router);
  private readonly authStore = inject(AuthStore);
  readonly palette = inject(CommandPaletteService);

  readonly items = input.required<readonly NavigationItem[]>();
  readonly query = signal('');
  readonly activeIndex = signal(0);
  private readonly list = viewChild<ElementRef<HTMLElement>>('list');

  private readonly actions = computed<PaletteCommand[]>(() => {
    const commands: PaletteCommand[] = [];
    if (this.authStore.hasRole(SYSTEM_ROLES.customer)) {
      commands.push(
        { id: 'a-quote', group: 'Actions', label: 'Get a quote', hint: 'Estimate a premium for a property', route: '/policies/apply', icon: 'sparkles', keywords: 'quote apply premium estimate new policy' },
        { id: 'a-claim', group: 'Actions', label: 'Submit a claim', hint: 'Report storm damage', route: '/claims/submit', icon: 'file', keywords: 'claim report damage loss' },
        { id: 'a-property', group: 'Actions', label: 'Add a property', hint: 'Profile › Properties', route: '/profile/properties', icon: 'house', keywords: 'property home address add' },
      );
    }
    if (this.authStore.hasPermission(SYSTEM_PERMISSIONS.managePlans)) {
      commands.push({ id: 'a-plan', group: 'Actions', label: 'Create a plan', hint: 'Plans › New', route: '/admin/plans/create', icon: 'plus', keywords: 'plan product create new' });
    }
    commands.push(
      { id: 'a-security', group: 'Actions', label: 'Account security', hint: 'MFA and password', route: '/profile/security', icon: 'lock', keywords: 'mfa security password two factor' },
      { id: 'a-activity', group: 'Actions', label: 'Login activity', hint: 'Recent sign-ins', route: '/profile/login-activity', icon: 'history', keywords: 'login activity sign in history' },
    );
    return commands;
  });

  private readonly navigation = computed<PaletteCommand[]>(() =>
    this.items().map((item) => ({
      id: `n-${item.route}`,
      group: 'Go to' as const,
      label: item.label,
      hint: item.route,
      route: item.route,
      icon: NAVIGATION_ICON_MAP[item.icon],
      keywords: item.label.toLowerCase(),
    })),
  );

  readonly results = computed(() => {
    const terms = this.query().trim().toLowerCase().split(/\s+/).filter(Boolean);
    const all = [...this.navigation(), ...this.actions()];
    if (!terms.length) return all;
    return all.filter((command) => {
      const haystack = `${command.label} ${command.keywords} ${command.hint}`.toLowerCase();
      return terms.every((term) => haystack.includes(term));
    });
  });

  readonly groups = computed(() => {
    const results = this.results();
    return (['Go to', 'Actions'] as const)
      .map((name) => ({
        name,
        commands: results
          .map((command, index) => ({ command, index }))
          .filter((entry) => entry.command.group === name),
      }))
      .filter((group) => group.commands.length > 0);
  });

  onDocumentKeydown(event: KeyboardEvent): void {
    const target = event.target as HTMLElement | null;
    const typing = !!target && (target.isContentEditable || ['INPUT', 'TEXTAREA', 'SELECT'].includes(target.tagName));
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') {
      event.preventDefault();
      this.toggle();
      return;
    }
    if (event.key === '/' && !typing && !this.palette.isOpen()) {
      event.preventDefault();
      this.toggle();
    }
  }

  toggle(): void {
    if (this.palette.isOpen()) {
      this.close();
    } else {
      this.query.set('');
      this.activeIndex.set(0);
      this.palette.open();
    }
  }

  close(): void {
    this.palette.close();
  }

  onQuery(value: string): void {
    this.query.set(value);
    this.activeIndex.set(0);
  }

  onInputKeydown(event: KeyboardEvent): void {
    const count = this.results().length;
    if (event.key === 'ArrowDown') {
      event.preventDefault();
      this.activeIndex.update((index) => (count ? (index + 1) % count : 0));
      this.scrollActiveIntoView();
    } else if (event.key === 'ArrowUp') {
      event.preventDefault();
      this.activeIndex.update((index) => (count ? (index - 1 + count) % count : 0));
      this.scrollActiveIntoView();
    } else if (event.key === 'Enter') {
      event.preventDefault();
      const command = this.results()[this.activeIndex()];
      if (command) this.run(command);
    } else if (event.key === 'Escape') {
      event.preventDefault();
      this.close();
    }
  }

  run(command: PaletteCommand): void {
    this.close();
    void this.router.navigateByUrl(command.route);
  }

  private scrollActiveIntoView(): void {
    queueMicrotask(() =>
      this.list()?.nativeElement.querySelector('[data-active="true"]')?.scrollIntoView({ block: 'nearest' }),
    );
  }
}

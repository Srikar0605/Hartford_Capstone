import { ChangeDetectionStrategy, Component, input } from '@angular/core';

import { IconComponent } from '../icon/icon.component';

/**
 * Decorative, tilted "product window" used on the public landing pages (Control Room direction).
 * It is an illustration of the HurricaneShield workspace with example values only — no API calls,
 * hidden from assistive technology.
 */
@Component({
  selector: 'app-product-preview',
  imports: [IconComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  host: { 'aria-hidden': 'true', class: 'block' },
  template: `
    <div class="cr-stage">
      <div class="cr-window cr-window-enter flex h-[25rem] overflow-hidden text-left sm:h-[29rem]">
        <!-- Sidebar -->
        <div class="hidden w-52 shrink-0 flex-col gap-1 border-r border-brand-950/6 bg-[#fbf8f6] p-4 text-[0.8rem] font-semibold text-slate-500 md:flex">
          <div class="mb-4 flex gap-1.5">
            <span class="size-2.5 rounded-full bg-[#e5d7d3]"></span><span class="size-2.5 rounded-full bg-[#e5d7d3]"></span><span class="size-2.5 rounded-full bg-[#e5d7d3]"></span>
          </div>
          @for (item of nav; track item.label; let first = $first) {
            <span class="flex items-center gap-2 rounded-lg px-2.5 py-2" [class]="first ? 'bg-brand-900 text-white' : ''">
              <app-icon [name]="item.icon" class="size-3.5" /> {{ item.label }}
            </span>
          }
          <span class="cr-mono mt-auto !normal-case !tracking-normal text-slate-400">⌘K · jump anywhere</span>
        </div>

        <!-- Content -->
        <div class="grid min-w-0 flex-1 content-start gap-3.5 p-4 sm:grid-cols-3 sm:p-6">
          @if (variant() === 'quote') {
            @for (tier of tiers; track tier.name; let i = $index) {
              <div class="rounded-xl border p-4" [class]="i === 1 ? 'border-brand-800 ring-2 ring-brand-800/15' : 'border-brand-950/8'">
                <p class="cr-mono text-slate-400">{{ tier.label }}</p>
                <p class="mt-1 font-extrabold tracking-tight text-brand-950">{{ tier.name }}</p>
                <p class="mt-3 text-2xl font-extrabold tracking-tight text-brand-950">{{ tier.price }}</p>
                <p class="text-[0.7rem] text-slate-500">per year · example</p>
                <span class="mt-4 block rounded-lg py-1.5 text-center text-[0.7rem] font-bold" [class]="i === 1 ? 'bg-brand-900 text-white' : 'bg-slate-100 text-slate-700'">{{ i === 1 ? 'Selected' : 'Choose' }}</span>
              </div>
            }
            <div class="rounded-xl border border-brand-950/8 p-4 sm:col-span-3">
              <p class="cr-mono text-slate-400">Risk factors</p>
              <div class="mt-3 grid gap-2.5 sm:grid-cols-2">
                @for (f of factors; track f.name) {
                  <div>
                    <div class="flex justify-between text-[0.72rem] font-semibold text-slate-600"><span>{{ f.name }}</span><span>{{ f.value }}</span></div>
                    <div class="mt-1 h-1.5 rounded-full bg-slate-100"><div class="h-full rounded-full" [class]="f.up ? 'bg-brand-800' : 'bg-emerald-600'" [style.width.%]="f.width"></div></div>
                  </div>
                }
              </div>
            </div>
          } @else {
            <div class="relative overflow-hidden rounded-xl bg-brand-900 p-5 text-white sm:col-span-2">
              <p class="font-mono text-[0.68rem] text-brand-200">HS-POL-20418 · ACTIVE</p>
              <p class="mt-1.5 text-2xl font-extrabold tracking-tight">Coastal Plus</p>
              <div class="mt-4 flex gap-6 text-[0.75rem] text-brand-200">
                <span>Term <b class="text-white">62%</b></span><span>Risk <b class="text-white">Medium</b></span><span>Version <b class="text-white">v3</b></span>
              </div>
              <div class="mt-3 h-1 rounded-full bg-white/15"><div class="h-full w-[62%] rounded-full bg-white"></div></div>
            </div>
            <div class="rounded-xl border border-brand-950/8 p-4">
              <p class="cr-mono text-slate-400">Readiness</p>
              <p class="mt-1 text-3xl font-extrabold tracking-tight text-brand-950">4 / 6</p>
              <div class="mt-3 grid grid-cols-6 gap-1">
                @for (n of [0, 1, 2, 3, 4, 5]; track n) {
                  <span class="h-1.5 rounded-full" [class]="n < 4 ? 'bg-brand-800' : 'bg-[#efe4e1]'"></span>
                }
              </div>
            </div>
            <div class="overflow-hidden rounded-xl border border-brand-950/8 sm:col-span-3">
              <div class="grid grid-cols-[1fr_1.3fr_1fr] bg-[#fbf8f6] px-4 py-2 font-mono text-[0.65rem] text-slate-400 sm:grid-cols-[1fr_1.3fr_1fr_1fr]">
                <span>CLAIM</span><span>COVERAGE</span><span class="hidden sm:block">INCIDENT</span><span>STATUS</span>
              </div>
              @for (row of claims; track row.id; let first = $first) {
                <div class="relative grid grid-cols-[1fr_1.3fr_1fr] items-center border-t border-brand-950/5 px-4 py-2.5 text-[0.78rem] sm:grid-cols-[1fr_1.3fr_1fr_1fr]">
                  @if (first) { <span class="cr-scan pointer-events-none absolute inset-0"></span> }
                  <span class="font-mono text-brand-950">{{ row.id }}</span>
                  <span class="truncate text-slate-700">{{ row.coverage }}</span>
                  <span class="hidden text-slate-500 sm:block">{{ row.date }}</span>
                  <span class="w-fit rounded-full px-2 py-0.5 text-[0.68rem] font-bold" [class]="row.tone">{{ row.status }}</span>
                </div>
              }
            </div>
            @for (stat of stats; track stat.label) {
              <div class="rounded-xl border border-brand-950/8 p-4">
                <p class="cr-mono flex items-center gap-1.5 text-slate-400"><app-icon [name]="stat.icon" class="size-3.5" /> {{ stat.label }}</p>
                <p class="mt-2 text-lg font-extrabold tracking-tight text-brand-950">{{ stat.value }}</p>
              </div>
            }
          }
        </div>
      </div>
    </div>
  `,
})
export class ProductPreviewComponent {
  readonly variant = input<'workspace' | 'quote'>('workspace');

  readonly nav = [
    { label: 'Dashboard', icon: 'dashboard' as const },
    { label: 'My Policies', icon: 'shield' as const },
    { label: 'My Claims', icon: 'file' as const },
    { label: 'Payments', icon: 'card' as const },
    { label: 'Properties', icon: 'house' as const },
  ];
  readonly claims = [
    { id: 'CLM-8812', coverage: 'Wind & Cyclone', date: '19 Oct', status: 'Under review', tone: 'bg-violet-50 text-violet-800' },
    { id: 'CLM-8790', coverage: 'Storm Surge', date: '30 Sep', status: 'Approved', tone: 'bg-emerald-50 text-emerald-800' },
    { id: 'CLM-8751', coverage: 'Temporary Living', date: '02 Sep', status: 'Closed', tone: 'bg-slate-100 text-slate-700' },
  ];
  readonly stats = [
    { label: 'Next premium', value: '14 Mar 2027', icon: 'calendar' as const },
    { label: 'Properties', value: '2 saved', icon: 'house' as const },
    { label: 'Documents', value: '3 verified', icon: 'file-check' as const },
  ];
  readonly tiers = [
    { label: 'Basic', name: 'Essential', price: '₹13,850' },
    { label: 'Standard', name: 'Plus', price: '₹19,900' },
    { label: 'Comprehensive', name: 'Complete', price: '₹28,350' },
  ];
  readonly factors = [
    { name: 'Risk zone', value: '+18', width: 72, up: true },
    { name: 'Property age', value: '+9', width: 40, up: true },
    { name: 'Construction', value: '−6', width: 28, up: false },
    { name: 'Mitigations', value: '−9', width: 40, up: false },
  ];
}


import { ChangeDetectionStrategy, Component, input } from '@angular/core';

export interface TimelineItem {
  title: string;
  description?: string | null;
  occurredAt: string;
  actor?: string | null;
}

@Component({
  selector: 'app-timeline',
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './timeline.component.html',
})
export class TimelineComponent {
  readonly items = input.required<readonly TimelineItem[]>();
}

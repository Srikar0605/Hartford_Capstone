
import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, Input } from '@angular/core';

@Component({
  selector: 'app-kpi-card',
  standalone: true,
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="hs-card relative flex h-full flex-col gap-2 overflow-hidden px-5 pb-4 pt-5 sm:px-6">
      <dt>
        <p class="truncate text-[0.8rem] font-bold text-slate-500">{{ title }}</p>
      </dt>
      <dd class="flex flex-1 flex-col gap-3">
        <div class="flex flex-wrap items-baseline gap-2">
          <p class="text-[1.75rem] font-extrabold leading-tight tracking-tight text-brand-950 tabular-nums">{{ value }}</p>
          @if (variance) {
            <p
              [ngClass]="{
                'bg-emerald-50 text-emerald-800': isGoodTrend === true,
                'bg-orange-50 text-orange-800': isGoodTrend === false,
                'bg-slate-100 text-slate-600': isGoodTrend === null
              }"
              class="inline-flex items-baseline rounded-full px-2 py-0.5 text-xs font-bold"
            >
              {{ variance }}
            </p>
          }
        </div>
        <div class="mt-auto border-t border-dashed border-slate-200 pt-3">
          <div class="text-xs">
            <span class="font-bold text-brand-700">{{ footerText }}</span>
          </div>
        </div>
      </dd>
    </div>
  `,
})
export class KpiCardComponent {
  @Input({ required: true }) title!: string;
  @Input({ required: true }) value!: string | number | null;
  @Input() variance?: string;
  @Input() isGoodTrend: boolean | null = null;
  @Input() footerText: string = 'View details';
}

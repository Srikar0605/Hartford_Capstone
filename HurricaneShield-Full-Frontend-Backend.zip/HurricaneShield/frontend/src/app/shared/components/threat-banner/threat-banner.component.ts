import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, Input, signal } from '@angular/core';

import { IconComponent } from '../icon/icon.component';

@Component({
  selector: 'app-threat-banner',
  standalone: true,
  imports: [CommonModule, IconComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (isActive) {
      <div class="relative overflow-hidden bg-brand-900 px-4 py-2.5 text-white sm:px-6 lg:px-8" role="alert">
        <div class="pointer-events-none absolute inset-0 bg-[radial-gradient(60%_140%_at_100%_0%,rgba(194,122,115,0.35),transparent_60%)]" aria-hidden="true"></div>
        <div class="pointer-events-none absolute -left-10 top-1/2 size-40 -translate-y-1/2 rounded-full border border-white/10 animate-ping [animation-duration:3s]" aria-hidden="true"></div>
        <div class="relative mx-auto flex max-w-7xl flex-wrap items-center justify-center gap-x-3 gap-y-1 text-center">
          <span class="inline-flex items-center gap-1.5 rounded-full bg-amber-300 px-2.5 py-0.5 text-[0.7rem] font-extrabold uppercase tracking-wider text-amber-950">
            <app-icon name="warning" class="size-3.5" />
            {{ severity }}
          </span>
          <app-icon name="storm" class="hidden size-4 text-brand-200 sm:inline-grid" />
          <p class="text-sm font-medium leading-6">
            <strong class="font-bold">{{ title }}</strong>
            <span class="text-brand-200"> · {{ source }}</span>
            <span class="text-brand-100"> — {{ message }}</span>
          </p>
        </div>
      </div>
    } @else if (!dismissed()) {
      @if (isFeedUnavailable) {
        <div class="border-b border-slate-200 bg-slate-100 px-4 py-1.5 text-slate-700 sm:px-6 lg:px-8" role="status">
          <div class="mx-auto flex max-w-7xl items-center justify-center gap-2 text-center">
            <app-icon name="wind" class="size-4 text-slate-400" />
            <p class="text-xs font-semibold leading-6 sm:text-sm">Storm feed unavailable — {{ message }}</p>
            <button type="button" class="ml-1 grid size-6 place-items-center rounded-full text-slate-500 hover:bg-slate-200" aria-label="Hide storm status" (click)="dismissed.set(true)">
              <app-icon name="x" class="size-3.5" />
            </button>
          </div>
        </div>
      } @else {
        <div class="border-b border-emerald-900/10 bg-emerald-50 px-4 py-1.5 text-emerald-900 sm:px-6 lg:px-8" role="status">
          <div class="mx-auto flex max-w-7xl items-center justify-center gap-2 text-center">
            <span class="relative flex size-2" aria-hidden="true">
              <span class="absolute inline-flex size-full animate-ping rounded-full bg-emerald-500 opacity-50"></span>
              <span class="relative inline-flex size-2 rounded-full bg-emerald-600"></span>
            </span>
            <p class="text-xs font-semibold leading-6 sm:text-sm">{{ title }}: <span class="font-medium">{{ message }}</span></p>
            <button type="button" class="ml-1 grid size-6 place-items-center rounded-full text-emerald-700 hover:bg-emerald-100" aria-label="Hide storm status" (click)="dismissed.set(true)">
              <app-icon name="x" class="size-3.5" />
            </button>
          </div>
        </div>
      }
    }
  `,
})
export class ThreatBannerComponent {
  @Input({ required: true }) isActive!: boolean;
  @Input({ required: true }) title!: string;
  @Input({ required: true }) message!: string;
  @Input({ required: true }) source!: string;
  @Input({ required: true }) severity!: string;

  /** Calm states can be hidden for the session; active storm warnings always stay visible. */
  readonly dismissed = signal(false);

  /** ThreatService returns source 'SYSTEM' when the live feed could not be reached. */
  get isFeedUnavailable(): boolean {
    return this.source === 'SYSTEM';
  }
}

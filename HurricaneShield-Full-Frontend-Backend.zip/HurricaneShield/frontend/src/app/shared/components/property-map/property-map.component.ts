import {
  afterNextRender,
  ChangeDetectionStrategy,
  Component,
  effect,
  ElementRef,
  input,
  OnDestroy,
  output,
  signal,
  viewChild,
} from '@angular/core';

export interface PropertyMapPoint {
  id: string;
  latitude: number;
  longitude: number;
  title: string;
  subtitle?: string;
}

type LeafletModule = typeof import('leaflet');

/**
 * OpenStreetMap view of the customer's saved properties (Leaflet, loaded lazily so it
 * never touches the initial bundle). Purely presentational: it only reads coordinates
 * that the Profile API already returns.
 */
@Component({
  selector: 'app-property-map',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="relative overflow-hidden rounded-[1.25rem] border border-brand-950/6 bg-[#efe9e1] shadow-[var(--shadow-soft)]">
      <div #mapHost class="h-72 w-full sm:h-80" role="region" aria-label="Map of your properties"></div>
      @if (!ready()) {
        <div class="absolute inset-0 grid place-items-center text-sm font-medium text-slate-500" aria-hidden="true">
          <span class="h-full w-full animate-pulse bg-[#e9e1d7]"></span>
        </div>
      }
    </div>
  `,
})
export class PropertyMapComponent implements OnDestroy {
  readonly points = input.required<PropertyMapPoint[]>();
  readonly selectedId = input<string | null>(null);
  readonly pointSelected = output<string>();

  readonly ready = signal(false);
  private readonly mapHost = viewChild.required<ElementRef<HTMLElement>>('mapHost');
  private leaflet: LeafletModule | null = null;
  private map: import('leaflet').Map | null = null;
  private layer: import('leaflet').LayerGroup | null = null;

  constructor() {
    afterNextRender(async () => {
      const L = (await import('leaflet')).default ?? (await import('leaflet'));
      this.leaflet = L as LeafletModule;
      this.map = L.map(this.mapHost().nativeElement, {
        zoomControl: true,
        scrollWheelZoom: false,
        attributionControl: true,
      }).setView([20.5, 79], 4);
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 18,
        attribution: '&copy; OpenStreetMap contributors',
      }).addTo(this.map);
      this.layer = L.layerGroup().addTo(this.map);
      this.ready.set(true);
      this.render();
    });

    effect(() => {
      this.points();
      this.selectedId();
      if (this.ready()) this.render();
    });
  }

  private render(): void {
    const L = this.leaflet;
    if (!L || !this.map || !this.layer) return;
    this.layer.clearLayers();
    const points = this.points();
    if (points.length === 0) return;

    const bounds: [number, number][] = [];
    points.forEach((point, index) => {
      const selected = point.id === this.selectedId();
      const icon = L.divIcon({
        className: '',
        html: `<div class="hs-map-pin${selected ? ' hs-map-pin-primary' : ''}"><span>${index + 1}</span></div>`,
        iconSize: [34, 34],
        iconAnchor: [17, 34],
        popupAnchor: [0, -30],
      });
      const marker = L.marker([point.latitude, point.longitude], { icon, title: point.title, keyboard: true })
        .bindPopup(`<strong>${this.escape(point.title)}</strong>${point.subtitle ? `<br><span style="color:#64748b">${this.escape(point.subtitle)}</span>` : ''}`)
        .on('click', () => this.pointSelected.emit(point.id));
      marker.addTo(this.layer!);
      if (selected) marker.openPopup();
      bounds.push([point.latitude, point.longitude]);
    });

    if (bounds.length === 1) this.map.setView(bounds[0], 11, { animate: true });
    else this.map.fitBounds(bounds, { padding: [48, 48], maxZoom: 11, animate: true });
  }

  private escape(value: string): string {
    return value.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]!);
  }

  ngOnDestroy(): void {
    this.map?.remove();
    this.map = null;
  }
}


import { A11yModule } from '@angular/cdk/a11y';
import { ChangeDetectionStrategy, Component, input, output } from '@angular/core';

import { IconComponent } from '../icon/icon.component';

export type ConfirmationTone = 'primary' | 'danger';

@Component({
  selector: 'app-confirmation-dialog',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [A11yModule, IconComponent],
  templateUrl: './confirmation-dialog.component.html',
})
export class ConfirmationDialogComponent {
  readonly open = input(false);
  readonly title = input.required<string>();
  readonly message = input.required<string>();
  readonly confirmText = input('Confirm');
  readonly cancelText = input('Cancel');
  readonly busyText = input('Working…');
  readonly busy = input(false);
  readonly tone = input<ConfirmationTone>('primary');
  readonly confirmed = output<void>();
  readonly cancelled = output<void>();
  readonly dialogId = `confirmation-${crypto.randomUUID()}`;

  get confirmClasses(): string {
    const colour =
      this.tone() === 'danger' ? 'bg-red-700 hover:bg-red-800' : 'bg-brand-900 hover:bg-brand-800';
    return `hs-btn text-white disabled:cursor-wait disabled:opacity-60 ${colour}`;
  }
}

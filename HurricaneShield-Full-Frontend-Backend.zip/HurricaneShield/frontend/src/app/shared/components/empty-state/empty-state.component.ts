
import { ChangeDetectionStrategy, Component, computed, input } from '@angular/core';

import { HS_ICONS, IconComponent, type IconName } from '../icon/icon.component';

@Component({
  selector: 'app-empty-state',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [IconComponent],
  templateUrl: './empty-state.component.html'
})
export class EmptyStateComponent {
  readonly title = input.required<string>();
  readonly message = input.required<string>();
  /** Lucide icon name (e.g. 'house') or any short glyph. */
  readonly icon = input<string>('sparkles');
  readonly iconName = computed<IconName | null>(() =>
    this.icon() in HS_ICONS ? (this.icon() as IconName) : null,
  );
}

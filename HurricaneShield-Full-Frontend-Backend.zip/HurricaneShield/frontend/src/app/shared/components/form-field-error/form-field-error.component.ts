
import { Component, input } from '@angular/core';
import type { AbstractControl, ValidationErrors } from '@angular/forms';

@Component({
  selector: 'app-form-field-error',

  standalone: true,

  templateUrl: './form-field-error.component.html',
})
export class FormFieldErrorComponent {
  readonly control = input.required<AbstractControl>();

  readonly label = input.required<string>();

  readonly customMessages = input<Readonly<Record<string, string>>>({});

  readonly id = input<string | undefined>();

  isVisible(): boolean {
    const control = this.control();

    return control.invalid && (control.touched || control.dirty);
  }

  message(): string | null {
    const errors = this.control().errors;

    if (!errors) {
      return null;
    }

    return this.resolveMessage(errors);
  }

  private resolveMessage(errors: ValidationErrors): string {
    const customMessages = this.customMessages();

    for (const errorKey of Object.keys(errors)) {
      const customMessage = customMessages[errorKey];

      if (customMessage) {
        return customMessage;
      }

      const defaultMessage = this.defaultMessage(errorKey, errors[errorKey]);

      if (defaultMessage) {
        return defaultMessage;
      }
    }

    return `Review the ${this.label().toLowerCase()} value.`;
  }

  private defaultMessage(errorKey: string, errorValue: unknown): string | null {
    const label = this.label();

    switch (errorKey) {
      case 'required':
        return `${label} is required.`;

      case 'requiredTrue':
        return `${label} must be selected.`;

      case 'email':
        return 'Enter a valid email address.';

      case 'minlength': {
        const details = errorValue as {
          requiredLength: number;
        };

        return `${label} must contain at least ${details.requiredLength} characters.`;
      }

      case 'maxlength': {
        const details = errorValue as {
          requiredLength: number;
        };

        return `${label} cannot exceed ${details.requiredLength} characters.`;
      }

      case 'min': {
        const details = errorValue as {
          min: number;
        };

        return `${label} must be at least ${details.min}.`;
      }

      case 'max': {
        const details = errorValue as {
          max: number;
        };

        return `${label} cannot exceed ${details.max}.`;
      }

      case 'pattern':
        return `${label} is not in the expected format.`;

      case 'guid':
        return `${label} must be a valid identifier.`;

      case 'positiveNumber':
        return `${label} must be greater than zero.`;

      case 'nonNegativeNumber':
        return `${label} cannot be negative.`;

      case 'password':
        return 'The password does not meet the required format.';

      case 'isoDateNotInFuture':
        return `${label} cannot be in the future.`;

      case 'maximumFileSize':
        return 'The selected file cannot exceed 10 MB.';

      default:
        return null;
    }
  }
}

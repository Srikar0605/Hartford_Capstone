
import { Component } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { By } from '@angular/platform-browser';

import { FormFieldErrorComponent } from './form-field-error.component';

@Component({
  standalone: true,
  imports: [ReactiveFormsModule, FormFieldErrorComponent],
  template: `
    <form [formGroup]="form">
      <input formControlName="email" />
      <app-form-field-error [control]="form.controls.email" label="Email address" />
    </form>
  `,
})
class HostComponent {
  readonly form = new FormGroup({
    email: new FormControl('', { nonNullable: true, validators: [Validators.required, Validators.email] }),
  });
}

describe('FormFieldErrorComponent', () => {
  let fixture: ComponentFixture<HostComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({ imports: [HostComponent] }).compileComponents();
    fixture = TestBed.createComponent(HostComponent);
    fixture.detectChanges();
  });

  it('does not show an error for an untouched invalid control', () => {
    expect(fixture.debugElement.query(By.css('[role="alert"]'))).toBeNull();
  });

  it('shows the centralized required message for a touched control', () => {
    fixture.componentInstance.form.controls.email.markAsTouched();
    fixture.detectChanges();
    expect(fixture.nativeElement.textContent).toContain('Email address is required.');
  });

  it('hides the error after the value becomes valid', () => {
    const control = fixture.componentInstance.form.controls.email;
    control.markAsTouched();
    control.setValue('customer@example.test');
    fixture.detectChanges();
    expect(fixture.debugElement.query(By.css('[role="alert"]'))).toBeNull();
  });
});

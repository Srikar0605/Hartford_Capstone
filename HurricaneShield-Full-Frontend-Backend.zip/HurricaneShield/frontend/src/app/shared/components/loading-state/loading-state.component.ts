
import { ChangeDetectionStrategy, Component, input } from '@angular/core';

@Component({
  selector: 'app-loading-state',
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl:
  './loading-state.component.html',
})
export class LoadingStateComponent {
  readonly rows = input(3);
  readonly label = input('Loading content');
  rowsArray(): readonly number[] { return Array.from({ length: this.rows() }, (_, index) => index); }
}

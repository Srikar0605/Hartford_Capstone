
import { ChangeDetectionStrategy, Component, input } from '@angular/core';

import { IconComponent } from '../icon/icon.component';

export interface StepperItem { label: string; description?: string; }

@Component({
  selector: 'app-stepper',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [IconComponent],
  templateUrl:
  './stepper.component.html',
})
export class StepperComponent {
  readonly steps = input.required<readonly StepperItem[]>();
  readonly currentIndex = input(0);
}

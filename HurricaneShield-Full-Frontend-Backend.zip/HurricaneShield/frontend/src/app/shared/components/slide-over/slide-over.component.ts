import { A11yModule } from '@angular/cdk/a11y';
import { ChangeDetectionStrategy, Component, input, output } from '@angular/core';

import { IconComponent } from '../icon/icon.component';

/**
 * Right-hand slide-over panel for quick views (Linear/Stripe style).
 * Focus is trapped while open, Esc or the backdrop closes it, and it animates in and out.
 */
@Component({
  selector: 'app-slide-over',
  imports: [A11yModule, IconComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  host: { '(document:keydown.escape)': 'onEscape()' },
  template: `
    @if (open()) {
      <div class="fixed inset-0 z-[85]">
        <button
          type="button"
          class="hs-backdrop block w-full cursor-default"
          tabindex="-1"
          aria-label="Close panel"
          animate.enter="hs-enter-fade"
          animate.leave="hs-leave-fade"
          (click)="closed.emit()"
        ></button>
        <aside
          class="absolute inset-y-0 right-0 flex w-full max-w-lg flex-col bg-white shadow-[var(--shadow-pop)] sm:inset-y-3 sm:right-3 sm:rounded-3xl"
          role="dialog"
          aria-modal="true"
          [attr.aria-label]="title()"
          cdkTrapFocus
          cdkTrapFocusAutoCapture
          animate.enter="hs-enter-right"
          animate.leave="hs-leave-right"
        >
          <header class="flex items-start justify-between gap-4 border-b border-slate-100 px-6 py-5">
            <div class="min-w-0">
              @if (eyebrow()) {
                <p class="hs-eyebrow">{{ eyebrow() }}</p>
              }
              <h2 class="mt-1 truncate text-xl font-extrabold text-brand-950">{{ title() }}</h2>
              @if (subtitle()) {
                <p class="mt-1 truncate text-sm text-slate-500">{{ subtitle() }}</p>
              }
            </div>
            <button
              type="button"
              class="grid size-10 shrink-0 place-items-center rounded-full border border-slate-200 text-slate-500 hover:border-brand-200 hover:bg-brand-50 hover:text-brand-900"
              aria-label="Close panel"
              (click)="closed.emit()"
            >
              <app-icon name="x" class="size-4" />
            </button>
          </header>
          <div class="flex-1 overflow-y-auto px-6 py-5">
            <ng-content />
          </div>
          <footer class="border-t border-slate-100 bg-[#fbf8f6] px-6 py-4 sm:rounded-b-3xl">
            <ng-content select="[slideOverFooter]" />
          </footer>
        </aside>
      </div>
    }
  `,
})
export class SlideOverComponent {
  readonly open = input(false);
  readonly title = input.required<string>();
  readonly subtitle = input<string>();
  readonly eyebrow = input<string>();
  readonly closed = output<void>();

  onEscape(): void {
    if (this.open()) this.closed.emit();
  }
}

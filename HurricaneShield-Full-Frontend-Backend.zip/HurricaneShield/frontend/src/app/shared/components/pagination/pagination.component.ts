
import { ChangeDetectionStrategy, Component, computed, input, output } from '@angular/core';

import { IconComponent } from '../icon/icon.component';

@Component({
  selector: 'app-pagination',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [IconComponent],
  templateUrl:
  './pagination.component.html',
  styles: [`
    .pagination-button { display: inline-flex; align-items: center; justify-content: center; gap: .3rem; border: 1px solid #dacbc5; border-radius: 999px; min-width: 2.5rem; min-height: 2.5rem; padding: .45rem .85rem; background: white; color: #2a0a0d; font-size: .82rem; font-weight: 700; transition: background-color .15s ease, border-color .15s ease; }
    .pagination-button:hover:not(:disabled) { background: #fbf3f2; border-color: #dba7a1; }
    .pagination-button:disabled { cursor: not-allowed; opacity: .45; }
    .pagination-current, .pagination-current:hover:not(:disabled) { border-color: #400106; background: #400106; color: white; }
  `],
})
export class PaginationComponent {
  readonly page = input.required<number>();
  readonly totalPages = input.required<number>();
  readonly totalCount = input.required<number>();
  readonly pageChange = output<number>();

  readonly visiblePages = computed(() => {
    const start = Math.max(1, Math.min(this.page() - 2, this.totalPages() - 4));
    const end = Math.min(this.totalPages(), start + 4);
    return Array.from({ length: end - start + 1 }, (_, index) => start + index);
  });
}

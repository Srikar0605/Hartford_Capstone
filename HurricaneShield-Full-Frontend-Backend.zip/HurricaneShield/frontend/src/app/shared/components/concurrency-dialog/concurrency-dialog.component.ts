
import { A11yModule } from '@angular/cdk/a11y';
import { ChangeDetectionStrategy, Component, input, output } from '@angular/core';

import { IconComponent } from '../icon/icon.component';

@Component({
  selector: 'app-concurrency-dialog',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [A11yModule, IconComponent],
  templateUrl: './concurrency-dialog.component.html',
})
export class ConcurrencyDialogComponent {
  readonly open = input(false);
  readonly correlationId = input<string | null>(null);
  readonly reloadRequested = output<void>();
  readonly closed = output<void>();
}


import { ChangeDetectionStrategy, Component, input, output } from '@angular/core';

import { IconComponent } from '../icon/icon.component';

@Component({
  selector: 'app-file-upload',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [IconComponent],
  templateUrl:
  './file-upload.component.html',
})
export class FileUploadComponent {
  readonly accept = input('.pdf,.png,.jpg,.jpeg');
  readonly maxBytes = input(10 * 1024 * 1024);
  readonly helperText = input('PDF, PNG, or JPG up to 10 MB');
  readonly disabled = input(false);
  readonly fileSelected = output<File>();
  readonly cleared = output<void>();
  readonly invalidFile = output<string>();
  selectedFile: File | null = null;
  dragActive = false;

  onDragOver(event: DragEvent): void { event.preventDefault(); if (!this.disabled()) this.dragActive = true; }
  onDrop(event: DragEvent): void { event.preventDefault(); this.dragActive = false; const file = event.dataTransfer?.files.item(0); if (file) this.acceptFile(file); }
  onSelection(event: Event): void { const file = (event.target as HTMLInputElement).files?.item(0); if (file) this.acceptFile(file); }
  clear(): void { this.selectedFile = null; this.cleared.emit(); }
  formatSize(bytes: number): string { return bytes < 1024 * 1024 ? `${Math.ceil(bytes / 1024)} KB` : `${(bytes / 1024 / 1024).toFixed(1)} MB`; }

  private acceptFile(file: File): void {
    if (this.disabled()) return;
    if (file.size > this.maxBytes()) { this.invalidFile.emit('The selected file is larger than the allowed limit.'); return; }
    this.selectedFile = file;
    this.fileSelected.emit(file);
  }
}

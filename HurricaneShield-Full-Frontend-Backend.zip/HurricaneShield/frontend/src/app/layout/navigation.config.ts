
import type { SystemPermission } from '../core/constants/permissions';
import { SYSTEM_PERMISSIONS } from '../core/constants/permissions';
import type { SystemRole } from '../core/constants/roles';
import { SYSTEM_ROLES } from '../core/constants/roles';

export type NavigationIcon =
  | 'dashboard'
  | 'profile'
  | 'policies'
  | 'claims'
  | 'payments'
  | 'customers'
  | 'underwriting'
  | 'settlements'
  | 'plans'
  | 'roles';

export interface NavigationItem {
  label: string;
  route: string;
  icon: NavigationIcon;
  roles?: readonly SystemRole[];
  permissions?: readonly SystemPermission[];
}

const customer = [SYSTEM_ROLES.customer] as const;
const policyStaff = [SYSTEM_ROLES.agent, SYSTEM_ROLES.administrator] as const;
const claimsStaff = [SYSTEM_ROLES.claimsManager, SYSTEM_ROLES.administrator] as const;
const administrators = [SYSTEM_ROLES.administrator] as const;

/**
 * Authoritative navigation registry for the authenticated portal.
 * I paired each route with its required system roles and fine-grained permissions so navigation
 * dynamically mirrors our backend authorization policies without hardcoding sidebar links in templates.
 */
export const APP_NAVIGATION: readonly NavigationItem[] = [
  { label: 'Dashboard', route: '/dashboard', icon: 'dashboard' },
  { label: 'My Profile', route: '/profile/overview', icon: 'profile', roles: customer },
  { label: 'My Policies', route: '/policies/my', icon: 'policies', roles: customer },
  {
    label: 'My Claims',
    route: '/claims/my',
    icon: 'claims',
    roles: customer,
  },
  {
    label: 'Payments',
    route: '/payments/my',
    icon: 'payments',
    roles: customer,
    permissions: [SYSTEM_PERMISSIONS.viewPayments],
  },
  {
    label: 'Customer Policies',
    route: '/staff/policies/search',
    icon: 'policies',
    roles: policyStaff,
    permissions: [SYSTEM_PERMISSIONS.reviewPolicies],
  },
  {
    label: 'Underwriting',
    route: '/staff/policies/underwriting',
    icon: 'underwriting',
    roles: policyStaff,
    permissions: [SYSTEM_PERMISSIONS.reviewUnderwritingRequests],
  },
  {
    label: 'Claims Queue',
    route: '/staff/claims/queue',
    icon: 'claims',
    roles: claimsStaff,
    permissions: [SYSTEM_PERMISSIONS.reviewClaims],
  },
  {
    label: 'Settlements',
    route: '/staff/claims/settlements',
    icon: 'settlements',
    roles: claimsStaff,
    permissions: [SYSTEM_PERMISSIONS.initiateSettlement],
  },
  {
    label: 'Executive Dashboard',
    route: '/admin/dashboard',
    icon: 'dashboard',
    roles: administrators,
  },
  {
    label: 'Customers',
    route: '/admin/customers/search',
    icon: 'customers',
    roles: [SYSTEM_ROLES.administrator],
  },
  {
    label: 'Plans',
    route: '/admin/plans/list',
    icon: 'plans',
    roles: administrators,
    permissions: [SYSTEM_PERMISSIONS.managePlans],
  },
  {
    label: 'Role Assignment',
    route: '/admin/roles/assign',
    icon: 'roles',
    roles: administrators,
    permissions: [SYSTEM_PERMISSIONS.manageRoles],
  },
  {
    label: 'Transactions',
    route: '/admin/payments/search',
    icon: 'payments',
    roles: administrators,
  },
];

/**
 * Determines whether a navigation item should be rendered for the current user.
 * I designed the rule to evaluate OR semantics for roles (having any of the listed roles suffices),
 * but AND semantics for permissions (all declared permissions must be granted).
 */
export function canShowNavigationItem(
  item: NavigationItem,
  roles: readonly SystemRole[],
  permissions: readonly SystemPermission[],
): boolean {
  const roleAllowed = !item.roles || item.roles.some((role) => roles.includes(role));
  const permissionsAllowed =
    !item.permissions || item.permissions.every((permission) => permissions.includes(permission));
  return roleAllowed && permissionsAllowed;
}

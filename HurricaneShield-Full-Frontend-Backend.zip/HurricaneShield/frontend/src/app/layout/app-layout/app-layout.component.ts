
import { ChangeDetectionStrategy, Component, computed, inject, OnInit } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { toSignal } from '@angular/core/rxjs-interop';

import { AuthStore } from '../../core/auth/auth.store';
import { canShowNavigationItem, APP_NAVIGATION } from '../navigation.config';
import { NotificationHostComponent } from '../shared/notification-host.component';
import { AppSidebarComponent } from './app-sidebar.component';
import { AppTopbarComponent } from './app-topbar.component';
import { BreadcrumbsComponent } from '../../shared/breadcrumbs/breadcrumbs.component';
import { ThreatBannerComponent } from '../../shared/components/threat-banner/threat-banner.component';
import { ThreatService } from '../../core/services/threat.service';
import { CommandPaletteComponent } from '../../shared/components/command-palette/command-palette.component';

/**
 * Main application shell for authenticated users.
 * Houses the persistent responsive sidebar, top navigation bar, global breadcrumbs,
 * toast notification container, and the routed feature view.
 * Configured with OnPush change detection to leverage Angular 21's zoneless reactivity.
 */
@Component({
  selector: 'app-app-layout',
  imports: [AppSidebarComponent, AppTopbarComponent, NotificationHostComponent, RouterOutlet, BreadcrumbsComponent, ThreatBannerComponent, CommandPaletteComponent],
  templateUrl: './app-layout.component.html',
  styleUrl: './app-layout.component.css',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AppLayoutComponent implements OnInit {
  private readonly authStore = inject(AuthStore);
  private readonly threatService = inject(ThreatService);
  
  mobileNavigationOpen = false;

  readonly threatAlert = toSignal(this.threatService.checkThreats());

  /**
   * Filters the master navigation tree reactively based on the user's active roles and permissions.
   * If claims or roles change, the sidebar links automatically refresh without reloading the page.
   */
  readonly navigationItems = computed(() =>
    APP_NAVIGATION.filter((item) =>
      canShowNavigationItem(item, this.authStore.roles(), this.authStore.permissions()),
    ),
  );

  ngOnInit() {
    // Polling logic could be added here
  }

  closeMobileNavigation(): void {
    this.mobileNavigationOpen = false;
  }
}

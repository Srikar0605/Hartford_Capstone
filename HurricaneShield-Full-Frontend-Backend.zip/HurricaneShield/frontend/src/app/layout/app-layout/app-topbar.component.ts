
import { CdkMenu, CdkMenuItem, CdkMenuTrigger } from '@angular/cdk/menu';
import type { ConnectedPosition } from '@angular/cdk/overlay';
import { ChangeDetectionStrategy, Component, computed, inject, output } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { finalize } from 'rxjs';

import { CommandPaletteService } from '../../shared/components/command-palette/command-palette.component';
import { IconComponent } from '../../shared/components/icon/icon.component';

import { AuthService } from '../../core/auth/auth.service';
import { AuthStore } from '../../core/auth/auth.store';

@Component({
  selector: 'app-topbar',
  imports: [RouterLink, CdkMenu, CdkMenuItem, CdkMenuTrigger, IconComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl:
  './app-topbar.component.html',
  styles: [`
    :host { display: block; }
    .menu-link { display: flex; align-items: center; gap: .65rem; border-radius: .75rem; padding: .65rem .75rem; font-size: .875rem; font-weight: 600; color: #2a0a0d; outline: none; }
    .menu-link:hover, .menu-link:focus-visible, .menu-link.cdk-menu-item:focus { background: #fbf3f2; }
    .menu-link:disabled { cursor: wait; opacity: .6; }
  `],
})
export class AppTopbarComponent {
  readonly menuRequested = output<void>();
  readonly authStore = inject(AuthStore);
  readonly palette = inject(CommandPaletteService);
  readonly menuPositions: ConnectedPosition[] = [
    { originX: 'end', originY: 'bottom', overlayX: 'end', overlayY: 'top' },
    { originX: 'end', originY: 'top', overlayX: 'end', overlayY: 'bottom' },
  ];
  private readonly authService = inject(AuthService);
  private readonly router = inject(Router);

  userMenuOpen = false;
  signingOut = false;

  readonly primaryRole = computed(() => this.authStore.roles()[0] ?? 'Authenticated user');
  readonly initials = computed(() => {
    const email = this.authStore.currentUser()?.email ?? 'HS';
    return email.slice(0, 2).toUpperCase();
  });

  signOut(): void {
    if (this.signingOut) return;
    const refreshToken = this.authStore.refreshToken();
    if (!refreshToken) {
      this.finishSignOut();
      return;
    }
    this.signingOut = true;
    this.authService.logout({ refreshToken }).pipe(finalize(() => this.finishSignOut())).subscribe({
      error: () => undefined,
    });
  }

  private finishSignOut(): void {
    this.authStore.clearSession();
    this.signingOut = false;
    this.userMenuOpen = false;
    void this.router.navigateByUrl('/auth/login');
  }
}

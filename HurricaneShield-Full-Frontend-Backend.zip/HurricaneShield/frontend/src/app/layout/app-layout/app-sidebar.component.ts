
import { ChangeDetectionStrategy, Component, input, output } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';

import { NAVIGATION_ICON_MAP } from '../../shared/components/command-palette/command-palette.component';
import { IconComponent, type IconName } from '../../shared/components/icon/icon.component';
import { BrandMarkComponent } from '../brand/brand-mark.component';
import type { NavigationItem } from '../navigation.config';

@Component({
  selector: 'app-sidebar',
  imports: [BrandMarkComponent, RouterLink, RouterLinkActive, IconComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl:
  './app-sidebar.component.html',
  styles: [`
    :host { height: 100%; }
    .sidebar-link { display: flex; min-height: 2.75rem; align-items: center; gap: .75rem; border-radius: 999px; padding: .35rem .9rem .35rem .4rem; color: #4c3d3b; font-size: .875rem; font-weight: 600; transition: background-color .15s ease, color .15s ease; }
    .sidebar-link:hover { background: #fbf3f2; color: #2a0a0d; }
    .sidebar-icon { display: grid; width: 2rem; height: 2rem; flex: none; place-items: center; border-radius: 999px; color: #776560; }
    .sidebar-link:hover .sidebar-icon { color: #6a040f; }
    .sidebar-link-active, .sidebar-link-active:hover { background: #400106; color: #ffffff; box-shadow: 0 10px 22px -14px rgb(64 1 6 / .8); }
    .sidebar-link-active .sidebar-icon, .sidebar-link-active:hover .sidebar-icon { background: rgb(255 255 255 / .12); color: #f6e5e3; }
    .sidebar-chevron { opacity: 0; translate: -4px 0; transition: opacity .15s ease, translate .2s cubic-bezier(.16,1,.3,1); }
    .sidebar-link:hover .sidebar-chevron { opacity: .45; translate: 0 0; }
    .sidebar-link-active .sidebar-chevron { opacity: .8; translate: 0 0; }
  `],
})
export class AppSidebarComponent {
  readonly items = input.required<readonly NavigationItem[]>();
  readonly mobile = input(false);
  readonly navigate = output<void>();

  icon(icon: NavigationItem['icon']): IconName {
    return NAVIGATION_ICON_MAP[icon];
  }
}

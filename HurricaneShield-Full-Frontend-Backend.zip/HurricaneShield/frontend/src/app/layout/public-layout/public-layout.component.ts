
import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { toSignal } from '@angular/core/rxjs-interop';

import { AuthStore } from '../../core/auth/auth.store';
import { BrandMarkComponent } from '../brand/brand-mark.component';
import { NotificationHostComponent } from '../shared/notification-host.component';
import { ThreatBannerComponent } from '../../shared/components/threat-banner/threat-banner.component';
import { ThreatService } from '../../core/services/threat.service';

@Component({
  selector: 'app-public-layout',
  imports: [BrandMarkComponent, NotificationHostComponent, RouterLink, RouterLinkActive, RouterOutlet, ThreatBannerComponent],
  templateUrl: './public-layout.component.html',
  styleUrl: './public-layout.component.css',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PublicLayoutComponent {
  readonly authStore = inject(AuthStore);
  private readonly threatService = inject(ThreatService);
  
  readonly threatAlert = toSignal(this.threatService.checkThreats());
  
  menuOpen = false;

  closeMenu(): void {
    this.menuOpen = false;
  }
}

import { ChangeDetectionStrategy, Component, effect, inject } from '@angular/core';
import { NgxSonnerToaster, toast } from 'ngx-sonner';

import {
  type AppNotification,
  NotificationService,
} from '../../core/services/notification.service';

/**
 * Renders NotificationService messages as animated, stackable, swipe-to-dismiss toasts (ngx-sonner).
 * NotificationService is unchanged: it still owns the list and the auto-dismiss timers; this host
 * mirrors additions and removals into the toaster.
 */
@Component({
  selector: 'app-notification-host',
  imports: [NgxSonnerToaster],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './notification-host.component.html',
})
export class NotificationHostComponent {
  readonly notifications = inject(NotificationService);
  private readonly shown = new Set<string>();

  readonly toastOptions = {
    classes: {
      toast: 'hs-toast',
      title: 'hs-toast-title',
      description: 'hs-toast-description',
      closeButton: 'hs-toast-close',
    },
  };

  constructor() {
    effect(() => {
      const items = this.notifications.notifications();
      const present = new Set(items.map((item) => item.id));

      for (const item of items) {
        if (!this.shown.has(item.id)) {
          this.shown.add(item.id);
          this.present(item);
        }
      }

      for (const id of [...this.shown]) {
        if (!present.has(id)) {
          this.shown.delete(id);
          toast.dismiss(id);
        }
      }
    });
  }

  borderClass(kind: 'success' | 'error' | 'warning' | 'info'): string {
    return {
      success: 'border-l-emerald-600',
      error: 'border-l-red-600',
      warning: 'border-l-amber-500',
      info: 'border-l-brand-700',
    }[kind];
  }

  private present(item: AppNotification): void {
    const description = item.correlationId
      ? `${item.message}  ·  Reference ${item.correlationId}`
      : item.message;

    toast[item.kind](item.title, {
      id: item.id,
      description,
      duration: Number.POSITIVE_INFINITY,
      onDismiss: () => this.notifications.dismiss(item.id),
    });
  }
}

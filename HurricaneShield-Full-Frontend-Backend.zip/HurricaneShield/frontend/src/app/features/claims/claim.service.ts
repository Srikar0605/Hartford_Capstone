
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';

import { API_HEADERS, API_ROUTES } from '../../core/constants/api-routes';
import type { ApiResponse } from '../../core/models/api.models';
import type { PagedResponse } from '../../core/models/pagination.models';
import { apiUrl } from '../../core/services/api-url';
import { toHttpParams } from '../../core/services/http-params';
import type {
  ApproveClaimRequest,
  ClaimDetailsResponse,
  ClaimDocumentResponse,
  ClaimDocumentUpload,
  ClaimMutationResponse,
  ClaimNoteResponse,
  ClaimReviewResponse,
  ClaimSearchRequest,
  ClaimSubmissionResponse,
  ClaimSummaryResponse,
  ClaimTimelineResponse,
  DocumentVerificationResponse,
  InitiateSettlementRequest,
  RejectClaimRequest,
  RequestAdditionalInformationRequest,
  SettlementInitiationResponse,
  StartClaimReviewRequest,
  SubmitClaimRequest,
  VerifyClaimDocumentRequest,
} from './claim.models';

/**
 * Service managing claims operations and lifecycle transitions in the Claims microservice.
 * Handles customer FNOL submissions, document attachments, adjuster review workflows,
 * and settlement handoff to the Payment service.
 */
@Injectable({
  providedIn: 'root',
})
export class ClaimService {
  private readonly http = inject(HttpClient);

  /**
   * Submits a First Notice of Loss (FNOL).
   * We pass the X-Idempotency-Key header so that accidental multiple clicks do not open
   * multiple claim files for the same incident.
   */
  submit(request: SubmitClaimRequest, idempotencyKey: string): Observable<ClaimSubmissionResponse> {
    const headers = new HttpHeaders().set(API_HEADERS.idempotencyKey, idempotencyKey);

    return this.http
      .post<ApiResponse<ClaimSubmissionResponse>>(apiUrl(API_ROUTES.claims.root), request, {
        headers,
      })
      .pipe(map((response) => response.data));
  }

  getMine(request: ClaimSearchRequest = {}): Observable<PagedResponse<ClaimSummaryResponse>> {
    return this.searchAt(API_ROUTES.claims.mine, request);
  }

  search(request: ClaimSearchRequest = {}): Observable<PagedResponse<ClaimSummaryResponse>> {
    return this.searchAt(API_ROUTES.claims.root, request);
  }

  getClaim(claimId: string): Observable<ClaimDetailsResponse> {
    return this.get<ClaimDetailsResponse>(API_ROUTES.claims.byId(claimId));
  }

  getTimeline(claimId: string): Observable<ClaimTimelineResponse[]> {
    return this.get<ClaimTimelineResponse[]>(API_ROUTES.claims.timeline(claimId));
  }

  /**
   * Uploads claim damage photos, structural reports, or repair estimates.
   * I use standard FormData here so the browser automatically handles multipart/form-data boundary generation.
   */
  uploadDocument(claimId: string, request: ClaimDocumentUpload): Observable<ClaimDocumentResponse> {
    const formData = new FormData();

    formData.append('documentType', request.documentType);
    formData.append('file', request.file, request.file.name);

    return this.http
      .post<ApiResponse<ClaimDocumentResponse>>(
        apiUrl(API_ROUTES.claims.documents(claimId)),
        formData,
      )
      .pipe(map((response) => response.data));
  }

  verifyDocument(
    claimId: string,
    documentId: string,
    request: VerifyClaimDocumentRequest,
  ): Observable<DocumentVerificationResponse> {
    return this.post<DocumentVerificationResponse>(
      API_ROUTES.claims.verifyDocument(claimId, documentId),
      request,
    );
  }

  startReview(claimId: string, request: StartClaimReviewRequest): Observable<ClaimReviewResponse> {
    return this.post<ClaimReviewResponse>(API_ROUTES.claims.startReview(claimId), request);
  }

  approve(claimId: string, request: ApproveClaimRequest): Observable<ClaimMutationResponse> {
    return this.post<ClaimMutationResponse>(API_ROUTES.claims.approve(claimId), request);
  }

  reject(claimId: string, request: RejectClaimRequest): Observable<ClaimMutationResponse> {
    return this.post<ClaimMutationResponse>(API_ROUTES.claims.reject(claimId), request);
  }

  requestAdditionalInformation(
    claimId: string,
    request: RequestAdditionalInformationRequest,
  ): Observable<ClaimNoteResponse> {
    return this.post<ClaimNoteResponse>(API_ROUTES.claims.requestInformation(claimId), request);
  }

  /**
   * Initiates settlement payout for an approved claim.
   * Because disbursing claim money is high risk, this call requires an idempotency key to prevent double disbursements.
   */
  initiateSettlement(
    claimId: string,
    request: InitiateSettlementRequest,
    idempotencyKey: string,
  ): Observable<SettlementInitiationResponse> {
    const headers = new HttpHeaders().set(API_HEADERS.idempotencyKey, idempotencyKey);

    return this.http
      .post<ApiResponse<SettlementInitiationResponse>>(
        apiUrl(API_ROUTES.claims.settlement(claimId)),
        request,
        {
          headers,
        },
      )
      .pipe(map((response) => response.data));
  }

  private get<T>(route: string): Observable<T> {
    return this.http.get<ApiResponse<T>>(apiUrl(route)).pipe(map((response) => response.data));
  }

  private post<T>(route: string, body: unknown): Observable<T> {
    return this.http
      .post<ApiResponse<T>>(apiUrl(route), body)
      .pipe(map((response) => response.data));
  }

  private searchAt(
    route: string,
    request: ClaimSearchRequest,
  ): Observable<PagedResponse<ClaimSummaryResponse>> {
    return this.http
      .get<ApiResponse<PagedResponse<ClaimSummaryResponse>>>(apiUrl(route), {
        params: toHttpParams({
          ...request,
        }),
      })
      .pipe(map((response) => response.data));
  }

  getActiveReview(claimId: string): Observable<ClaimReviewResponse> {
    return this.get<ClaimReviewResponse>(API_ROUTES.claims.activeReview(claimId));
  }
}

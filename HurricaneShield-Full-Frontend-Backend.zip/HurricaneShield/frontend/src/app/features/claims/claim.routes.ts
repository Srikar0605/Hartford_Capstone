
import type { Routes } from '@angular/router';

import { authGuard } from '../../core/guards/auth.guard';
import { activeCustomerProfileGuard } from '../../core/guards/profile.guard';
import { permissionGuard } from '../../core/guards/permission.guard';
import { roleGuard } from '../../core/guards/role.guard';
import { unsavedChangesGuard } from '../../core/guards/unsaved-changes.guard';
import { SYSTEM_PERMISSIONS } from '../../core/constants/permissions';
import { SYSTEM_ROLES } from '../../core/constants/roles';
import { placeholderRoute } from '../../core/routing/route-helpers';

export const claimRoutes: Routes = [
  placeholderRoute({
    path: 'claims/my',
    title: 'My Claims',
    pageKey: 'claims.my',
    canActivate: [authGuard, roleGuard],
    data: { roles: [SYSTEM_ROLES.customer] },
  }),
  placeholderRoute({
    path: 'claims/submit',
    title: 'Submit Claim',
    pageKey: 'claims.submit',
    canActivate: [authGuard, roleGuard, permissionGuard, activeCustomerProfileGuard],
    canDeactivate: [unsavedChangesGuard],
    data: {
      roles: [SYSTEM_ROLES.customer],
      permissions: [SYSTEM_PERMISSIONS.submitClaims],
    },
  }),
  placeholderRoute({
    path: 'claims/:claimId',
    title: 'Claim Details',
    pageKey: 'claims.details',
    canActivate: [authGuard, roleGuard],
    data: {
      roles: [
        SYSTEM_ROLES.customer,
        SYSTEM_ROLES.claimsManager,
        SYSTEM_ROLES.administrator,
      ],
    },
  }),
];

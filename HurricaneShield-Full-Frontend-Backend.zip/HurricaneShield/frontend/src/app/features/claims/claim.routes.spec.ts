
import { roleGuard } from '../../core/guards/role.guard';
import { SYSTEM_ROLES } from '../../core/constants/roles';
import { claimRoutes } from './claim.routes';

describe('claimRoutes', () => {
  it('limits Claim details to supported reader roles', () => {
    const route = claimRoutes.find((value) => value.path === 'claims/:claimId');

    expect(route?.canActivate).toContain(roleGuard);
    expect(route?.data?.['roles']).toEqual([
      SYSTEM_ROLES.customer,
      SYSTEM_ROLES.claimsManager,
      SYSTEM_ROLES.administrator,
    ]);
  });
});


import type {
  ClaimNoteType,
  ClaimReviewDecision,
  ClaimStatus,
  DocumentVerificationStatus,
} from '../../core/constants/statuses';
import type { ApiDate, ApiDateTime, Guid, RowVersion } from '../../core/models/api.models';
import type { PageRequest } from '../../core/models/pagination.models';

export interface SubmitClaimRequest {
  customerId: Guid;
  policyId: Guid;
  coverageTypeId: Guid;
  claimAmount: number;
  incidentDate: ApiDate;
  incidentDescription: string;
}

export interface ClaimSearchRequest extends PageRequest {
  status?: ClaimStatus;
  policyId?: Guid;
  fromIncidentDate?: ApiDate;
  toIncidentDate?: ApiDate;
}

export interface ClaimSummaryResponse {
  claimId: Guid;
  claimNumber: string;
  customerId: Guid;
  customerDisplayName: string;
  customerEmail: string;
  policyId: Guid;
  policyNumber: string;
  coverageTypeId: Guid;
  coverageTypeName: string;
  claimAmount: number;
  incidentDate: string;
  status: ClaimStatus;
  createdAt: string;
  rowVersion: RowVersion;
}

export interface ClaimSubmissionResponse {
  claimId: Guid;
  claimNumber: string;
  status: ClaimStatus;
  submittedAt: ApiDateTime;
  rowVersion: RowVersion;
}

export interface ClaimMutationResponse {
  claimId: Guid;
  claimNumber: string;
  status: ClaimStatus;
  settlementTransactionId: Guid | null;
  rowVersion: RowVersion;
}

export interface ClaimDocumentResponse {
  documentId: Guid;
  claimId: Guid;
  fileName: string;
  contentType: string;
  fileSize: number;
  documentType: string;
  uploadedAt: ApiDateTime;
  uploadedBy: string;
  verificationStatus: DocumentVerificationStatus;
  verificationNotes: string | null;
  verifiedAt: ApiDateTime | null;
  verifiedBy: string | null;
}

export interface VerifyClaimDocumentRequest {
  status: DocumentVerificationStatus;
  notes: string | null;
  claimRowVersion: RowVersion;
}

export interface DocumentVerificationResponse {
  documentId: Guid;
  status: DocumentVerificationStatus;
  notes: string | null;
  verifiedAt: ApiDateTime | null;
  verifiedBy: string | null;
}

export interface ClaimTimelineResponse {
  timelineId: Guid;
  fromStatus: ClaimStatus | null;
  toStatus: ClaimStatus;
  notes: string;
  changedAt: ApiDateTime;
  changedBy: string;
  correlationId: string;
}

export interface ClaimNoteResponse {
  noteId: Guid;
  noteType: ClaimNoteType;
  noteText: string;
  createdAt: ApiDateTime;
  createdBy: string;
}

export interface AiClaimTriageResponse {
  fraudFlags: string[];
  complexityScore: number;
  summary: string;
  recommendation: string;
  aiConfidence: number;
  triagedAt: ApiDateTime;
  /** "Gemini" = live language model, "RuleBased" = the built-in fallback engine; null for older claims. */
  engine?: 'Gemini' | 'RuleBased' | null;
}

export interface ClaimDetailsResponse {
  claimId: Guid;
  claimNumber: string;
  customerId: Guid;
  customerDisplayName: string;
  customerEmail: string;
  policyId: Guid;
  policyNumber: string;
  coverageTypeId: Guid;
  coverageTypeName: string;
  claimAmount: number;
  incidentDate: string;
  incidentDescription: string;
  status: ClaimStatus;
  settlementTransactionId:
    Guid | null;
  createdAt: string;
  updatedAt: string | null;
  documents:
    ClaimDocumentResponse[];
  timeline:
    ClaimTimelineResponse[];
  notes:
    ClaimNoteResponse[];
  rowVersion: RowVersion;
  aiTriage?: AiClaimTriageResponse | null;
  assessedAmount?: number | null;
  approvedAmount?: number | null;
  deductibleApplied?: number | null;
  adjustmentReason?: string | null;
}

export interface StartClaimReviewRequest {
  claimRowVersion: RowVersion;
}

export interface ApproveClaimRequest {
  notes: string;
  claimRowVersion: RowVersion;
  reviewRowVersion: RowVersion;
  assessedAmount?: number | null;
  adjustmentReason?: string | null;
}

export interface RejectClaimRequest {
  reason: string;
  claimRowVersion: RowVersion;
  reviewRowVersion: RowVersion;
}

export interface RequestAdditionalInformationRequest {
  note: string;
  claimRowVersion: RowVersion;
}

export interface ClaimReviewResponse {
  reviewId: Guid;
  claimId: Guid;
  reviewerUserId: Guid;
  decision: ClaimReviewDecision | null;
  notes: string | null;
  createdAt: ApiDateTime;
  reviewedAt: ApiDateTime | null;
  rowVersion: RowVersion;
}

export interface InitiateSettlementRequest {
  claimRowVersion: RowVersion;
}

export interface SettlementInitiationResponse {
  claimId: Guid;
  claimNumber: string;
  transactionId: Guid;
  amount: number;
  status: ClaimStatus;
  rowVersion: RowVersion;
}

/** Frontend-owned metadata used to construct multipart/form-data. */
export interface ClaimDocumentUpload {
  documentType: string;
  file: File;
}


import { FormControl, FormGroup, Validators } from '@angular/forms';
import { HurricaneValidators } from '../../shared/validators/hurricane.validators';

/**
 * Creates the reactive form model for First Notice of Loss (FNOL) claim submissions.
 * We validate that incidentDate is not in the future (disaster dates must already have occurred),
 * that claimAmount is positive, and enforce GUID validation for customer, policy, and coverage type IDs.
 */
export function createSubmitClaimForm() {
  return new FormGroup({
    customerId: new FormControl('', { nonNullable: true, validators: [Validators.required, HurricaneValidators.guid] }),
    policyId: new FormControl('', { nonNullable: true, validators: [Validators.required, HurricaneValidators.guid] }),
    coverageTypeId: new FormControl('', { nonNullable: true, validators: [Validators.required, HurricaneValidators.guid] }),
    claimAmount: new FormControl<number | null>(null, [Validators.required, HurricaneValidators.positiveNumber]),
    incidentDate: new FormControl('', { nonNullable: true, validators: [Validators.required, HurricaneValidators.isoDateNotInFuture] }),
    incidentDescription: new FormControl('', { nonNullable: true, validators: [Validators.required, Validators.maxLength(2000)] }),
  });
}

/**
 * Form for uploading damage photos, repair estimates, and receipts.
 * I capped the file size at 10 MB to prevent high memory pressure and upload timeouts on mobile devices.
 */
export function createClaimDocumentForm() {
  return new FormGroup({
    documentType: new FormControl('', { nonNullable: true, validators: [Validators.required, Validators.maxLength(100)] }),
    file: new FormControl<File | null>(null, [Validators.required, HurricaneValidators.maximumFileSize(10 * 1024 * 1024)]),
  });
}

/**
 * Adjudication approval form used by Claims Managers.
 * Notice that both claimRowVersion AND reviewRowVersion are required: this guarantees optimistic concurrency
 * across both the claim entity and the active review lifecycle record simultaneously.
 */
export function createClaimDecisionForm() {
  return new FormGroup({
    notes: new FormControl('', { nonNullable: true, validators: [Validators.required, Validators.maxLength(2000)] }),
    claimRowVersion: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    reviewRowVersion: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
  });
}

/**
 * Adjudication rejection form requiring a detailed justification note and dual optimistic concurrency tokens.
 */
export function createClaimRejectionForm() {
  return new FormGroup({
    reason: new FormControl('', { nonNullable: true, validators: [Validators.required, Validators.maxLength(2000)] }),
    claimRowVersion: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    reviewRowVersion: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
  });
}

/**
 * Form for adjusters requesting supplemental documentation or clarification from the policyholder.
 */
export function createAdditionalInformationForm() {
  return new FormGroup({
    note: new FormControl('', { nonNullable: true, validators: [Validators.required, Validators.maxLength(2000)] }),
    claimRowVersion: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
  });
}

/**
 * Form for verifying or rejecting customer-submitted damage proofs during document review.
 */
export function createDocumentVerificationForm() {
  return new FormGroup({
    status: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    notes: new FormControl('', { nonNullable: true, validators: [Validators.maxLength(1000)] }),
    claimRowVersion: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
  });
}

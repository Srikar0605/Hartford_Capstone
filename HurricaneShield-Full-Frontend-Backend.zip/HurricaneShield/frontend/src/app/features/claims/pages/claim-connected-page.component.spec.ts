
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';
import { ActivatedRoute } from '@angular/router';
import { of } from 'rxjs';
import { ClaimConnectedPageComponent } from './claim-connected-page.component';

describe('ClaimConnectedPageComponent', () => {
  let fixture: ComponentFixture<ClaimConnectedPageComponent>;
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ClaimConnectedPageComponent],
      providers: [
        provideRouter([]),
        provideHttpClient(),
        provideHttpClientTesting(),
        {
          provide: ActivatedRoute,
          useValue: {
            data: of({ pageKey: 'claims.my' }),
            snapshot: { paramMap: { get: () => null } },
          },
        },
      ],
    }).compileComponents();
    fixture = TestBed.createComponent(ClaimConnectedPageComponent);
  });
  it('creates the connected Claims page', () => expect(fixture.componentInstance).toBeTruthy());
  it('does not report unsaved changes for My Claims', () =>
    expect(fixture.componentInstance.hasUnsavedChanges()).toBeFalsy());
});

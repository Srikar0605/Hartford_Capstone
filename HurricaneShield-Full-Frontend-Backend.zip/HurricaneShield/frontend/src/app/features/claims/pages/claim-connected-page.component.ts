
import { CommonModule } from '@angular/common';
import {
  ChangeDetectionStrategy,
  Component,
  OnDestroy,
  OnInit,
  ElementRef,
  inject,
  signal,
  computed,
} from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { forkJoin, Subject, takeUntil } from 'rxjs';

import { CLAIM_STATUSES, DOCUMENT_VERIFICATION_STATUSES, type ClaimStatus } from '../../../core/constants/statuses';
import { IDEMPOTENT_OPERATIONS } from '../../../core/constants/storage-keys';
import type { HasUnsavedChanges } from '../../../core/guards/unsaved-changes.guard';
import { ApiClientError } from '../../../core/interceptors/error.interceptor';
import type { PagedResponse } from '../../../core/models/pagination.models';
import { IdempotencyService } from '../../../core/services/idempotency.service';
import { NotificationService } from '../../../core/services/notification.service';
import { PolicyService } from '../../policies/policy.service';
import type {
  PlanCoverageResponse,
  PolicyDetailsResponse,
  PolicySummaryResponse,
} from '../../policies/policy.models';
import { ProfileService } from '../../profile/profile.service';
import {
  createAdditionalInformationForm,
  createClaimDecisionForm,
  createClaimDocumentForm,
  createClaimRejectionForm,
  createDocumentVerificationForm,
  createSubmitClaimForm,
} from '../claim.forms';
import type {
  ClaimDetailsResponse,
  ClaimDocumentResponse,
  ClaimReviewResponse,
  ClaimSearchRequest,
  ClaimSubmissionResponse,
  ClaimSummaryResponse,
  SettlementInitiationResponse,
  SubmitClaimRequest,
} from '../claim.models';
import { FormFieldErrorComponent } from '../../../shared/components/form-field-error/form-field-error.component';
import { IconComponent, type IconName } from '../../../shared/components/icon/icon.component';
import { StatusBadgeComponent } from '../../../shared/components/status-badge/status-badge.component';
import { EmptyStateComponent } from '../../../shared/components/empty-state/empty-state.component';
import { PaginationComponent } from '../../../shared/components/pagination/pagination.component';
import { SlideOverComponent } from '../../../shared/components/slide-over/slide-over.component';
import { ClaimService } from '../claim.service';

@Component({
  selector: 'app-claim-connected-page',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterLink,
    FormFieldErrorComponent,
    IconComponent,
    StatusBadgeComponent,
    EmptyStateComponent,
    PaginationComponent,
    SlideOverComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './claim-connected-page.component.html',
})
export class ClaimConnectedPageComponent implements OnInit, OnDestroy, HasUnsavedChanges {
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);
  private readonly claimsService = inject(ClaimService);
  private readonly policiesService = inject(PolicyService);
  private readonly profileService = inject(ProfileService);
  private readonly idem = inject(IdempotencyService);
  private readonly notifications = inject(NotificationService);
  private readonly destroy$ = new Subject<void>();

  readonly pageKey = signal('claims.my');
  readonly busy = signal(false);
  readonly errorMessage = signal('');
  readonly claims = signal<PagedResponse<ClaimSummaryResponse>>({
    items: [],
    page: 1,
    pageSize: 20,
    totalCount: 0,
    totalPages: 0,
  });
  readonly rejectedDocumentId = signal<string | null>(null);
  readonly rejectionNotesRequired = signal(false);
  readonly claim = signal<ClaimDetailsResponse | null>(null);
  readonly review = signal<ClaimReviewResponse | null>(null);
  readonly policies = signal<PolicySummaryResponse[]>([]);
  readonly coverages = signal<PlanCoverageResponse[]>([]);
  readonly submission = signal<ClaimSubmissionResponse | null>(null);
  readonly settlement = signal<SettlementInitiationResponse | null>(null);
  readonly selectedStatus = signal('');
  readonly claimStatuses = CLAIM_STATUSES;
  readonly verificationStatuses = DOCUMENT_VERIFICATION_STATUSES;
  readonly submitForm = createSubmitClaimForm();
  readonly documentForm = createClaimDocumentForm();
  readonly decisionForm = createClaimDecisionForm();
  readonly rejectionForm = createClaimRejectionForm();
  readonly informationForm = createAdditionalInformationForm();
  readonly verificationForm = createDocumentVerificationForm();

  /* List presentation helpers (derived from the already-loaded page of Claims). */
  readonly quickViewClaim = signal<ClaimSummaryResponse | null>(null);
  readonly claimStages = ['Submitted', 'Review', 'Decision', 'Paid'];
  readonly claimTrackerStages: { title: string; text: string; icon: IconName }[] = [
    { title: 'Submitted', text: 'Your claim has been registered.', icon: 'send' },
    { title: 'Under review', text: 'A Claims Manager verifies your documents.', icon: 'eye' },
    { title: 'Decision', text: 'The claim is approved or declined.', icon: 'badge-check' },
    { title: 'Settlement', text: 'Approved amounts are paid out.', icon: 'banknote' },
  ];
  readonly claimStats = computed<{ label: string; value: number; icon: IconName }[]>(() => {
    const items = this.claims().items;
    const count = (...statuses: string[]) => items.filter((c) => statuses.includes(c.status)).length;
    return [
      { label: 'New', value: count('Submitted'), icon: 'send' },
      { label: 'In review', value: count('UnderReview'), icon: 'eye' },
      { label: 'Approved', value: count('Approved', 'PaymentInitiated'), icon: 'badge-check' },
      { label: 'On this page', value: items.length, icon: 'list' },
    ];
  });
  readonly settlementTotal = computed(() => this.claims().items.reduce((sum, c) => sum + c.claimAmount, 0));
  claimStageIndex(status: string): number {
    return ({ Submitted: 0, UnderReview: 1, Approved: 2, Rejected: 2, PaymentInitiated: 3, Closed: 3 } as Record<string, number>)[status] ?? 0;
  }
  initialsOf(name: string | null | undefined): string {
    return (name ?? '')
      .split(/\s+/)
      .filter(Boolean)
      .slice(0, 2)
      .map((part) => part[0]!.toUpperCase())
      .join('') || '–';
  }
  spaced(value: string | null | undefined): string {
    return (value ?? '').replace(/([a-z])([A-Z])/g, '$1 $2');
  }

  /* Submit-claim wizard (UI state only; the request payload is unchanged). */
  private readonly hostElement = inject(ElementRef<HTMLElement>);
  readonly claimSteps = [{ title: 'Policy & coverage' }, { title: 'Incident' }, { title: 'Review' }];
  readonly claimStep = signal(0);
  readonly today = new Date().toISOString().slice(0, 10);
  readonly claimNextSteps: { icon: IconName; title: string; text: string }[] = [
    { icon: 'send', title: 'Claim registered', text: 'You get a claim number instantly.' },
    { icon: 'upload', title: 'Add evidence', text: 'Upload photos, estimates and receipts.' },
    { icon: 'user-cog', title: 'Claims review', text: 'A Claims Manager verifies documents.' },
    { icon: 'banknote', title: 'Settlement', text: 'Approved amounts are paid out to you.' },
  ];

  selectedPolicy(): PolicySummaryResponse | undefined {
    return this.policies().find((p) => p.policyId === this.submitForm.controls.policyId.value);
  }
  selectedCoverage(): PlanCoverageResponse | undefined {
    return this.coverages().find((c) => c.coverageTypeId === this.submitForm.controls.coverageTypeId.value);
  }
  nextClaimStep(): void {
    const c = this.submitForm.controls;
    const stepControls = [[c.policyId, c.coverageTypeId], [c.incidentDate, c.claimAmount, c.incidentDescription]][this.claimStep()] ?? [];
    if (stepControls.some((control) => control.invalid)) {
      stepControls.forEach((control) => control.markAsTouched());
      return;
    }
    this.goToClaimStep(this.claimStep() + 1);
  }
  previousClaimStep(): void {
    this.goToClaimStep(this.claimStep() - 1);
  }
  goToClaimStep(step: number): void {
    if (step < 0 || step >= this.claimSteps.length || step > this.claimStep() + 1) return;
    this.claimStep.set(step);
    setTimeout(() => {
      const heading = (this.hostElement.nativeElement as HTMLElement).querySelector<HTMLElement>('[data-step-heading]');
      heading?.focus({ preventScroll: true });
      heading?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    });
  }

  readonly title = () =>
    ({
      'claims.my': 'My Claims',
      'claims.submit': 'Submit a Claim',
      'claims.details': 'Claim Details',
      'staff.claims-queue': 'Claims Queue',
      'staff.claim-review': 'Claim Review',
      'staff.settlements': 'Claim Settlements',
    })[this.pageKey()] ?? 'Claims';
  readonly description = () =>
    this.pageKey().startsWith('staff.')
      ? 'Review, decide, and settle claims.'
      : 'Submit and track hurricane insurance claims.';

  ngOnInit(): void {
    this.route.data.pipe(takeUntil(this.destroy$)).subscribe((data) => {
      this.pageKey.set(String(data['pageKey'] ?? 'claims.my'));
      this.loadPage();
    });
  }
  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
  hasUnsavedChanges(): boolean {
    return this.pageKey() === 'claims.submit' && this.submitForm.dirty && !this.submission();
  }

  loadPage(): void {
    this.errorMessage.set('');
    const key = this.pageKey();
    if (key === 'claims.my' || key === 'staff.claims-queue' || key === 'staff.settlements')
      this.loadList(1);
    else if (key === 'claims.submit') this.loadSubmitContext();
    else this.loadClaim();
  }
  loadList(page: number): void {
    this.busy.set(true);
    const request: ClaimSearchRequest = {
      page,
      pageSize: 20,
      status: (this.pageKey() === 'staff.settlements'
        ? 'Approved'
        : (this.selectedStatus() as ClaimStatus) || undefined),
    };
    const call =
      this.pageKey() === 'claims.my'
        ? this.claimsService.getMine(request)
        : this.claimsService.search(request);
    call.pipe(takeUntil(this.destroy$)).subscribe({
      next: (value) => {
        this.claims.set(value);
        this.busy.set(false);
      },
      error: (e) => this.fail(e),
    });
  }
  filterStatus(value: string): void {
    this.selectedStatus.set(value);
    this.loadList(1);
  }
  loadSubmitContext(): void {
    this.busy.set(true);
    forkJoin({
      profile: this.profileService.getCurrentProfile(),
      policies: this.policiesService.getMyPolicies({ page: 1, pageSize: 100, status: 'Active' }),
    })
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: ({ profile, policies }) => {
          this.submitForm.controls.customerId.setValue(profile.customerId);
          this.policies.set(policies.items);
          this.busy.set(false);
        },
        error: (e) => this.fail(e),
      });
  }
  policyChanged(): void {
    const id = this.submitForm.controls.policyId.value;
    this.coverages.set([]);
    this.submitForm.controls.coverageTypeId.setValue('');
    if (!id) return;
    this.busy.set(true);
    this.policiesService
      .getPolicy(id)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (p: PolicyDetailsResponse) => {
          this.coverages.set(p.plan.coverages);
          this.busy.set(false);
        },
        error: (e) => this.fail(e),
      });
  }

  submitNewClaim(): void {
    /*
     * Once this page has successfully created a Claim,
     * do not allow the same completed form to submit again.
     */
    if (this.submission() || this.busy()) {
      return;
    }

    if (this.submitForm.invalid) {
      this.submitForm.markAllAsTouched();
      return;
    }

    const formValue = this.submitForm.getRawValue();

    const request: SubmitClaimRequest = {
      customerId: formValue.customerId,

      policyId: formValue.policyId,

      coverageTypeId: formValue.coverageTypeId,

      claimAmount: formValue.claimAmount!,

      incidentDate: formValue.incidentDate,

      incidentDescription: formValue.incidentDescription.trim(),
    };

    const idempotencyKey = this.idem.getOrCreate(IDEMPOTENT_OPERATIONS.claimSubmission, request);

    this.errorMessage.set('');
    this.busy.set(true);

    this.claimsService
      .submit(request, idempotencyKey)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (result: ClaimSubmissionResponse) => {
          /*
           * The server completed the operation, so the
           * pending retry key is no longer needed.
           */
          this.idem.complete(IDEMPOTENT_OPERATIONS.claimSubmission);

          this.submission.set(result);

          /*
           * Lock the successful form. The surrounding
           * success state also removes the Submit button.
           */
          this.submitForm.disable({
            emitEvent: false,
          });

          this.submitForm.markAsPristine();
          this.busy.set(false);

          this.notifications.success(
            'Claim submitted',
            `Claim ${result.claimNumber} was created successfully.`,
          );
        },
        error: (error: unknown) => {
          /*
           * Do not complete the idempotency operation on
           * failure. A safe retry of the same payload must
           * reuse the same key.
           */
          this.fail(error);
        },
      });
  }

  private loadActiveReview(claimId: string): void {
    this.claimsService
      .getActiveReview(claimId)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (review: ClaimReviewResponse) => {
          this.review.set(review);
          this.decisionForm.controls.reviewRowVersion.setValue(review.rowVersion);
          this.rejectionForm.controls.reviewRowVersion.setValue(review.rowVersion);
          this.busy.set(false);
        },
        error: (error: unknown) => {
          this.review.set(null);
          this.fail(error);
        },
      });
  }

  loadClaim(): void {
    const claimId = this.route.snapshot.paramMap.get('claimId');
    if (!claimId) {
      return;
    }
    this.busy.set(true);
    this.errorMessage.set('');
    this.review.set(null);
    this.claimsService
      .getClaim(claimId)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (claim: ClaimDetailsResponse) => {
          this.claim.set(claim);
          this.patchRows(claim.rowVersion);
          const isStaffReviewPage = this.pageKey() === 'staff.claim-review';
          if (isStaffReviewPage && claim.status === 'UnderReview') {
            this.loadActiveReview(claimId);
            return;
          }
          this.busy.set(false);
        },
        error: (error: unknown) => {
          this.fail(error);
        },
      });
  }
  fileSelected(event: Event): void {
    const file = (event.target as HTMLInputElement).files?.[0] ?? null;
    this.documentForm.controls.file.setValue(file);
    this.documentForm.controls.file.markAsTouched();
  }
  uploadDocument(): void {
    const item = this.claim();
    if (!item || this.documentForm.invalid) return;
    const raw = this.documentForm.getRawValue();
    this.busy.set(true);
    this.claimsService
      .uploadDocument(item.claimId, { documentType: raw.documentType, file: raw.file! })
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: () => {
          this.notifications.success(
            'Document uploaded',
            'The claim document was uploaded successfully.',
          );
          this.documentForm.reset();
          this.loadClaim();
        },
        error: (e) => this.fail(e),
      });
  }
  startReview(): void {
    const claim = this.claim();
    if (!claim) {
      return;
    }
    this.busy.set(true);
    this.errorMessage.set('');
    this.claimsService
      .startReview(claim.claimId, { claimRowVersion: claim.rowVersion })
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (review: ClaimReviewResponse) => {
          this.review.set(review);
          this.decisionForm.controls.reviewRowVersion.setValue(review.rowVersion);
          this.rejectionForm.controls.reviewRowVersion.setValue(review.rowVersion);
          this.notifications.success('Review started', 'The Claim is now under review.');
          this.loadClaim();
        },
        error: (error: unknown) => {
          this.fail(error);
        },
      });
  }
  approve(): void {
    const item = this.claim(),
      review = this.review();
    if (!item || !review || this.decisionForm.controls.notes.invalid) return;
    this.busy.set(true);
    this.claimsService
      .approve(item.claimId, {
        notes: this.decisionForm.controls.notes.value,
        claimRowVersion: item.rowVersion,
        reviewRowVersion: review.rowVersion,
      })
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: () => {
          this.notifications.success('Claim approved', 'The claim was approved successfully.');
          this.review.set(null);
          this.loadClaim();
        },
        error: (e) => this.fail(e),
      });
  }
  reject(): void {
    const item = this.claim(),
      review = this.review();
    if (!item || !review) return;
    const reason = this.decisionForm.controls.notes.value;
    if (!reason) return;
    this.busy.set(true);
    this.claimsService
      .reject(item.claimId, {
        reason,
        claimRowVersion: item.rowVersion,
        reviewRowVersion: review.rowVersion,
      })
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: () => {
          this.notifications.success('Claim rejected', 'The claim was rejected successfully.');
          this.review.set(null);
          this.loadClaim();
        },
        error: (e) => this.fail(e),
      });
  }
  requestInformation(): void {
    const item = this.claim();
    if (!item || this.informationForm.controls.note.invalid) return;
    this.busy.set(true);
    this.claimsService
      .requestAdditionalInformation(item.claimId, {
        note: this.informationForm.controls.note.value,
        claimRowVersion: item.rowVersion,
      })
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: () => {
          this.notifications.success(
            'Information requested',
            'The request was added to the claim.',
          );
          this.loadClaim();
        },
        error: (e) => this.fail(e),
      });
  }
  verifyDocument(document: ClaimDocumentResponse, status: 'Verified' | 'Rejected'): void {
    const claim = this.claim();
    if (!claim) {
      return;
    }
    const notes = this.verificationForm.controls.notes.value.trim();
    if (status === 'Rejected' && !notes) {
      this.rejectedDocumentId.set(document.documentId);
      this.rejectionNotesRequired.set(true);
      this.verificationForm.controls.notes.markAsTouched();
      return;
    }
    if (this.verificationForm.controls.notes.hasError('maxlength')) {
      this.verificationForm.controls.notes.markAsTouched();
      return;
    }
    this.rejectedDocumentId.set(null);
    this.rejectionNotesRequired.set(false);
    this.errorMessage.set('');
    this.busy.set(true);
    this.claimsService
      .verifyDocument(claim.claimId, document.documentId, {
        status,
        notes: status === 'Rejected' ? notes : notes || null,
        claimRowVersion: claim.rowVersion,
      })
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: () => {
          const title = status === 'Verified' ? 'Document verified' : 'Document rejected';
          const message =
            status === 'Verified'
              ? 'The document was verified successfully.'
              : 'The document was rejected and the reason was saved.';
          this.notifications.success(title, message);
          this.verificationForm.reset({ status: '', notes: '', claimRowVersion: '' });
          this.loadClaim();
        },
        error: (error: unknown) => {
          this.fail(error);
        },
      });
  }
  settle(): void {
    const item = this.claim();
    if (!item) return;
    const request = { claimRowVersion: item.rowVersion };
    const key = this.idem.getOrCreate(IDEMPOTENT_OPERATIONS.claimSettlement, request);
    this.busy.set(true);
    this.claimsService
      .initiateSettlement(item.claimId, request, key)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (value) => {
          this.idem.complete(IDEMPOTENT_OPERATIONS.claimSettlement);
          this.settlement.set(value);
          this.notifications.success(
            'Settlement initiated',
            'The approved claim was sent for settlement.',
          );
          this.loadClaim();
        },
        error: (e) => this.fail(e),
      });
  }
  private patchRows(rowVersion: string): void {
    this.decisionForm.controls.claimRowVersion.setValue(rowVersion);
    this.rejectionForm.controls.claimRowVersion.setValue(rowVersion);
    this.informationForm.controls.claimRowVersion.setValue(rowVersion);
    this.verificationForm.controls.claimRowVersion.setValue(rowVersion);
  }
  private fail(error: unknown): void {
    this.busy.set(false);
    const message =
      error instanceof ApiClientError ? error.message : 'The request could not be completed.';
    this.errorMessage.set(message);
  }
}

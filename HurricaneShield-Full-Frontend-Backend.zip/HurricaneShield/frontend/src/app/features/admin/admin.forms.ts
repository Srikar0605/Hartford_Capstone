
import { FormControl, FormGroup, Validators } from '@angular/forms';

import { SYSTEM_ROLES, type SystemRole } from '../../core/constants/roles';
import { HurricaneValidators } from '../../shared/validators/hurricane.validators';

/**
 * Filter form for customer account administration.
 */
export function createCustomerAdministrationSearchForm() {
  return new FormGroup({
    search: new FormControl('', {
      nonNullable: true,
      validators: [Validators.maxLength(255)],
    }),
    status: new FormControl('', {
      nonNullable: true,
    }),
  });
}

/**
 * Form for assigning or modifying user roles (RBAC).
 * Enforces valid user GUID format and valid SystemRole selection.
 */
export function createRoleAssignmentForm() {
  return new FormGroup({
    userId: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required, HurricaneValidators.guid],
    }),
    roleName: new FormControl<SystemRole>(SYSTEM_ROLES.customer, {
      nonNullable: true,
      validators: [Validators.required],
    }),
  });
}

/**
 * Search and filter form for managing platform identity records across roles and activation states.
 */
export function createAuthUserSearchForm() {
  return new FormGroup({
    search: new FormControl('', {
      nonNullable: true,
      validators: [Validators.maxLength(255)],
    }),
    role: new FormControl<SystemRole | ''>('', { nonNullable: true }),
    isActive: new FormControl('', { nonNullable: true }),
  });
}

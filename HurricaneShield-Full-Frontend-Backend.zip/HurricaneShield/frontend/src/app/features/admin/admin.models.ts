
import type { CustomerStatus } from '../../core/constants/statuses';
import type { SystemRole } from '../../core/constants/roles';
import type { ApiDate, ApiDateTime, Guid, RowVersion } from '../../core/models/api.models';
import type { PageRequest } from '../../core/models/pagination.models';

export interface CustomerAdministrationSearchRequest extends PageRequest {
  search?: string;
  status?: CustomerStatus;
}

export interface CustomerSearchItemResponse {
  customerId: Guid;
  firstName: string;
  lastName: string;
  email: string;
  dateOfBirth: ApiDate;
  status: CustomerStatus;
  createdAt: ApiDateTime;
  rowVersion: RowVersion;
}

export interface CustomerAdministrationResponse {
  customerId: Guid;
  authUserId: Guid;
  firstName: string;
  lastName: string;
  email: string;
  dateOfBirth: ApiDate;
  status: CustomerStatus;
  addressCount: number;
  emergencyContactCount: number;
  propertyCount: number;
  createdAt: ApiDateTime;
  updatedAt: ApiDateTime | null;
  rowVersion: RowVersion;
}

export interface CustomerStatusMutationResponse {
  customerId: Guid;
  status: CustomerStatus;
  customerRowVersion: RowVersion;
}

export interface RoleAssignmentFormValue {
  userId: Guid;
  roleName: SystemRole;
}

export interface AuthUserSearchRequest extends PageRequest {
  search?: string;
  role?: SystemRole;
  isActive?: boolean;
}

export interface AuthUserSummaryResponse {
  userId: Guid;
  firstName: string;
  lastName: string;
  email: string;
  roleNames: string[];
  currentRoleName: SystemRole | null;
  hasMultipleRoles: boolean;
  isActive: boolean;
  createdAt: ApiDateTime;
  updatedAt: ApiDateTime | null;
}


import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';

import { AuthService } from '../../core/auth/auth.service';
import { API_HEADERS, API_ROUTES } from '../../core/constants/api-routes';
import type { SystemRole } from '../../core/constants/roles';
import type { ApiResponse } from '../../core/models/api.models';
import type { PagedResponse } from '../../core/models/pagination.models';
import { apiUrl } from '../../core/services/api-url';
import { toHttpParams } from '../../core/services/http-params';
import type {
  CustomerAdministrationResponse,
  CustomerAdministrationSearchRequest,
  CustomerSearchItemResponse,
  CustomerStatusMutationResponse,
  AuthUserSearchRequest,
  AuthUserSummaryResponse,
} from './admin.models';

/**
 * Service orchestrating administrative tasks across Customer and Auth microservices.
 * Coordinates user discovery, role management, and customer account activation/deactivation.
 */
@Injectable({ providedIn: 'root' })
export class AdminService {
  private readonly http = inject(HttpClient);
  private readonly authService = inject(AuthService);

  searchCustomers(request: CustomerAdministrationSearchRequest = {}): Observable<PagedResponse<CustomerSearchItemResponse>> {
    return this.http
      .get<ApiResponse<PagedResponse<CustomerSearchItemResponse>>>(apiUrl(API_ROUTES.customers.root), {
        params: toHttpParams({ ...request }),
      })
      .pipe(map(response => response.data));
  }

  getCustomer(customerId: string): Observable<CustomerAdministrationResponse> {
    return this.http
      .get<ApiResponse<CustomerAdministrationResponse>>(apiUrl(API_ROUTES.customers.byId(customerId)))
      .pipe(map(response => response.data));
  }

  /**
   * Activates a customer account with optimistic concurrency protection.
   */
  activateCustomer(customerId: string, rowVersion: string): Observable<CustomerStatusMutationResponse> {
    return this.postCustomerStatus(API_ROUTES.customers.activate(customerId), rowVersion);
  }

  /**
   * Deactivates a customer account with optimistic concurrency protection.
   */
  deactivateCustomer(customerId: string, rowVersion: string): Observable<CustomerStatusMutationResponse> {
    return this.postCustomerStatus(API_ROUTES.customers.deactivate(customerId), rowVersion);
  }

  searchUsers(request: AuthUserSearchRequest = {}): Observable<PagedResponse<AuthUserSummaryResponse>> {
    return this.http
      .get<ApiResponse<PagedResponse<AuthUserSummaryResponse>>>(apiUrl(API_ROUTES.auth.users), {
        params: toHttpParams({ ...request }),
      })
      .pipe(map(response => response.data));
  }

  /**
   * Delegates role assignments to the core AuthService which maintains JWT and claim definitions.
   */
  assignRole(userId: string, roleName: SystemRole): Observable<void> {
    return this.authService.assignRole(userId, roleName);
  }

  /**
   * Sets the X-Row-Version header to prevent race conditions during account status mutations.
   */
  private postCustomerStatus(route: string, rowVersion: string): Observable<CustomerStatusMutationResponse> {
    const headers = new HttpHeaders().set(API_HEADERS.rowVersion, rowVersion);
    return this.http
      .post<ApiResponse<CustomerStatusMutationResponse>>(apiUrl(route), null, { headers })
      .pipe(map(response => response.data));
  }
}

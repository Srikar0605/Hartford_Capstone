
import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';
import { ActivatedRoute, provideRouter } from '@angular/router';
import { of } from 'rxjs';
import { AdminConnectedPageComponent } from './admin-connected-page.component';

describe('AdminConnectedPageComponent',()=>{beforeEach(async()=>{await TestBed.configureTestingModule({imports:[AdminConnectedPageComponent],providers:[provideRouter([]),provideHttpClient(),provideHttpClientTesting(),{provide:ActivatedRoute,useValue:{data:of({pageKey:'admin.customer-search'}),snapshot:{paramMap:{get:()=>null},queryParamMap:{get:()=>null}}}}]}).compileComponents();});it('creates',()=>{expect(TestBed.createComponent(AdminConnectedPageComponent).componentInstance).toBeTruthy();});});

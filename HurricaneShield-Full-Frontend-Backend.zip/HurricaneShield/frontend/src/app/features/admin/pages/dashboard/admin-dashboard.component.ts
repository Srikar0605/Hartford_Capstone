
import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  OnDestroy,
  OnInit,
  ViewChild,
  inject,
  signal,
  effect,
} from '@angular/core';
import { CommonModule, CurrencyPipe, PercentPipe, DecimalPipe } from '@angular/common';
import { SystemDashboardService, DashboardMetricsResponse } from '../../../../core/services/system-dashboard.service';
import { KpiCardComponent } from '../../../../shared/components/kpi-card/kpi-card.component';
import { ErrorStateComponent } from '../../../../shared/components/error-state/error-state.component';
import { LoadingStateComponent } from '../../../../shared/components/loading-state/loading-state.component';
import Chart from 'chart.js/auto';

// N2 chart typography: match the app's Manrope body font and warm neutral text.
Chart.defaults.font.family = "'Manrope', 'Segoe UI', Arial, sans-serif";
Chart.defaults.color = '#625250';
Chart.defaults.borderColor = '#f1e7e3';

import { StatusBadgeComponent } from '../../../../shared/components/status-badge/status-badge.component';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [StatusBadgeComponent, CommonModule, KpiCardComponent, ErrorStateComponent, LoadingStateComponent, CurrencyPipe, PercentPipe, DecimalPipe],
  templateUrl: './admin-dashboard.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AdminDashboardPageComponent implements OnInit, OnDestroy {
  private dashboardService = inject(SystemDashboardService);

  activeTab = signal<'business' | 'operations'>('business');
  loading = signal(true);
  error = signal<string | null>(null);
  metrics = signal<DashboardMetricsResponse | null>(null);

  // Canvas ViewChildren
  @ViewChild('operatingMarginChart') operatingMarginCanvas!: ElementRef<HTMLCanvasElement>;
  @ViewChild('riskExposureChart') riskExposureCanvas!: ElementRef<HTMLCanvasElement>;
  @ViewChild('policyChurnChart') policyChurnCanvas!: ElementRef<HTMLCanvasElement>;
  @ViewChild('claimsStatusChart') claimsStatusCanvas!: ElementRef<HTMLCanvasElement>;
  
  @ViewChild('latencyDistributionChart') latencyDistributionCanvas!: ElementRef<HTMLCanvasElement>;
  @ViewChild('trafficCorrelationChart') trafficCorrelationCanvas!: ElementRef<HTMLCanvasElement>;

  // Chart Instances
  private charts: Chart[] = [];

  constructor() {
    // Redraw charts when tab changes if data is loaded
    effect(() => {
      const tab = this.activeTab();
      const data = this.metrics();
      if (data) {
        // Slight timeout to allow DOM to render the canvas elements after tab switch
        setTimeout(() => this.renderCharts(), 50);
      }
    });
  }

  ngOnInit() {
    this.dashboardService.getMetrics().subscribe({
      next: (data) => {
        this.metrics.set(data);
        this.loading.set(false);
      },
      error: () => {
        this.error.set('Failed to load dashboard metrics.');
        this.loading.set(false);
      }
    });
  }

  ngOnDestroy() {
    this.destroyCharts();
  }

  setTab(tab: 'business' | 'operations') {
    this.activeTab.set(tab);
  }

  private destroyCharts() {
    this.charts.forEach(c => c.destroy());
    this.charts = [];
  }

  private renderCharts() {
    this.destroyCharts();
    const data = this.metrics();
    if (!data) return;

    if (this.activeTab() === 'business') {
      this.renderBusinessCharts(data.business);
    } else {
      this.renderOperationsCharts(data.operations);
    }
  }

  private renderBusinessCharts(business: DashboardMetricsResponse['business']) {
    // 1. Operating Margin (Combo)
    if (this.operatingMarginCanvas) {
      this.charts.push(new Chart(this.operatingMarginCanvas.nativeElement, {
        type: 'bar',
        data: {
          labels: business.operatingMargin.map(x => x.month),
          datasets: [
            {
              type: 'line',
              label: 'Claims Paid',
              data: business.operatingMargin.map(x => x.claimsPaid),
              borderColor: '#d08a1e', // amber accent
              backgroundColor: '#d08a1e',
              borderWidth: 2,
              tension: 0.3
            },
            {
              type: 'bar',
              label: 'Gross Written Premium',
              data: business.operatingMargin.map(x => x.gwp),
              backgroundColor: '#6a040f', // brand rosewood
            }
          ]
        },
        options: { responsive: true, maintainAspectRatio: false }
      }));
    }

    // 2. Risk Exposure (Doughnut)
    if (this.riskExposureCanvas) {
      this.charts.push(new Chart(this.riskExposureCanvas.nativeElement, {
        type: 'doughnut',
        data: {
          labels: business.riskExposure.map(x => x.riskZone),
          datasets: [{
            data: business.riskExposure.map(x => x.policyCount),
            backgroundColor: ['#400106', '#82222a', '#c27a73', '#ebcac6', '#a8958f']
          }]
        },
        options: { responsive: true, maintainAspectRatio: false }
      }));
    }

    // 3. Policy Churn (Stacked Bar)
    if (this.policyChurnCanvas) {
      this.charts.push(new Chart(this.policyChurnCanvas.nativeElement, {
        type: 'bar',
        data: {
          labels: business.policyChurn.map(x => x.month),
          datasets: [
            {
              label: 'New Policies',
              data: business.policyChurn.map(x => x.newPolicies),
              backgroundColor: '#6a040f', // brand rosewood
            },
            {
              label: 'Cancelled',
              data: business.policyChurn.map(x => -x.cancelledPolicies), // Negative for inverse stacking effect visually
              backgroundColor: '#d08a1e', // amber accent
            }
          ]
        },
        options: { 
          responsive: true, 
          maintainAspectRatio: false,
          scales: { x: { stacked: true }, y: { stacked: true } }
        }
      }));
    }

    // 4. Claims Status (Polar Area)
    if (this.claimsStatusCanvas) {
      this.charts.push(new Chart(this.claimsStatusCanvas.nativeElement, {
        type: 'polarArea',
        data: {
          labels: business.claimsStatus.map(x => x.status),
          datasets: [{
            data: business.claimsStatus.map(x => x.count),
            backgroundColor: ['#c27a73', '#d08a1e', '#2f6b3e', '#82222a', '#a8958f']
          }]
        },
        options: { responsive: true, maintainAspectRatio: false }
      }));
    }
  }

  private renderOperationsCharts(ops: DashboardMetricsResponse['operations']) {
    // 5. Latency Distribution
    if (this.latencyDistributionCanvas) {
      this.charts.push(new Chart(this.latencyDistributionCanvas.nativeElement, {
        type: 'bar',
        data: {
          labels: ops.serviceHealth.map(x => x.serviceName),
          datasets: [
            { label: 'P50', data: ops.serviceHealth.map(x => x.p50Latency), backgroundColor: '#ebcac6' },
            { label: 'P90', data: ops.serviceHealth.map(x => x.p90Latency), backgroundColor: '#c27a73' },
            { label: 'P99', data: ops.serviceHealth.map(x => x.p99Latency), backgroundColor: '#6a040f' }
          ]
        },
        options: { responsive: true, maintainAspectRatio: false }
      }));
    }

    // 6. Traffic Correlation
    if (this.trafficCorrelationCanvas) {
      this.charts.push(new Chart(this.trafficCorrelationCanvas.nativeElement, {
        type: 'line',
        data: {
          labels: ops.trafficCorrelation.map(x => x.timeLabel),
          datasets: [
            {
              label: 'Requests/min',
              data: ops.trafficCorrelation.map(x => x.requests),
              borderColor: '#6a040f',
              backgroundColor: 'rgba(106, 4, 15, 0.08)',
              fill: true,
              yAxisID: 'y'
            },
            {
              label: 'Errors/min',
              data: ops.trafficCorrelation.map(x => x.errors),
              borderColor: '#d08a1e',
              backgroundColor: 'rgba(208, 138, 30, 0.12)',
              fill: true,
              yAxisID: 'y1'
            }
          ]
        },
        options: { 
          responsive: true, 
          maintainAspectRatio: false,
          scales: {
            y: { type: 'linear', position: 'left' },
            y1: { type: 'linear', position: 'right', grid: { drawOnChartArea: false } }
          }
        }
      }));
    }
  }
}

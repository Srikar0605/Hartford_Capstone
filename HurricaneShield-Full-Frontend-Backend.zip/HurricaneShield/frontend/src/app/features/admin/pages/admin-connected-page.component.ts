

import { CommonModule } from '@angular/common';
import {
  ChangeDetectionStrategy,
  Component,
  OnDestroy,
  OnInit,
  inject,
  signal,
} from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { Subject, takeUntil } from 'rxjs';

import { ALL_SYSTEM_ROLES, SYSTEM_ROLES, type SystemRole } from '../../../core/constants/roles';
import { CUSTOMER_STATUSES, type CustomerStatus } from '../../../core/constants/statuses';
import { ApiClientError } from '../../../core/interceptors/error.interceptor';
import type { PagedResponse } from '../../../core/models/pagination.models';
import { NotificationService } from '../../../core/services/notification.service';
import {
  createAuthUserSearchForm,
  createCustomerAdministrationSearchForm,
  createRoleAssignmentForm,
} from '../admin.forms';
import type {
  AuthUserSummaryResponse,
  CustomerAdministrationResponse,
  CustomerSearchItemResponse,
} from '../admin.models';
import { AdminService } from '../admin.service';

import { FormFieldErrorComponent } from '../../../shared/components/form-field-error/form-field-error.component';

import { StatusBadgeComponent } from '../../../shared/components/status-badge/status-badge.component';
import { IconComponent } from '../../../shared/components/icon/icon.component';
import { SlideOverComponent } from '../../../shared/components/slide-over/slide-over.component';

@Component({
  selector: 'app-admin-connected-page',
  standalone: true,
  imports: [StatusBadgeComponent, IconComponent, SlideOverComponent, CommonModule, ReactiveFormsModule, RouterLink,
    FormFieldErrorComponent
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl:
  './admin-connected-page.component.html',
})
export class AdminConnectedPageComponent implements OnInit, OnDestroy {
  private readonly route = inject(ActivatedRoute);
  private readonly admin = inject(AdminService);
  private readonly notifications = inject(NotificationService);
  private readonly destroy$ = new Subject<void>();
  readonly pageKey = signal('admin.customer-search');
  readonly busy = signal(false);
  readonly errorMessage = signal('');
  /** Row opened in the quick-view panel (UI state only). */
  readonly quickViewCustomer = signal<CustomerSearchItemResponse | null>(null);
  readonly customers = signal<PagedResponse<CustomerSearchItemResponse>>({
    items: [],
    page: 1,
    pageSize: 20,
    totalCount: 0,
    totalPages: 0,
  });
  readonly customer = signal<CustomerAdministrationResponse | null>(null);
  readonly users = signal<PagedResponse<AuthUserSummaryResponse>>({
    items: [],
    page: 1,
    pageSize: 20,
    totalCount: 0,
    totalPages: 0,
  });
  readonly selectedUser = signal<AuthUserSummaryResponse | null>(null);
  readonly customerSearchForm = createCustomerAdministrationSearchForm();
  readonly userSearchForm = createAuthUserSearchForm();
  readonly roleForm = createRoleAssignmentForm();
  readonly customerStatuses = CUSTOMER_STATUSES;
  readonly roles = ALL_SYSTEM_ROLES;
  readonly title = () =>
    ({
      'admin.customer-search': 'Customer Search',
      'admin.customer-details': 'Customer Details',
      'admin.role-assignment': 'User and Role Administration',
    })[this.pageKey()] ?? 'Administration';
  readonly description = () =>
    this.pageKey() === 'admin.role-assignment'
      ? 'Search every Auth user and replace the selected user role.'
      : 'Search and manage Customer accounts.';
  ngOnInit() {
    this.route.data.pipe(takeUntil(this.destroy$)).subscribe((data) => {
      this.pageKey.set(String(data['pageKey'] ?? 'admin.customer-search'));
      this.loadPage();
    });
  }
  ngOnDestroy() {
    this.destroy$.next();
    this.destroy$.complete();
  }
  loadPage() {
    this.errorMessage.set('');
    if (this.pageKey() === 'admin.customer-search') this.loadCustomers(1);
    else if (this.pageKey() === 'admin.customer-details') this.loadCustomer();
    else this.loadUsers(1);
  }
  searchCustomers() {
    this.loadCustomers(1);
  }
  resetCustomerSearch() {
    this.customerSearchForm.reset({ search: '', status: '' });
    this.loadCustomers(1);
  }
  loadCustomers(page: number) {
    const v = this.customerSearchForm.getRawValue();
    this.busy.set(true);
    this.admin
      .searchCustomers({
        page,
        pageSize: 20,
        search: v.search.trim() || undefined,
        status: (v.status as CustomerStatus) || undefined,
      })
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (x) => {
          this.customers.set(x);
          this.busy.set(false);
        },
        error: (e) => this.fail(e),
      });
  }
  loadCustomer() {
    const id = this.route.snapshot.paramMap.get('customerId');
    if (!id) return;
    this.busy.set(true);
    this.admin
      .getCustomer(id)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (x) => {
          this.customer.set(x);
          this.busy.set(false);
        },
        error: (e) => this.fail(e),
      });
  }
  toggleCustomerFromList(item: CustomerSearchItemResponse) {
    this.mutateCustomer(item.customerId, item.rowVersion, item.status === 'Active');
  }
  toggleCustomerDetails() {
    const x = this.customer();
    if (x) this.mutateCustomer(x.customerId, x.rowVersion, x.status === 'Active', true);
  }
  mutateCustomer(id: string, rowVersion: string, deactivate: boolean, details = false) {
    this.busy.set(true);
    const call = deactivate
      ? this.admin.deactivateCustomer(id, rowVersion)
      : this.admin.activateCustomer(id, rowVersion);
    call.pipe(takeUntil(this.destroy$)).subscribe({
      next: () => {
        this.busy.set(false);
        if (details) {
          this.loadCustomer();
        } else {
          this.loadCustomers(this.customers().page);
        }
      },
      error: (e) => this.fail(e),
    });
  }
  searchUsers() {
    if (this.userSearchForm.invalid) return;
    this.loadUsers(1);
  }
  resetUserSearch() {
    this.userSearchForm.reset({ search: '', role: '', isActive: '' });
    this.selectedUser.set(null);
    this.loadUsers(1);
  }
  loadUsers(page: number) {
    const v = this.userSearchForm.getRawValue();
    const requested = this.route.snapshot.queryParamMap.get('userId');
    this.busy.set(true);
    this.admin
      .searchUsers({
        page,
        pageSize: 20,
        search: v.search.trim() || undefined,
        role: (v.role || undefined) as SystemRole | undefined,
        isActive: v.isActive === '' ? undefined : v.isActive === 'true',
      })
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (x) => {
          this.users.set(x);
          this.busy.set(false);
          const selected = this.selectedUser();
          const match = x.items.find((u) => u.userId === (requested || selected?.userId));
          if (match) this.selectUser(match);
        },
        error: (e) => this.fail(e),
      });
  }
  selectUser(item: AuthUserSummaryResponse) {
    this.selectedUser.set(item);
    this.roleForm.setValue({
      userId: item.userId,
      roleName: item.currentRoleName ?? SYSTEM_ROLES.customer,
    });
    this.roleForm.markAsPristine();
  }
  roleLabel(item: AuthUserSummaryResponse) {
    return item.hasMultipleRoles ? item.roleNames.join(', ') : (item.currentRoleName ?? 'No role');
  }
  updateRole() {
    const user = this.selectedUser();
    if (!user || this.roleForm.invalid || this.busy()) return;
    const v = this.roleForm.getRawValue();
    this.busy.set(true);
    this.admin
      .assignRole(user.userId, v.roleName)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: () => {
          this.notifications.success(
            'Role updated',
            `The role was changed to ${v.roleName}. The user must sign in again.`,
          );
          this.busy.set(false);
          this.loadUsers(this.users().page);
        },
        error: (e) => this.fail(e),
      });
  }
  hasUnsavedChanges() {
    return this.roleForm.dirty;
  }
  private fail(error: unknown) {
    this.busy.set(false);
    this.errorMessage.set(
      error instanceof ApiClientError ? error.message : 'The request could not be completed.',
    );
  }
}

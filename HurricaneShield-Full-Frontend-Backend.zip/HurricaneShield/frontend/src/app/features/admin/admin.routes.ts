
import type { Routes } from '@angular/router';

import { authGuard } from '../../core/guards/auth.guard';
import { permissionGuard } from '../../core/guards/permission.guard';
import { roleGuard } from '../../core/guards/role.guard';
import { unsavedChangesGuard } from '../../core/guards/unsaved-changes.guard';
import { SYSTEM_PERMISSIONS } from '../../core/constants/permissions';
import { SYSTEM_ROLES } from '../../core/constants/roles';
import { placeholderRoute } from '../../core/routing/route-helpers';
import { AdminDashboardPageComponent } from './pages/dashboard/admin-dashboard.component';

const administratorOnly = [SYSTEM_ROLES.administrator] as const;

export const adminRoutes: Routes = [
  {
    path: 'admin/dashboard',
    title: 'System Dashboard',
    component: AdminDashboardPageComponent,
    canActivate: [authGuard, roleGuard],
    data: { roles: administratorOnly },
  },
  placeholderRoute({
    path: 'admin/customers/search',
    title: 'Customer Search',
    pageKey: 'admin.customer-search',
    canActivate: [authGuard, roleGuard],
    data: { roles: administratorOnly },
  }),
  placeholderRoute({
    path: 'admin/customers/:customerId',
    title: 'Customer Details',
    pageKey: 'admin.customer-details',
    canActivate: [authGuard, roleGuard],
    data: { roles: administratorOnly },
  }),
  placeholderRoute({
    path: 'admin/roles/assign',
    title: 'Role Assignment',
    pageKey: 'admin.role-assignment',
    canActivate: [authGuard, roleGuard, permissionGuard],
    canDeactivate: [unsavedChangesGuard],
    data: {
      roles: administratorOnly,
      permissions: [SYSTEM_PERMISSIONS.manageRoles],
    },
  }),
  placeholderRoute({
    path: 'admin/plans/list',
    title: 'Plan Administration',
    pageKey: 'admin.plan-list',
    canActivate: [authGuard, roleGuard, permissionGuard],
    data: {
      roles: administratorOnly,
      permissions: [SYSTEM_PERMISSIONS.managePlans],
    },
  }),
  placeholderRoute({
    path: 'admin/plans/create',
    title: 'Create Plan',
    pageKey: 'admin.plan-create',
    canActivate: [authGuard, roleGuard, permissionGuard],
    canDeactivate: [unsavedChangesGuard],
    data: {
      roles: administratorOnly,
      permissions: [SYSTEM_PERMISSIONS.managePlans],
    },
  }),
  placeholderRoute({
    path: 'admin/plans/coverage-types',
    title: 'Coverage Types',
    pageKey: 'admin.coverage-types',
    canActivate: [authGuard, roleGuard, permissionGuard],
    data: {
      roles: administratorOnly,
      permissions: [SYSTEM_PERMISSIONS.managePlans],
    },
  }),
  placeholderRoute({
    path: 'admin/plans/coverage-types/new',
    title: 'Create Coverage Type',
    pageKey: 'admin.coverage-type-create',
    canActivate: [authGuard, roleGuard, permissionGuard],
    canDeactivate: [unsavedChangesGuard],
    data: {
      roles: administratorOnly,
      permissions: [SYSTEM_PERMISSIONS.managePlans],
    },
  }),
  placeholderRoute({
    path: 'admin/plans/coverage-types/:coverageTypeId/edit',
    title: 'Edit Coverage Type',
    pageKey: 'admin.coverage-type-edit',
    canActivate: [authGuard, roleGuard, permissionGuard],
    canDeactivate: [unsavedChangesGuard],
    data: {
      roles: administratorOnly,
      permissions: [SYSTEM_PERMISSIONS.managePlans],
    },
  }),
  placeholderRoute({
    path: 'admin/plans/:planId/coverages',
    title: 'Plan Coverage Assignment',
    pageKey: 'admin.plan-coverages',
    canActivate: [authGuard, roleGuard, permissionGuard],
    canDeactivate: [unsavedChangesGuard],
    data: {
      roles: administratorOnly,
      permissions: [SYSTEM_PERMISSIONS.managePlans],
    },
  }),
  placeholderRoute({
    path: 'admin/plans/:planId/edit',
    title: 'Edit Plan',
    pageKey: 'admin.plan-edit',
    canActivate: [authGuard, roleGuard, permissionGuard],
    canDeactivate: [unsavedChangesGuard],
    data: {
      roles: administratorOnly,
      permissions: [SYSTEM_PERMISSIONS.managePlans],
    },
  }),
  placeholderRoute({
    path: 'admin/payments/search',
    title: 'Transaction Search',
    pageKey: 'admin.payment-search',
    canActivate: [authGuard, roleGuard],
    data: { roles: administratorOnly },
  }),
  placeholderRoute({
    path: 'admin/payments/:transactionId',
    title: 'Administrative Transaction Details',
    pageKey: 'admin.payment-details',
    canActivate: [authGuard, roleGuard],
    data: { roles: administratorOnly },
  }),
  placeholderRoute({
    path: 'admin/payments/:transactionId/receipt',
    title: 'Administrative Payment Receipt',
    pageKey: 'payments.receipt',
    canActivate: [authGuard, roleGuard],
    data: { roles: administratorOnly },
  }),
];

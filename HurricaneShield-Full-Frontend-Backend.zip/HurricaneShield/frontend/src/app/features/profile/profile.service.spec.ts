
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { afterEach, beforeEach, describe, expect, it } from 'vitest';

import { API_ROUTES } from '../../core/constants/api-routes';
import { apiUrl } from '../../core/services/api-url';
import type { AddressSuggestion } from './profile.models';
import { ProfileService } from './profile.service';

describe('ProfileService', () => {
  let service: ProfileService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting(), ProfileService],
    });
    service = TestBed.inject(ProfileService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('queries autocomplete endpoint with query param and unwraps response data', () => {
    const mockSuggestions: AddressSuggestion[] = [
      {
        displayName: '100 Biscayne Blvd, Miami, FL 33132',
        addressLine1: '100 Biscayne Blvd',
        city: 'Miami',
        state: 'Florida',
        postalCode: '33132',
        country: 'United States',
      },
    ];

    let actual: AddressSuggestion[] | undefined;
    service.searchAddressAutocomplete('100 Biscayne').subscribe((results) => {
      actual = results;
    });

    const req = httpMock.expectOne((request) => {
      return (
        request.url === apiUrl(API_ROUTES.customers.addressAutocomplete) &&
        request.params.get('query') === '100 Biscayne'
      );
    });

    expect(req.request.method).toBe('GET');
    req.flush({ success: true, message: 'OK', data: mockSuggestions });

    expect(actual).toEqual(mockSuggestions);
  });
});

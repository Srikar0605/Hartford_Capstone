

import { HttpErrorResponse } from '@angular/common/http';
import {
  ChangeDetectionStrategy,
  Component,
  computed,
  DestroyRef,
  inject,
  OnInit,
  signal,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { catchError, debounceTime, distinctUntilChanged, finalize, forkJoin, of, Subject, switchMap } from 'rxjs';

import { AuthService } from '../../../core/auth/auth.service';
import { AuthStore } from '../../../core/auth/auth.store';
import { OWNERSHIP_TYPES, type OwnershipType } from '../../../core/constants/statuses';
import { ApiClientError } from '../../../core/interceptors/error.interceptor';
import { NotificationService } from '../../../core/services/notification.service';
import { ConcurrencyDialogComponent } from '../../../shared/components/concurrency-dialog/concurrency-dialog.component';
import { EmptyStateComponent } from '../../../shared/components/empty-state/empty-state.component';
import { ErrorStateComponent } from '../../../shared/components/error-state/error-state.component';
import { LoadingStateComponent } from '../../../shared/components/loading-state/loading-state.component';
import { PageHeaderComponent } from '../../../shared/components/page-header/page-header.component';
import { StatusBadgeComponent } from '../../../shared/components/status-badge/status-badge.component';
import {
  createAddressForm,
  createCustomerProfileForm,
  createEmergencyContactForm,
  createPropertyOwnershipForm,
  type PropertyOwnershipFormModel,
} from '../profile.forms';
import type {
  AddressRequest,
  AddressResponse,
  AddressSuggestion,
  CustomerProfileResponse,
  EmergencyContactRequest,
  EmergencyContactResponse,
  PropertyOwnershipRequest,
  PropertyOwnershipResponse,
} from '../profile.models';
import { ProfileService } from '../profile.service';
import { PolicyService } from '../../policies/policy.service';

type AddressMutationRequest = AddressRequest & {
  customerRowVersion: string;
};

type EmergencyContactMutationRequest = EmergencyContactRequest & {
  customerRowVersion: string;
};

type PropertyMutationRequest = PropertyOwnershipRequest & {
  customerRowVersion: string;
};

import { FormFieldErrorComponent } from '../../../shared/components/form-field-error/form-field-error.component';
import { IconComponent, type IconName } from '../../../shared/components/icon/icon.component';
import { PropertyMapComponent, type PropertyMapPoint } from '../../../shared/components/property-map/property-map.component';

@Component({
  selector: 'app-profile-connected-page',
  imports: [
    ReactiveFormsModule,
    RouterLink,
    PageHeaderComponent,
    StatusBadgeComponent,
    LoadingStateComponent,
    EmptyStateComponent,
    ErrorStateComponent,
    ConcurrencyDialogComponent,
    FormFieldErrorComponent,
    IconComponent,
    PropertyMapComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './profile-connected-page.component.html',
  styles: [
    `
      .card,
      .form-card {
        border: 1px solid rgb(64 1 6 / 0.06);
        border-radius: 1.25rem;
        box-shadow: var(--shadow-soft);
        background: white;
        padding: 1.5rem;
      }
      .form-card {
        display: flex;
        flex-direction: column;
        gap: 1rem;
      }
      .form-card label {
        color: #2a0a0d;
        font-size: 0.875rem;
        font-weight: 600;
      }
      .field {
        display: block;
        width: 100%;
        margin-top: 0.35rem;
        border: 1px solid #dacbc5;
        border-radius: 0.75rem;
        padding: 0.65rem 0.75rem;
        background: white;
        font-weight: 400;
      }
      .section-title {
        color: #2a0a0d;
        font-size: 1.1rem;
        font-weight: 700;
      }
      .primary-button {
        display: inline-flex;
        justify-content: center;
        border-radius: 999px;
        background: #400106;
        padding: 0.65rem 1rem;
        color: white;
        font-size: 0.875rem;
        font-weight: 700;
      }
      .secondary-button {
        border: 1px solid #dacbc5;
        border-radius: 999px;
        padding: 0.55rem 0.9rem;
        color: #400106;
        font-size: 0.875rem;
        font-weight: 700;
      }
      .danger-button {
        border-radius: 999px;
        padding: 0.55rem 0.9rem;
        color: #b91c1c;
        font-size: 0.875rem;
        font-weight: 700;
      }
      .resource-link {
        display: block;
        border-radius: 0.6rem;
        background: #fbf3f2;
        padding: 0.85rem 1rem;
        color: #400106;
        font-weight: 700;
      }
      .details {
        margin-top: 1.25rem;
        display: grid;
        gap: 1rem;
      }
      .details div {
        display: flex;
        justify-content: space-between;
        gap: 1rem;
        border-bottom: 1px solid #f5efeb;
        padding-bottom: 0.7rem;
      }
      .details dt {
        color: #776560;
      }
      .details dd {
        color: #2a0a0d;
        font-weight: 700;
        text-align: right;
      }
    `,
  ],
})
export class ProfileConnectedPageComponent implements OnInit {
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);
  private readonly profiles = inject(ProfileService);
  private readonly auth = inject(AuthService);
  private readonly notifications = inject(NotificationService);
  private readonly policies = inject(PolicyService);
  readonly authStore = inject(AuthStore);
  readonly pageKey = computed(() => String(this.route.snapshot.data['pageKey']));
  readonly title = computed(() => String(this.route.snapshot.data['title']));
  readonly description = computed(
    () =>
      ({
        'profile.create': 'Create the customer profile required for customer operations.',
        'profile.overview': 'Review customer identity and profile resources.',
        'profile.edit': 'Update customer details with concurrency protection.',
        'profile.addresses': 'Manage customer contact locations.',
        'profile.contacts': 'View and add emergency contacts.',
        'profile.properties': 'View and add property ownership records.',
        'profile.security': 'Review account identity and MFA status.',
        'profile.login-activity': 'Review successful and unsuccessful authentication activity.',
        'profile.pending-activation': 'Customer operations remain unavailable until activation.',
      })[this.pageKey()] ?? '',
  );
  readonly loading = signal(false);
  readonly showDisableMfa = signal(false);

  readonly disablingMfa = signal(false);

  readonly disableMfaForm = new FormGroup({
    currentPassword: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required],
    }),

    verificationCode: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required, Validators.pattern(/^\d{6}$/)],
    }),
  });
  readonly busy = signal(false);
  readonly error = signal<string | null>(null);
  readonly profile = signal<CustomerProfileResponse | null>(null);
  readonly addresses = signal<AddressResponse[]>([]);
  readonly contacts = signal<EmergencyContactResponse[]>([]);
  readonly properties = signal<PropertyOwnershipResponse[]>([]);

  /* Profile section navigation (UI only). */
  readonly profileTabs: { key: string; label: string; link: string; icon: IconName }[] = [
    { key: 'profile.overview', label: 'Overview', link: '/profile/overview', icon: 'user' },
    { key: 'profile.addresses', label: 'Addresses', link: '/profile/addresses', icon: 'pin' },
    { key: 'profile.contacts', label: 'Contacts', link: '/profile/contacts', icon: 'phone' },
    { key: 'profile.properties', label: 'Properties', link: '/profile/properties', icon: 'house' },
    { key: 'profile.security', label: 'Security', link: '/profile/security', icon: 'shield-check' },
    { key: 'profile.login-activity', label: 'Login activity', link: '/profile/login-activity', icon: 'activity' },
  ];
  readonly showProfileTabs = computed(() => this.profileTabs.some((tab) => tab.key === this.pageKey() || this.pageKey() === 'profile.edit'));
  readonly selectedPropertyId = signal<string | null>(null);
  readonly propertyMapPoints = computed<PropertyMapPoint[]>(() =>
    this.properties()
      .filter((item) => item.latitude != null && item.longitude != null)
      .map((item) => ({
        id: item.propertyOwnershipId,
        latitude: item.latitude as number,
        longitude: item.longitude as number,
        title: item.addressLine1,
        subtitle: `${item.city}, ${item.state}`,
      })),
  );
  focusProperty(id: string): void {
    this.selectedPropertyId.set(id);
    document.getElementById(`property-${id}`)?.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }
  initials(first?: string | null, last?: string | null): string {
    return `${first?.[0] ?? ''}${last?.[0] ?? ''}`.toUpperCase() || 'HS';
  }
  readonly insuredPropertyIds = signal<Set<string>>(new Set());
  readonly loginActivity = signal<
    ReturnType<AuthService['getLoginActivity']> extends import('rxjs').Observable<infer T>
      ? T
      : never
  >([]);
  readonly editingAddressId = signal<string | null>(null);
  readonly editingPropertyId = signal<string | null>(null);
  readonly concurrencyOpen = signal(false);
  readonly concurrencyCorrelationId = signal<string | null>(null);
  readonly constructionTypes = [
    'ReinforcedConcrete',
    'Concrete',
    'Masonry',
    'WoodFrame',
    'Other',
  ] as const;
  readonly riskZones = ['A', 'B', 'C', 'D', 'E'] as const;

  readonly profileForm = createCustomerProfileForm();
  readonly addressForm = createAddressForm();
  readonly contactForm = createEmergencyContactForm();
  readonly propertyForm: FormGroup<PropertyOwnershipFormModel> = createPropertyOwnershipForm();

  private readonly destroyRef = inject(DestroyRef);
  private readonly addressSearchSubject = new Subject<string>();
  private readonly propertySearchSubject = new Subject<string>();

  readonly addressSearchQuery = signal('');
  readonly addressSuggestions = signal<AddressSuggestion[]>([]);
  readonly addressSearchLoading = signal(false);
  readonly addressAutoPopulated = signal(false);

  readonly propertySearchQuery = signal('');
  readonly propertySuggestions = signal<AddressSuggestion[]>([]);
  readonly propertySearchLoading = signal(false);
  readonly propertyAutoPopulated = signal(false);

  ngOnInit(): void {
    this.setupAddressAutocomplete();
    this.reload();
  }

  private setupAddressAutocomplete(): void {
    this.addressSearchSubject
      .pipe(
        debounceTime(350),
        distinctUntilChanged(),
        switchMap((query) => {
          const trimmed = query?.trim() ?? '';
          if (trimmed.length < 3) {
            this.addressSearchLoading.set(false);
            return of([]);
          }
          this.addressSearchLoading.set(true);
          return this.profiles.searchAddressAutocomplete(trimmed).pipe(
            catchError(() => of([])),
            finalize(() => this.addressSearchLoading.set(false)),
          );
        }),
        takeUntilDestroyed(this.destroyRef),
      )
      .subscribe((suggestions) => {
        this.addressSuggestions.set(suggestions);
      });

    this.propertySearchSubject
      .pipe(
        debounceTime(350),
        distinctUntilChanged(),
        switchMap((query) => {
          const trimmed = query?.trim() ?? '';
          if (trimmed.length < 3) {
            this.propertySearchLoading.set(false);
            return of([]);
          }
          this.propertySearchLoading.set(true);
          return this.profiles.searchAddressAutocomplete(trimmed).pipe(
            catchError(() => of([])),
            finalize(() => this.propertySearchLoading.set(false)),
          );
        }),
        takeUntilDestroyed(this.destroyRef),
      )
      .subscribe((suggestions) => {
        this.propertySuggestions.set(suggestions);
      });
  }

  onAddressSearchInput(event: Event): void {
    const val = (event.target as HTMLInputElement).value;
    this.addressSearchQuery.set(val);
    this.addressSearchSubject.next(val);
  }

  private sanitizePostalCode(code: string | null | undefined): string {
    if (!code) return '';
    const match = code.match(/\b\d{5}\b/);
    if (match) return match[0];
    const digits = code.replace(/\D/g, '');
    return digits.length >= 5 ? digits.slice(0, 5) : code;
  }

  selectAddressSuggestion(suggestion: AddressSuggestion): void {
    this.addressForm.patchValue({
      addressLine1: suggestion.addressLine1,
      city: suggestion.city,
      state: suggestion.state,
      postalCode: this.sanitizePostalCode(suggestion.postalCode),
      country: suggestion.country,
    });
    this.addressSearchQuery.set(suggestion.displayName);
    this.addressSuggestions.set([]);
    this.addressAutoPopulated.set(true);
  }

  clearAddressSuggestions(): void {
    this.addressSuggestions.set([]);
  }

  onPropertySearchInput(event: Event): void {
    const val = (event.target as HTMLInputElement).value;
    this.propertySearchQuery.set(val);
    this.propertySearchSubject.next(val);
  }

  private calculateRiskZoneFromAddress(state?: string, postalCode?: string): string {
    const st = (state || '').trim().toUpperCase();
    const zip = (postalCode || '').trim();

    // Florida Keys, Miami-Dade, Broward, coastal Louisiana, coastal Carolinas, Gulf Coast
    const highRiskPrefixes = ['330', '331', '332', '333', '334', '700', '701', '703', '775', '294', '295', '284'];
    if (highRiskPrefixes.some(prefix => zip.startsWith(prefix))) {
      return 'A'; // Zone A: High-risk coastal hurricane zone
    }

    // Inland Florida, Georgia coast, Texas Gulf, North Carolina inland
    if (st === 'FLORIDA' || st === 'FL' || st === 'LOUISIANA' || st === 'LA') {
      return 'B'; // Zone B: Moderate hurricane impact zone
    }

    if (st === 'TEXAS' || st === 'TX' || st === 'GEORGIA' || st === 'GA' || st === 'SOUTH CAROLINA' || st === 'SC' || st === 'NORTH CAROLINA' || st === 'NC') {
      return 'C'; // Zone C: Low-to-moderate wind zone
    }

    return 'D'; // Zone D: Inland minimal storm hazard
  }

  selectPropertySuggestion(suggestion: AddressSuggestion): void {
    const sanitizedPostal = this.sanitizePostalCode(suggestion.postalCode);
    const assignedZone = this.calculateRiskZoneFromAddress(suggestion.state, sanitizedPostal);

    this.propertyForm.patchValue({
      addressLine1: suggestion.addressLine1,
      city: suggestion.city,
      state: suggestion.state,
      postalCode: sanitizedPostal,
      country: suggestion.country,
      riskZone: assignedZone,
      latitude: suggestion.latitude ?? null,
      longitude: suggestion.longitude ?? null,
    });
    this.propertySearchQuery.set(suggestion.displayName);
    this.propertySuggestions.set([]);
    this.propertyAutoPopulated.set(true);
  }

  clearPropertySuggestions(): void {
    this.propertySuggestions.set([]);
  }

  reload(): void {
    const key = this.pageKey();
    if (key === 'profile.create' || key === 'profile.security') return;
    if (key === 'profile.login-activity') return void this.loadActivity();
    if (key === 'profile.addresses') return void this.loadProfileAndAddresses();
    if (key === 'profile.contacts') return void this.loadContacts();
    if (key === 'profile.properties') return void this.loadProperties();
    this.loadProfile();
  }

  loadProfile(): void {
    this.setLoading(true);
    this.profiles
      .getCurrentProfile()
      .pipe(finalize(() => this.setLoading(false)))
      .subscribe({
        next: (p) => {
          this.profile.set(p);
          if (this.pageKey() === 'profile.edit')
            this.profileForm.setValue({
              firstName: p.firstName,
              lastName: p.lastName,
              dateOfBirth: p.dateOfBirth,
              rowVersion: p.rowVersion,
            });
        },
        error: () => this.error.set('The customer profile could not be loaded.'),
      });
  }

  createProfile(): void {
    if (this.profileForm.invalid || this.busy()) {
      this.profileForm.markAllAsTouched();
      return;
    }
    const v = this.profileForm.getRawValue();
    this.busy.set(true);
    this.profiles
      .createProfile({ firstName: v.firstName, lastName: v.lastName, dateOfBirth: v.dateOfBirth })
      .pipe(finalize(() => this.busy.set(false)))
      .subscribe({
        next: (p) => {
          this.profile.set(p);
          this.profileForm.markAsPristine();
          this.notifications.success(
            'Profile created',
            'The profile is awaiting administrator activation.',
          );
          void this.router.navigateByUrl('/profile/pending-activation');
        },
      });
  }

  disableMfa(): void {
    if (this.disablingMfa()) {
      return;
    }

    if (this.disableMfaForm.invalid) {
      this.disableMfaForm.markAllAsTouched();

      return;
    }

    const request = this.disableMfaForm.getRawValue();

    this.disablingMfa.set(true);

    this.auth
      .disableMfa(request)
      .pipe(finalize(() => this.disablingMfa.set(false)))
      .subscribe({
        next: () => {
          this.authStore.clearSession();

          void this.router.navigateByUrl('/auth/login');
        },

        error: () => {
          this.error.set('MFA could not be disabled. Verify the password and authenticator code.');
        },
      });
  }

  requestPasswordReset(): void {
    const email = this.authStore.currentUser()?.email;
    if (!email) {
      this.notifications.error('Error', 'Unable to determine user email for password reset.');
      return;
    }

    this.busy.set(true);
    this.auth
      .requestPasswordReset({ email })
      .pipe(
        finalize(() => {
          this.busy.set(false);
        })
      )
      .subscribe({
        next: (result) => {
          if (result.developmentToken) {
            this.notifications.success(
              'Reset code generated',
              'Redirecting you to set your new password...',
            );
            void this.router.navigate(['/auth/reset-password'], {
              queryParams: { token: result.developmentToken },
            });
          } else {
            this.notifications.success(
              'Request received',
              'Check your email or enter your code to reset your password.',
            );
            void this.router.navigate(['/auth/reset-password']);
          }
        },
        error: () => {
          this.notifications.error(
            'Request failed',
            'Unable to initiate password reset at this time.',
          );
        },
      });
  }

  updateProfile(): void {
    if (this.profileForm.invalid || this.busy()) {
      this.profileForm.markAllAsTouched();
      return;
    }
    this.busy.set(true);
    this.profiles
      .updateProfile(this.profileForm.getRawValue())
      .pipe(finalize(() => this.busy.set(false)))
      .subscribe({
        next: (p) => {
          this.profile.set(p);
          this.profileForm.markAsPristine();
          this.notifications.success('Profile updated', 'Customer details were saved.');
          void this.router.navigateByUrl('/profile/overview');
        },
        error: (e) => this.handleMutationError(e),
      });
  }

  loadProfileAndAddresses(show = true): void {
    if (show) this.setLoading(true);
    forkJoin({
      profile: this.profiles.getCurrentProfile(),
      addresses: this.profiles.getAddresses(),
    })
      .pipe(
        finalize(() => {
          if (show) this.setLoading(false);
        }),
      )
      .subscribe({
        next: (r) => {
          this.profile.set(r.profile);
          this.addresses.set(Array.isArray(r.addresses) ? r.addresses : []);
          this.addressForm.controls.customerRowVersion.setValue(r.profile.rowVersion);
        },
        error: () => this.error.set('Addresses could not be loaded.'),
      });
  }

  saveAddress(): void {
    if (this.addressForm.invalid || this.busy()) {
      this.addressForm.markAllAsTouched();
      return;
    }
    const v = this.addressForm.getRawValue();
    const request: AddressMutationRequest = {
      addressLine1: v.addressLine1,
      addressLine2: v.addressLine2.trim() || null,
      city: v.city,
      state: v.state,
      postalCode: v.postalCode,
      country: v.country,
      customerRowVersion: v.customerRowVersion,
    };
    const id = this.editingAddressId();
    const req = id ? this.profiles.updateAddress(id, request) : this.profiles.addAddress(request);
    this.busy.set(true);
    req.pipe(finalize(() => this.busy.set(false))).subscribe({
      next: (r) => {
        this.applyRowVersion(r.customerRowVersion);
        this.addressForm.reset({
          addressLine1: '',
          addressLine2: '',
          city: '',
          state: '',
          postalCode: '',
          country: '',
          customerRowVersion: r.customerRowVersion,
        });
        this.editingAddressId.set(null);
        this.addressSearchQuery.set('');
        this.addressSuggestions.set([]);
        this.addressAutoPopulated.set(false);
        this.notifications.success('Address saved', 'The customer address was updated.');
        queueMicrotask(() => this.loadProfileAndAddresses(false));
      },
      error: (e) => this.handleMutationError(e),
    });
  }

  editAddress(a: AddressResponse): void {
    this.editingAddressId.set(a.addressId);
    this.addressSearchQuery.set(a.addressLine1);
    this.addressSuggestions.set([]);
    this.addressAutoPopulated.set(false);
    this.addressForm.setValue({
      addressLine1: a.addressLine1,
      addressLine2: a.addressLine2 ?? '',
      city: a.city,
      state: a.state,
      postalCode: a.postalCode,
      country: a.country,
      customerRowVersion: this.profile()?.rowVersion ?? '',
    });
  }
  cancelAddressEdit(): void {
    this.editingAddressId.set(null);
    this.addressSearchQuery.set('');
    this.addressSuggestions.set([]);
    this.addressAutoPopulated.set(false);
    this.addressForm.reset({
      addressLine1: '',
      addressLine2: '',
      city: '',
      state: '',
      postalCode: '',
      country: '',
      customerRowVersion: this.profile()?.rowVersion ?? '',
    });
  }
  deleteAddress(id: string): void {
    const rv = this.profile()?.rowVersion;
    if (!rv || this.busy() || !window.confirm('Delete this address?')) return;
    this.busy.set(true);
    this.profiles
      .deleteAddress(id, rv)
      .pipe(finalize(() => this.busy.set(false)))
      .subscribe({
        next: (r) => {
          this.applyRowVersion(r.customerRowVersion);
          this.notifications.success('Address deleted', 'The address was removed.');
          queueMicrotask(() => this.loadProfileAndAddresses(false));
        },
        error: (e) => this.handleMutationError(e),
      });
  }

  loadContacts(showPageLoading = true): void {
    if (showPageLoading && this.loading()) {
      return;
    }

    if (showPageLoading) {
      this.setLoading(true);
    } else {
      this.error.set(null);
    }

    forkJoin({
      profile: this.profiles.getCurrentProfile(),

      contacts: this.profiles.getEmergencyContacts(),
    })
      .pipe(
        finalize(() => {
          if (showPageLoading) {
            this.setLoading(false);
          }
        }),
      )
      .subscribe({
        next: (result) => {
          this.profile.set(result.profile);

          this.contacts.set(Array.isArray(result.contacts) ? result.contacts : []);
        },

        error: () => {
          this.contacts.set([]);

          this.error.set('Emergency contacts could not be loaded.');
        },
      });
  }

  addContact(): void {
    if (this.contactForm.invalid || this.busy()) {
      this.contactForm.markAllAsTouched();
      return;
    }
    const rv = this.profile()?.rowVersion;
    if (!rv) {
      this.missingVersion('Contact');
      return;
    }
    const v = this.contactForm.getRawValue();
    const request: EmergencyContactMutationRequest = { ...v, customerRowVersion: rv };
    this.busy.set(true);
    this.profiles
      .addEmergencyContact(request)
      .pipe(finalize(() => this.busy.set(false)))
      .subscribe({
        next: (r) => {
          this.applyRowVersion(r.customerRowVersion);
          this.contactForm.reset({ name: '', relationship: '', phoneNumber: '' });
          this.notifications.success('Contact added', 'The emergency contact was added.');
          queueMicrotask(() => this.loadContacts(false));
        },
        error: (e) => this.handleMutationError(e),
      });
  }

  loadProperties(showPageLoading = true): void {
    if (showPageLoading && this.loading()) {
      return;
    }

    if (showPageLoading) {
      this.setLoading(true);
    } else {
      this.error.set(null);
    }

    forkJoin({
      profile: this.profiles.getCurrentProfile(),
      properties: this.profiles.getProperties(),
      insuredIds: this.policies.getMyInsuredPropertyIds().pipe(catchError(() => of([]))),
    })
      .pipe(
        finalize(() => {
          if (showPageLoading) {
            this.setLoading(false);
          }
        }),
      )
      .subscribe({
        next: (result) => {
          this.profile.set(result.profile);
          this.properties.set(Array.isArray(result.properties) ? result.properties : []);
          this.insuredPropertyIds.set(new Set(result.insuredIds ?? []));
        },

        error: () => {
          this.properties.set([]);
          this.error.set('Properties could not be loaded.');
        },
      });
  }
  addProperty(): void {
    if (this.propertyForm.invalid || this.busy()) {
      this.propertyForm.markAllAsTouched();
      return;
    }
    const rv = this.profile()?.rowVersion;
    if (!rv) {
      this.missingVersion('Property');
      return;
    }
    const v = this.propertyForm.getRawValue();
    if (!OWNERSHIP_TYPES.includes(v.ownershipType as OwnershipType)) {
      this.propertyForm.controls.ownershipType.setErrors({ invalidOwnershipType: true });
      return;
    }
    const request: PropertyMutationRequest = {
      addressLine1: v.addressLine1,
      addressLine2: v.addressLine2.trim() || null,
      city: v.city,
      state: v.state,
      postalCode: v.postalCode,
      country: v.country,
      ownershipType: v.ownershipType as OwnershipType,
      acquiredOn: v.acquiredOn,
      isPrimaryResidence: v.isPrimaryResidence,
      customerRowVersion: rv,
      yearBuilt: v.yearBuilt ? Number(v.yearBuilt) : null,
      constructionType: v.constructionType || null,
      riskZone: v.riskZone || null,
      stormShutters: Boolean(v.stormShutters),
      impactResistantWindows: Boolean(v.impactResistantWindows),
      reinforcedRoof: Boolean(v.reinforcedRoof),
      emergencyGenerator: Boolean(v.emergencyGenerator),
      homeInspectionCertification: Boolean(v.homeInspectionCertification),
      latitude: v.latitude ?? null,
      longitude: v.longitude ?? null,
    };

    const propertyId = this.editingPropertyId();
    if (propertyId) {
      if (this.insuredPropertyIds().has(propertyId)) {
        this.error.set('This property has an active insurance policy and cannot be edited.');
        return;
      }
      this.busy.set(true);
      this.profiles
        .updateProperty(propertyId, request)
        .pipe(finalize(() => this.busy.set(false)))
        .subscribe({
          next: (r) => {
            this.applyRowVersion(r.customerRowVersion);
            this.cancelPropertyEdit();
            this.notifications.success(
              'Property updated',
              'The property ownership record was updated.',
            );
            queueMicrotask(() => this.loadProperties(false));
          },
          error: (e) => this.handleMutationError(e),
        });
      return;
    }

    this.busy.set(true);
    this.profiles
      .addProperty(request)
      .pipe(finalize(() => this.busy.set(false)))
      .subscribe({
        next: (r) => {
          this.applyRowVersion(r.customerRowVersion);
          this.cancelPropertyEdit();
          this.notifications.success('Property added', 'The property ownership record was added.');
          queueMicrotask(() => this.loadProperties(false));
        },
        error: (e) => this.handleMutationError(e),
      });
  }

  editProperty(p: PropertyOwnershipResponse): void {
    if (this.insuredPropertyIds().has(p.propertyOwnershipId)) {
      this.error.set(
        'This property is covered by an active insurance policy and cannot be modified.',
      );
      return;
    }
    this.editingPropertyId.set(p.propertyOwnershipId);
    this.propertySearchQuery.set(p.addressLine1);
    this.propertySuggestions.set([]);
    this.propertyAutoPopulated.set(false);
    this.propertyForm.setValue({
      addressLine1: p.addressLine1,
      addressLine2: p.addressLine2 ?? '',
      city: p.city,
      state: p.state,
      postalCode: p.postalCode,
      country: p.country,
      ownershipType: p.ownershipType,
      acquiredOn: p.acquiredOn,
      isPrimaryResidence: p.isPrimaryResidence,
      yearBuilt: p.yearBuilt ?? null,
      constructionType: p.constructionType ?? 'ReinforcedConcrete',
      riskZone: p.riskZone ?? 'C',
      stormShutters: p.stormShutters ?? false,
      impactResistantWindows: p.impactResistantWindows ?? false,
      reinforcedRoof: p.reinforcedRoof ?? false,
      emergencyGenerator: p.emergencyGenerator ?? false,
      homeInspectionCertification: p.homeInspectionCertification ?? false,
      latitude: p.latitude ?? null,
      longitude: p.longitude ?? null,
    });
  }

  cancelPropertyEdit(): void {
    this.editingPropertyId.set(null);
    this.propertyForm.reset({
      addressLine1: '',
      addressLine2: '',
      city: '',
      state: '',
      postalCode: '',
      country: '',
      ownershipType: 'Owned',
      acquiredOn: '',
      isPrimaryResidence: false,
      yearBuilt: null,
      constructionType: 'ReinforcedConcrete',
      riskZone: 'C',
      stormShutters: false,
      impactResistantWindows: false,
      reinforcedRoof: false,
      emergencyGenerator: false,
      homeInspectionCertification: false,
    });
    this.propertySearchQuery.set('');
    this.propertySuggestions.set([]);
    this.propertyAutoPopulated.set(false);
  }

  loadActivity(): void {
    this.setLoading(true);
    this.auth
      .getLoginActivity()
      .pipe(finalize(() => this.setLoading(false)))
      .subscribe({
        next: (r) => this.loginActivity.set(Array.isArray(r) ? r : []),
        error: () => this.error.set('Login activity could not be loaded.'),
      });
  }
  hasUnsavedChanges(): boolean {
    return (
      this.profileForm.dirty ||
      this.addressForm.dirty ||
      this.contactForm.dirty ||
      this.propertyForm.dirty
    );
  }
  reloadAfterConcurrency(): void {
    this.concurrencyOpen.set(false);
    this.concurrencyCorrelationId.set(null);
    this.reload();
  }
  private setLoading(value: boolean): void {
    this.loading.set(value);
    if (value) this.error.set(null);
  }
  private applyRowVersion(rowVersion: string): void {
    this.profile.update((p) => (p ? { ...p, rowVersion } : p));
  }
  private missingVersion(subject: string): void {
    this.notifications.error(
      `${subject} could not be added`,
      'The current customer version is unavailable. Reload the page and try again.',
      null,
    );
  }
  private handleMutationError(error: unknown): void {
    const status = this.status(error);
    if (status === 409 || status === 412) {
      this.concurrencyCorrelationId.set(
        error instanceof ApiClientError ? error.correlationId : null,
      );
      this.concurrencyOpen.set(true);
      return;
    }
    this.notifications.error(
      'Operation failed',
      'The requested change could not be completed.',
      error instanceof ApiClientError ? error.correlationId : null,
    );
  }
  private status(error: unknown): number | null {
    return error instanceof ApiClientError || error instanceof HttpErrorResponse
      ? error.status
      : null;
  }
}

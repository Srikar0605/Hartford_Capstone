
import type { CustomerStatus, OwnershipType } from '../../core/constants/statuses';
import type { ApiDate, ApiDateTime, Guid, RowVersion } from '../../core/models/api.models';
import type { PageRequest } from '../../core/models/pagination.models';

export interface CreateCustomerProfileRequest {
  firstName: string;
  lastName: string;
  dateOfBirth: ApiDate;
}

export interface UpdateCustomerProfileRequest extends CreateCustomerProfileRequest {
  rowVersion: RowVersion;
}

export interface CustomerProfileResponse {
  customerId: Guid;
  authUserId: Guid;
  firstName: string;
  lastName: string;
  email: string;
  dateOfBirth: ApiDate;
  status: CustomerStatus;
  rowVersion: RowVersion;
}

export interface AddressRequest {
  addressLine1: string;
  addressLine2: string | null;
  city: string;
  state: string;
  postalCode: string;
  country: string;
}

export interface UpdateAddressRequest extends AddressRequest {
  customerRowVersion: RowVersion;
}

export interface AddressResponse extends AddressRequest {
  addressId: Guid;
  createdAt: ApiDateTime;
  updatedAt: ApiDateTime | null;
}

export interface AddressSuggestion {
  displayName: string;
  addressLine1: string;
  city: string;
  state: string;
  postalCode: string;
  country: string;
  latitude?: number | null;
  longitude?: number | null;
}

export interface EmergencyContactRequest {
  name: string;
  relationship: string;
  phoneNumber: string;
}

export interface UpdateEmergencyContactRequest extends EmergencyContactRequest {
  customerRowVersion: RowVersion;
}

export interface EmergencyContactResponse extends EmergencyContactRequest {
  emergencyContactId: Guid;
  createdAt: ApiDateTime;
  updatedAt: ApiDateTime | null;
}

export interface PropertyOwnershipRequest {
  addressLine1: string;
  addressLine2: string | null;
  city: string;
  state: string;
  postalCode: string;
  country: string;
  ownershipType: OwnershipType;
  acquiredOn: ApiDate;
  isPrimaryResidence: boolean;
  yearBuilt?: number | null;
  constructionType?: string | null;
  riskZone?: string | null;
  stormShutters?: boolean;
  impactResistantWindows?: boolean;
  reinforcedRoof?: boolean;
  emergencyGenerator?: boolean;
  homeInspectionCertification?: boolean;
  latitude?: number | null;
  longitude?: number | null;
}

export interface UpdatePropertyOwnershipRequest extends PropertyOwnershipRequest {
  customerRowVersion: RowVersion;
}

export interface PropertyOwnershipResponse {
  propertyOwnershipId: Guid;
  addressLine1: string;
  addressLine2: string | null;
  city: string;
  state: string;
  postalCode: string;
  country: string;
  ownershipType: OwnershipType;
  acquiredOn: ApiDate;
  isPrimaryResidence: boolean;
  createdAt: ApiDateTime;
  updatedAt: ApiDateTime | null;
  yearBuilt: number | null;
  constructionType: string | null;
  riskZone: string | null;
  stormShutters: boolean;
  impactResistantWindows: boolean;
  reinforcedRoof: boolean;
  emergencyGenerator: boolean;
  homeInspectionCertification: boolean;
  latitude: number | null;
  longitude: number | null;
}

export interface CustomerEmergencyContactsSnapshot {
  customerId: Guid;
  emergencyContacts: EmergencyContactResponse[];
}

export interface CustomerPropertiesSnapshot {
  customerId: Guid;
  properties: PropertyOwnershipResponse[];
}

export interface CustomerMutationResult {
  customerRowVersion: RowVersion;
}

export interface CustomerStatusMutationResult {
  customerId: Guid;
  status: CustomerStatus;
  customerRowVersion: RowVersion;
}

export interface CustomerEligibilityResponse {
  customerId: Guid;
  isActive: boolean;
  isAgeEligible: boolean;
  isEligible: boolean;
  reasons: string[];
}

export interface CustomerAdministrationResponse {
  customerId: Guid;
  authUserId: Guid;
  firstName: string;
  lastName: string;
  email: string;
  dateOfBirth: ApiDate;
  status: CustomerStatus;
  addressCount: number;
  emergencyContactCount: number;
  propertyCount: number;
  createdAt: ApiDateTime;
  updatedAt: ApiDateTime | null;
  rowVersion: RowVersion;
}

export interface CustomerSearchItemResponse {
  customerId: Guid;
  firstName: string;
  lastName: string;
  email: string;
  dateOfBirth: ApiDate;
  status: CustomerStatus;
  createdAt: ApiDateTime;
  rowVersion: RowVersion;
}

/** Query shape retained separately because controller binding is query-based. */
export interface CustomerSearchRequest extends PageRequest {
  search?: string;
  status?: CustomerStatus;
}


import type { Routes } from '@angular/router';

import { authGuard } from '../../core/guards/auth.guard';
import { roleGuard } from '../../core/guards/role.guard';
import { unsavedChangesGuard } from '../../core/guards/unsaved-changes.guard';
import { SYSTEM_ROLES } from '../../core/constants/roles';
import { placeholderRoute } from '../../core/routing/route-helpers';

const customerOnly = {
  roles: [SYSTEM_ROLES.customer] as const,
};

export const profileRoutes: Routes = [
  placeholderRoute({
    path: 'profile/create',
    title: 'Create Customer Profile',
    pageKey: 'profile.create',
    canActivate: [authGuard, roleGuard],
    canDeactivate: [unsavedChangesGuard],
    data: customerOnly,
  }),
  placeholderRoute({
    path: 'profile/overview',
    title: 'My Profile',
    pageKey: 'profile.overview',
    canActivate: [authGuard, roleGuard],
    data: customerOnly,
  }),
  placeholderRoute({
    path: 'profile/edit',
    title: 'Edit Profile',
    pageKey: 'profile.edit',
    canActivate: [authGuard, roleGuard],
    canDeactivate: [unsavedChangesGuard],
    data: customerOnly,
  }),
  placeholderRoute({
    path: 'profile/addresses',
    title: 'Addresses',
    pageKey: 'profile.addresses',
    canActivate: [authGuard, roleGuard],
    data: customerOnly,
  }),
  placeholderRoute({
    path: 'profile/contacts',
    title: 'Emergency Contacts',
    pageKey: 'profile.contacts',
    canActivate: [authGuard, roleGuard],
    data: customerOnly,
  }),
  placeholderRoute({
    path: 'profile/properties',
    title: 'My Properties',
    pageKey: 'profile.properties',
    canActivate: [authGuard, roleGuard],
    data: customerOnly,
  }),
  placeholderRoute({
    path: 'profile/security',
    title: 'Account Security',
    pageKey: 'profile.security',
    canActivate: [authGuard],
  }),
  placeholderRoute({
    path: 'profile/login-activity',
    title: 'Login Activity',
    pageKey: 'profile.login-activity',
    canActivate: [authGuard],
  }),
  placeholderRoute({
    path: 'profile/pending-activation',
    title: 'Profile Awaiting Activation',
    pageKey: 'profile.pending-activation',
    canActivate: [authGuard, roleGuard],
    data: customerOnly,
  }),
];

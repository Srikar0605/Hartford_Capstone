
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { HurricaneValidators } from '../../shared/validators/hurricane.validators';

/**
 * Creates the reactive form for managing basic customer identity details.
 * We enforce that dateOfBirth is not in the future and capture rowVersion for concurrency checks.
 */
export function createCustomerProfileForm() {
  return new FormGroup({
    firstName: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required, Validators.maxLength(100)],
    }),
    lastName: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required, Validators.maxLength(100)],
    }),
    dateOfBirth: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required, HurricaneValidators.isoDateNotInFuture],
    }),
    rowVersion: new FormControl('', { nonNullable: true }),
  });
}

/**
 * Creates the form for customer mailing and billing addresses.
 * Enforces standard 5-digit US ZIP code format.
 */
export function createAddressForm() {
  return new FormGroup({
    addressLine1: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required, Validators.maxLength(200)],
    }),
    addressLine2: new FormControl('', {
      nonNullable: true,
      validators: [Validators.maxLength(200)],
    }),
    city: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required, Validators.maxLength(100)],
    }),
    state: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required, Validators.maxLength(100)],
    }),
    postalCode: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required, Validators.pattern(/^\d{5}$/)],
    }),
    country: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required, Validators.maxLength(100)],
    }),
    customerRowVersion: new FormControl('', { nonNullable: true }),
  });
}

/**
 * Creates the emergency contact form used during disaster response coordination.
 */
export function createEmergencyContactForm() {
  return new FormGroup({
    name: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required, Validators.maxLength(150)],
    }),
    relationship: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required, Validators.maxLength(100)],
    }),
    phoneNumber: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required, Validators.maxLength(30)],
    }),
  });
}

export interface PropertyOwnershipFormModel {
  addressLine1: FormControl<string>;
  addressLine2: FormControl<string>;
  city: FormControl<string>;
  state: FormControl<string>;
  postalCode: FormControl<string>;
  country: FormControl<string>;
  ownershipType: FormControl<string>;
  acquiredOn: FormControl<string>;
  isPrimaryResidence: FormControl<boolean>;
  yearBuilt: FormControl<number | null>;
  constructionType: FormControl<string>;
  riskZone: FormControl<string>;
  stormShutters: FormControl<boolean>;
  impactResistantWindows: FormControl<boolean>;
  reinforcedRoof: FormControl<boolean>;
  emergencyGenerator: FormControl<boolean>;
  homeInspectionCertification: FormControl<boolean>;
  latitude: FormControl<number | null>;
  longitude: FormControl<number | null>;
}

/**
 * Creates the property ownership registration form.
 * Captures structural characteristics and hurricane mitigation features (storm shutters, reinforced roof, etc.)
 * to allow accurate risk profiling when applying for policies.
 */
export function createPropertyOwnershipForm(): FormGroup<PropertyOwnershipFormModel> {
  return new FormGroup<PropertyOwnershipFormModel>({
    addressLine1: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required, Validators.maxLength(200)],
    }),
    addressLine2: new FormControl('', {
      nonNullable: true,
      validators: [Validators.maxLength(200)],
    }),
    city: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required, Validators.maxLength(100)],
    }),
    state: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required, Validators.maxLength(100)],
    }),
    postalCode: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required, Validators.pattern(/^\d{5}$/)],
    }),
    country: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required, Validators.maxLength(100)],
    }),
    ownershipType: new FormControl('Owned', {
      nonNullable: true,
      validators: [Validators.required],
    }),
    acquiredOn: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required, HurricaneValidators.isoDateNotInFuture],
    }),
    isPrimaryResidence: new FormControl(false, { nonNullable: true }),
    yearBuilt: new FormControl<number | null>(null, {
      validators: [Validators.min(1800), Validators.max(new Date().getFullYear())],
    }),
    constructionType: new FormControl<string>('ReinforcedConcrete', {
      nonNullable: true,
    }),
    riskZone: new FormControl<string>('C', {
      nonNullable: true,
    }),
    stormShutters: new FormControl(false, { nonNullable: true }),
    impactResistantWindows: new FormControl(false, { nonNullable: true }),
    reinforcedRoof: new FormControl(false, { nonNullable: true }),
    emergencyGenerator: new FormControl(false, { nonNullable: true }),
    homeInspectionCertification: new FormControl(false, { nonNullable: true }),
    latitude: new FormControl<number | null>(null),
    longitude: new FormControl<number | null>(null),
  });
}


import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';

import { API_HEADERS, API_ROUTES } from '../../core/constants/api-routes';
import type { ApiResponse } from '../../core/models/api.models';
import type { PagedResponse } from '../../core/models/pagination.models';
import { apiUrl } from '../../core/services/api-url';
import { toHttpParams } from '../../core/services/http-params';
import type {
  AddressRequest,
  AddressResponse,
  AddressSuggestion,
  CreateCustomerProfileRequest,
  CustomerAdministrationResponse,
  CustomerEligibilityResponse,
  CustomerMutationResult,
  CustomerProfileResponse,
  CustomerSearchItemResponse,
  CustomerSearchRequest,
  CustomerStatusMutationResult,
  EmergencyContactRequest,
  EmergencyContactResponse,
  PropertyOwnershipRequest,
  PropertyOwnershipResponse,
  UpdateAddressRequest,
  UpdateCustomerProfileRequest,
  UpdatePropertyOwnershipRequest,
} from './profile.models';

/**
 * Service managing customer profile, contact, address, and property ownership records
 * with the Customer microservice.
 * Enforces optimistic locking via X-Row-Version on address and property modifications.
 */
@Injectable({
  providedIn: 'root',
})
export class ProfileService {
  private readonly http = inject(HttpClient);

  createProfile(request: CreateCustomerProfileRequest): Observable<CustomerProfileResponse> {
    return this.post<CustomerProfileResponse>(API_ROUTES.customers.root, request);
  }

  getCurrentProfile(): Observable<CustomerProfileResponse> {
    return this.get<CustomerProfileResponse>(API_ROUTES.customers.me);
  }

  updateProfile(request: UpdateCustomerProfileRequest): Observable<CustomerProfileResponse> {
    return this.put<CustomerProfileResponse>(API_ROUTES.customers.me, request);
  }

  getAddresses(): Observable<AddressResponse[]> {
    return this.get<AddressResponse[]>(API_ROUTES.customers.addresses);
  }

  /**
   * Queries the backend geocoding / address autocomplete service to assist customers
   * in entering standardized property and mailing addresses.
   */
  searchAddressAutocomplete(query: string): Observable<AddressSuggestion[]> {
    return this.http
      .get<ApiResponse<AddressSuggestion[]>>(apiUrl(API_ROUTES.customers.addressAutocomplete), {
        params: toHttpParams({ query }),
      })
      .pipe(map((response) => response.data));
  }

  addAddress(request: AddressRequest): Observable<CustomerMutationResult> {
    return this.post<CustomerMutationResult>(API_ROUTES.customers.addresses, request);
  }

  updateAddress(
    addressId: string,
    request: UpdateAddressRequest,
  ): Observable<CustomerMutationResult> {
    return this.put<CustomerMutationResult>(API_ROUTES.customers.address(addressId), request);
  }

  /**
   * Deletes an address while sending the entity rowVersion in the header to ensure
   * concurrent edits are detected before deletion.
   */
  deleteAddress(addressId: string, rowVersion: string): Observable<CustomerMutationResult> {
    const headers = new HttpHeaders().set(API_HEADERS.rowVersion, rowVersion);

    return this.http
      .delete<ApiResponse<CustomerMutationResult>>(
        apiUrl(API_ROUTES.customers.address(addressId)),
        {
          headers,
        },
      )
      .pipe(map((response) => response.data));
  }

  getEmergencyContacts(): Observable<EmergencyContactResponse[]> {
    return this.get<EmergencyContactResponse[]>(API_ROUTES.customers.emergencyContacts);
  }

  addEmergencyContact(request: EmergencyContactRequest): Observable<CustomerMutationResult> {
    return this.post<CustomerMutationResult>(API_ROUTES.customers.emergencyContacts, request);
  }

  getProperties(): Observable<PropertyOwnershipResponse[]> {
    return this.get<PropertyOwnershipResponse[]>(API_ROUTES.customers.properties);
  }

  addProperty(request: PropertyOwnershipRequest): Observable<CustomerMutationResult> {
    return this.post<CustomerMutationResult>(API_ROUTES.customers.properties, request);
  }

  updateProperty(
    propertyId: string,
    request: UpdatePropertyOwnershipRequest,
  ): Observable<CustomerMutationResult> {
    const headers = new HttpHeaders().set(API_HEADERS.rowVersion, request.customerRowVersion);

    return this.http
      .put<ApiResponse<CustomerMutationResult>>(
        apiUrl(API_ROUTES.customers.property(propertyId)),
        request,
        {
          headers,
        },
      )
      .pipe(map((response) => response.data));
  }

  searchCustomers(
    request: CustomerSearchRequest,
  ): Observable<PagedResponse<CustomerSearchItemResponse>> {
    return this.http
      .get<ApiResponse<PagedResponse<CustomerSearchItemResponse>>>(
        apiUrl(API_ROUTES.customers.root),
        {
          params: toHttpParams({
            ...request,
          }),
        },
      )
      .pipe(map((response) => response.data));
  }

  getCustomer(customerId: string): Observable<CustomerAdministrationResponse> {
    return this.get<CustomerAdministrationResponse>(API_ROUTES.customers.byId(customerId));
  }

  getEligibility(customerId: string): Observable<CustomerEligibilityResponse> {
    return this.get<CustomerEligibilityResponse>(API_ROUTES.customers.eligibility(customerId));
  }

  activateCustomer(
    customerId: string,
    rowVersion: string,
  ): Observable<CustomerStatusMutationResult> {
    return this.postWithRowVersion<CustomerStatusMutationResult>(
      API_ROUTES.customers.activate(customerId),
      rowVersion,
    );
  }

  deactivateCustomer(
    customerId: string,
    rowVersion: string,
  ): Observable<CustomerStatusMutationResult> {
    return this.postWithRowVersion<CustomerStatusMutationResult>(
      API_ROUTES.customers.deactivate(customerId),
      rowVersion,
    );
  }

  private get<T>(route: string): Observable<T> {
    return this.http.get<ApiResponse<T>>(apiUrl(route)).pipe(map((response) => response.data));
  }

  private post<T>(route: string, body: unknown): Observable<T> {
    return this.http
      .post<ApiResponse<T>>(apiUrl(route), body)
      .pipe(map((response) => response.data));
  }

  private put<T>(route: string, body: unknown): Observable<T> {
    return this.http
      .put<ApiResponse<T>>(apiUrl(route), body)
      .pipe(map((response) => response.data));
  }

  private postWithRowVersion<T>(route: string, rowVersion: string): Observable<T> {
    const headers = new HttpHeaders().set(API_HEADERS.rowVersion, rowVersion);

    return this.http
      .post<ApiResponse<T>>(apiUrl(route), null, {
        headers,
      })
      .pipe(map((response) => response.data));
  }
}

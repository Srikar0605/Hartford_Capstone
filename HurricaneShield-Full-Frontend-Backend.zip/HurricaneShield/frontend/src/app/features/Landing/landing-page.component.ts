
import {
  ChangeDetectionStrategy,
  Component,
  inject,
} from '@angular/core';
import { Router, RouterLink } from '@angular/router';

import { IconComponent, type IconName } from '../../shared/components/icon/icon.component';
import { ProductPreviewComponent } from '../../shared/components/product-preview/product-preview.component';

@Component({
  selector: 'app-landing-page',
  standalone: true,
  imports: [
    RouterLink,
    IconComponent,
    ProductPreviewComponent,
  ],
  templateUrl: './landing-page.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  host: { '(document:keydown)': 'onShortcut($event)' },
})
export class LandingPageComponent {
  private readonly router = inject(Router);

  /* Static page content (Control Room direction). */
  readonly journey = [
    { tag: 'Estimate', title: 'Risk priced in three steps', text: 'Value, age, build and protections.' },
    { tag: 'Apply', title: 'Saved property, one tier', text: 'Underwriting starts straight away.' },
    { tag: 'Pay', title: 'Premium paid, receipt kept', text: 'Coverage activates on payment.' },
    { tag: 'Claim', title: 'Every step tracked', text: 'From report to settlement.' },
  ];

  readonly perils: { name: string; icon: IconName; text: string; live?: boolean }[] = [
    { name: 'Hurricane', icon: 'storm', text: 'Quote, Policy, Payment and Claims — fully online.', live: true },
    { name: 'Flood', icon: 'umbrella', text: 'High-water and flood-related damage.' },
    { name: 'Wildfire', icon: 'zap', text: 'Fire exposure and fire-related loss.' },
    { name: 'Hail', icon: 'wind', text: 'Exterior and structural hail damage.' },
    { name: 'Earthquake', icon: 'activity', text: 'Seismic and earthquake damage.' },
  ];

  /** Example claim history shown in the activity panel (illustrative). */
  readonly claimLog = [
    { time: '19 Oct 21:40', text: 'Claim CLM-8812 submitted · Wind & Cyclone', done: true },
    { time: '19 Oct 21:46', text: '3 photos and a repair estimate uploaded', done: true },
    { time: '20 Oct 10:12', text: 'Documents verified by Claims Manager', done: true },
    { time: '20 Oct 10:15', text: 'Claim moved to review', done: true },
    { time: '21 Oct 09:30', text: 'Settlement decision in progress', done: false },
  ];

  /** Single-key shortcuts advertised on the page: Q → quote, P → plans. */
  onShortcut(event: KeyboardEvent): void {
    if (event.metaKey || event.ctrlKey || event.altKey || event.repeat) return;
    const target = event.target as HTMLElement | null;
    if (target && (target.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(target.tagName))) return;
    const key = event.key.toLowerCase();
    if (key === 'q') void this.router.navigateByUrl('/quote');
    if (key === 'p') void this.router.navigateByUrl('/plans');
  }
}

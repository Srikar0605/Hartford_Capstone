
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { HurricaneValidators } from '../../shared/validators/hurricane.validators';

/**
 * Creates the reactive form model for customer premium payments.
 * We include a simulateFailure flag for testing sandbox integration and error handling flows.
 */
export function createPremiumPaymentForm() {
  return new FormGroup({
    policyId: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required, HurricaneValidators.guid],
    }),
    amount: new FormControl<number | null>(null, [
      Validators.required,
      HurricaneValidators.positiveNumber,
    ]),
    simulateFailure: new FormControl(false, { nonNullable: true }),
  });
}

/**
 * Form for retrying a failed transaction.
 * Requires rowVersion so we don't attempt to retry a transaction that was already resolved concurrently.
 */
export function createRetryPaymentForm() {
  return new FormGroup({
    simulateFailure: new FormControl(false, { nonNullable: true }),
    rowVersion: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
  });
}

/**
 * Filter form for staff and customer transaction histories.
 * Enables query composition across transaction types, dates, and related domain IDs.
 */
export function createTransactionSearchForm() {
  return new FormGroup({
    type: new FormControl('', { nonNullable: true }),
    status: new FormControl('', { nonNullable: true }),
    customerId: new FormControl('', { nonNullable: true, validators: [HurricaneValidators.guid] }),
    policyId: new FormControl('', { nonNullable: true, validators: [HurricaneValidators.guid] }),
    claimId: new FormControl('', { nonNullable: true, validators: [HurricaneValidators.guid] }),
    from: new FormControl('', { nonNullable: true }),
    to: new FormControl('', { nonNullable: true }),
  });
}

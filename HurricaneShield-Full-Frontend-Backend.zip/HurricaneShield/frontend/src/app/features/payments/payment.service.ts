
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';

import { API_HEADERS, API_ROUTES } from '../../core/constants/api-routes';
import type { ApiResponse } from '../../core/models/api.models';
import type { PagedResponse } from '../../core/models/pagination.models';
import { apiUrl } from '../../core/services/api-url';
import { toHttpParams } from '../../core/services/http-params';
import type {
  PaymentReceiptResponse,
  PremiumPaymentResponse,
  ProcessPremiumPaymentRequest,
  RetryPaymentRequest,
  TransactionDetailsResponse,
  TransactionSearchRequest,
  TransactionSummaryResponse,
} from './payment.models';

/**
 * Service managing payment operations with the Payment microservice.
 * Enforces strict idempotency contracts on premium payments and handles transaction history auditing.
 */
@Injectable({ providedIn: 'root' })
export class PaymentService {
  private readonly http = inject(HttpClient);

  /**
   * Processes a policy premium payment.
   * I require an idempotencyKey here to ensure the credit card or bank account is charged exactly once,
   * even if network latency triggers browser retries.
   */
  processPremium(
    request: ProcessPremiumPaymentRequest,
    idempotencyKey: string,
  ): Observable<PremiumPaymentResponse> {
    const headers = new HttpHeaders().set(API_HEADERS.idempotencyKey, idempotencyKey);
    return this.http
      .post<ApiResponse<PremiumPaymentResponse>>(
        apiUrl(API_ROUTES.payments.premium),
        request,
        { headers },
      )
      .pipe(map((response) => response.data));
  }

  getMine(
    request: TransactionSearchRequest = {},
  ): Observable<PagedResponse<TransactionSummaryResponse>> {
    return this.searchAt(API_ROUTES.payments.mine, request);
  }

  search(
    request: TransactionSearchRequest = {},
  ): Observable<PagedResponse<TransactionSummaryResponse>> {
    return this.searchAt(API_ROUTES.payments.transactions, request);
  }

  getTransaction(transactionId: string): Observable<TransactionDetailsResponse> {
    return this.get<TransactionDetailsResponse>(
      API_ROUTES.payments.byId(transactionId),
    );
  }

  getSettlement(transactionId: string): Observable<TransactionDetailsResponse> {
    return this.get<TransactionDetailsResponse>(
      API_ROUTES.payments.settlement(transactionId),
    );
  }

  getReceipt(transactionId: string): Observable<PaymentReceiptResponse> {
    return this.get<PaymentReceiptResponse>(
      API_ROUTES.payments.receipt(transactionId),
    );
  }

  retry(
    transactionId: string,
    request: RetryPaymentRequest,
  ): Observable<TransactionDetailsResponse> {
    return this.http
      .post<ApiResponse<TransactionDetailsResponse>>(
        apiUrl(API_ROUTES.payments.retry(transactionId)),
        request,
      )
      .pipe(map((response) => response.data));
  }

  private get<T>(route: string): Observable<T> {
    return this.http
      .get<ApiResponse<T>>(apiUrl(route))
      .pipe(map((response) => response.data));
  }

  private searchAt(
    route: string,
    request: TransactionSearchRequest,
  ): Observable<PagedResponse<TransactionSummaryResponse>> {
    return this.http
      .get<ApiResponse<PagedResponse<TransactionSummaryResponse>>>(apiUrl(route), {
        params: toHttpParams({ ...request }),
      })
      .pipe(map((response) => response.data));
  }
}


import { Injectable } from '@angular/core';
import { jsPDF } from 'jspdf';
import type { PaymentReceiptResponse } from './payment.models';

@Injectable({
  providedIn: 'root',
})
export class PaymentReceiptGeneratorService {
  generateReceipt(receipt: PaymentReceiptResponse): void {
    const doc = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
    });

    const pageWidth = doc.internal.pageSize.getWidth();
    const margin = 20;
    const contentWidth = pageWidth - margin * 2;

    // Header bar
    doc.setFillColor(64, 1, 6); // Brand oxblood
    doc.rect(0, 0, pageWidth, 24, 'F');

    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(255, 255, 255);
    doc.text('NATURALSHIELD INSURANCE', margin, 15);

    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.text('Official Transaction Receipt', pageWidth - margin, 15, { align: 'right' });

    let y = 40;

    // Title
    doc.setFontSize(18);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(15, 23, 42); // slate-900
    doc.text('Payment Receipt', margin, y);

    y += 6;
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(100, 116, 139); // slate-500
    doc.text('Thank you for your payment. Keep this receipt for your financial records.', margin, y);

    y += 10;
    doc.setDrawColor(226, 232, 240); // slate-200
    doc.line(margin, y, margin + contentWidth, y);

    // Summary Highlight Box
    y += 10;
    doc.setFillColor(248, 250, 252); // slate-50
    doc.roundedRect(margin, y, contentWidth, 32, 3, 3, 'F');
    doc.setDrawColor(203, 213, 225); // slate-300
    doc.roundedRect(margin, y, contentWidth, 32, 3, 3, 'D');

    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(100, 116, 139);
    doc.text('AMOUNT PAID', margin + 8, y + 10);
    doc.text('RECEIPT NUMBER', margin + contentWidth - 8, y + 10, { align: 'right' });

    doc.setFontSize(18);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(106, 4, 15); // brand-700 rosewood
    doc.text(
      `INR ${receipt.amount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}`,
      margin + 8,
      y + 22
    );

    doc.setFontSize(13);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(15, 23, 42);
    doc.text(receipt.receiptNumber, margin + contentWidth - 8, y + 22, { align: 'right' });

    // Transaction Details Table / Grid
    y += 45;
    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(15, 23, 42);
    doc.text('Transaction Details', margin, y);

    y += 6;
    doc.setDrawColor(226, 232, 240);
    doc.line(margin, y, margin + contentWidth, y);

    const rows: [string, string][] = [
      ['Transaction Identifier', receipt.transactionNumber],
      ['Transaction ID (GUID)', receipt.transactionId],
      ['Receipt ID', receipt.receiptId],
      ['Date & Time', new Date(receipt.generatedAt).toUTCString()],
      ['Issued By', receipt.createdBy || 'NaturalShield Payment Gateway'],
      ['Payment Status', 'Confirmed & Completed'],
    ];

    y += 6;
    for (const [label, val] of rows) {
      y += 8;
      doc.setFontSize(10);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(100, 116, 139);
      doc.text(label, margin, y);

      doc.setFont('helvetica', 'bold');
      doc.setTextColor(15, 23, 42);
      doc.text(val, margin + contentWidth, y, { align: 'right' });

      y += 2;
      doc.setDrawColor(241, 245, 249);
      doc.line(margin, y, margin + contentWidth, y);
    }

    // Security / Signature Notice
    y += 25;
    doc.setFillColor(251, 243, 242); // brand-50
    doc.roundedRect(margin, y, contentWidth, 24, 2, 2, 'F');
    doc.setDrawColor(235, 202, 198); // brand-200
    doc.roundedRect(margin, y, contentWidth, 24, 2, 2, 'D');

    doc.setFontSize(9);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(106, 4, 15);
    doc.text('ELECTRONICALLY VERIFIED RECORD', margin + 6, y + 8);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    doc.setTextColor(51, 65, 85);
    doc.text(
      'This document serves as proof of payment for your NaturalShield natural disaster coverage.\nFor questions or verification, contact support@hurricaneshield.local.',
      margin + 6,
      y + 14
    );

    // Footer
    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(148, 163, 184);
    doc.text(
      `Generated on ${new Date().toISOString()} • NaturalShield Financial Operations`,
      pageWidth / 2,
      285,
      { align: 'center' }
    );

    doc.save(`receipt-${receipt.receiptNumber}.pdf`);
  }
}

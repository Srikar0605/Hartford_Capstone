
import type { Routes } from '@angular/router';

import { authGuard } from '../../core/guards/auth.guard';
import { permissionGuard } from '../../core/guards/permission.guard';
import { roleGuard } from '../../core/guards/role.guard';
import { SYSTEM_PERMISSIONS } from '../../core/constants/permissions';
import { SYSTEM_ROLES } from '../../core/constants/roles';
import { placeholderRoute } from '../../core/routing/route-helpers';

const paymentReader = {
  roles: [SYSTEM_ROLES.customer, SYSTEM_ROLES.administrator] as const,
  permissions: [SYSTEM_PERMISSIONS.viewPayments] as const,
};

export const paymentRoutes: Routes = [
  placeholderRoute({
    path: 'payments/my',
    title: 'Payment History',
    pageKey: 'payments.my',
    canActivate: [authGuard, roleGuard, permissionGuard],
    data: paymentReader,
  }),
  placeholderRoute({
    path: 'payments/:transactionId/receipt',
    title: 'Payment Receipt',
    pageKey: 'payments.receipt',
    canActivate: [authGuard, roleGuard, permissionGuard],
    data: paymentReader,
  }),
  placeholderRoute({
    path: 'payments/:transactionId',
    title: 'Payment Details',
    pageKey: 'payments.details',
    canActivate: [authGuard, roleGuard, permissionGuard],
    data: paymentReader,
  }),
];


import type { PaymentStatus, PaymentType } from '../../core/constants/statuses';
import type { ApiDateTime, Guid, RowVersion } from '../../core/models/api.models';
import type { PageRequest } from '../../core/models/pagination.models';

export interface ProcessPremiumPaymentRequest {
  policyId: Guid;
  amount: number;
  simulateFailure?: boolean;
}

export interface PremiumPaymentResponse {
  transactionId: Guid;
  transactionNumber: string;
  policyId: Guid;
  amount: number;
  status: PaymentStatus;
  failureReason: string | null;
  receiptNumber: string | null;
  transactionDate: ApiDateTime;
  rowVersion: RowVersion;
}

export interface ProcessClaimSettlementRequest {
  claimId: Guid;
  customerId: Guid;
  policyId: Guid;
  amount: number;
  simulateFailure?: boolean;
}

export interface ClaimSettlementResponse {
  transactionId: Guid;
  transactionNumber: string;
  claimId: Guid;
  amount: number;
  status: PaymentStatus;
  failureReason: string | null;
  receiptNumber: string | null;
  transactionDate: ApiDateTime;
  rowVersion: RowVersion;
}

export interface TransactionSearchRequest extends PageRequest {
  type?: PaymentType;
  status?: PaymentStatus;
  customerId?: Guid;
  policyId?: Guid;
  claimId?: Guid;
  from?: ApiDateTime;
  to?: ApiDateTime;
}

export interface TransactionSummaryResponse {
  transactionId: Guid;
  transactionNumber: string;
  type: PaymentType;
  amount: number;
  status: PaymentStatus;
  transactionDate: ApiDateTime;
  rowVersion: RowVersion;
}

export interface PaymentAttemptResponse {
  requestId: Guid;
  requestType: string;
  requestedAt: ApiDateTime;
  responseCode: string;
  responseStatus: PaymentStatus;
  responseMessage: string;
  processedAt: ApiDateTime;
}

export interface TransactionDetailsResponse {
  transactionId: Guid;
  transactionNumber: string;
  type: PaymentType;
  customerId: Guid | null;
  policyId: Guid | null;
  claimId: Guid | null;
  amount: number;
  status: PaymentStatus;
  failureReason: string | null;
  transactionDate: ApiDateTime;
  attempts: PaymentAttemptResponse[];
  receiptNumber: string | null;
  rowVersion: RowVersion;
}

export interface RetryPaymentRequest {
  simulateFailure: boolean;
  rowVersion: RowVersion;
}

export interface PaymentReceiptResponse {
  receiptId: Guid;
  transactionId: Guid;
  transactionNumber: string;
  receiptNumber: string;
  amount: number;
  generatedAt: ApiDateTime;
  createdBy: string;
}

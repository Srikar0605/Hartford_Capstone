
import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';
import { ActivatedRoute, provideRouter } from '@angular/router';
import { of } from 'rxjs';
import { describe, expect, it, vi, beforeEach } from 'vitest';
import { PaymentConnectedPageComponent } from './payment-connected-page.component';
import { PaymentReceiptGeneratorService } from '../payment-receipt-generator.service';

describe('PaymentConnectedPageComponent', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PaymentConnectedPageComponent],
      providers: [
        provideRouter([]),
        provideHttpClient(),
        provideHttpClientTesting(),
        {
          provide: ActivatedRoute,
          useValue: {
            data: of({ pageKey: 'payments.my' }),
            snapshot: { paramMap: { get: () => null } },
          },
        },
      ],
    }).compileComponents();
  });

  it('creates the connected Payment page', () => {
    const fixture = TestBed.createComponent(PaymentConnectedPageComponent);
    expect(fixture.componentInstance).toBeTruthy();
  });

  it('calculates totalPaid and totalReceived from transaction items', () => {
    const fixture = TestBed.createComponent(PaymentConnectedPageComponent);
    const component = fixture.componentInstance;

    component.transactions.set({
      items: [
        {
          transactionId: 'tx-1',
          transactionNumber: 'TX-001',
          type: 'Premium',
          amount: 1000,
          status: 'Success',
          transactionDate: '2026-01-01T00:00:00Z',
          rowVersion: 'AQIDBAUGBwg=',
        },
        {
          transactionId: 'tx-2',
          transactionNumber: 'TX-002',
          type: 'ClaimSettlement',
          amount: 500,
          status: 'Success',
          transactionDate: '2026-02-01T00:00:00Z',
          rowVersion: 'AQIDBAUGBwg=',
        },
        {
          transactionId: 'tx-3',
          transactionNumber: 'TX-003',
          type: 'Refund',
          amount: 200,
          status: 'Success',
          transactionDate: '2026-03-01T00:00:00Z',
          rowVersion: 'AQIDBAUGBwg=',
        },
        {
          transactionId: 'tx-4',
          transactionNumber: 'TX-004',
          type: 'Premium',
          amount: 1000,
          status: 'Failed',
          transactionDate: '2026-04-01T00:00:00Z',
          rowVersion: 'AQIDBAUGBwg=',
        },
      ],
      page: 1,
      pageSize: 20,
      totalCount: 4,
      totalPages: 1,
    });

    expect(component.totalPaid()).toBe(1000);
    expect(component.totalReceived()).toBe(700);
  });

  it('invokes PaymentReceiptGeneratorService when printReceipt is called with receipt data', () => {
    const fixture = TestBed.createComponent(PaymentConnectedPageComponent);
    const component = fixture.componentInstance;
    const generator = TestBed.inject(PaymentReceiptGeneratorService);

    const spy = vi.spyOn(generator, 'generateReceipt').mockImplementation(() => undefined);

    component.receipt.set({
      receiptId: 'rec-1',
      transactionId: 'tx-1',
      transactionNumber: 'TX-001',
      receiptNumber: 'RCPT-001',
      amount: 1000,
      generatedAt: '2026-01-01T00:00:00Z',
      createdBy: 'system',
    });

    component.printReceipt();

    expect(spy).toHaveBeenCalledWith(
      expect.objectContaining({
        receiptNumber: 'RCPT-001',
        amount: 1000,
      }),
    );
  });
});

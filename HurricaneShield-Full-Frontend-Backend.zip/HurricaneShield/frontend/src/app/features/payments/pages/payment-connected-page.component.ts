

import { CommonModule } from '@angular/common';
import {
  ChangeDetectionStrategy,
  Component,
  OnDestroy,
  OnInit,
  computed,
  inject,
  signal,
} from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { Subject, takeUntil } from 'rxjs';

import { PAYMENT_STATUSES, PAYMENT_TYPES } from '../../../core/constants/statuses';
import { ApiClientError } from '../../../core/interceptors/error.interceptor';
import type { PagedResponse } from '../../../core/models/pagination.models';
import { NotificationService } from '../../../core/services/notification.service';
import { createRetryPaymentForm, createTransactionSearchForm } from '../payment.forms';
import type {
  PaymentReceiptResponse,
  TransactionDetailsResponse,
  TransactionSearchRequest,
  TransactionSummaryResponse,
} from '../payment.models';
import { PaymentService } from '../payment.service';
import { PaymentReceiptGeneratorService } from '../payment-receipt-generator.service';

import { FormFieldErrorComponent } from '../../../shared/components/form-field-error/form-field-error.component';

import { StatusBadgeComponent } from '../../../shared/components/status-badge/status-badge.component';
import { IconComponent } from '../../../shared/components/icon/icon.component';
import { SlideOverComponent } from '../../../shared/components/slide-over/slide-over.component';

@Component({
  selector: 'app-payment-connected-page',
  standalone: true,
  imports: [StatusBadgeComponent, IconComponent, SlideOverComponent, CommonModule, ReactiveFormsModule, RouterLink,
    FormFieldErrorComponent
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './payment-connected-page.component.html',
})
export class PaymentConnectedPageComponent implements OnInit, OnDestroy {
  private readonly route = inject(ActivatedRoute);
  private readonly payments = inject(PaymentService);
  private readonly receiptPdfGenerator = inject(PaymentReceiptGeneratorService);
  private readonly notifications = inject(NotificationService);
  private readonly destroy$ = new Subject<void>();

  readonly pageKey = signal('payments.my');
  readonly busy = signal(false);
  readonly errorMessage = signal('');
  /** Row opened in the quick-view panel (UI state only). */
  readonly quickViewTransaction = signal<TransactionSummaryResponse | null>(null);
  isIncoming(type: string | null | undefined): boolean {
    return type === 'Refund' || type === 'ClaimSettlement';
  }
  spaced(value: string | null | undefined): string {
    return (value ?? '').replace(/([a-z])([A-Z])/g, '$1 $2');
  }
  readonly transactions = signal<PagedResponse<TransactionSummaryResponse>>({
    items: [],
    page: 1,
    pageSize: 20,
    totalCount: 0,
    totalPages: 0,
  });
  readonly details = signal<TransactionDetailsResponse | null>(null);
  readonly receipt = signal<PaymentReceiptResponse | null>(null);
  readonly searchForm = createTransactionSearchForm();
  readonly retryForm = createRetryPaymentForm();
  readonly paymentStatuses = PAYMENT_STATUSES;
  readonly paymentTypes = PAYMENT_TYPES;

  readonly totalPaid = computed(() =>
    this.transactions().items
      .filter((t) => t.status === 'Success' && t.type === 'Premium')
      .reduce((sum, t) => sum + t.amount, 0)
  );

  readonly totalReceived = computed(() =>
    this.transactions().items
      .filter((t) => t.status === 'Success' && (t.type === 'ClaimSettlement' || (t.type as string) === 'Refund'))
      .reduce((sum, t) => sum + t.amount, 0)
  );

  readonly title = () =>
    ({
      'payments.my': 'My Payments',
      'payments.details': 'Payment Details',
      'payments.receipt': 'Payment Receipt',
      'admin.payment-search': 'Transaction Search',
      'admin.payment-details': 'Transaction Details',
    })[this.pageKey()] ?? 'Payments';
  readonly description = () =>
    this.pageKey().startsWith('admin.')
      ? 'Search, inspect, and retry payment transactions.'
      : 'Review your transactions and receipts.';

  ngOnInit(): void {
    this.route.data.pipe(takeUntil(this.destroy$)).subscribe((data) => {
      this.pageKey.set(String(data['pageKey'] ?? 'payments.my'));
      this.loadPage();
    });
  }
  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  loadPage(): void {
    const key = this.pageKey();
    this.errorMessage.set('');
    if (key === 'payments.my' || key === 'admin.payment-search') this.loadTransactions(1);
    else if (key === 'payments.receipt') this.loadReceipt();
    else this.loadDetails();
  }
  applySearch(): void {
    if (this.searchForm.invalid) {
      this.searchForm.markAllAsTouched();
      return;
    }
    this.loadTransactions(1);
  }
  resetSearch(): void {
    this.searchForm.reset({
      type: '',
      status: '',
      customerId: '',
      policyId: '',
      claimId: '',
      from: '',
      to: '',
    });
    this.loadTransactions(1);
  }
  loadTransactions(page: number): void {
    const raw = this.searchForm.getRawValue();
    const request: TransactionSearchRequest = {
      page,
      pageSize: 20,
      type: (raw.type || undefined) as TransactionSearchRequest['type'],
      status: (raw.status || undefined) as TransactionSearchRequest['status'],
      customerId: raw.customerId || undefined,
      policyId: raw.policyId || undefined,
      claimId: raw.claimId || undefined,
      from: raw.from ? new Date(raw.from).toISOString() : undefined,
      to: raw.to ? new Date(raw.to).toISOString() : undefined,
    };
    this.busy.set(true);
    const call =
      this.pageKey() === 'payments.my'
        ? this.payments.getMine(request)
        : this.payments.search(request);
    call.pipe(takeUntil(this.destroy$)).subscribe({
      next: (value) => {
        this.transactions.set(value);
        this.busy.set(false);
      },
      error: (e) => this.fail(e),
    });
  }
  loadDetails(): void {
    const id = this.route.snapshot.paramMap.get('transactionId');
    if (!id) return;
    this.busy.set(true);
    const call =
      this.pageKey() === 'admin.payment-details'
        ? this.payments.getTransaction(id)
        : this.payments.getTransaction(id);
    call.pipe(takeUntil(this.destroy$)).subscribe({
      next: (value) => {
        this.details.set(value);
        this.retryForm.controls.rowVersion.setValue(value.rowVersion);
        this.busy.set(false);
      },
      error: (e) => this.fail(e),
    });
  }
  loadReceipt(): void {
    const id = this.route.snapshot.paramMap.get('transactionId');
    if (!id) return;
    this.busy.set(true);
    this.payments
      .getReceipt(id)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (value) => {
          this.receipt.set(value);
          this.busy.set(false);
        },
        error: (e) => this.fail(e),
      });
  }
  retryPayment(): void {
    const item = this.details();
    if (!item || this.retryForm.invalid || this.busy()) return;
    this.busy.set(true);
    this.payments
      .retry(item.transactionId, this.retryForm.getRawValue())
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (value) => {
          this.details.set(value);
          this.retryForm.controls.rowVersion.setValue(value.rowVersion);
          this.busy.set(false);
          this.notifications.success(
            'Payment retried',
            'The payment retry was processed successfully.',
          );
        },
        error: (e) => this.fail(e),
      });
  }
  printReceipt(): void {
    const item = this.receipt();
    if (item) {
      this.receiptPdfGenerator.generateReceipt(item);
    } else {
      window.print();
    }
  }
  private fail(error: unknown): void {
    this.busy.set(false);
    this.errorMessage.set(
      error instanceof ApiClientError ? error.message : 'The request could not be completed.',
    );
  }
}


import type { Routes } from '@angular/router';

import { authGuard } from '../../core/guards/auth.guard';
import { permissionGuard } from '../../core/guards/permission.guard';
import { roleGuard } from '../../core/guards/role.guard';
import { SYSTEM_PERMISSIONS } from '../../core/constants/permissions';
import { SYSTEM_ROLES } from '../../core/constants/roles';
import { placeholderRoute } from '../../core/routing/route-helpers';

const policyStaff = [SYSTEM_ROLES.agent, SYSTEM_ROLES.administrator] as const;
const claimsStaff = [SYSTEM_ROLES.claimsManager, SYSTEM_ROLES.administrator] as const;

export const staffRoutes: Routes = [
  placeholderRoute({
    path: 'staff/policies/search',
    title: 'Policy Search',
    pageKey: 'staff.policy-search',
    canActivate: [authGuard, roleGuard, permissionGuard],
    data: {
      roles: policyStaff,
      permissions: [SYSTEM_PERMISSIONS.reviewPolicies],
    },
  }),
  placeholderRoute({
    path: 'staff/policies/underwriting',
    title: 'Underwriting Queue',
    pageKey: 'staff.underwriting-queue',
    canActivate: [authGuard, roleGuard, permissionGuard],
    data: {
      roles: policyStaff,
      permissions: [SYSTEM_PERMISSIONS.reviewUnderwritingRequests],
    },
  }),
  placeholderRoute({
    path: 'staff/policies/underwriting/:policyId',
    title: 'Underwriting Review',
    pageKey: 'staff.underwriting-review',
    canActivate: [authGuard, roleGuard, permissionGuard],
    data: {
      roles: policyStaff,
      permissions: [SYSTEM_PERMISSIONS.reviewUnderwritingRequests],
    },
  }),
  placeholderRoute({
    path: 'staff/policies/:policyId',
    title: 'Administrative Policy Details',
    pageKey: 'staff.policy-details',
    canActivate: [authGuard, roleGuard, permissionGuard],
    data: {
      roles: policyStaff,
      permissions: [SYSTEM_PERMISSIONS.reviewPolicies],
    },
  }),
  placeholderRoute({
    path: 'staff/claims/queue',
    title: 'Claims Queue',
    pageKey: 'staff.claims-queue',
    canActivate: [authGuard, roleGuard, permissionGuard],
    data: {
      roles: claimsStaff,
      permissions: [SYSTEM_PERMISSIONS.reviewClaims],
    },
  }),
  placeholderRoute({
    path: 'staff/claims/settlements',
    title: 'Settlements',
    pageKey: 'staff.settlements',
    canActivate: [authGuard, roleGuard, permissionGuard],
    data: {
      roles: claimsStaff,
      permissions: [SYSTEM_PERMISSIONS.initiateSettlement],
    },
  }),
  placeholderRoute({
    path: 'staff/claims/:claimId',
    title: 'Claim Review',
    pageKey: 'staff.claim-review',
    canActivate: [authGuard, roleGuard, permissionGuard],
    data: {
      roles: claimsStaff,
      permissions: [SYSTEM_PERMISSIONS.reviewClaims],
    },
  }),
];

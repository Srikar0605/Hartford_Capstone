
import { HttpErrorResponse } from '@angular/common/http';
import {
  ChangeDetectionStrategy,
  Component,
  computed,
  inject,
  OnInit,
  signal,
} from '@angular/core';
import { DatePipe, NgTemplateOutlet } from '@angular/common';
import { RouterLink } from '@angular/router';
import { finalize } from 'rxjs';

import { AuthStore } from '../../../core/auth/auth.store';
import { SYSTEM_PERMISSIONS } from '../../../core/constants/permissions';
import { SYSTEM_ROLES } from '../../../core/constants/roles';
import { ApiClientError } from '../../../core/interceptors/error.interceptor';
import { ErrorStateComponent } from '../../../shared/components/error-state/error-state.component';
import { LoadingStateComponent } from '../../../shared/components/loading-state/loading-state.component';
import { StatusBadgeComponent } from '../../../shared/components/status-badge/status-badge.component';
import { IconComponent, type IconName } from '../../../shared/components/icon/icon.component';
import { CommandPaletteService } from '../../../shared/components/command-palette/command-palette.component';
import type { CustomerProfileResponse } from '../../profile/profile.models';
import { ProfileService } from '../../profile/profile.service';

interface DashboardAction {
  eyebrow: string;
  title: string;
  description: string;
  route: string;
  actionLabel: string;
  icon: string;
  emphasis?: boolean;
  permission?: string;
}

interface WorkflowStep {
  label: string;
  description: string;
}

/**
 * Role-aware Dashboard Orchestrator.
 * I built this as a unified smart component that dynamically reconfigures its UI based on the user's role.
 * Rather than creating 4 separate dashboard components for Customer, Agent, Claims Manager, and Admin,
 * I derived hero banners, quick actions, workflow timelines, and primary CTAs reactively via Angular computed signals.
 */
@Component({
  selector: 'app-dashboard-connected-page',
  imports: [RouterLink, DatePipe, NgTemplateOutlet, StatusBadgeComponent, LoadingStateComponent, ErrorStateComponent, IconComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './dashboard-connected-page.component.html',
  styleUrl: './dashboard-connected-page.component.css',
})
export class DashboardConnectedPageComponent implements OnInit {
  private readonly authStore = inject(AuthStore);
  private readonly profiles = inject(ProfileService);

  readonly profile = signal<CustomerProfileResponse | null>(null);
  readonly loading = signal(false);
  readonly error = signal<string | null>(null);

  // Role flags evaluated reactively from AuthStore claims
  readonly isCustomer = computed(() => this.authStore.hasRole(SYSTEM_ROLES.customer));
  readonly isAgent = computed(() => this.authStore.hasRole(SYSTEM_ROLES.agent));
  readonly isClaimsManager = computed(() => this.authStore.hasRole(SYSTEM_ROLES.claimsManager));
  readonly isAdministrator = computed(() => this.authStore.hasRole(SYSTEM_ROLES.administrator));
  readonly email = computed(() => this.authStore.currentUser()?.email ?? 'Signed-in user');
  readonly roleLabel = computed(() => this.authStore.roles()[0] ?? 'User');
  readonly palette = inject(CommandPaletteService);

  /** Lucide icon for an action card, keyed by its eyebrow. */
  cardIcon(eyebrow: string): IconName {
    const icons: Record<string, IconName> = {
      Coverage: 'shield-check', Policies: 'file', Claims: 'file-check', Payments: 'card', Finance: 'banknote',
      Underwriting: 'badge-check', Customers: 'users', Access: 'key', Products: 'list', Security: 'lock',
    };
    return icons[eyebrow] ?? 'sparkles';
  }
  /** Lucide icon for a profile resource row, keyed by its title. */
  profileIcon(title: string): IconName {
    const icons: Record<string, IconName> = {
      Addresses: 'pin', 'Emergency Contacts': 'phone', Properties: 'house', 'Security and MFA': 'lock', 'Login Activity': 'activity',
    };
    return icons[title] ?? 'user';
  }

  /* Personal touches computed on the client only (no extra API calls). */
  readonly today = new Date();
  readonly dayGreeting = computed(() => {
    const hour = this.today.getHours();
    return hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening';
  });

  /** Cyclone readiness checklist; ticks are kept in this browser only. */
  private static readonly readinessKey = 'hs.readinessChecklist';
  readonly readinessItems: { id: string; icon: IconName; label: string; hint: string }[] = [
    { id: 'kit', icon: 'sparkles', label: 'Emergency kit packed', hint: 'Water, torch, first-aid and medicines for 3 days.' },
    { id: 'docs', icon: 'file', label: 'Documents backed up', hint: 'Policy, ID and property papers saved digitally.' },
    { id: 'home', icon: 'house', label: 'Home secured', hint: 'Shutters, loose items and roof fixings checked.' },
    { id: 'route', icon: 'pin', label: 'Evacuation route known', hint: 'Nearest cyclone shelter and a meeting point.' },
    { id: 'power', icon: 'zap', label: 'Phones & power banks charged', hint: 'Keep IMD and local alerts switched on.' },
    { id: 'contacts', icon: 'phone', label: 'Emergency contacts shared', hint: 'Family and neighbours know how to reach you.' },
  ];
  readonly readinessDone = signal<ReadonlySet<string>>(this.readReadiness());
  readonly readinessPercent = computed(() =>
    Math.round((this.readinessDone().size / this.readinessItems.length) * 100),
  );
  toggleReadiness(id: string): void {
    const next = new Set(this.readinessDone());
    if (next.has(id)) next.delete(id);
    else next.add(id);
    this.readinessDone.set(next);
    try {
      localStorage.setItem(DashboardConnectedPageComponent.readinessKey, JSON.stringify([...next]));
    } catch {
      /* storage unavailable: keep the in-memory state only */
    }
  }
  private readReadiness(): ReadonlySet<string> {
    try {
      const raw = localStorage.getItem(DashboardConnectedPageComponent.readinessKey);
      return new Set(raw ? (JSON.parse(raw) as string[]) : []);
    } catch {
      return new Set();
    }
  }

  readonly heroTitle = computed(() => {
    if (this.isCustomer())
      return this.profile()
        ? `Welcome, ${this.profile()!.firstName}`
        : 'Welcome to HurricaneShield';
    if (this.isAgent()) return 'Agent Workspace';
    if (this.isClaimsManager()) return 'Claims Operations';
    return 'Platform Administration';
  });

  readonly heroDescription = computed(() => {
    if (this.isCustomer())
      return 'Manage your profile, protect your property, review coverage, and access Claims and Payments.';
    if (this.isAgent())
      return 'Review Customer Policies, evaluate property risk, and complete Underwriting decisions.';
    if (this.isClaimsManager())
      return 'Review submitted Claims, verify evidence, record decisions, and initiate settlements.';
    return 'Manage insurance operations, Customers, product configuration, user access, and transactions.';
  });

  /**
   * Intelligently routes the primary Call-To-Action button.
   * If a customer hasn't created a profile yet, we guide them directly to profile onboarding.
   */
  readonly primaryRoute = computed(() => {
    if (this.isCustomer()) {
      if (!this.profile()) return '/profile/create';
      return this.profile()!.status === 'Active' ? '/policies/apply' : '/profile/overview';
    }
    if (this.isAgent()) return '/staff/policies/underwriting';
    if (this.isClaimsManager()) return '/staff/claims/queue';
    return '/staff/policies/search';
  });

  readonly primaryLabel = computed(() => {
    if (this.isCustomer()) {
      if (!this.profile()) return 'Create Customer Profile';
      return this.profile()!.status === 'Active' ? 'Get a Quote' : 'View Profile Status';
    }
    if (this.isAgent()) return 'Open Underwriting Queue';
    if (this.isClaimsManager()) return 'Open Claims Queue';
    return 'Open Customer Policies';
  });

  readonly secondaryRoute = computed(() => {
    if (this.isCustomer()) return '/policies/my';
    if (this.isAgent()) return '/staff/policies/search';
    if (this.isClaimsManager()) return '/staff/claims/settlements';
    return '/admin/customers/search';
  });

  readonly secondaryLabel = computed(() => {
    if (this.isCustomer()) return 'View My Policies';
    if (this.isAgent()) return 'Search Customer Policies';
    if (this.isClaimsManager()) return 'View Settlements';
    return 'Manage Customers';
  });

  readonly customerActions: DashboardAction[] = [
    {
      eyebrow: 'Coverage',
      title: 'Get a Quote',
      description: 'Estimate coverage pricing using your property and insurance requirements.',
      route: '/policies/apply',
      actionLabel: 'Start a quote',
      icon: 'Q',
      emphasis: true,
    },
    {
      eyebrow: 'Policies',
      title: 'My Policies',
      description:
        'Review Policy applications, active coverage, premium requirements, Versions, and History.',
      route: '/policies/my',
      actionLabel: 'View Policies',
      icon: 'P',
    },
    {
      eyebrow: 'Claims',
      title: 'Submit a Claim',
      description:
        'Report a covered loss and provide supporting incident information and evidence.',
      route: '/claims/submit',
      actionLabel: 'Start a Claim',
      icon: 'C',
    },
    {
      eyebrow: 'Payments',
      title: 'Payment History',
      description: 'Review transactions, Payment status, details, and available receipts.',
      route: '/payments/my',
      actionLabel: 'View Payments',
      icon: '₹',
    },
  ];

  readonly profileActions: DashboardAction[] = [
    {
      eyebrow: 'Profile',
      title: 'Profile Overview',
      description: 'Review your Customer identity and account status.',
      route: '/profile/overview',
      actionLabel: 'Open',
      icon: 'U',
    },
    {
      eyebrow: 'Profile',
      title: 'Addresses',
      description: 'Maintain the addresses linked to your Customer profile.',
      route: '/profile/addresses',
      actionLabel: 'Manage',
      icon: 'A',
    },
    {
      eyebrow: 'Profile',
      title: 'Emergency Contacts',
      description: 'Keep emergency contact information current.',
      route: '/profile/contacts',
      actionLabel: 'Manage',
      icon: 'E',
    },
    {
      eyebrow: 'Profile',
      title: 'Properties',
      description: 'Maintain the properties available for insurance applications.',
      route: '/profile/properties',
      actionLabel: 'Manage',
      icon: 'H',
    },
    {
      eyebrow: 'Security',
      title: 'Security and MFA',
      description: 'Review account security and configure multi-factor authentication.',
      route: '/profile/security',
      actionLabel: 'Review',
      icon: 'S',
    },
    {
      eyebrow: 'Security',
      title: 'Login Activity',
      description: 'Review recent sign-in activity for your account.',
      route: '/profile/login-activity',
      actionLabel: 'Review',
      icon: 'L',
    },
  ];

  /**
   * Operations action cards available to staff members based on granular permissions.
   */
  readonly operations = computed<DashboardAction[]>(() => {
    const cards: DashboardAction[] = [];
    if (this.authStore.hasPermission(SYSTEM_PERMISSIONS.reviewPolicies))
      cards.push({
        eyebrow: 'Policies',
        title: 'Customer Policies',
        description:
          'Search the Policy portfolio and inspect Customer, Plan, risk, premium, and status information.',
        route: '/staff/policies/search',
        actionLabel: 'Open Customer Policies',
        icon: 'P',
      });
    if (this.authStore.hasPermission(SYSTEM_PERMISSIONS.reviewUnderwritingRequests))
      cards.push({
        eyebrow: 'Underwriting',
        title: 'Underwriting Queue',
        description:
          'Review pending applications, evaluate risk, and record Approve or Reject decisions.',
        route: '/staff/policies/underwriting',
        actionLabel: 'Open Queue',
        icon: 'U',
        emphasis: this.isAgent(),
      });
    if (this.authStore.hasPermission(SYSTEM_PERMISSIONS.reviewClaims))
      cards.push({
        eyebrow: 'Claims',
        title: 'Claims Queue',
        description:
          'Inspect submitted Claims, Policy snapshots, documents, and active Claim Reviews.',
        route: '/staff/claims/queue',
        actionLabel: 'Open Queue',
        icon: 'C',
        emphasis: this.isClaimsManager(),
      });
    if (this.authStore.hasPermission(SYSTEM_PERMISSIONS.initiateSettlement))
      cards.push({
        eyebrow: 'Claims',
        title: 'Settlements',
        description: 'Review approved Claims and initiate eligible settlement operations.',
        route: '/staff/claims/settlements',
        actionLabel: 'View Settlements',
        icon: 'S',
      });
    return cards;
  });

  /**
   * Action cards restricted exclusively to administrators.
   */
  readonly administration = computed<DashboardAction[]>(() => {
    if (!this.isAdministrator()) return [];
    const cards: DashboardAction[] = [
      {
        eyebrow: 'Customers',
        title: 'Customer Management',
        description: 'Search Customer records, inspect Profiles, and manage account activation.',
        route: '/admin/customers/search',
        actionLabel: 'Manage Customers',
        icon: 'C',
      },
      {
        eyebrow: 'Finance',
        title: 'Transactions',
        description:
          'Search Payment transactions, inspect failures, retry eligible Payments, and review receipts.',
        route: '/admin/payments/search',
        actionLabel: 'Open Transactions',
        icon: '₹',
      },
    ];
    if (this.authStore.hasPermission(SYSTEM_PERMISSIONS.manageRoles))
      cards.push({
        eyebrow: 'Access',
        title: 'Role Assignment',
        description: 'Search Auth users and replace the current authoritative platform role.',
        route: '/admin/roles/assign',
        actionLabel: 'Manage Roles',
        icon: 'R',
      });
    if (this.authStore.hasPermission(SYSTEM_PERMISSIONS.managePlans))
      cards.push({
        eyebrow: 'Products',
        title: 'Plans and Coverage Types',
        description: 'Configure Plans, premiums, limits, deductibles, and Coverage Types.',
        route: '/admin/plans/list',
        actionLabel: 'Manage Products',
        icon: 'P',
        emphasis: true,
      });
    return cards;
  });

  /**
   * Displays a visual lifecycle workflow customized to each role's responsibility.
   */
  readonly workflow = computed<WorkflowStep[]>(() => {
    if (this.isCustomer())
      return [
        { label: 'Create Profile', description: 'Establish your Customer identity.' },
        { label: 'Add Property', description: 'Record the property to insure.' },
        { label: 'Get Quote', description: 'Estimate premium and coverage.' },
        { label: 'Apply', description: 'Submit a Policy application.' },
        { label: 'Underwriting', description: 'Risk is reviewed by staff.' },
        { label: 'Pay', description: 'Complete the required premium.' },
        { label: 'Covered', description: 'Access active Policy protection.' },
      ];
    if (this.isClaimsManager())
      return [
        { label: 'Submitted', description: 'Customer reports a covered loss.' },
        { label: 'Review', description: 'A Claim Review is started.' },
        { label: 'Documents', description: 'Evidence is verified.' },
        { label: 'Decision', description: 'Approve, reject, or request details.' },
        { label: 'Settlement', description: 'Approved Claims are settled.' },
      ];
    if (this.isAgent())
      return [
        { label: 'Application', description: 'Customer submits a Policy.' },
        { label: 'Risk', description: 'Property risk is assessed.' },
        { label: 'Review', description: 'Underwriting evaluates the application.' },
        { label: 'Decision', description: 'Approve or reject with reasons.' },
        { label: 'Payment', description: 'Approved Policy awaits premium.' },
        { label: 'Active', description: 'Payment activates coverage.' },
      ];
    return [
      { label: 'Customers', description: 'Profiles and account access.' },
      { label: 'Policies', description: 'Applications and coverage.' },
      { label: 'Underwriting', description: 'Risk-based decisions.' },
      { label: 'Payments', description: 'Premium transactions.' },
      { label: 'Claims', description: 'Covered-loss review.' },
      { label: 'Settlements', description: 'Approved Claim completion.' },
    ];
  });

  readonly guidance = computed(() => {
    if (this.isCustomer())
      return [
        'Keep profile and property details current.',
        'Review Policy and Payment status regularly.',
        'Use Claims only for covered losses.',
      ];
    if (this.isAgent())
      return [
        'Review the latest Policy and Review state.',
        'Use clear decision reasons.',
        'Respect both concurrency RowVersions.',
      ];
    if (this.isClaimsManager())
      return [
        'Confirm Policy coverage.',
        'Verify supporting documents.',
        'Use current Claim and Review RowVersions.',
      ];
    return [
      'Use role and permission boundaries consistently.',
      'Keep product configuration deliberate.',
      'Review operational state before mutations.',
    ];
  });

  ngOnInit(): void {
    if (this.isCustomer()) this.loadProfile();
  }

  loadProfile(): void {
    if (this.loading()) return;
    this.loading.set(true);
    this.error.set(null);
    this.profiles
      .getCurrentProfile()
      .pipe(finalize(() => this.loading.set(false)))
      .subscribe({
        next: (value) => this.profile.set(value),
        error: (error: unknown) => {
          if (this.status(error) === 404) this.profile.set(null);
          else this.error.set('The Customer Profile could not be loaded.');
        },
      });
  }

  private status(error: unknown): number | null {
    return error instanceof ApiClientError || error instanceof HttpErrorResponse
      ? error.status
      : null;
  }
}

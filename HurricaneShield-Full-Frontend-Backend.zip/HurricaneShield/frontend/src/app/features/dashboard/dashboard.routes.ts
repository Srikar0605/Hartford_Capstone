
import type { Routes } from '@angular/router';

import { authGuard } from '../../core/guards/auth.guard';
import { placeholderRoute } from '../../core/routing/route-helpers';

export const dashboardRoutes: Routes = [
  placeholderRoute({
    path: 'dashboard',
    title: 'Dashboard',
    pageKey: 'dashboard.role-aware',
    canActivate: [authGuard],
  }),
];


import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';

import { API_HEADERS, API_ROUTES } from '../../core/constants/api-routes';
import type { ApiResponse } from '../../core/models/api.models';
import type { PagedResponse } from '../../core/models/pagination.models';
import { apiUrl } from '../../core/services/api-url';
import { toHttpParams } from '../../core/services/http-params';
import type {
  ApprovePolicyRequest,
  CalculateQuoteRequest,
  CalculateRecommendationsRequest,
  CoverageTypeResponse,
  CreateCoverageTypeRequest,
  CreatePlanRequest,
  CreatePolicyApplicationRequest,
  MyPoliciesRequest,
  PlanAdministrationResponse,
  PlanDetailsResponse,
  PlanSearchRequest,
  PlanSummaryResponse,
  PolicyActionRequest,
  PolicyApplicationResponse,
  PolicyDetailsResponse,
  PolicyEndorsementRequest,
  PolicyEndorsementResponse,
  PolicyHistoryResponse,
  PolicyMutationResponse,
  PolicySummaryResponse,
  CancellationPreviewResponse,
  StaffPolicySearchRequest,
  StaffPolicySummaryResponse,
  PolicyVersionResponse,
  QuoteResponse,
  RejectPolicyRequest,
  RevisePolicyRequest,
  RenewalEstimateRequest,
  RenewalEstimateResponse,
  RenewPolicyRequest,
  RenewalResponse,
  ReplacePlanCoveragesRequest,
  UnderwritingDetailsResponse,
  UnderwritingQueueItemResponse,
  UnderwritingSearchRequest,
  UpdateCoverageTypeRequest,
  UpdatePlanRequest,
} from './policy.models';
import { CustomerQuoteRequest } from './policy.models';

/**
 * I designed PolicyService to orchestrate all policy operations across customer self-service,
 * agent underwriting, and administrative plan management.
 * It enforces backend contracts including idempotency headers for purchases and rowVersion checks for state transitions.
 */
@Injectable({
  providedIn: 'root',
})
export class PolicyService {
  private readonly http = inject(HttpClient);

  getPlans(): Observable<PlanSummaryResponse[]> {
    return this.get<PlanSummaryResponse[]>(API_ROUTES.policies.plans);
  }

  getPlan(planId: string): Observable<PlanDetailsResponse> {
    return this.get<PlanDetailsResponse>(API_ROUTES.policies.plan(planId));
  }

  calculateQuote(request: CalculateQuoteRequest): Observable<QuoteResponse> {
    return this.post<QuoteResponse>(API_ROUTES.policies.quote, request);
  }

  calculateRecommendations(request: CalculateRecommendationsRequest): Observable<QuoteResponse[]> {
    return this.post<QuoteResponse[]>(API_ROUTES.policies.recommendations, request);
  }

  calculateCustomerQuote(request: CustomerQuoteRequest): Observable<QuoteResponse> {
    return this.post<QuoteResponse>(API_ROUTES.policies.customerQuote, request);
  }

  /**
   * Submits a formal policy application.
   * I require an idempotencyKey here so that network retries or accidental double-submissions
   * never result in multiple policy records being created for the same property.
   */
  apply(
    request: CreatePolicyApplicationRequest,
    idempotencyKey: string,
  ): Observable<PolicyApplicationResponse> {
    return this.postIdempotent<PolicyApplicationResponse>(
      API_ROUTES.policies.root,
      request,
      idempotencyKey,
    );
  }

  getMyPolicies(request: MyPoliciesRequest = {}): Observable<PagedResponse<PolicySummaryResponse>> {
    return this.getPaged<PolicySummaryResponse>(API_ROUTES.policies.mine, request);
  }

  getMyInsuredPropertyIds(): Observable<string[]> {
    return this.get<string[]>(API_ROUTES.policies.insuredProperties);
  }

  searchPolicies(
    request: StaffPolicySearchRequest = {},
  ): Observable<PagedResponse<StaffPolicySummaryResponse>> {
    return this.getPaged<StaffPolicySummaryResponse>(API_ROUTES.policies.search, request);
  }

  getPolicy(policyId: string): Observable<PolicyDetailsResponse> {
    return this.get<PolicyDetailsResponse>(API_ROUTES.policies.byId(policyId));
  }

  getStaffPolicy(policyId: string): Observable<PolicyDetailsResponse> {
    return this.get<PolicyDetailsResponse>(API_ROUTES.policies.staffById(policyId));
  }

  getStaffVersions(policyId: string): Observable<PolicyVersionResponse[]> {
    return this.get<PolicyVersionResponse[]>(API_ROUTES.policies.staffVersions(policyId));
  }

  getStaffHistory(policyId: string): Observable<PolicyHistoryResponse[]> {
    return this.get<PolicyHistoryResponse[]>(API_ROUTES.policies.staffHistory(policyId));
  }

  getVersions(policyId: string): Observable<PolicyVersionResponse[]> {
    return this.get<PolicyVersionResponse[]>(API_ROUTES.policies.versions(policyId));
  }

  getHistory(policyId: string): Observable<PolicyHistoryResponse[]> {
    return this.get<PolicyHistoryResponse[]>(API_ROUTES.policies.history(policyId));
  }

  cancel(policyId: string, request: PolicyActionRequest): Observable<PolicyMutationResponse> {
    return this.post<PolicyMutationResponse>(API_ROUTES.policies.cancel(policyId), request);
  }

  getCancellationPreview(policyId: string): Observable<CancellationPreviewResponse> {
    return this.get<CancellationPreviewResponse>(API_ROUTES.policies.cancelPreview(policyId));
  }

  suspend(policyId: string, request: PolicyActionRequest): Observable<PolicyMutationResponse> {
    return this.post<PolicyMutationResponse>(API_ROUTES.policies.suspend(policyId), request);
  }

  reactivate(policyId: string, request: PolicyActionRequest): Observable<PolicyMutationResponse> {
    return this.post<PolicyMutationResponse>(API_ROUTES.policies.reactivate(policyId), request);
  }

  expire(policyId: string, request: PolicyActionRequest): Observable<PolicyMutationResponse> {
    return this.post<PolicyMutationResponse>(API_ROUTES.policies.expire(policyId), request);
  }

  /**
   * Submits a policy renewal. Like application, renewals are idempotent.
   */
  renew(
    policyId: string,
    request: RenewPolicyRequest,
    idempotencyKey: string,
  ): Observable<RenewalResponse> {
    return this.postIdempotent<RenewalResponse>(
      API_ROUTES.policies.renew(policyId),
      request,
      idempotencyKey,
    );
  }

  /**
   * Submits a mid-term policy mitigation endorsement on an active policy.
   */
  endorse(
    policyId: string,
    request: PolicyEndorsementRequest,
    idempotencyKey: string,
  ): Observable<PolicyEndorsementResponse> {
    return this.postIdempotent<PolicyEndorsementResponse>(
      API_ROUTES.policies.endorse(policyId),
      request,
      idempotencyKey,
    );
  }

  /**
   * Retrieves an on-demand, read-only renewal estimate.
   */
  getRenewalEstimate(
    policyId: string,
    request: RenewalEstimateRequest,
  ): Observable<RenewalEstimateResponse> {
    return this.post<RenewalEstimateResponse>(
      API_ROUTES.policies.renewalEstimate(policyId),
      request,
    );
  }

  getUnderwritingQueue(
    request: UnderwritingSearchRequest = {},
  ): Observable<PagedResponse<UnderwritingQueueItemResponse>> {
    return this.getPaged<UnderwritingQueueItemResponse>(API_ROUTES.policies.underwriting, request);
  }

  getUnderwritingDetails(policyId: string): Observable<UnderwritingDetailsResponse> {
    return this.get<UnderwritingDetailsResponse>(API_ROUTES.policies.underwritingDetails(policyId));
  }

  approve(policyId: string, request: ApprovePolicyRequest): Observable<PolicyMutationResponse> {
    return this.post<PolicyMutationResponse>(API_ROUTES.policies.approve(policyId), request);
  }

  reject(policyId: string, request: RejectPolicyRequest): Observable<PolicyMutationResponse> {
    return this.post<PolicyMutationResponse>(API_ROUTES.policies.reject(policyId), request);
  }

  /**
   * Underwriter revision: re-runs risk and premium with verified property facts.
   * The application stays in Underwriting so it can then be approved or rejected.
   */
  revise(policyId: string, request: RevisePolicyRequest): Observable<PolicyMutationResponse> {
    return this.post<PolicyMutationResponse>(API_ROUTES.policies.revise(policyId), request);
  }

  getCoverageTypes(): Observable<CoverageTypeResponse[]> {
    return this.get<CoverageTypeResponse[]>(API_ROUTES.policies.coverageTypes);
  }

  getAdminCoverageTypes(): Observable<CoverageTypeResponse[]> {
    return this.get<CoverageTypeResponse[]>(API_ROUTES.policies.adminCoverageTypes);
  }

  getAdminPlans(
    request: PlanSearchRequest = {},
  ): Observable<PagedResponse<PlanAdministrationResponse>> {
    return this.getPaged<PlanAdministrationResponse>(API_ROUTES.policies.adminPlans, request);
  }

  createPlan(request: CreatePlanRequest): Observable<PlanAdministrationResponse> {
    return this.post<PlanAdministrationResponse>(API_ROUTES.policies.plans, request);
  }

  updatePlan(planId: string, request: UpdatePlanRequest): Observable<PlanAdministrationResponse> {
    return this.put<PlanAdministrationResponse>(API_ROUTES.policies.plan(planId), request);
  }

  replacePlanCoverages(
    planId: string,
    request: ReplacePlanCoveragesRequest,
  ): Observable<PlanAdministrationResponse> {
    return this.put<PlanAdministrationResponse>(API_ROUTES.policies.planCoverages(planId), request);
  }

  activatePlan(planId: string, rowVersion: string): Observable<PlanAdministrationResponse> {
    return this.postRowVersion<PlanAdministrationResponse>(
      API_ROUTES.policies.activatePlan(planId),
      rowVersion,
    );
  }

  deactivatePlan(planId: string, rowVersion: string): Observable<PlanAdministrationResponse> {
    return this.postRowVersion<PlanAdministrationResponse>(
      API_ROUTES.policies.deactivatePlan(planId),
      rowVersion,
    );
  }

  createCoverageType(request: CreateCoverageTypeRequest): Observable<CoverageTypeResponse> {
    return this.post<CoverageTypeResponse>(API_ROUTES.policies.coverageTypes, request);
  }

  updateCoverageType(
    coverageTypeId: string,
    request: UpdateCoverageTypeRequest,
  ): Observable<CoverageTypeResponse> {
    return this.put<CoverageTypeResponse>(
      API_ROUTES.policies.coverageType(coverageTypeId),
      request,
    );
  }

  activateCoverageType(
    coverageTypeId: string,
    rowVersion: string,
  ): Observable<CoverageTypeResponse> {
    return this.postRowVersion<CoverageTypeResponse>(
      API_ROUTES.policies.activateCoverageType(coverageTypeId),
      rowVersion,
    );
  }

  deactivateCoverageType(
    coverageTypeId: string,
    rowVersion: string,
  ): Observable<CoverageTypeResponse> {
    return this.postRowVersion<CoverageTypeResponse>(
      API_ROUTES.policies.deactivateCoverageType(coverageTypeId),
      rowVersion,
    );
  }

  private get<T>(route: string): Observable<T> {
    return this.http.get<ApiResponse<T>>(apiUrl(route)).pipe(map((response) => response.data));
  }

  private getPaged<T>(route: string, request: object): Observable<PagedResponse<T>> {
    return this.http
      .get<ApiResponse<PagedResponse<T>>>(apiUrl(route), {
        params: toHttpParams({
          ...request,
        }),
      })
      .pipe(map((response) => response.data));
  }

  private post<T>(route: string, body: unknown): Observable<T> {
    return this.http
      .post<ApiResponse<T>>(apiUrl(route), body)
      .pipe(map((response) => response.data));
  }

  private put<T>(route: string, body: unknown): Observable<T> {
    return this.http
      .put<ApiResponse<T>>(apiUrl(route), body)
      .pipe(map((response) => response.data));
  }

  /**
   * Injects the X-Idempotency-Key header on mutating operations so the backend can cache and replay identical calls safely.
   */
  private postIdempotent<T>(route: string, body: unknown, idempotencyKey: string): Observable<T> {
    const headers = new HttpHeaders().set(API_HEADERS.idempotencyKey, idempotencyKey);

    return this.http
      .post<ApiResponse<T>>(apiUrl(route), body, {
        headers,
      })
      .pipe(map((response) => response.data));
  }

  /**
   * Sends optimistic concurrency rowVersion to avoid overwriting changes made by another admin or process.
   */
  private postRowVersion<T>(route: string, rowVersion: string): Observable<T> {
    return this.http
      .post<ApiResponse<T>>(apiUrl(route), {
        rowVersion,
      })
      .pipe(map((response) => response.data));
  }
}



import { CommonModule } from '@angular/common';
import {
  ChangeDetectionStrategy,
  Component,
  OnDestroy,
  OnInit,
  inject,
  signal,
} from '@angular/core';
import { FormArray, FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { Subject, forkJoin, takeUntil } from 'rxjs';

import { ApiClientError } from '../../../core/interceptors/error.interceptor';
import type { PagedResponse } from '../../../core/models/pagination.models';
import { NotificationService } from '../../../core/services/notification.service';
import { HurricaneValidators } from '../../../shared/validators/hurricane.validators';
import type {
  CoverageTypeResponse,
  CreatePlanRequest,
  PlanAdministrationResponse,
  PlanCoverageAssignmentRequest,
  PlanDetailsResponse,
  UpdatePlanRequest,
} from '../policy.models';
import { PolicyService } from '../policy.service';

function planForm() {
  return new FormGroup({
    planCode: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required, Validators.maxLength(50)],
    }),
    planName: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required, Validators.maxLength(150)],
    }),
    description: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required, Validators.maxLength(1000)],
    }),
    basePremium: new FormControl<number | null>(null, [
      Validators.required,
      HurricaneValidators.positiveNumber,
    ]),
    coverageLimit: new FormControl<number | null>(null, [
      Validators.required,
      HurricaneValidators.positiveNumber,
    ]),
    deductibleAmount: new FormControl<number | null>(null, [
      Validators.required,
      HurricaneValidators.nonNegativeNumber,
    ]),
    rowVersion: new FormControl('', { nonNullable: true }),
  });
}
function coverageTypeForm() {
  return new FormGroup({
    name: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required, Validators.maxLength(150)],
    }),
    description: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required, Validators.maxLength(1000)],
    }),
    rowVersion: new FormControl('', { nonNullable: true }),
  });
}
function assignmentForm() {
  return new FormGroup({
    coverageTypeId: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required, HurricaneValidators.guid],
    }),
    coverageLimit: new FormControl<number | null>(null, [
      Validators.required,
      HurricaneValidators.positiveNumber,
    ]),
    deductibleAmount: new FormControl<number | null>(null, [
      Validators.required,
      HurricaneValidators.nonNegativeNumber,
    ]),
  });
}

import { FormFieldErrorComponent } from '../../../shared/components/form-field-error/form-field-error.component';

@Component({
  selector: 'app-plan-admin-connected-page',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink,
    FormFieldErrorComponent
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl:
  './plan-admin-connected-page.component.html',
})
export class PlanAdminConnectedPageComponent implements OnInit, OnDestroy {
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);
  private readonly policies = inject(PolicyService);
  private readonly notifications = inject(NotificationService);
  private readonly destroy$ = new Subject<void>();
  readonly pageKey = signal('admin.plan-list');
  readonly busy = signal(false);
  readonly errorMessage = signal('');
  readonly plans = signal<PagedResponse<PlanAdministrationResponse>>({
    items: [],
    page: 1,
    pageSize: 20,
    totalCount: 0,
    totalPages: 0,
  });
  readonly coverageTypes = signal<CoverageTypeResponse[]>([]);
  readonly selectedPlan = signal<PlanAdministrationResponse | null>(null);
  readonly planDetails = signal<PlanDetailsResponse | null>(null);
  readonly planSearch = new FormControl('', { nonNullable: true });
  readonly planActive = new FormControl('', { nonNullable: true });
  readonly planEditorForm = planForm();
  readonly coverageEditorForm = coverageTypeForm();
  readonly coveragesForm = new FormGroup({
    coverages: new FormArray<ReturnType<typeof assignmentForm>>([]),
  });
  readonly title = () =>
    ({
      'admin.plan-list': 'Plan Administration',
      'admin.plan-create': 'Create Plan',
      'admin.plan-edit': 'Edit Plan',
      'admin.plan-coverages': 'Plan Coverage Assignment',
      'admin.coverage-types': 'Coverage Types',
      'admin.coverage-type-create': 'Create Coverage Type',
      'admin.coverage-type-edit': 'Edit Coverage Type',
    })[this.pageKey()] ?? 'Plan Administration';
  readonly description = () =>
    this.pageKey() === 'admin.plan-coverages'
      ? 'Replace the complete set of Coverage assignments using the current Plan RowVersion.'
      : 'Manage Plans and Coverage Types with optimistic concurrency.';
  get coverageAssignments() {
    return this.coveragesForm.controls.coverages;
  }
  activeCoverageTypes = () => this.coverageTypes().filter((x) => x.isActive);
  ngOnInit() {
    this.route.data.pipe(takeUntil(this.destroy$)).subscribe((data) => {
      this.pageKey.set(String(data['pageKey'] ?? 'admin.plan-list'));
      this.loadPage();
    });
  }
  ngOnDestroy() {
    this.destroy$.next();
    this.destroy$.complete();
  }
  loadPage() {
    this.errorMessage.set('');
    const key = this.pageKey();
    if (key === 'admin.plan-list') this.loadPlans(1);
    else if (key === 'admin.plan-create') return;
    else if (key === 'admin.plan-edit' || key === 'admin.plan-coverages') this.loadPlanAdmin();
    else if (key === 'admin.coverage-types') this.loadCoverageTypes();
    else if (key === 'admin.coverage-type-edit') this.loadCoverageTypeForEdit();
  }
  loadPlans(page: number): void {
    if (this.busy()) {
      return;
    }

    const search = this.planSearch.value.trim();

    const activeValue = this.planActive.value;

    this.errorMessage.set('');
    this.busy.set(true);

    this.policies
      .getAdminPlans({
        page,
        pageSize: 20,
        search: search || undefined,
        isActive: activeValue === '' ? undefined : activeValue === 'true',
      })
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response) => {
          this.plans.set(response);
          this.busy.set(false);
        },
        error: (error) => {
          this.fail(error);
        },
      });
  }
  searchPlans(): void {
    this.loadPlans(1);
  }

  resetPlanSearch(): void {
    this.planSearch.setValue('', {
      emitEvent: false,
    });

    this.planActive.setValue('', {
      emitEvent: false,
    });

    this.loadPlans(1);
  }
  loadPlanAdmin() {
    const id = this.route.snapshot.paramMap.get('planId');
    if (!id) return;
    this.busy.set(true);
    forkJoin({
      plans: this.policies.getAdminPlans({ page: 1, pageSize: 100 }),
      details: this.policies.getPlan(id),
      types: this.policies.getAdminCoverageTypes(),
    })
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (x) => {
          const admin = x.plans.items.find((p) => p.planId === id);
          if (!admin) {
            this.fail(new Error('Plan not found.'));
            return;
          }
          this.selectedPlan.set(admin);
          this.planDetails.set(x.details);
          this.coverageTypes.set(x.types);
          this.planEditorForm.setValue({
            planCode: admin.planCode,
            planName: admin.planName,
            description: admin.description,
            basePremium: admin.basePremium,
            coverageLimit: admin.coverageLimit,
            deductibleAmount: admin.deductibleAmount,
            rowVersion: admin.rowVersion,
          });
          this.coverageAssignments.clear();
          for (const c of x.details.coverages) {
            const g = assignmentForm();
            g.setValue({
              coverageTypeId: c.coverageTypeId,
              coverageLimit: c.coverageLimit,
              deductibleAmount: c.deductibleAmount,
            });
            this.coverageAssignments.push(g);
          }
          this.busy.set(false);
        },
        error: (e) => this.fail(e),
      });
  }
  savePlan() {
    if (this.planEditorForm.invalid || this.busy()) return;
    const v = this.planEditorForm.getRawValue();
    const request: CreatePlanRequest = {
      planCode: v.planCode.trim(),
      planName: v.planName.trim(),
      description: v.description.trim(),
      basePremium: v.basePremium!,
      coverageLimit: v.coverageLimit!,
      deductibleAmount: v.deductibleAmount!,
    };
    this.busy.set(true);
    const id = this.route.snapshot.paramMap.get('planId');
    const call = id
      ? this.policies.updatePlan(id, { ...request, rowVersion: v.rowVersion } as UpdatePlanRequest)
      : this.policies.createPlan(request);
    call.pipe(takeUntil(this.destroy$)).subscribe({
      next: () => {
        this.busy.set(false);
        this.notifications.success(
          id ? 'Plan updated' : 'Plan created',
          'The Plan was saved successfully.',
        );
        void this.router.navigateByUrl('/admin/plans/list');
      },
      error: (e) => this.fail(e),
    });
  }
  togglePlan(item: PlanAdministrationResponse): void {
    if (this.busy()) {
      return;
    }

    this.errorMessage.set('');
    this.busy.set(true);

    const request$ = item.isActive
      ? this.policies.deactivatePlan(item.planId, item.rowVersion)
      : this.policies.activatePlan(item.planId, item.rowVersion);

    request$.pipe(takeUntil(this.destroy$)).subscribe({
      next: (updatedPlan) => {
        this.notifications.success(
          updatedPlan.isActive ? 'Plan activated' : 'Plan deactivated',
          `Plan ${updatedPlan.planCode} was updated successfully.`,
        );

        this.busy.set(false);
        this.loadPlans(this.plans().page);
      },
      error: (error) => {
        this.fail(error);
      },
    });
  }
  addAssignment() {
    this.coverageAssignments.push(assignmentForm());
  }
  removeAssignment(i: number) {
    this.coverageAssignments.removeAt(i);
  }
  duplicateCoverageAssignment() {
    const ids = this.coverageAssignments.controls
      .map((x) => x.controls.coverageTypeId.value)
      .filter(Boolean);
    return new Set(ids).size !== ids.length;
  }
  saveCoverages() {
    const plan = this.selectedPlan();
    if (!plan || this.coveragesForm.invalid || this.duplicateCoverageAssignment()) return;
    const coverages: PlanCoverageAssignmentRequest[] = this.coverageAssignments
      .getRawValue()
      .map((x) => ({
        coverageTypeId: x.coverageTypeId,
        coverageLimit: x.coverageLimit!,
        deductibleAmount: x.deductibleAmount!,
      }));
    this.busy.set(true);
    this.policies
      .replacePlanCoverages(plan.planId, { coverages, rowVersion: plan.rowVersion })
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: () => {
          this.busy.set(false);
          this.notifications.success(
            'Coverages replaced',
            'The complete Plan Coverage list was replaced.',
          );
          void this.router.navigateByUrl('/admin/plans/list');
        },
        error: (e) => this.fail(e),
      });
  }
  loadCoverageTypes() {
    this.busy.set(true);
    this.policies
      .getAdminCoverageTypes()
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (x) => {
          this.coverageTypes.set(x);
          this.busy.set(false);
        },
        error: (e) => this.fail(e),
      });
  }
  loadCoverageTypeForEdit() {
    const id = this.route.snapshot.paramMap.get('coverageTypeId');
    if (!id) return;
    this.busy.set(true);
    this.policies
      .getAdminCoverageTypes()
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (x) => {
          const item = x.find((c) => c.coverageTypeId === id);
          if (!item) {
            this.fail(new Error('Coverage Type not found.'));
            return;
          }
          this.coverageEditorForm.setValue({
            name: item.name,
            description: item.description,
            rowVersion: item.rowVersion,
          });
          this.busy.set(false);
        },
        error: (e) => this.fail(e),
      });
  }
  saveCoverageType() {
    if (this.coverageEditorForm.invalid || this.busy()) return;
    const v = this.coverageEditorForm.getRawValue();
    const id = this.route.snapshot.paramMap.get('coverageTypeId');
    this.busy.set(true);
    const call = id
      ? this.policies.updateCoverageType(id, {
          name: v.name.trim(),
          description: v.description.trim(),
          rowVersion: v.rowVersion,
        })
      : this.policies.createCoverageType({
          name: v.name.trim(),
          description: v.description.trim(),
        });
    call.pipe(takeUntil(this.destroy$)).subscribe({
      next: () => {
        this.busy.set(false);
        this.notifications.success(
          id ? 'Coverage Type updated' : 'Coverage Type created',
          'The Coverage Type was saved successfully.',
        );
        void this.router.navigateByUrl('/admin/plans/coverage-types');
      },
      error: (e) => this.fail(e),
    });
  }
  
  toggleCoverageType(item: CoverageTypeResponse): void {
    if (this.busy()) {
      return;
    }

    this.errorMessage.set('');
    this.busy.set(true);

    const request$ = item.isActive
      ? this.policies.deactivateCoverageType(item.coverageTypeId, item.rowVersion)
      : this.policies.activateCoverageType(item.coverageTypeId, item.rowVersion);

    request$.pipe(takeUntil(this.destroy$)).subscribe({
      next: (updatedCoverageType) => {
        this.notifications.success(
          updatedCoverageType.isActive ? 'Coverage Type activated' : 'Coverage Type deactivated',
          `${updatedCoverageType.name} was updated successfully.`,
        );

        this.busy.set(false);
        this.loadCoverageTypes();
      },
      error: (error) => {
        this.fail(error);
      },
    });
  }
  hasUnsavedChanges() {
    return this.planEditorForm.dirty || this.coverageEditorForm.dirty || this.coveragesForm.dirty;
  }
  private fail(error: unknown) {
    this.busy.set(false);
    this.errorMessage.set(
      error instanceof ApiClientError
        ? error.message
        : error instanceof Error
          ? error.message
          : 'The request could not be completed.',
    );
  }
}

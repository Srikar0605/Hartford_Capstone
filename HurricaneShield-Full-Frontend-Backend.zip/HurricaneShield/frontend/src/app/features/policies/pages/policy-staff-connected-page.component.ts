

import { CommonModule } from '@angular/common';
import {
  ChangeDetectionStrategy,
  Component,
  OnDestroy,
  OnInit,
  computed,
  inject,
  signal,
} from '@angular/core';
import {
  AbstractControl,
  FormArray,
  FormControl,
  FormGroup,
  ReactiveFormsModule,
  ValidationErrors,
  ValidatorFn,
  Validators,
} from '@angular/forms';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { Subject, forkJoin, of, takeUntil } from 'rxjs';

import { AuthStore } from '../../../core/auth/auth.store';
import { SYSTEM_PERMISSIONS } from '../../../core/constants/permissions';
import { SYSTEM_ROLES } from '../../../core/constants/roles';
import {
  CONSTRUCTION_TYPES,
  POLICY_STATUSES,
  RISK_LEVELS,
  RISK_ZONES,
  type ConstructionType,
  type PolicyStatus,
  type RiskLevel,
  type RiskZone,
} from '../../../core/constants/statuses';
import { ApiClientError } from '../../../core/interceptors/error.interceptor';
import type { PagedResponse } from '../../../core/models/pagination.models';
import { NotificationService } from '../../../core/services/notification.service';
import { HurricaneValidators } from '../../../shared/validators/hurricane.validators';
import type {
  PolicyDetailsResponse,
  PolicyHistoryResponse,
  PolicyVersionResponse,
  StaffPolicySummaryResponse,
  UnderwritingDetailsResponse,
  RevisePolicyRequest,
  UnderwritingQueueItemResponse,
} from '../policy.models';
import { PolicyService } from '../policy.service';

function orderedRangeValidator(
  firstName: string,
  secondName: string,
  numeric = false,
): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const firstRaw = control.get(firstName)?.value;
    const secondRaw = control.get(secondName)?.value;
    if (firstRaw === null || firstRaw === '' || secondRaw === null || secondRaw === '') return null;
    const first = numeric ? Number(firstRaw) : new Date(String(firstRaw)).getTime();
    const second = numeric ? Number(secondRaw) : new Date(String(secondRaw)).getTime();
    return Number.isFinite(first) && Number.isFinite(second) && first <= second
      ? null
      : { invalidRange: { firstName, secondName } };
  };
}

function nonWhitespaceValidator(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const value = String(control.value ?? '');

    return value.trim().length > 0
      ? null
      : {
          whitespace: true,
        };
  };
}

function createStaffSearchForm() {
  return new FormGroup(
    {
      search: new FormControl('', { nonNullable: true, validators: [Validators.maxLength(100)] }),
      status: new FormControl('', { nonNullable: true }),
      customerId: new FormControl('', {
        nonNullable: true,
        validators: [HurricaneValidators.guid],
      }),
      planId: new FormControl('', { nonNullable: true, validators: [HurricaneValidators.guid] }),
      createdFrom: new FormControl('', { nonNullable: true }),
      createdTo: new FormControl('', { nonNullable: true }),
    },
    { validators: [orderedRangeValidator('createdFrom', 'createdTo')] },
  );
}

function createQueueForm() {
  return new FormGroup(
    {
      riskLevel: new FormControl('', { nonNullable: true }),
      planId: new FormControl('', { nonNullable: true, validators: [HurricaneValidators.guid] }),
      minimumPropertyAge: new FormControl<number | null>(null, [
        HurricaneValidators.nonNegativeNumber,
      ]),
      maximumPropertyAge: new FormControl<number | null>(null, [
        HurricaneValidators.nonNegativeNumber,
      ]),
      submittedFrom: new FormControl('', { nonNullable: true }),
      submittedTo: new FormControl('', { nonNullable: true }),
    },
    {
      validators: [
        orderedRangeValidator('minimumPropertyAge', 'maximumPropertyAge', true),
        orderedRangeValidator('submittedFrom', 'submittedTo'),
      ],
    },
  );
}

/** Underwriter revision form: verified property facts, the coverage to quote, and why. */
function createReviseForm() {
  return new FormGroup({
    propertyValue: new FormControl<number | null>(null, [Validators.required, Validators.min(1)]),
    yearBuilt: new FormControl<number | null>(null, [
      Validators.required,
      Validators.min(1800),
      Validators.max(new Date().getFullYear()),
    ]),
    constructionType: new FormControl<ConstructionType>('Masonry', { nonNullable: true }),
    riskZone: new FormControl<RiskZone>('B', { nonNullable: true }),
    claimsHistoryCount: new FormControl<number>(0, {
      nonNullable: true,
      validators: [Validators.required, Validators.min(0), Validators.max(50)],
    }),
    requestedCoverage: new FormControl<number | null>(null, [Validators.required, Validators.min(1)]),
    stormShutters: new FormControl(false, { nonNullable: true }),
    impactResistantWindows: new FormControl(false, { nonNullable: true }),
    reinforcedRoof: new FormControl(false, { nonNullable: true }),
    emergencyGenerator: new FormControl(false, { nonNullable: true }),
    homeInspectionCertification: new FormControl(false, { nonNullable: true }),
    revisionReason: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required, nonWhitespaceValidator(), Validators.maxLength(500)],
    }),
  });
}

function createReasonForm() {
  return new FormGroup({
    reasonCode: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required, nonWhitespaceValidator(), Validators.maxLength(100)],
    }),

    reasonDescription: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required, nonWhitespaceValidator(), Validators.maxLength(500)],
    }),
  });
}

import { FormFieldErrorComponent } from '../../../shared/components/form-field-error/form-field-error.component';

import { IconComponent } from '../../../shared/components/icon/icon.component';
import { StatusBadgeComponent } from '../../../shared/components/status-badge/status-badge.component';
import { SlideOverComponent } from '../../../shared/components/slide-over/slide-over.component';

@Component({
  selector: 'app-policy-staff-connected-page',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink,
    FormFieldErrorComponent,
    IconComponent,
    StatusBadgeComponent,
    SlideOverComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './policy-staff-connected-page.component.html',
})
export class PolicyStaffConnectedPageComponent implements OnInit, OnDestroy {
  private readonly route = inject(ActivatedRoute);
  private readonly service = inject(PolicyService);
  private readonly notifications = inject(NotificationService);
  private readonly authStore = inject(AuthStore);
  private readonly destroy$ = new Subject<void>();

  readonly pageKey = signal('staff.policy-search');
  readonly busy = signal(false);
  readonly errorMessage = signal('');
  readonly policies = signal<PagedResponse<StaffPolicySummaryResponse>>({
    items: [],
    page: 1,
    pageSize: 20,
    totalCount: 0,
    totalPages: 0,
  });
  /** Row opened in the quick-view panel (UI state only). */
  readonly quickViewPolicy = signal<StaffPolicySummaryResponse | null>(null);
  readonly queueItems = signal<PagedResponse<UnderwritingQueueItemResponse>>({
    items: [],
    page: 1,
    pageSize: 20,
    totalCount: 0,
    totalPages: 0,
  });
  readonly policy = signal<PolicyDetailsResponse | null>(null);
  readonly reviewDetails = signal<UnderwritingDetailsResponse | null>(null);
  readonly versions = signal<PolicyVersionResponse[]>([]);
  readonly history = signal<PolicyHistoryResponse[]>([]);

  readonly searchForm = createStaffSearchForm();
  readonly queueSearchForm = createQueueForm();
  readonly actionForm = new FormGroup({
    reason: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required, Validators.maxLength(500)],
    }),
  });
  readonly decisionForm = new FormGroup({ reasons: new FormArray([createReasonForm()]) });
  readonly reviseForm = createReviseForm();
  /** Whether the "Revise & re-quote" panel is expanded (UI state only). */
  readonly reviseOpen = signal(false);
  readonly constructionTypes = CONSTRUCTION_TYPES;
  readonly riskZones = RISK_ZONES;
  readonly mitigationFields = [
    { key: 'stormShutters', label: 'Storm shutters' },
    { key: 'impactResistantWindows', label: 'Impact-resistant windows' },
    { key: 'reinforcedRoof', label: 'Reinforced roof' },
    { key: 'emergencyGenerator', label: 'Emergency generator' },
    { key: 'homeInspectionCertification', label: 'Home inspection certificate' },
  ] as const;
  readonly statuses = POLICY_STATUSES;
  readonly risks = RISK_LEVELS;

  readonly isAdministrator = computed(() => this.authStore.hasRole(SYSTEM_ROLES.administrator));
  readonly canManagePolicies = computed(() =>
    this.authStore.hasPermission(SYSTEM_PERMISSIONS.managePolicies),
  );
  readonly canApprovePolicies = computed(() =>
    this.authStore.hasPermission(SYSTEM_PERMISSIONS.approvePolicies),
  );
  readonly canRejectPolicies = computed(() =>
    this.authStore.hasPermission(SYSTEM_PERMISSIONS.rejectPolicies),
  );

  get reasons() {
    return this.decisionForm.controls.reasons;
  }

  readonly title = computed(
    () =>
      ({
        'staff.policy-search': 'Customer Policy Search',
        'staff.policy-details': 'Customer Policy Details',
        'staff.underwriting-queue': 'Underwriting Queue',
        'staff.underwriting-review': 'Underwriting Review',
      })[this.pageKey()] ?? 'Customer Policies',
  );

  readonly description = computed(() =>
    this.pageKey().includes('underwriting')
      ? 'Review Customer Policy applications awaiting a risk decision.'
      : 'Search and service Policies issued to Customers.',
  );

  ngOnInit(): void {
    this.route.data.pipe(takeUntil(this.destroy$)).subscribe((data) => {
      this.pageKey.set(String(data['pageKey']));
      this.loadPage();
    });
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  private loadPage(): void {
    this.errorMessage.set('');
    if (this.pageKey() === 'staff.policy-search') this.loadPolicies(1);
    else if (this.pageKey() === 'staff.underwriting-queue') this.loadQueue(1);
    else if (this.pageKey() === 'staff.underwriting-review') this.loadReview();
    else this.loadDetails();
  }

  loadPolicies(page: number): void {
    if (this.searchForm.invalid || this.busy()) {
      this.searchForm.markAllAsTouched();
      return;
    }
    const value = this.searchForm.getRawValue();
    this.busy.set(true);
    this.errorMessage.set('');
    this.service
      .searchPolicies({
        page,
        pageSize: 20,
        search: value.search.trim() || undefined,
        status: (value.status as PolicyStatus) || undefined,
        customerId: value.customerId.trim() || undefined,
        planId: value.planId.trim() || undefined,
        createdFrom: value.createdFrom ? new Date(value.createdFrom).toISOString() : undefined,
        createdTo: value.createdTo ? new Date(value.createdTo).toISOString() : undefined,
      })
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (result) => {
          this.policies.set(result);
          this.busy.set(false);
        },
        error: (error) => this.fail(error),
      });
  }

  resetPolicySearch(): void {
    this.searchForm.reset({
      search: '',
      status: '',
      customerId: '',
      planId: '',
      createdFrom: '',
      createdTo: '',
    });
    this.loadPolicies(1);
  }

  loadQueue(page: number): void {
    if (this.queueSearchForm.invalid || this.busy()) {
      this.queueSearchForm.markAllAsTouched();
      return;
    }
    const value = this.queueSearchForm.getRawValue();
    this.busy.set(true);
    this.errorMessage.set('');
    this.service
      .getUnderwritingQueue({
        page,
        pageSize: 20,
        riskLevel: (value.riskLevel as RiskLevel) || undefined,
        planId: value.planId.trim() || undefined,
        minimumPropertyAge: value.minimumPropertyAge ?? undefined,
        maximumPropertyAge: value.maximumPropertyAge ?? undefined,
        submittedFrom: value.submittedFrom
          ? new Date(value.submittedFrom).toISOString()
          : undefined,
        submittedTo: value.submittedTo ? new Date(value.submittedTo).toISOString() : undefined,
      })
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (result) => {
          this.queueItems.set(result);
          this.busy.set(false);
        },
        error: (error) => this.fail(error),
      });
  }

  resetQueueSearch(): void {
    this.queueSearchForm.reset({
      riskLevel: '',
      planId: '',
      minimumPropertyAge: null,
      maximumPropertyAge: null,
      submittedFrom: '',
      submittedTo: '',
    });
    this.loadQueue(1);
  }

  private loadDetails(): void {
    const id = this.route.snapshot.paramMap.get('policyId');
    if (!id) return;
    this.busy.set(true);
    this.errorMessage.set('');
    const request = this.isAdministrator()
      ? forkJoin({
          policy: this.service.getStaffPolicy(id),
          versions: this.service.getStaffVersions(id),
          history: this.service.getStaffHistory(id),
        })
      : forkJoin({
          policy: this.service.getStaffPolicy(id),
          versions: of([] as PolicyVersionResponse[]),
          history: of([] as PolicyHistoryResponse[]),
        });
    request.pipe(takeUntil(this.destroy$)).subscribe({
      next: (result) => {
        this.policy.set(result.policy);
        this.versions.set(result.versions);
        this.history.set(result.history);
        this.busy.set(false);
      },
      error: (error) => this.fail(error),
    });
  }

  private loadReview(): void {
    const id = this.route.snapshot.paramMap.get('policyId');
    if (!id) return;
    this.busy.set(true);
    this.errorMessage.set('');
    this.service
      .getUnderwritingDetails(id)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (result) => {
          this.reviewDetails.set(result);
          this.busy.set(false);
        },
        error: (error) => this.fail(error),
      });
  }

  /** Opens the revision panel pre-filled with the property facts currently on the application. */
  openRevise(): void {
    const details = this.reviewDetails();
    if (!details) return;
    const property = details.policy.property;
    const plan = details.policy.plan;
    this.reviseForm.reset({
      propertyValue: property.propertyValue,
      yearBuilt: property.yearBuilt,
      constructionType: property.constructionType,
      riskZone: property.riskZone,
      claimsHistoryCount: 0,
      requestedCoverage: Math.min(property.propertyValue, plan.coverageLimit),
      stormShutters: property.stormShutters,
      impactResistantWindows: property.impactResistantWindows,
      reinforcedRoof: property.reinforcedRoof,
      emergencyGenerator: property.emergencyGenerator,
      homeInspectionCertification: property.homeInspectionCertification,
      revisionReason: '',
    });
    this.reviseOpen.set(true);
  }

  /** "ReinforcedConcrete" → "Reinforced concrete". */
  constructionLabel(type: string): string {
    const spaced = type.replace(/([a-z])([A-Z])/g, '$1 $2').toLowerCase();
    return spaced.charAt(0).toUpperCase() + spaced.slice(1);
  }

  closeRevise(): void {
    this.reviseOpen.set(false);
  }

  /** Coverage cannot exceed the property value or the plan limit (same rule as the backend). */
  readonly maxRevisedCoverage = computed(() => {
    const details = this.reviewDetails();
    return details ? details.policy.plan.coverageLimit : null;
  });

  submitRevise(): void {
    const details = this.reviewDetails();
    if (!details || details.reviewStatus !== 'Pending' || this.busy()) return;

    const v = this.reviseForm.getRawValue();
    const propertyValue = Number(v.propertyValue);
    const coverage = Number(v.requestedCoverage);
    if (coverage > propertyValue || coverage > details.policy.plan.coverageLimit) {
      this.reviseForm.controls.requestedCoverage.setErrors({ coverageTooHigh: true });
    }
    if (this.reviseForm.invalid) {
      this.reviseForm.markAllAsTouched();
      return;
    }

    const request: RevisePolicyRequest = {
      revisedProperty: {
        propertyValue,
        yearBuilt: Number(v.yearBuilt),
        constructionType: v.constructionType,
        riskZone: v.riskZone,
        claimsHistoryCount: Number(v.claimsHistoryCount),
        stormShutters: v.stormShutters,
        impactResistantWindows: v.impactResistantWindows,
        reinforcedRoof: v.reinforcedRoof,
        emergencyGenerator: v.emergencyGenerator,
        homeInspectionCertification: v.homeInspectionCertification,
      },
      requestedCoverage: coverage,
      revisionReason: v.revisionReason.trim(),
      policyRowVersion: details.policy.rowVersion,
      reviewRowVersion: details.reviewRowVersion,
    };

    this.errorMessage.set('');
    this.busy.set(true);
    this.service
      .revise(details.policy.policyId, request)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: () => {
          this.notifications.success(
            'Application re-quoted',
            'Risk and premium were recalculated. Review the new figures, then approve or reject.',
          );
          this.busy.set(false);
          this.reviseOpen.set(false);
          this.loadReview();
        },
        error: (error) => this.fail(error),
      });
  }

  addReason(): void {
    this.reasons.push(createReasonForm());
  }
  removeReason(index: number): void {
    if (this.reasons.length > 1) this.reasons.removeAt(index);
  }

  decide(approve: boolean): void {
    const details = this.reviewDetails();

    if (!details || details.reviewStatus !== 'Pending' || this.busy()) {
      return;
    }

    if (this.decisionForm.invalid) {
      this.decisionForm.markAllAsTouched();

      return;
    }

    const reasons = this.reasons.getRawValue().map((reason) => ({
      reasonCode: reason.reasonCode.trim(),

      reasonDescription: reason.reasonDescription.trim(),
    }));

    const request = {
      reasons,

      policyRowVersion: details.policy.rowVersion,

      reviewRowVersion: details.reviewRowVersion,
    };

    this.errorMessage.set('');

    this.busy.set(true);

    const operation = approve
      ? this.service.approve(details.policy.policyId, request)
      : this.service.reject(details.policy.policyId, request);

    operation.pipe(takeUntil(this.destroy$)).subscribe({
      next: () => {
        this.notifications.success(
          approve ? 'Policy approved' : 'Policy rejected',

          'Underwriting decision completed.',
        );

        this.busy.set(false);

        this.loadReview();
      },

      error: (error) => this.fail(error),
    });
  }

  lifecycle(action: 'suspend' | 'reactivate' | 'expire'): void {
    const current = this.policy();
    if (!current || !this.canManagePolicies() || this.actionForm.invalid || this.busy()) return;
    const request = {
      reason: this.actionForm.controls.reason.value.trim(),
      rowVersion: current.rowVersion,
    };
    this.busy.set(true);
    this.service[action](current.policyId, request)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (result) => {
          this.notifications.success(
            'Policy updated',
            `Policy status changed to ${result.status}.`,
          );
          this.actionForm.reset({ reason: '' });
          this.busy.set(false);
          this.loadDetails();
        },
        error: (error) => this.fail(error),
      });
  }

  private fail(error: unknown): void {
    this.busy.set(false);
    this.errorMessage.set(
      error instanceof ApiClientError
        ? error.message
        : error instanceof Error
          ? error.message
          : 'Request failed.',
    );
  }
}

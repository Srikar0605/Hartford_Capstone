
import { CommonModule } from '@angular/common';
import {
  ChangeDetectionStrategy,
  Component,
  computed,
  effect,
  OnDestroy,
  OnInit,
  inject,
  signal,
} from '@angular/core';
import { CustomerQuoteEstimateComponent } from '../customer-quote-estimate/customer-quote-estimate.component';
import { ReactiveFormsModule } from '@angular/forms';
import { A11yModule } from '@angular/cdk/a11y';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { catchError, forkJoin, of, Subject, takeUntil } from 'rxjs';
import { ApiClientError } from '../../../core/interceptors/error.interceptor';
import { IDEMPOTENT_OPERATIONS } from '../../../core/constants/storage-keys';
import {
  CONSTRUCTION_TYPES,
  POLICY_STATUSES,
  RISK_ZONES,
  type ConstructionType,
  type PolicyStatus,
  type RiskZone,
} from '../../../core/constants/statuses';
import { IdempotencyService } from '../../../core/services/idempotency.service';
import { NotificationService } from '../../../core/services/notification.service';
import type { HasUnsavedChanges } from '../../../core/guards/unsaved-changes.guard';
import { ProfileService } from '../../profile/profile.service';
import type { PropertyOwnershipResponse } from '../../profile/profile.models';
import { PaymentService } from '../../payments/payment.service';
import { createPremiumPaymentForm } from '../../payments/payment.forms';
import type { PremiumPaymentResponse } from '../../payments/payment.models';
import {
  createCancelPolicyForm,
  createEndorsementForm,
  createPolicyApplicationForm,
  createRenewPolicyForm,
} from '../policy.forms';
import type {
  CalculateRecommendationsRequest,
  PlanSummaryResponse,
  PolicyApplicationResponse,
  PolicyDetailsResponse,
  PolicyEndorsementRequest,
  PolicyHistoryResponse,
  PolicySummaryResponse,
  PolicyVersionResponse,
  PropertyRiskRequest,
  QuoteResponse,
  RenewalEstimateResponse,
  CancellationPreviewResponse,
} from '../policy.models';
import { PolicyService } from '../policy.service';
import { PolicyDocumentGeneratorService } from '../policy-document-generator.service';
import type { PagedResponse } from '../../../core/models/pagination.models';

import { FormFieldErrorComponent } from '../../../shared/components/form-field-error/form-field-error.component';
import { IconComponent, type IconName } from '../../../shared/components/icon/icon.component';
import { StatusBadgeComponent } from '../../../shared/components/status-badge/status-badge.component';
import { EmptyStateComponent } from '../../../shared/components/empty-state/empty-state.component';
import { PaginationComponent } from '../../../shared/components/pagination/pagination.component';

type PaymentModalState = 'closed' | 'confirmation' | 'processing' | 'success' | 'failed';

@Component({
  selector: 'app-policy-connected-page',
  standalone: true,
  imports: [
    CommonModule,
    CustomerQuoteEstimateComponent,
    ReactiveFormsModule,
    RouterLink,
    FormFieldErrorComponent,
    IconComponent,
    StatusBadgeComponent,
    EmptyStateComponent,
    PaginationComponent,
    A11yModule,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './policy-connected-page.component.html',
  styles: [
    `
      label {
        display: block;
        color: #2a0a0d;
        font-size: 0.875rem;
        font-weight: 600;
      }
      label > .field {
        margin-top: 0.4rem;
      }
      .field {
        display: block;
        min-height: 2.75rem;
        width: 100%;
        border: 1px solid #dacbc5;
        border-radius: 0.75rem;
        padding: 0.65rem;
        background: #fff;
      }
      .button,
      .button-secondary,
      .button-danger {
        display: inline-block;
        border-radius: 999px;
        padding: 0.7rem 1.2rem;
        font-weight: 700;
      }
      .button {
        background: #400106;
        color: #fff;
      }
      .button-secondary {
        border: 1px solid #dacbc5;
        background: #fff;
      }
      .button-danger {
        background: #b91c1c;
        color: #fff;
      }
    `,
  ],
})
export class PolicyConnectedPageComponent implements OnInit, OnDestroy, HasUnsavedChanges {
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);
  private readonly policies = inject(PolicyService);
  private readonly profiles = inject(ProfileService);
  private readonly payments = inject(PaymentService);
  private readonly idem = inject(IdempotencyService);
  private readonly notifications = inject(NotificationService);
  private readonly pdfGenerator = inject(PolicyDocumentGeneratorService);
  private readonly destroyed = new Subject<void>();
  readonly pageKey = signal('');
  readonly title = signal('Policies');
  readonly loading = signal(true);
  readonly busy = signal(false);
  readonly error = signal<string | null>(null);
  readonly plans = signal<PlanSummaryResponse[]>([]);
  readonly properties = signal<PropertyOwnershipResponse[]>([]);
  readonly insuredPropertyIds = signal<Set<string>>(new Set());
  readonly uninsuredProperties = computed(() =>
    this.properties().filter((p) => !this.insuredPropertyIds().has(p.propertyOwnershipId)),
  );
  readonly isSelectedPropertyComplete = signal(false);
  readonly quote = signal<QuoteResponse | null>(null);
  readonly quotes = signal<QuoteResponse[]>([]);
  readonly applicationResult = signal<PolicyApplicationResponse | null>(
    window.history.state?.['applicationResult'] ?? null,
  );
  readonly policy = signal<PolicyDetailsResponse | null>(null);
  readonly versions = signal<PolicyVersionResponse[]>([]);
  readonly history = signal<PolicyHistoryResponse[]>([]);
  readonly paymentResult = signal<PremiumPaymentResponse | null>(null);
  readonly paymentModalState = signal<PaymentModalState>('closed');

  readonly paymentModalError = signal<string | null>(null);
  readonly policyStatus = signal('');
  readonly myPolicies = signal<PagedResponse<PolicySummaryResponse>>({
    items: [],
    page: 1,
    pageSize: 20,
    totalCount: 0,
    totalPages: 0,
  });
  readonly applicationForm = createPolicyApplicationForm();
  readonly cancelForm = createCancelPolicyForm();
  readonly renewForm = createRenewPolicyForm();
  readonly endorsementForm = createEndorsementForm();
  readonly paymentForm = createPremiumPaymentForm();
  readonly endorsementModalOpen = signal(false);
  readonly cancelModalOpen = signal(false);
  readonly cancelPreview = signal<CancellationPreviewResponse | null>(null);
  readonly loadingCancelPreview = signal(false);
  readonly renewalEstimate = signal<RenewalEstimateResponse | null>(null);
  readonly estimatingRenewal = signal(false);
  readonly renewalEstimateError = signal<string | null>(null);
  readonly constructionTypes = CONSTRUCTION_TYPES;
  readonly riskZones = RISK_ZONES;
  readonly policyStatuses = POLICY_STATUSES;
  readonly mitigationFields = [
    { key: 'stormShutters' as const, label: 'Storm shutters', hint: 'Shields windows and doors from debris.', icon: 'wind' as IconName },
    { key: 'impactResistantWindows' as const, label: 'Impact-resistant windows', hint: 'Laminated, cyclone-rated glazing.', icon: 'shield' as IconName },
    { key: 'reinforcedRoof' as const, label: 'Reinforced roof', hint: 'Hurricane straps or reinforced decking.', icon: 'house' as IconName },
    { key: 'emergencyGenerator' as const, label: 'Emergency generator', hint: 'Backup power through outages.', icon: 'zap' as IconName },
    { key: 'homeInspectionCertification' as const, label: 'Inspection certification', hint: 'Recent wind-mitigation inspection.', icon: 'badge-check' as IconName },
  ];
  /* Visual progress for the apply flow (derived from existing state). */
  readonly applySteps = ['Property & coverage', 'Choose tier', 'Apply'] as const;
  readonly applyStep = computed(() => (this.quote() ? 1 : 0));
  /** Celebrate a successful premium payment (skipped for users who prefer reduced motion). */
  private readonly celebratePayment = effect(() => {
    if (this.paymentModalState() !== 'success') return;
    if (window.matchMedia?.('(prefers-reduced-motion: reduce)').matches) return;
    const colors = ['#400106', '#7a1a22', '#c27a73', '#f4d9d4', '#10b981'];
    // Loaded on demand so the confetti library stays out of the initial bundle.
    void import('canvas-confetti').then(({ default: confetti }) => {
      void confetti({ particleCount: 110, spread: 75, startVelocity: 42, origin: { y: 0.55 }, colors, zIndex: 120, disableForReducedMotion: true });
      setTimeout(() => void confetti({ particleCount: 60, spread: 110, origin: { y: 0.45 }, colors, zIndex: 120, disableForReducedMotion: true }), 260);
    });
  });

  ngOnInit() {
    this.route.data.pipe(takeUntil(this.destroyed)).subscribe((d) => {
      this.pageKey.set(d['pageKey'] ?? '');
      this.title.set(d['title'] ?? 'Policies');
      this.loadPage();
    });

    this.applicationForm.controls.property.controls.customerPropertyOwnershipId.valueChanges
      .pipe(takeUntil(this.destroyed))
      .subscribe((selectedId) => {
        if (!selectedId) {
          this.isSelectedPropertyComplete.set(false);
          return;
        }
        const prop = this.properties().find((p) => p.propertyOwnershipId === selectedId);
        if (!prop) {
          this.isSelectedPropertyComplete.set(false);
          return;
        }

        const isComplete =
          prop.yearBuilt != null &&
          Boolean(prop.constructionType?.trim());

        this.isSelectedPropertyComplete.set(isComplete);

        this.applicationForm.controls.property.patchValue({
          yearBuilt: prop.yearBuilt ?? null,
          constructionType: prop.constructionType ?? '',
          stormShutters: prop.stormShutters ?? false,
          impactResistantWindows: prop.impactResistantWindows ?? false,
          reinforcedRoof: prop.reinforcedRoof ?? false,
          emergencyGenerator: prop.emergencyGenerator ?? false,
          homeInspectionCertification: prop.homeInspectionCertification ?? false,
        });
      });
  }
  ngOnDestroy() {
    this.destroyed.next();
    this.destroyed.complete();
  }
  hasUnsavedChanges() {
    const k = this.pageKey();
    return (
      (k === 'policies.apply' && this.applicationForm.dirty) ||
      (k === 'policies.renew' && this.renewForm.dirty)
    );
  }
  confirmDiscardChanges() {
    return window.confirm('You have unsaved changes. Leaving this page will discard them.');
  }
  private loadPage() {
    this.error.set(null);
    this.loading.set(true);
    const k = this.pageKey();
    if (k === 'policies.apply') {
      this.applicationForm.controls.planId.clearValidators();
      this.applicationForm.controls.planId.updateValueAndValidity();

      forkJoin({
        plans: this.policies.getPlans(),
        properties: this.profiles.getProperties(),
        insuredIds: this.policies.getMyInsuredPropertyIds().pipe(catchError(() => of([]))),
      }).subscribe({
        next: (x) => {
          this.plans.set(x.plans);
          this.properties.set(x.properties);
          this.insuredPropertyIds.set(new Set(x.insuredIds ?? []));

          const paramId = this.route.snapshot.queryParamMap.get('propertyOwnershipId');
          if (paramId && !this.insuredPropertyIds().has(paramId)) {
            this.applicationForm.controls.property.controls.customerPropertyOwnershipId.setValue(paramId);
          }

          this.loading.set(false);
        },
        error: (e) => this.fail(e),
      });
      return;
    }
    if (k === 'policies.my') {
      this.loadMyPolicies(1);
      return;
    }
    if (k === 'policies.application-result') {
      this.loading.set(false);
      return;
    }
    const id = this.route.snapshot.paramMap.get('policyId');
    if (!id) {
      this.loading.set(false);
      return;
    }
    if (k === 'policies.details') {
      forkJoin({
        policy: this.policies.getPolicy(id),
        versions: this.policies.getVersions(id),
        history: this.policies.getHistory(id),
        properties: this.profiles.getProperties().pipe(catchError(() => of([]))),
      }).subscribe({
        next: (x) => {
          this.policy.set(x.policy);
          this.versions.set(x.versions);
          this.history.set(x.history);
          this.properties.set(Array.isArray(x.properties) ? x.properties : []);
          this.loading.set(false);
        },
        error: (e) => this.fail(e),
      });
      return;
    }
    if (k === 'policies.cancel') {
      forkJoin({
        policy: this.policies.getPolicy(id),
        preview: this.policies.getCancellationPreview(id).pipe(catchError(() => of(null))),
      }).subscribe({
        next: (x) => {
          this.policy.set(x.policy);
          this.cancelPreview.set(x.preview);
          this.prefillActionForms(x.policy);
          this.loading.set(false);
        },
        error: (e) => this.fail(e),
      });
      return;
    }
    this.policies.getPolicy(id).subscribe({
      next: (p) => {
        this.policy.set(p);
        this.prefillActionForms(p);
        this.loading.set(false);
      },
      error: (e) => this.fail(e),
    });
  }

  getEffectiveDate(p: PolicyDetailsResponse): Date {
    return p.effectiveDate ? new Date(p.effectiveDate) : new Date(p.createdAt);
  }

  getExpirationDate(p: PolicyDetailsResponse): Date {
    if (p.expirationDate) {
      return new Date(p.expirationDate);
    }
    const date = new Date(p.createdAt);
    date.setFullYear(date.getFullYear() + 1);
    return date;
  }

  canRenew(p: PolicyDetailsResponse): boolean {
    if (p.status !== 'Active') {
      return false;
    }
    const exp = this.getExpirationDate(p);
    const now = new Date();
    const diffDays = (exp.getTime() - now.getTime()) / (1000 * 3600 * 24);
    // 60-day renewal window rule: Can only renew if within 60 days of expiration and not yet expired.
    return diffDays > 0 && diffDays <= 60;
  }

  getDaysUntilExpiration(p: PolicyDetailsResponse): number {
    const exp = this.getExpirationDate(p);
    const now = new Date();
    return Math.max(0, Math.ceil((exp.getTime() - now.getTime()) / (1000 * 3600 * 24)));
  }

  openEndorsementModal(): void {
    const p = this.policy();
    if (!p) return;
    this.endorsementForm.reset({
      stormShutters: Boolean(p.property.stormShutters),
      impactResistantWindows: Boolean(p.property.impactResistantWindows),
      reinforcedRoof: Boolean(p.property.reinforcedRoof),
      emergencyGenerator: Boolean(p.property.emergencyGenerator),
      homeInspectionCertification: Boolean(p.property.homeInspectionCertification),
      reason: '',
      rowVersion: p.rowVersion,
    });
    this.endorsementModalOpen.set(true);
  }

  closeEndorsementModal(): void {
    this.endorsementModalOpen.set(false);
    this.endorsementForm.reset();
  }

  submitEndorsement(): void {
    if (this.endorsementForm.invalid) {
      this.endorsementForm.markAllAsTouched();
      return;
    }
    const p = this.policy();
    if (!p) return;

    const val = this.endorsementForm.getRawValue();
    const req: PolicyEndorsementRequest = {
      stormShutters: Boolean(val.stormShutters),
      impactResistantWindows: Boolean(val.impactResistantWindows),
      reinforcedRoof: Boolean(val.reinforcedRoof),
      emergencyGenerator: Boolean(val.emergencyGenerator),
      homeInspectionCertification: Boolean(val.homeInspectionCertification),
      reason: val.reason.trim(),
      rowVersion: p.rowVersion,
    };

    this.busy.set(true);
    const key = this.idem.getOrCreate(IDEMPOTENT_OPERATIONS.policyEndorsement, {
      policyId: p.policyId,
      ...req,
    });

    this.policies.endorse(p.policyId, req, key).subscribe({
      next: () => {
        this.idem.complete(IDEMPOTENT_OPERATIONS.policyEndorsement);
        this.notifications.success('Property Mitigations Updated', 'Policy version has been incremented.');
        this.busy.set(false);
        this.closeEndorsementModal();
        this.loadPage();
      },
      error: (e) => this.fail(e, true),
    });
  }

  calculateRenewalEstimate(): void {
    const p = this.policy();
    if (!p) return;

    this.estimatingRenewal.set(true);
    this.renewalEstimateError.set(null);

    this.policies.getRenewalEstimate(p.policyId, { rowVersion: p.rowVersion }).subscribe({
      next: (est) => {
        this.renewalEstimate.set(est);
        this.estimatingRenewal.set(false);
      },
      error: (e) => {
        this.estimatingRenewal.set(false);
        this.renewalEstimateError.set(
          e instanceof ApiClientError ? e.message : 'Unable to calculate renewal estimate.'
        );
      },
    });
  }

  openCancelModal(): void {
    const p = this.policy();
    if (!p) return;
    this.cancelForm.reset({ reason: '', rowVersion: p.rowVersion });
    this.cancelModalOpen.set(true);
    this.loadingCancelPreview.set(true);
    this.policies.getCancellationPreview(p.policyId).subscribe({
      next: (prev) => {
        this.cancelPreview.set(prev);
        this.loadingCancelPreview.set(false);
      },
      error: () => {
        this.loadingCancelPreview.set(false);
      },
    });
  }

  closeCancelModal(): void {
    this.cancelModalOpen.set(false);
    this.cancelPreview.set(null);
    this.cancelForm.reset();
  }

  confirmCancellation(): void {
    const p = this.policy();
    if (!p || this.cancelForm.invalid) {
      this.cancelForm.markAllAsTouched();
      return;
    }
    this.busy.set(true);
    this.policies
      .cancel(p.policyId, {
        reason: this.cancelForm.controls.reason.value,
        rowVersion: p.rowVersion,
      })
      .subscribe({
        next: () => {
          this.busy.set(false);
          this.notifications.success(
            'Policy Cancelled',
            'Your policy was cancelled and unearned premium refunded.',
          );
          this.closeCancelModal();
          this.loadPage();
        },
        error: (e) => this.fail(e, true),
      });
  }

  getPropertyAddress(ownershipId: string | null | undefined): PropertyOwnershipResponse | null {
    if (!ownershipId) return null;
    return this.properties().find((p) => p.propertyOwnershipId === ownershipId) || null;
  }

  downloadPolicyDocument(): void {
    const p = this.policy();
    if (!p) return;
    const addr = this.getPropertyAddress(p.property.customerPropertyOwnershipId);
    this.pdfGenerator.generatePolicyDocument(p, addr);
  }

  loadMyPolicies(page: number) {
    this.loading.set(true);
    this.policies
      .getMyPolicies({ page, pageSize: 20, status: (this.policyStatus() as PolicyStatus) || undefined })
      .subscribe({
        next: (x) => {
          this.myPolicies.set(x);
          this.loading.set(false);
        },
        error: (e) => this.fail(e),
      });
  }
  /** Status chips on My Policies (same behaviour as the original status select). */
  filterPolicyStatus(value: string) {
    this.policyStatus.set(value);
    this.loadMyPolicies(1);
  }
  /** Splits enum-style values such as PaymentPending into words for display. */
  spaced(value: string | null | undefined): string {
    return (value ?? '').replace(/([a-z])([A-Z])/g, '$1 $2');
  }
  /** Percentage of the Policy term that has elapsed, for the coverage progress bar. */
  termProgress(start: string | Date, end: string | Date): number {
    const from = new Date(start).getTime();
    const to = new Date(end).getTime();
    if (!(to > from)) return 0;
    return Math.min(100, Math.max(0, ((Date.now() - from) / (to - from)) * 100));
  }
  changeStatus(e: Event) {
    this.policyStatus.set((e.target as HTMLSelectElement).value);
    this.loadMyPolicies(1);
  }

  calculateQuote(): void {
    if (this.applicationForm.invalid) {
      this.applicationForm.markAllAsTouched();
      const errs: string[] = [];
      if (this.applicationForm.controls.requestedCoverage.invalid) {
        errs.push('Requested Coverage must be greater than zero.');
      }
      if (this.applicationForm.controls.property.controls.propertyValue.invalid) {
        errs.push('Property Value must be greater than zero.');
      }
      this.error.set(
        errs.length > 0 ? errs.join(' ') : 'Please complete all required fields marked with *.'
      );
      return;
    }

    if (this.busy()) {
      return;
    }

    const formVal = this.applicationForm.getRawValue();

    this.busy.set(true);
    this.error.set(null);

    const recommendationsRequest: CalculateRecommendationsRequest = {
      requestedCoverage: Number(formVal.requestedCoverage),
      property: {
        customerPropertyOwnershipId: formVal.property.customerPropertyOwnershipId,
        propertyValue: Number(formVal.property.propertyValue),
        yearBuilt: Number(formVal.property.yearBuilt),
        constructionType: formVal.property.constructionType as ConstructionType,
        claimsHistoryCount: Number(formVal.property.claimsHistoryCount ?? 0),
        stormShutters: Boolean(formVal.property.stormShutters),
        impactResistantWindows: Boolean(formVal.property.impactResistantWindows),
        reinforcedRoof: Boolean(formVal.property.reinforcedRoof),
        emergencyGenerator: Boolean(formVal.property.emergencyGenerator),
        homeInspectionCertification: Boolean(formVal.property.homeInspectionCertification),
      },
    };

    this.policies.calculateRecommendations(recommendationsRequest).subscribe({
      next: (results) => {
        if (!results || results.length === 0) {
          this.error.set(
            'No active insurance plans qualify for the requested coverage amount. Please adjust the coverage amount.',
          );
          this.busy.set(false);
          return;
        }

        this.quotes.set(results);

        // If user picked a planId, select it; otherwise default to middle (recommended) tier
        let selected = results.find((r) => r.plan.planId === formVal.planId);
        if (!selected) {
          const defaultIdx = results.length >= 3 ? 1 : 0;
          selected = results[defaultIdx];
        }

        this.quote.set(selected);
        this.applicationForm.controls.planId.setValue(selected.plan.planId, { emitEvent: false });
        this.applicationForm.controls.property.controls.claimsHistoryCount.setValue(
          selected.property.claimsHistoryCount,
          { emitEvent: false },
        );

        this.busy.set(false);
      },
      error: (error: unknown) => {
        this.fail(error, true);
      },
    });
  }

  selectRecommendedQuote(quote: QuoteResponse): void {
    this.quote.set(quote);
    this.applicationForm.controls.planId.setValue(quote.plan.planId, { emitEvent: false });
  }

  submitApplication() {
    const q = this.quote();
    if (!q) return;
    this.busy.set(true);
    this.profiles.getCurrentProfile().subscribe({
      next: (profile) => {
        const request = {
          customerId: profile.customerId,
          planId: q.plan.planId,
          requestedCoverage: q.requestedCoverage,
          property: q.property,
        };
        const key = this.idem.getOrCreate(IDEMPOTENT_OPERATIONS.policyApplication, request);
        this.policies.apply(request, key).subscribe({
          next: (r) => {
            this.idem.complete(IDEMPOTENT_OPERATIONS.policyApplication);
            this.applicationForm.markAsPristine();
            this.busy.set(false);
            void this.router.navigate(['/policies/application/result'], {
              state: { applicationResult: r },
            });
          },
          error: (e) => this.fail(e, true),
        });
      },
      error: (e) => this.fail(e, true),
    });
  }

  openPaymentModal(): void {
    if (this.busy() || this.paymentForm.invalid) {
      this.paymentForm.markAllAsTouched();
      return;
    }

    this.paymentResult.set(null);
    this.paymentModalError.set(null);
    this.paymentModalState.set('confirmation');
  }

  closePaymentModal(): void {
    if (this.paymentModalState() === 'processing') {
      return;
    }

    this.paymentModalState.set('closed');
    this.paymentModalError.set(null);
  }

  retryPayment(): void {
    if (this.busy()) {
      return;
    }

    this.paymentModalError.set(null);
    this.paymentModalState.set('confirmation');
  }

  payPremium(): void {
    const policy = this.policy();

    // Guard against missing policy or an active process
    if (!policy || this.busy()) {
      return;
    }

    // Handle form validation errors
    if (this.paymentForm.invalid) {
      this.paymentForm.markAllAsTouched();
      this.paymentModalState.set('closed');
      return;
    }

    const request = {
      policyId: policy.policyId,
      amount: policy.premiumDue,
      simulateFailure: this.paymentForm.controls.simulateFailure.value,
    };

    // Generate or retrieve the idempotency key using the original enum/request setup
    const idempotencyKey = this.idem.getOrCreate(IDEMPOTENT_OPERATIONS.premiumPayment, request);

    // Initialize UI and loading states
    this.error.set(null);
    this.paymentResult.set(null);
    this.paymentModalError.set(null);
    this.paymentModalState.set('processing');
    this.busy.set(true);

    // FIXED: Reverted back to this.payments.processPremium matching the original method signature
    this.payments.processPremium(request, idempotencyKey).subscribe({
      next: (result) => {
        // Clear the idempotency operation marker
        this.idem.complete(IDEMPOTENT_OPERATIONS.premiumPayment);

        this.paymentResult.set(result);
        this.busy.set(false);

        // FIXED: Reverted string check back to 'Success' to match the original API contract
        if (result.status === 'Success') {
          this.paymentModalState.set('success');
          this.notifications.success(
            'Payment completed',
            'Your premium payment was processed successfully.',
          );
          return;
        }

        // Handle logical payment failure responses
        this.paymentModalError.set(result.failureReason || 'The payment could not be completed.');
        this.paymentModalState.set('failed');
      },

      error: (error: unknown) => {
        // FIXED: Complete the idempotency operation so the user can retry on network failure
        this.idem.complete(IDEMPOTENT_OPERATIONS.premiumPayment);
        this.busy.set(false);

        this.paymentModalError.set(
          error instanceof ApiClientError
            ? error.message
            : 'The payment could not be processed. Please try again.',
        );
        this.paymentModalState.set('failed');

        // FIXED: Re-introduced the original error side-effects/logging
        this.fail(error, true);
      },
    });
  }

  cancelPolicy() {
    const p = this.policy();
    if (!p || this.cancelForm.invalid) {
      this.cancelForm.markAllAsTouched();
      return;
    }
    this.busy.set(true);
    this.policies
      .cancel(p.policyId, {
        reason: this.cancelForm.controls.reason.value,
        rowVersion: p.rowVersion,
      })
      .subscribe({
        next: () => {
          this.busy.set(false);
          this.notifications.success('Policy cancelled', 'The policy was cancelled.');
          void this.router.navigate(['/policies', p.policyId]);
        },
        error: (e) => this.fail(e, true),
      });
  }
  renewPolicy() {
    const p = this.policy();
    if (!p || this.renewForm.invalid) {
      this.renewForm.markAllAsTouched();
      return;
    }
    const raw = this.renewForm.getRawValue();
    const request = {
      property: raw.property as PropertyRiskRequest,
      reason: raw.reason,
      rowVersion: p.rowVersion,
    };
    const key = this.idem.getOrCreate(IDEMPOTENT_OPERATIONS.policyRenewal, {
      policyId: p.policyId,
      ...request,
    });
    this.busy.set(true);
    this.policies.renew(p.policyId, request, key).subscribe({
      next: (r) => {
        this.idem.complete(IDEMPOTENT_OPERATIONS.policyRenewal);
        this.renewForm.markAsPristine();
        this.busy.set(false);
        void this.router.navigate(['/policies', r.policyId, 'payment']);
      },
      error: (e) => this.fail(e, true),
    });
  }
  private prefillActionForms(p: PolicyDetailsResponse) {
    this.renewalEstimate.set(null);
    this.renewalEstimateError.set(null);
    this.paymentForm.patchValue({ policyId: p.policyId, amount: p.premiumDue });
    this.cancelForm.patchValue({ rowVersion: p.rowVersion });
    this.renewForm.patchValue({
      rowVersion: p.rowVersion,
      property: {
        customerPropertyOwnershipId: p.property.customerPropertyOwnershipId,
        propertyValue: p.property.propertyValue,
        yearBuilt: p.property.yearBuilt,
        constructionType: p.property.constructionType,
        claimsHistoryCount: 0,
        stormShutters: p.property.stormShutters,
        impactResistantWindows: p.property.impactResistantWindows,
        reinforcedRoof: p.property.reinforcedRoof,
        emergencyGenerator: p.property.emergencyGenerator,
        homeInspectionCertification: p.property.homeInspectionCertification,
      },
    });
    this.renewForm.markAsPristine();
  }
  private fail(e: unknown, busy = false) {
    this.loading.set(false);
    if (busy) this.busy.set(false);
    this.error.set(
      e instanceof ApiClientError
        ? e.message
        : 'The requested Policy operation could not be completed.',
    );
  }
}


import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { ActivatedRoute, provideRouter } from '@angular/router';
import { of } from 'rxjs';

import { AuthStore } from '../../../core/auth/auth.store';
import { PolicyStaffConnectedPageComponent } from './policy-staff-connected-page.component';

describe('PolicyStaffConnectedPageComponent', () => {
  it('creates without treating route metadata as the current user role', async () => {
    await TestBed.configureTestingModule({
      imports: [PolicyStaffConnectedPageComponent],
      providers: [
        provideRouter([]),
        provideHttpClient(),
        provideHttpClientTesting(),
        {
          provide: ActivatedRoute,
          useValue: {
            data: of({ pageKey: 'staff.policy-search', roles: ['Agent', 'Administrator'] }),
            snapshot: { paramMap: { get: () => null } },
          },
        },
      ],
    }).compileComponents();

    const component = TestBed.createComponent(PolicyStaffConnectedPageComponent).componentInstance;
    const store = TestBed.inject(AuthStore);

    expect(component).toBeTruthy();
    expect(store.hasRole('Administrator')).toBe(false);
    expect(component.isAdministrator()).toBe(false);
  });
});

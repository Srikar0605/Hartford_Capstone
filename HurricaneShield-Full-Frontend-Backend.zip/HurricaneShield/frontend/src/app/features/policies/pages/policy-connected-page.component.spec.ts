
import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { ActivatedRoute, provideRouter } from '@angular/router';
import { of } from 'rxjs';
import { describe, expect, it, vi } from 'vitest';

import { PolicyConnectedPageComponent } from './policy-connected-page.component';
import { PolicyService } from '../policy.service';
import type { PolicyDetailsResponse, RenewalEstimateResponse } from '../policy.models';

describe('PolicyConnectedPageComponent', () => {
  const mockPolicy: PolicyDetailsResponse = {
    policyId: 'pol-123',
    policyNumber: 'POL-20261021-001',
    customerId: 'cust-1',
    planId: 'plan-1',
    premiumDue: 1200,
    status: 'Active',
    paymentTransactionId: 'tx-1',
    effectiveDate: '2026-01-01T00:00:00Z',
    expirationDate: '2027-01-01T00:00:00Z',
    createdAt: '2026-01-01T00:00:00Z',
    updatedAt: null,
    currentVersionNumber: 1,
    rowVersion: 'AQIDBAUGBwg=',
    plan: {
      planId: 'plan-1',
      planName: 'Coastal Shield Elite',
      planCode: 'CSE',
      description: 'Comprehensive coastal protection',
      basePremium: 1000,
      coverageLimit: 250000,
      deductibleAmount: 5000,
      coverages: [],
    },
    property: {
      propertyId: 'prop-1',
      customerPropertyOwnershipId: 'own-1',
      propertyValue: 250000,
      yearBuilt: 2018,
      constructionType: 'Concrete',
      riskZone: 'B',
      stormShutters: false,
      impactResistantWindows: false,
      reinforcedRoof: false,
      emergencyGenerator: false,
      homeInspectionCertification: false,
    },
    latestRiskAssessment: {
      riskScore: 25,
      riskLevel: 'Low',
      propertyAge: 8,
      requiresManualReview: false,
      factors: [],
    },
    latestPremiumBreakdown: {
      basePremium: 1000,
      locationRiskAdjustment: 100,
      propertyRiskAdjustment: 100,
      claimsHistoryAdjustment: 0,
      riskAdjustment: 200,
      discountAmount: 0,
      finalPremium: 1200,
    },
  };

  const mockEstimate: RenewalEstimateResponse = {
    policyId: 'pol-123',
    policyNumber: 'POL-20261021-001',
    planId: 'plan-1',
    planName: 'Coastal Shield Elite',
    coverageLimit: 250000,
    currentPremium: 1200,
    estimatedRenewalPremium: 1050,
    differenceAmount: 150,
    comparisonOutcome: 'Saving',
    totalMitigationDiscount: 150,
    riskScore: 20,
    riskLevel: 'Low',
    manualReviewRequired: false,
    breakdown: {
      basePremium: 1000,
      locationRiskAdjustment: 100,
      propertyRiskAdjustment: 100,
      claimsHistoryAdjustment: 0,
      riskAdjustment: 200,
      discountAmount: 150,
      finalPremium: 1050,
    },
  };

  it('prefills endorsement form and submits with valid rowVersion and reason', async () => {
    await TestBed.configureTestingModule({
      imports: [PolicyConnectedPageComponent],
      providers: [
        provideRouter([]),
        provideHttpClient(),
        provideHttpClientTesting(),
        {
          provide: ActivatedRoute,
          useValue: {
            data: of({ pageKey: 'policies.details', title: 'Policy Details' }),
            snapshot: { paramMap: { get: () => 'pol-123' } },
          },
        },
      ],
    }).compileComponents();

    const fixture = TestBed.createComponent(PolicyConnectedPageComponent);
    const component = fixture.componentInstance;
    const policyService = TestBed.inject(PolicyService);

    component.policy.set(mockPolicy);

    // Open endorsement modal
    component.openEndorsementModal();
    expect(component.endorsementModalOpen()).toBe(true);

    // Initial form values should match policy property
    expect(component.endorsementForm.controls.stormShutters.value).toBe(false);
    expect(component.endorsementForm.controls.rowVersion.value).toBe('AQIDBAUGBwg=');

    // Update mitigations and set reason
    component.endorsementForm.controls.stormShutters.setValue(true);
    component.endorsementForm.controls.impactResistantWindows.setValue(true);
    component.endorsementForm.controls.reason.setValue('Added hurricane storm shutters.');

    const endorseSpy = vi.spyOn(policyService, 'endorse').mockReturnValue(
      of({
        policyId: 'pol-123',
        policyNumber: 'POL-20261021-001',
        status: 'Active',
        premiumDue: 1200,
        currentVersionNumber: 2,
        rowVersion: 'CQgHBgUEAwI=',
      }),
    );

    component.submitEndorsement();

    expect(endorseSpy).toHaveBeenCalledWith(
      'pol-123',
      expect.objectContaining({
        stormShutters: true,
        impactResistantWindows: true,
        reason: 'Added hurricane storm shutters.',
        rowVersion: 'AQIDBAUGBwg=',
      }),
      expect.any(String),
    );
    expect(component.endorsementModalOpen()).toBe(false);
  });

  it('calculates on-demand renewal estimate with breakdown and savings comparison', async () => {
    await TestBed.configureTestingModule({
      imports: [PolicyConnectedPageComponent],
      providers: [
        provideRouter([]),
        provideHttpClient(),
        provideHttpClientTesting(),
        {
          provide: ActivatedRoute,
          useValue: {
            data: of({ pageKey: 'policies.renew', title: 'Renew Policy' }),
            snapshot: { paramMap: { get: () => 'pol-123' } },
          },
        },
      ],
    }).compileComponents();

    const fixture = TestBed.createComponent(PolicyConnectedPageComponent);
    const component = fixture.componentInstance;
    const policyService = TestBed.inject(PolicyService);

    component.policy.set(mockPolicy);

    const estimateSpy = vi.spyOn(policyService, 'getRenewalEstimate').mockReturnValue(of(mockEstimate));

    component.calculateRenewalEstimate();

    expect(estimateSpy).toHaveBeenCalledWith('pol-123', { rowVersion: 'AQIDBAUGBwg=' });
    expect(component.estimatingRenewal()).toBe(false);
    expect(component.renewalEstimate()).toEqual(mockEstimate);
    expect(component.renewalEstimate()?.comparisonOutcome).toBe('Saving');
    expect(component.renewalEstimate()?.totalMitigationDiscount).toBe(150);
  });

  it('loads cancellation preview and confirms policy cancellation', async () => {
    await TestBed.configureTestingModule({
      imports: [PolicyConnectedPageComponent],
      providers: [
        provideRouter([]),
        provideHttpClient(),
        provideHttpClientTesting(),
        {
          provide: ActivatedRoute,
          useValue: {
            data: of({ pageKey: 'policies.details', title: 'Policy Details' }),
            snapshot: { paramMap: { get: () => 'pol-123' } },
          },
        },
      ],
    }).compileComponents();

    const fixture = TestBed.createComponent(PolicyConnectedPageComponent);
    const component = fixture.componentInstance;
    const policyService = TestBed.inject(PolicyService);

    component.policy.set(mockPolicy);

    const previewSpy = vi.spyOn(policyService, 'getCancellationPreview').mockReturnValue(
      of({
        policyId: 'pol-123',
        policyNumber: 'POL-20261021-001',
        premiumDue: 1200,
        effectiveDate: '2026-01-01T00:00:00Z',
        expirationDate: '2027-01-01T00:00:00Z',
        totalTermDays: 365,
        daysActive: 100,
        daysRemaining: 265,
        refundAmount: 871.23,
      }),
    );

    component.openCancelModal();

    expect(previewSpy).toHaveBeenCalledWith('pol-123');
    expect(component.cancelModalOpen()).toBe(true);
    expect(component.cancelPreview()?.refundAmount).toBe(871.23);

    component.cancelForm.controls.reason.setValue('Relocating to another state.');
    component.cancelForm.controls.confirmed.setValue(true);

    const cancelSpy = vi.spyOn(policyService, 'cancel').mockReturnValue(
      of({
        policyId: 'pol-123',
        policyNumber: 'POL-20261021-001',
        status: 'Cancelled',
        premiumDue: 1200,
        currentVersionNumber: 1,
        paymentTransactionId: null,
        rowVersion: 'AQIDBAUGBwg=',
      }),
    );

    component.confirmCancellation();

    expect(cancelSpy).toHaveBeenCalledWith('pol-123', {
      reason: 'Relocating to another state.',
      rowVersion: 'AQIDBAUGBwg=',
    });
    expect(component.cancelModalOpen()).toBe(false);
  });
});

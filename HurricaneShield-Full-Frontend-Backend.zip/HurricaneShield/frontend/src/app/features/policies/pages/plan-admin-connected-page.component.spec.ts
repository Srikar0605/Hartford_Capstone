
import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';
import { ActivatedRoute, provideRouter } from '@angular/router';
import { of } from 'rxjs';
import { PlanAdminConnectedPageComponent } from './plan-admin-connected-page.component';

describe('PlanAdminConnectedPageComponent',()=>{beforeEach(async()=>{await TestBed.configureTestingModule({imports:[PlanAdminConnectedPageComponent],providers:[provideRouter([]),provideHttpClient(),provideHttpClientTesting(),{provide:ActivatedRoute,useValue:{data:of({pageKey:'admin.plan-list'}),snapshot:{paramMap:{get:()=>null}}}}]}).compileComponents();});it('creates',()=>{expect(TestBed.createComponent(PlanAdminConnectedPageComponent).componentInstance).toBeTruthy();});});

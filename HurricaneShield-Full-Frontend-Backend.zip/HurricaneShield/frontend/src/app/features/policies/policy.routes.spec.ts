
import { roleGuard } from '../../core/guards/role.guard';
import { SYSTEM_ROLES } from '../../core/constants/roles';
import { policyRoutes } from './policy.routes';

describe('policyRoutes', () => {
  it('limits Policy details to supported reader roles', () => {
    const route = policyRoutes.find((value) => value.path === 'policies/:policyId');

    expect(route?.canActivate).toContain(roleGuard);
    expect(route?.data?.['roles']).toEqual([
      SYSTEM_ROLES.customer,
      SYSTEM_ROLES.agent,
      SYSTEM_ROLES.administrator,
    ]);
  });
});

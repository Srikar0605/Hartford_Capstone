
import { FormArray, FormControl, FormGroup, Validators } from '@angular/forms';
import { HurricaneValidators } from '../../shared/validators/hurricane.validators';

/**
 * Creates the reactive form model for assessing property hurricane risk.
 * I included mitigation feature booleans (storm shutters, reinforced roof, impact windows) because
 * the backend RiskAssessmentEngine awards discount credits against the base premium for verified defenses.
 */
export function createPropertyRiskForm() {
  return new FormGroup({
    customerPropertyOwnershipId: new FormControl<string | null>(null, [HurricaneValidators.guid]),
    propertyValue: new FormControl<number | null>(null, [
      Validators.required,
      HurricaneValidators.positiveNumber,
    ]),
    // Built year must be historic or current; we cap at the current year because homes cannot be built in the future.
    yearBuilt: new FormControl<number | null>(null, [
      Validators.required,
      Validators.min(1800),
      Validators.max(new Date().getFullYear()),
    ]),
    constructionType: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required],
    }),
    claimsHistoryCount: new FormControl(0, {
      nonNullable: true,
      validators: [HurricaneValidators.nonNegativeNumber],
    }),
    // Disaster mitigation attributes that feed directly into risk discount scoring:
    stormShutters: new FormControl(false, { nonNullable: true }),
    impactResistantWindows: new FormControl(false, { nonNullable: true }),
    reinforcedRoof: new FormControl(false, { nonNullable: true }),
    emergencyGenerator: new FormControl(false, { nonNullable: true }),
    homeInspectionCertification: new FormControl(false, { nonNullable: true }),
  });
}

/**
 * Form for generating an initial quote estimate.
 * Note: requestedCoverage is validated as a positive number. On submission, the backend also enforces
 * the Indemnity Principle (requested coverage cannot exceed 100% of propertyValue).
 */
export function createQuoteForm() {
  return new FormGroup({
    planId: new FormControl('', {
      nonNullable: true,
      validators: [HurricaneValidators.guid],
    }),
    requestedCoverage: new FormControl<number | null>(null, [
      Validators.required,
      HurricaneValidators.positiveNumber,
    ]),
    property: createPropertyRiskForm(),
  });
}

export function createPolicyApplicationForm() {
  return createQuoteForm();
}

/**
 * Form for requesting a policy cancellation.
 * We require rowVersion to guard against conflicting updates (e.g. if the policy status changed concurrently).
 */
export function createCancelPolicyForm() {
  return new FormGroup({
    reason: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required, Validators.maxLength(500)],
    }),
    rowVersion: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    confirmed: new FormControl(false, { nonNullable: true, validators: [Validators.requiredTrue] }),
  });
}

/**
 * Policy renewal form allowing property risk profiles to be updated prior to re-underwriting.
 */
export function createRenewPolicyForm() {
  return new FormGroup({
    property: createPropertyRiskForm(),
    reason: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required, Validators.maxLength(500)],
    }),
    rowVersion: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
  });
}

/**
 * Underwriting decision form for agents and underwriters.
 * I used a FormArray for 'reasons' so underwriters can attach multiple itemized compliance or risk notes
 * when approving with conditions or rejecting an application.
 */
export function createUnderwritingDecisionForm() {
  return new FormGroup({
    policyRowVersion: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    reviewRowVersion: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    reasons: new FormArray<FormGroup>([]),
  });
}

export function createUnderwritingReasonForm() {
  return new FormGroup({
    reasonCode: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required, Validators.maxLength(100)],
    }),
    reasonDescription: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required, Validators.maxLength(500)],
    }),
  });
}

/**
 * Form for submitting mid-term mitigation updates (endorsements) on active policies.
 */
export function createEndorsementForm() {
  return new FormGroup({
    stormShutters: new FormControl(false, { nonNullable: true }),
    impactResistantWindows: new FormControl(false, { nonNullable: true }),
    reinforcedRoof: new FormControl(false, { nonNullable: true }),
    emergencyGenerator: new FormControl(false, { nonNullable: true }),
    homeInspectionCertification: new FormControl(false, { nonNullable: true }),
    reason: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required, Validators.maxLength(500)],
    }),
    rowVersion: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
  });
}


import { Injectable } from '@angular/core';
import { jsPDF } from 'jspdf';
import type { PolicyDetailsResponse } from './policy.models';
import type { PropertyOwnershipResponse } from '../profile/profile.models';

@Injectable({
  providedIn: 'root',
})
export class PolicyDocumentGeneratorService {
  generatePolicyDocument(
    policy: PolicyDetailsResponse,
    propertyAddress: PropertyOwnershipResponse | null
  ): void {
    const doc = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
    });

    const pageWidth = doc.internal.pageSize.getWidth();
    const margin = 20;
    const contentWidth = pageWidth - margin * 2;

    // --- PAGE 1: DECLARATIONS ---
    this.renderHeader(doc, 'PAGE 1 OF 3: POLICY DECLARATIONS');

    let y = 45;

    doc.setFontSize(16);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(64, 1, 6); // Brand oxblood
    doc.text('NATURALSHIELD INSURANCE POLICY', margin, y);

    y += 6;
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(100, 116, 139);
    doc.text('Underwritten by NaturalShield Insurance Corporation', margin, y);

    y += 10;
    doc.setDrawColor(226, 232, 240);
    doc.line(margin, y, margin + contentWidth, y);

    // Policy & Insured Summary
    y += 8;
    doc.setFontSize(11);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(15, 23, 42);
    doc.text('1. Policy Identification & Term', margin, y);

    y += 6;
    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(51, 65, 85);

    const effDate = new Date(policy.createdAt).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
    const expDate = new Date(new Date(policy.createdAt).setFullYear(new Date(policy.createdAt).getFullYear() + 1)).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });

    doc.text(`Policy Number: ${policy.policyNumber}`, margin, y);
    doc.text(`Effective Date: ${effDate} (12:01 AM)`, margin + 85, y);

    y += 5;
    doc.text(`Plan Name: ${policy.plan.planName}`, margin, y);
    doc.text(`Expiration Date: ${expDate} (11:59 PM)`, margin + 85, y);

    y += 5;
    doc.text(`Status: ${policy.status}`, margin, y);
    doc.text(`Annual Premium: INR ${policy.premiumDue.toLocaleString()}`, margin + 85, y);

    // Insured Property Block
    y += 10;
    doc.setFontSize(11);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(15, 23, 42);
    doc.text('2. Insured Property Location', margin, y);

    y += 6;
    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(51, 65, 85);

    if (propertyAddress) {
      doc.text(`Address: ${propertyAddress.addressLine1}${propertyAddress.addressLine2 ? ', ' + propertyAddress.addressLine2 : ''}`, margin, y);
      y += 5;
      doc.text(`Location: ${propertyAddress.city}, ${propertyAddress.state} ${propertyAddress.postalCode} (${propertyAddress.country})`, margin, y);
    } else {
      doc.text('Address: On file with policy registry', margin, y);
    }

    y += 5;
    doc.text(`Declared Structure Value: INR ${policy.property.propertyValue.toLocaleString()}`, margin, y);
    doc.text(`Construction: ${policy.property.constructionType}`, margin + 85, y);

    y += 5;
    doc.text(`Year Built: ${policy.property.yearBuilt}`, margin, y);
    doc.text(`Assigned Risk Zone: Zone ${policy.property.riskZone}`, margin + 85, y);

    // Credits / Mitigations
    y += 8;
    const mitigations = [];
    if (policy.property.stormShutters) mitigations.push('Storm Shutters');
    if (policy.property.impactResistantWindows) mitigations.push('Impact Windows');
    if (policy.property.reinforcedRoof) mitigations.push('Reinforced Roof');
    if (policy.property.emergencyGenerator) mitigations.push('Backup Generator');
    if (policy.property.homeInspectionCertification) mitigations.push('Certified Inspection');

    doc.setFont('helvetica', 'bold');
    doc.text('Applied Mitigation Credits:', margin, y);
    doc.setFont('helvetica', 'normal');
    doc.text(mitigations.length > 0 ? mitigations.join(' • ') : 'None registered', margin + 45, y);

    // Schedule of Coverages Table
    y += 12;
    doc.setFontSize(11);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(15, 23, 42);
    doc.text('3. Schedule of Coverages & Limits', margin, y);

    y += 5;
    // Table Header
    doc.setFillColor(241, 245, 249);
    doc.rect(margin, y, contentWidth, 7, 'F');
    doc.setFontSize(8.5);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(71, 85, 105);
    doc.text('COVERAGE TYPE', margin + 3, y + 5);
    doc.text('LIMIT OF LIABILITY', margin + 95, y + 5);
    doc.text('DEDUCTIBLE', margin + 140, y + 5);

    y += 7;
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(15, 23, 42);

    for (const cov of policy.plan.coverages) {
      doc.text(cov.coverageName, margin + 3, y + 5);
      doc.text(`INR ${cov.coverageLimit.toLocaleString()}`, margin + 95, y + 5);
      doc.text(`INR ${cov.deductibleAmount.toLocaleString()}`, margin + 140, y + 5);
      y += 6;
      doc.setDrawColor(241, 245, 249);
      doc.line(margin, y, margin + contentWidth, y);
    }

    // Signatures
    y = 250;
    doc.setDrawColor(203, 213, 225);
    doc.line(margin, y, margin + 60, y);
    doc.line(margin + 100, y, margin + 160, y);

    y += 4;
    doc.setFontSize(8);
    doc.setTextColor(100, 116, 139);
    doc.text('Authorized Insurer Representative', margin, y);
    doc.text('Named Insured Acceptance', margin + 100, y);

    // --- PAGE 2: TERMS & CONDITIONS ---
    doc.addPage();
    this.renderHeader(doc, 'PAGE 2 OF 3: GENERAL TERMS & CONDITIONS');

    y = 45;
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(64, 1, 6); // Brand oxblood
    doc.text('GENERAL TERMS, PROVISIONS & DUTIES', margin, y);

    y += 8;
    this.renderSection(
      doc,
      margin,
      y,
      contentWidth,
      '1. Principle of Indemnity',
      'This contract is strictly governed by the Principle of Indemnity. The sole intent of this policy is to restore the insured property and structure to its approximate financial and physical condition existing immediately prior to the occurrence of a covered disaster loss. Under no circumstances may an insurance settlement result in personal enrichment or financial gain for the policyholder. In accordance with platform standards, total requested insurance coverage cannot exceed 100% of the verified, inspected replacement value of the registered property.'
    );

    y += 26;
    this.renderSection(
      doc,
      margin,
      y,
      contentWidth,
      '2. Insurable Interest & Ownership Verification',
      'Continuous coverage is contingent upon the policyholder maintaining a valid, verifiable insurable interest in the property described on the Declarations Page. Proof of ownership, registered leasehold, or title interest must be provided upon request during claim adjudication. If the property ownership is transferred, this policy does not automatically transfer to the new owner without formal underwriting reassignment.'
    );

    y += 26;
    this.renderSection(
      doc,
      margin,
      y,
      contentWidth,
      '3. First Notice of Loss (FNOL) & Policyholder Duties',
      'Upon the occurrence of any event likely to give rise to a claim under this policy, the insured must:\n' +
      'a. Provide prompt written notice to NaturalShield within 14 calendar days of storm dissipation.\n' +
      'b. Take all reasonable and necessary measures to protect the damaged property from subsequent or secondary losses.\n' +
      'c. Keep an accurate, itemized record of all temporary emergency repair expenses.\n' +
      'd. Permit appointed insurance adjusters and structural engineers unhindered access to inspect the premises.'
    );

    y += 34;
    this.renderSection(
      doc,
      margin,
      y,
      contentWidth,
      '4. Deductible Application & Loss Settlement',
      'Losses will be settled on a replacement cost basis up to the individual limits specified in the Schedule of Coverages, subject to the applicable named deductible. For catastrophic storm declarations, hurricane deductibles apply on a per-calendar-year basis rather than per-occurrence, provided proof of prior deductible satisfaction within the same storm season is submitted.'
    );

    y += 26;
    this.renderSection(
      doc,
      margin,
      y,
      contentWidth,
      '5. Concurrency & Policy Record Security',
      'All policy adjustments, endorsements, and renewals are tracked via cryptographic version hashing and optimistic concurrency control (RowVersion). Any concurrent modification attempts will be validated against active claim records to prevent conflicting coverage adjustments during active settlement review.'
    );

    // --- PAGE 3: SCENARIOS & EXCLUSIONS ---
    doc.addPage();
    this.renderHeader(doc, 'PAGE 3 OF 3: COVERAGE SCENARIOS & EXCLUSIONS');

    y = 45;
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(64, 1, 6); // Brand oxblood
    doc.text('CLAIMS SCENARIOS & STANDARD EXCLUSIONS', margin, y);

    y += 8;
    this.renderSection(
      doc,
      margin,
      y,
      contentWidth,
      'Illustrative Scenario A: Category 4 Hurricane Direct Windstorm',
      'Event: Severe tropical storm winds tear away reinforced shingles, allowing wind-driven rain to enter and damage interior ceilings.\n' +
      'Adjudication: Structural roof repairs and interior damage are covered under the Primary Hazard coverage. If approved mitigation features (such as reinforced roofs or storm shutters) were functional at the time of the storm, applicable mitigation deductible discounts will be credited during settlement computation.'
    );

    y += 30;
    this.renderSection(
      doc,
      margin,
      y,
      contentWidth,
      'Illustrative Scenario B: Storm Surge & Coastal Inundation',
      'Event: Atmospheric pressure drop forces ocean water above normal tides, flooding the ground floor living areas.\n' +
      'Adjudication: Ground-level flood and surge losses are settled strictly under the Rising Waters & Inundation endorsement. If this specific coverage line is not itemized on Page 1, damages resulting from standing water or external inundation are not indemnified.'
    );

    y += 30;
    this.renderSection(
      doc,
      margin,
      y,
      contentWidth,
      'Standard Exclusions & Non-Covered Losses',
      'This insurance policy explicitly does not insure against loss caused directly or indirectly by any of the following:\n' +
      '• Wear, tear, marring, mechanical breakdown, or gradual deterioration due to humidity or lack of maintenance.\n' +
      '• Earth movement, including sinkholes, earthquake shocks, or landslides, unless formally certified as storm-induced.\n' +
      '• Intentional destruction or fraudulent claims filed by or with the consent of the named insured.\n' +
      '• Losses incurred while the property has been declared abandoned or unoccupied for more than 60 consecutive days without prior written underwriting approval.'
    );

    // Footer contact
    y = 240;
    doc.setFillColor(248, 250, 252);
    doc.roundedRect(margin, y, contentWidth, 25, 2, 2, 'F');
    doc.setFontSize(9);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(64, 1, 6); // Brand oxblood
    doc.text('NaturalShield Customer Support & Emergency Hotline', margin + 5, y + 8);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(100, 116, 139);
    doc.text('24/7 First Notice of Loss Portal: https://portal.hurricaneshield.local/claims', margin + 5, y + 14);
    doc.text('Headquarters: 100 Ocean Drive, Suite 500, Miami, FL 33139 | 1-800-SHIELD-01', margin + 5, y + 19);

    // Download Document
    doc.save(`HurricaneShield_Policy_${policy.policyNumber}.pdf`);
  }

  private renderHeader(doc: jsPDF, pageIndicator: string): void {
    const margin = 20;
    const pageWidth = doc.internal.pageSize.getWidth();

    doc.setFillColor(64, 1, 6); // Brand oxblood
    doc.rect(margin, 15, 6, 6, 'F');

    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(64, 1, 6); // Brand oxblood
    doc.text('NATURALSHIELD', margin + 9, 20);

    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(148, 163, 184);
    doc.text(pageIndicator, pageWidth - margin, 20, { align: 'right' });

    doc.setDrawColor(226, 232, 240);
    doc.line(margin, 25, pageWidth - margin, 25);
  }

  private renderSection(
    doc: jsPDF,
    x: number,
    y: number,
    width: number,
    title: string,
    body: string
  ): void {
    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(15, 23, 42);
    doc.text(title, x, y);

    doc.setFontSize(8.5);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(71, 85, 105);

    const lines = doc.splitTextToSize(body, width);
    doc.text(lines, x, y + 5);
  }
}


import type { Routes } from '@angular/router';

import { authGuard } from '../../core/guards/auth.guard';
import { activeCustomerProfileGuard } from '../../core/guards/profile.guard';
import { permissionGuard } from '../../core/guards/permission.guard';
import { roleGuard } from '../../core/guards/role.guard';
import { unsavedChangesGuard } from '../../core/guards/unsaved-changes.guard';
import { SYSTEM_PERMISSIONS } from '../../core/constants/permissions';
import { SYSTEM_ROLES } from '../../core/constants/roles';
import { placeholderRoute } from '../../core/routing/route-helpers';

export const policyRoutes: Routes = [
  placeholderRoute({
    path: 'policies/apply',
    title: 'Apply for a Policy',
    pageKey: 'policies.apply',
    canActivate: [authGuard, roleGuard, permissionGuard, activeCustomerProfileGuard],
    canDeactivate: [unsavedChangesGuard],
    data: {
      roles: [SYSTEM_ROLES.customer],
      permissions: [SYSTEM_PERMISSIONS.purchasePolicy],
    },
  }),
  placeholderRoute({
    path: 'policies/application/result',
    title: 'Application Result',
    pageKey: 'policies.application-result',
    canActivate: [authGuard, roleGuard],
    data: { roles: [SYSTEM_ROLES.customer] },
  }),
  placeholderRoute({
    path: 'policies/my',
    title: 'My Policies',
    pageKey: 'policies.my',
    canActivate: [authGuard, roleGuard],
    data: { roles: [SYSTEM_ROLES.customer] },
  }),
  placeholderRoute({
    path: 'policies/:policyId/payment',
    title: 'Pay Premium',
    pageKey: 'policies.payment',
    canActivate: [authGuard, roleGuard, permissionGuard, activeCustomerProfileGuard],
    data: {
      roles: [SYSTEM_ROLES.customer],
      permissions: [SYSTEM_PERMISSIONS.purchasePolicy],
    },
  }),
  placeholderRoute({
    path: 'policies/:policyId/renew',
    title: 'Renew Policy',
    pageKey: 'policies.renew',
    canActivate: [authGuard, roleGuard, permissionGuard, activeCustomerProfileGuard],
    canDeactivate: [unsavedChangesGuard],
    data: {
      roles: [SYSTEM_ROLES.customer],
      permissions: [SYSTEM_PERMISSIONS.renewPolicy],
    },
  }),
  placeholderRoute({
    path: 'policies/:policyId/cancel',
    title: 'Cancel Policy',
    pageKey: 'policies.cancel',
    canActivate: [authGuard, roleGuard, permissionGuard],
    data: {
      roles: [SYSTEM_ROLES.customer, SYSTEM_ROLES.administrator],
      permissions: [SYSTEM_PERMISSIONS.cancelPolicy],
    },
  }),
  placeholderRoute({
    path: 'policies/:policyId',
    title: 'Policy Details',
    pageKey: 'policies.details',
    canActivate: [authGuard, roleGuard],
    data: {
      roles: [SYSTEM_ROLES.customer, SYSTEM_ROLES.agent, SYSTEM_ROLES.administrator],
    },
  }),
];


import { ChangeDetectionStrategy, Component, input } from '@angular/core';
import { CurrencyPipe } from '@angular/common';

import type { QuoteResponse } from '../policy.models';
import { IconComponent } from '../../../shared/components/icon/icon.component';

@Component({
  selector: 'app-customer-quote-estimate',
  standalone: true,
  imports: [CurrencyPipe, IconComponent],
  templateUrl: './customer-quote-estimate.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CustomerQuoteEstimateComponent {
  readonly quote = input.required<QuoteResponse>();

  /** Human-readable names for the risk factor keys returned by the quote API. */
  riskFactorLabel(name: string): string {
    const labels: Readonly<Record<string, string>> = {
      zone: 'Risk Zone',
      propertyValue: 'Property Value',
      propertyAge: 'Property Age',
      construction: 'Construction Type',
      claimsHistory: 'Claims History',
      mitigations: 'Mitigation Protections',
    };
    return labels[name] ?? name;
  }

  /** Splits enum-style values such as ReinforcedConcrete into words. */
  spaced(value: string | null | undefined): string {
    return (value ?? '').replace(/([a-z])([A-Z])/g, '$1 $2');
  }
}


# Sample HurricaneShield Insurance Policy Document (Draft)

*This is a multi-page templated outline for the upcoming dynamic PDF generator.*

---

## Page 1: Policy Declarations Page

**NATURALSHIELD / HURRICANESHIELD INSURANCE**  
*Underwritten by NaturalShield Insurance Corporation*  
*100 Ocean Drive, Suite 500, Miami, FL 33139*  

---

### Policy Identification
- **Policy Number:** `{{PolicyNumber}}`
- **Plan Name:** `{{PlanName}}`
- **Policy Status:** `{{PolicyStatus}}`
- **Effective Date:** `{{EffectiveDate}}` (12:01 AM Local Time)
- **Expiration Date:** `{{ExpirationDate}}` (11:59 PM Local Time)
- **Named Insured:** `{{CustomerFullName}}`
- **Customer ID:** `{{CustomerId}}`

### Insured Location (Connected Property)
- **Physical Address:** `{{PropertyAddressLine1}}, {{PropertyCity}}, {{PropertyState}} {{PropertyPostalCode}}`
- **Declared Replacement Value:** `{{PropertyValue}}`
- **Year Built:** `{{PropertyYearBuilt}}`
- **Construction Type:** `{{PropertyConstructionType}}`
- **Assigned Flood/Storm Zone:** `{{PropertyRiskZone}}`

### Risk Mitigation Credits Applied
- Storm Shutters: `{{HasStormShutters}}`
- Impact Resistant Windows: `{{HasImpactWindows}}`
- Reinforced Roof Construction: `{{HasReinforcedRoof}}`
- Backup Power Generator: `{{HasGenerator}}`
- Certified Windstorm Inspection: `{{HasCertification}}`

### Schedule of Coverages & Limits
| Coverage Type | Limit of Liability | Deductible |
| :--- | :--- | :--- |
| `{{Coverage_1_Name}}` | `{{Coverage_1_Limit}}` | `{{Coverage_1_Deductible}}` |
| `{{Coverage_2_Name}}` | `{{Coverage_2_Limit}}` | `{{Coverage_2_Deductible}}` |
| `{{Coverage_3_Name}}` | `{{Coverage_3_Limit}}` | `{{Coverage_3_Deductible}}` |

**Total Annual Premium:** `{{TotalAnnualPremium}}`  
*Authorized Signature:* __________________________

---

\pagebreak

## Page 2: General Terms & Conditions

### 1. Agreement of Indemnity
In reliance upon the representations made in the application and subject to payment of the premium, NaturalShield agrees to provide indemnity strictly to restore the property to its pre-loss condition, subject to policy limits and deductibles.

### 2. Principle of Indemnity & Insurable Interest
In accordance with established insurance mandates:
- Insurance proceeds will under no circumstances exceed the proven repair/replacement cost.
- Requested coverage cannot exceed 100% of the verified property value.
- The insured must maintain an active insurable interest at the time of the event.

### 3. Duties in the Event of Loss (First Notice of Loss)
In the event of physical damage caused by an insured peril, the Named Insured must:
1. Provide prompt notice to the insurer via the HurricaneShield portal or claims hotline.
2. Protect the property from further damage by making reasonable and necessary repairs.
3. Keep an accurate record of all repair expenditures.
4. Allow full access to claims adjusters and designated inspectors.

### 4. Settlement Valuation & RowVersion Optimistic Concurrency
Claim disbursements and settlements are adjudicated according to the Schedule of Coverages on Page 1. Concurrent adjustments are tracked and locked using cryptographic verification.

---

\pagebreak

## Page 3: Coverage Scenarios & Exclusions

### Illustrative Claims Scenarios

#### Scenario A: Direct Tropical Storm & Hurricane Force Winds
- **Description:** Direct structural damage to the roof, siding, and attached structures caused by hurricane-force winds during a declared meteorological event.
- **Settlement Process:** Covered under the *Windstorm & Hurricane* endorsement up to the listed Coverage Limit, minus the named deductible.

#### Scenario B: Storm Surge Inundation
- **Description:** Ground-level rising waters resulting from oceanic storm surge.
- **Settlement Process:** Adjudicated strictly if the *Rising Waters & Inundation* optional rider is present on the Declarations Page.

### Standard Exclusions
The following conditions are strictly excluded from coverage:
- **Pre-existing Neglect:** Wear, tear, marring, deterioration, and rust.
- **Earth Movement:** Earthquakes, landslides, sinkholes, and soil movement unless triggered directly by a declared disaster covered in an optional endorsement.
- **Intentional Loss:** Any damage arising out of intentional acts by or at the direction of the insured.

---
*End of Policy Document. For support or claims, visit your account dashboard at NaturalShield.*

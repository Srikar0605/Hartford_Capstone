
import {
  ChangeDetectionStrategy,
  Component,
  computed,
  inject,
  OnInit,
  signal,
} from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import * as QRCode from 'qrcode';
import { finalize } from 'rxjs';

import { AuthService } from '../../../core/auth/auth.service';
import { AuthSessionService } from '../../../core/auth/auth-session.service';
import { AuthStore } from '../../../core/auth/auth.store';
import { NotificationService } from '../../../core/services/notification.service';
import {
  createForgotPasswordForm,
  createLoginForm,
  createMfaVerificationForm,
  createRecoveryCodeForm,
  createRegistrationForm,
  createResetPasswordForm,
} from '../auth.forms';
import { MfaSetupStore } from '../mfa-setup.store';

import { FormFieldErrorComponent } from '../../../shared/components/form-field-error/form-field-error.component';
import { IconComponent, type IconName } from '../../../shared/components/icon/icon.component';
import { ApiClientError } from '../../../core/interceptors/error.interceptor';

@Component({
  selector: 'app-auth-connected-page',
  imports: [ReactiveFormsModule, RouterLink, FormFieldErrorComponent, IconComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './auth-connected-page.component.html',
})
export class AuthConnectedPageComponent implements OnInit {
  private readonly route = inject(ActivatedRoute);

  private readonly router = inject(Router);

  private readonly auth = inject(AuthService);

  private readonly store = inject(AuthStore);

  private readonly session = inject(AuthSessionService);

  private readonly notifications = inject(NotificationService);

  private readonly mfaSetup = inject(MfaSetupStore);

  readonly pageKey = computed(() => String(this.route.snapshot.data['pageKey']));

  readonly title = computed(() => String(this.route.snapshot.data['title']));

  readonly busy = signal(false);

  /** Copy for the decorative brand panel beside each auth form. */
  readonly authAside = computed<{
    icon: IconName;
    eyebrow: string;
    headline: string;
    points: { icon: IconName; title: string; text: string }[];
  }>(() => {
    const key = this.pageKey();
    if (key === 'auth.register') {
      return {
        icon: 'user',
        eyebrow: 'Join HurricaneShield',
        headline: 'Cover for your home before the next storm season.',
        points: [
          { icon: 'calendar', title: 'Quote in minutes', text: 'Price your cover with live risk factors.' },
          { icon: 'shield-check', title: 'Coastal-grade plans', text: 'Wind, surge and temporary living cover.' },
          { icon: 'banknote', title: 'Fast settlements', text: 'Track claims from report to payout.' },
        ],
      };
    }
    if (key.startsWith('auth.mfa') || key === 'auth.recovery-code' || key === 'auth.recovery-codes') {
      return {
        icon: 'smartphone',
        eyebrow: 'Two-step verification',
        headline: 'A second lock on everything you have insured.',
        points: [
          { icon: 'key', title: 'Authenticator codes', text: 'Six digits that refresh every 30 seconds.' },
          { icon: 'scroll', title: 'Recovery codes', text: 'Keep them offline for when your phone is not around.' },
          { icon: 'activity', title: 'Login activity', text: 'Review every sign-in from your profile.' },
        ],
      };
    }
    if (key === 'auth.forgot-password' || key === 'auth.reset-password') {
      return {
        icon: 'key',
        eyebrow: 'Account recovery',
        headline: 'Back into your account, safely.',
        points: [
          { icon: 'mail', title: 'Check your inbox', text: 'Reset links are sent to your registered email.' },
          { icon: 'clock', title: 'Short-lived links', text: 'Each reset token expires quickly for safety.' },
          { icon: 'shield', title: 'Private by design', text: 'We never reveal whether an account exists.' },
        ],
      };
    }
    return {
      icon: 'lock',
      eyebrow: 'Welcome back',
      headline: 'Your home’s storm shield, one sign-in away.',
      points: [
        { icon: 'storm', title: 'Live cyclone watch', text: 'IMD alerts on every page while a storm is active.' },
        { icon: 'file-check', title: 'Policies & payments', text: 'Pay premiums and download documents anytime.' },
        { icon: 'send', title: 'Claims that move', text: 'Submit a claim and follow every step.' },
      ],
    };
  });

  readonly loginError = signal('');

  readonly developmentToken = signal<string | null>(null);

  readonly qrCodeUrl = signal<string | null>(null);

  readonly qrCodeImage = signal<string | null>(null);

  readonly manualSecret = signal<string | null>(null);

  readonly recoveryCodes = signal<readonly string[] | null>(null);

  readonly loginForm = createLoginForm();

  readonly registrationForm = createRegistrationForm();

  readonly mfaForm = createMfaVerificationForm();

  readonly recoveryForm = createRecoveryCodeForm();

  readonly forgotForm = createForgotPasswordForm();

  readonly resetForm = createResetPasswordForm();
  
  readonly showLoginPassword = signal(false);

  ngOnInit(): void {
    if (this.pageKey() === 'auth.login') {
      try {
        const remembered = localStorage.getItem('hurricaneshield_remembered_email');
        if (remembered) {
          this.loginForm.patchValue({
            email: remembered,
            rememberMe: true,
          });
        }
      } catch {
        // Ignore localStorage restrictions
      }

      if (typeof window !== 'undefined' && 'credentials' in navigator) {
        try {
          navigator.credentials
            .get({ password: true, mediation: 'optional' } as any)
            .then((cred: any) => {
              if (cred && cred.id && cred.password) {
                this.loginForm.patchValue({
                  email: cred.id,
                  password: cred.password,
                });
              }
            })
            .catch(() => {});
        } catch {
          // Ignore unsupported context
        }
      }
      return;
    }

    if (this.pageKey() === 'auth.reset-password') {
      const token = this.route.snapshot.queryParamMap.get('token');
      if (token) {
        this.resetForm.controls.token.setValue(token);
      }
      return;
    }

    if (this.pageKey() !== 'auth.recovery-codes') {
      return;
    }

    const codes = this.mfaSetup.consumeRecoveryCodes();

    if (!codes) {
      void this.router.navigateByUrl('/profile/security');

      return;
    }

    this.recoveryCodes.set(codes);
  }

  register(): void {
    if (this.registrationForm.invalid) {
      this.registrationForm.markAllAsTouched();

      return;
    }

    if (this.busy()) {
      return;
    }

    const value = this.registrationForm.getRawValue();

    const request = {
      firstName: value.firstName,
      lastName: value.lastName,
      email: value.email,
      password: value.password,
    };

    this.busy.set(true);

    this.auth
      .register(request)
      .pipe(
        finalize(() => {
          this.busy.set(false);
        }),
      )
      .subscribe({
        next: () => {
          this.notifications.success('Account created', 'Sign in to continue.');

          void this.router.navigateByUrl('/auth/login');
        },
      });
  }

  login(): void {
    this.loginError.set('');

    if (this.loginForm.invalid) {
      this.loginForm.markAllAsTouched();
      return;
    }

    if (this.busy()) {
      return;
    }

    this.busy.set(true);

    this.auth
      .login(this.loginForm.getRawValue())
      .pipe(
        finalize(() => {
          this.busy.set(false);
        }),
      )
      .subscribe({
        next: (result) => {
          const returnUrl = this.route.snapshot.queryParamMap.get('returnUrl');

          if (result.mfaRequired) {
            if (!result.mfaChallengeToken) {
              this.loginError.set('Sign-in could not continue. Please try again.');

              return;
            }

            this.store.setMfaPending({
              email: this.loginForm.controls.email.value,
              challengeToken: result.mfaChallengeToken,
            });

            void this.router.navigate(['/auth/mfa'], {
              queryParams: {
                returnUrl: this.session.safeReturnUrl(returnUrl),
              },
            });

            return;
          }

          if (!result.accessToken || !result.refreshToken || result.expiresIn === null) {
            this.loginError.set('Sign-in could not continue. Please try again.');

            return;
          }

          const accessToken = result.accessToken;
          const refreshToken = result.refreshToken;
          const expiresIn = result.expiresIn;

          const credData = this.loginForm.getRawValue();
          try {
            if (credData.rememberMe && credData.email) {
              localStorage.setItem('hurricaneshield_remembered_email', credData.email);
            } else {
              localStorage.removeItem('hurricaneshield_remembered_email');
            }
          } catch {
            // Ignore localStorage exceptions
          }

          const completeLogin = () => {
            this.session
              .complete(
                {
                  accessToken,
                  refreshToken,
                  expiresIn,
                },
                returnUrl,
              )
              .subscribe();
          };

          if (
            typeof window !== 'undefined' &&
            'credentials' in navigator &&
            typeof (window as any).PasswordCredential !== 'undefined'
          ) {
            try {
              const cred = new (window as any).PasswordCredential({
                id: credData.email,
                password: credData.password,
                name: credData.email,
              });
              navigator.credentials
                .store(cred)
                .then(completeLogin, completeLogin);
              return;
            } catch {
              // Ignore unsupported context
            }
          }

          completeLogin();
        },

        error: (error: unknown) => {
          if (error instanceof ApiClientError && error.status === 401) {
            this.loginError.set('The email address or password is incorrect.');

            this.loginForm.controls.password.setValue('');
            this.loginForm.controls.password.markAsTouched();
            return;
          }

          if (error instanceof ApiClientError && error.status === 423) {
            this.loginError.set(
              error.message || 'This account is temporarily locked. Try again later.',
            );

            return;
          }

          if (error instanceof ApiClientError && error.status === 0) {
            this.loginError.set('The sign-in service could not be reached. Try again shortly.');

            return;
          }

          this.loginError.set(
            error instanceof ApiClientError ? error.message : 'Sign-in failed. Please try again.',
          );
        },
      });
  }

  verifyMfa(): void {
    if (this.mfaForm.invalid) {
      this.mfaForm.markAllAsTouched();
      return;
    }

    if (this.busy()) {
      return;
    }

    const pending = this.store.mfaPending();

    if (!pending) {
      void this.router.navigateByUrl('/auth/login');

      return;
    }

    const returnUrl = this.route.snapshot.queryParamMap.get('returnUrl');

    this.busy.set(true);

    this.auth
      .verifyMfa({
        mfaChallengeToken: pending.challengeToken,

        verificationCode: this.mfaForm.controls.verificationCode.value,
      })
      .pipe(
        finalize(() => {
          this.busy.set(false);
        }),
      )
      .subscribe({
        next: (tokens) => {
          this.session.complete(tokens, returnUrl).subscribe();
        },
      });
  }

  verifyRecovery(): void {
    if (this.recoveryForm.invalid) {
      this.recoveryForm.markAllAsTouched();
      return;
    }

    if (this.busy()) {
      return;
    }

    this.busy.set(true);

    this.auth
      .verifyRecoveryCode(this.recoveryForm.getRawValue())
      .pipe(
        finalize(() => {
          this.busy.set(false);
        }),
      )
      .subscribe({
        next: (tokens) => {
          this.session.complete(tokens).subscribe();
        },
      });
  }

  forgotPassword(): void {
    if (this.forgotForm.invalid) {
      this.forgotForm.markAllAsTouched();
      return;
    }

    if (this.busy()) {
      return;
    }

    this.busy.set(true);
    this.developmentToken.set(null);

    this.auth
      .requestPasswordReset(this.forgotForm.getRawValue())
      .pipe(
        finalize(() => {
          this.busy.set(false);
        }),
      )
      .subscribe({
        next: (result) => {
          this.developmentToken.set(result.developmentToken);

          if (result.developmentToken) {
            this.resetForm.controls.token.setValue(result.developmentToken);
            this.notifications.success(
              'Reset code generated',
              'Redirecting you to enter your new password...',
            );
            void this.router.navigate(['/auth/reset-password'], {
              queryParams: { token: result.developmentToken },
            });
          } else {
            this.notifications.success(
              'Request received',
              'If the account exists, you can proceed with your reset code.',
            );
            void this.router.navigate(['/auth/reset-password']);
          }
        },
      });
  }

  resetPassword(): void {
    if (this.resetForm.invalid) {
      this.resetForm.markAllAsTouched();
      return;
    }

    if (this.busy()) {
      return;
    }

    const value = this.resetForm.getRawValue();

    const request = {
      token: value.token,
      newPassword: value.newPassword,
    };

    this.busy.set(true);

    this.auth
      .completePasswordReset(request)
      .pipe(
        finalize(() => {
          this.busy.set(false);
        }),
      )
      .subscribe({
        next: () => {
          this.notifications.success('Password reset', 'Sign in with the new password.');

          void this.router.navigateByUrl('/auth/login');
        },
      });
  }

  enableMfa(): void {
    if (this.busy()) {
      return;
    }

    this.busy.set(true);
    this.qrCodeImage.set(null);
    this.qrCodeUrl.set(null);
    this.manualSecret.set(null);

    this.auth
      .enableMfa()
      .pipe(
        finalize(() => {
          this.busy.set(false);
        }),
      )
      .subscribe({
        next: (result) => {
          this.qrCodeUrl.set(result.qrCodeUrl);

          this.manualSecret.set(result.manualSecret);

          void this.generateQrCode(result.qrCodeUrl);
        },
      });
  }

  confirmMfa(): void {
    if (this.mfaForm.invalid) {
      this.mfaForm.markAllAsTouched();
      return;
    }

    if (this.busy()) {
      return;
    }

    this.busy.set(true);

    this.auth
      .confirmMfa(this.mfaForm.getRawValue())
      .pipe(
        finalize(() => {
          this.busy.set(false);
        }),
      )
      .subscribe({
        next: (result) => {
          this.mfaSetup.setRecoveryCodes(result.recoveryCodes);

          this.qrCodeImage.set(null);
          this.qrCodeUrl.set(null);
          this.manualSecret.set(null);
          this.mfaForm.reset();

          void this.router.navigateByUrl('/auth/mfa/recovery-codes');
        },
      });
  }

  private async generateQrCode(authenticatorUri: string): Promise<void> {
    if (!authenticatorUri.startsWith('otpauth://')) {
      this.qrCodeImage.set(null);

      this.notifications.error(
        'QR code could not be generated',
        'The MFA setup response did not contain a valid authenticator URI.',
        null,
      );

      return;
    }

    try {
      const imageDataUrl = await QRCode.toDataURL(authenticatorUri, {
        errorCorrectionLevel: 'M',
        margin: 2,
        width: 240,

        color: {
          dark: '#2a0a0d',
          light: '#FFFFFF',
        },
      });

      this.qrCodeImage.set(imageDataUrl);
    } catch {
      this.qrCodeImage.set(null);

      /*
       * Manual setup remains available.
       * The authenticator URI and secret are
       * never sent to an external QR service.
       */
    }
  }
}

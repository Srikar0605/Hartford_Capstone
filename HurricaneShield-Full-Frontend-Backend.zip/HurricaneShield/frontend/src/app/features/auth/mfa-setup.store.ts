
import { Injectable, signal } from '@angular/core';

/**
 * I created MfaSetupStore to temporarily hold MFA recovery codes in-memory during the enrollment wizard.
 * We deliberately do NOT persist these codes to localStorage or sessionStorage because recovery codes
 * are sensitive emergency credentials.
 */
@Injectable({ providedIn: 'root' })
export class MfaSetupStore {
  private readonly recoveryCodesState = signal<readonly string[] | null>(null);

  readonly recoveryCodes = this.recoveryCodesState.asReadonly();

  setRecoveryCodes(codes: readonly string[]): void {
    this.recoveryCodesState.set([...codes]);
  }

  /**
   * I implemented a single-read "consume" pattern here: retrieving the recovery codes clears them from memory,
   * guaranteeing that once the user views or confirms them, they cannot be leaked or re-read elsewhere.
   */
  consumeRecoveryCodes(): readonly string[] | null {
    const value = this.recoveryCodesState();
    this.recoveryCodesState.set(null);
    return value;
  }

  clear(): void {
    this.recoveryCodesState.set(null);
  }
}

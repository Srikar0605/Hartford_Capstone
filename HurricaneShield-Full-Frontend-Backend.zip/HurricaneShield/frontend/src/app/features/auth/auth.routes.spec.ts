
import { authGuard } from '../../core/guards/auth.guard';
import { authRoutes } from './auth.routes';

describe('authRoutes', () => {
  it.each(['auth/mfa/setup', 'auth/mfa/recovery-codes'])(
    'protects %s with authGuard',
    (path) => {
      const route = authRoutes.find((value) => value.path === path);

      expect(route?.canActivate).toContain(authGuard);
    },
  );
});

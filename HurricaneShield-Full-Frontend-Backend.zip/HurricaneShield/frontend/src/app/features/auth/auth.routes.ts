
import type { Routes } from '@angular/router';

import { authGuard } from '../../core/guards/auth.guard';
import { guestGuard } from '../../core/guards/guest.guard';
import { mfaPendingGuard } from '../../core/guards/mfa-pending.guard';
import { placeholderRoute } from '../../core/routing/route-helpers';

export const authRoutes: Routes = [
  placeholderRoute({
    path: 'auth/login',
    title: 'Sign In',
    pageKey: 'auth.login',
    canActivate: [guestGuard],
  }),
  placeholderRoute({
    path: 'auth/register',
    title: 'Create Account',
    pageKey: 'auth.register',
    canActivate: [guestGuard],
  }),
  placeholderRoute({
    path: 'auth/mfa',
    title: 'MFA Verification',
    pageKey: 'auth.mfa',
    canActivate: [guestGuard, mfaPendingGuard],
  }),
  placeholderRoute({
    path: 'auth/recovery-code',
    title: 'Use Recovery Code',
    pageKey: 'auth.recovery-code',
    canActivate: [guestGuard],
  }),
  placeholderRoute({
    path: 'auth/mfa/setup',
    title: 'Set Up MFA',
    pageKey: 'auth.mfa-setup',
    canActivate: [authGuard],
  }),
  placeholderRoute({
    path: 'auth/mfa/recovery-codes',
    title: 'Recovery Codes',
    pageKey: 'auth.recovery-codes',
    canActivate: [authGuard],
  }),
  placeholderRoute({
    path: 'auth/forgot-password',
    title: 'Forgot Password',
    pageKey: 'auth.forgot-password',
  }),
  placeholderRoute({
    path: 'auth/reset-password',
    title: 'Reset Password',
    pageKey: 'auth.reset-password',
  }),
];

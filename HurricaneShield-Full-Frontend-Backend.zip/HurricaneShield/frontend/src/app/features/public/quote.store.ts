
import { computed, Injectable, signal } from '@angular/core';
import type { QuoteResponse } from '../policies/policy.models';

/**
 * I created QuoteStore to manage real-time quote generation state in our public and customer portals.
 * Because quote exploration is an interactive experience (switching between deductible levels, coverage limits,
 * or recommendation tiers like Bronze, Silver, and Gold), using signals here provides instant reactive updates
 * across the estimation cards without full-page re-renders.
 */
@Injectable({ providedIn: 'root' })
export class QuoteStore {
  private readonly valueState = signal<QuoteResponse | null>(null);
  private readonly quotesState = signal<QuoteResponse[]>([]);
  private readonly selectedQuoteState = signal<QuoteResponse | null>(null);

  readonly value = this.valueState.asReadonly();
  readonly quotes = this.quotesState.asReadonly();

  // Computes the active quote fallback: explicit selection -> single quote value -> first item in the list -> null.
  readonly selectedQuote = computed(
    () => this.selectedQuoteState() ?? this.valueState() ?? this.quotesState()[0] ?? null
  );

  /**
   * Sets a single calculated quote and synchronizes it across selection state.
   */
  set(value: QuoteResponse): void {
    this.valueState.set(value);
    this.quotesState.set([value]);
    this.selectedQuoteState.set(value);
  }

  /**
   * Populates multiple quote recommendations (typically 3 tiers: Basic, Standard, Premium).
   * By default, if 3 or more tiers are returned, I intentionally pre-select the middle tier (index 1)
   * which represents our recommended balanced coverage plan.
   */
  setQuotes(quotes: QuoteResponse[]): void {
    this.quotesState.set(quotes);
    if (quotes.length > 0) {
      const defaultIndex = quotes.length >= 3 ? 1 : 0;
      this.valueState.set(quotes[defaultIndex]);
      this.selectedQuoteState.set(quotes[defaultIndex]);
    } else {
      this.valueState.set(null);
      this.selectedQuoteState.set(null);
    }
  }

  selectQuote(quote: QuoteResponse): void {
    this.selectedQuoteState.set(quote);
    this.valueState.set(quote);
  }

  /**
   * Wipes state when transitioning between distinct customer properties or navigating away.
   */
  clear(): void {
    this.valueState.set(null);
    this.quotesState.set([]);
    this.selectedQuoteState.set(null);
  }
}

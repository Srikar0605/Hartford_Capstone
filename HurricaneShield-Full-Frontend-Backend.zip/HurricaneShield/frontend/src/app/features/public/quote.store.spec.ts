
import { TestBed } from '@angular/core/testing';
import { describe, expect, it } from 'vitest';
import type { QuoteResponse } from '../policies/policy.models';
import { QuoteStore } from './quote.store';

describe('QuoteStore', () => {
  it('starts empty and clears values', () => {
    const store = TestBed.inject(QuoteStore);
    expect(store.value()).toBeNull();
    expect(store.quotes()).toEqual([]);
    store.clear();
    expect(store.value()).toBeNull();
    expect(store.quotes()).toEqual([]);
  });

  it('sets multiple quotes and defaults to middle recommended tier', () => {
    const store = TestBed.inject(QuoteStore);
    const mockQuotes = [
      { plan: { planCode: 'BASIC' }, premium: { finalPremium: 500 } } as QuoteResponse,
      { plan: { planCode: 'STANDARD' }, premium: { finalPremium: 1000 } } as QuoteResponse,
      { plan: { planCode: 'PREMIUM' }, premium: { finalPremium: 1500 } } as QuoteResponse,
    ];

    store.setQuotes(mockQuotes);
    expect(store.quotes()).toHaveLength(3);
    expect(store.value()?.plan.planCode).toBe('STANDARD');
    expect(store.selectedQuote()?.plan.planCode).toBe('STANDARD');

    store.selectQuote(mockQuotes[2]);
    expect(store.selectedQuote()?.plan.planCode).toBe('PREMIUM');
    expect(store.value()?.plan.planCode).toBe('PREMIUM');
  });
});

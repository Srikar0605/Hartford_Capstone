

import { CurrencyPipe } from '@angular/common';
import {
  ChangeDetectionStrategy,
  Component,
  computed,
  ElementRef,
  inject,
  OnInit,
  signal,
} from '@angular/core';
import { type AbstractControl, ReactiveFormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { finalize } from 'rxjs';

import type { ConstructionType, RiskZone } from '../../../core/constants/statuses';
import { EmptyStateComponent } from '../../../shared/components/empty-state/empty-state.component';
import { ErrorStateComponent } from '../../../shared/components/error-state/error-state.component';
import { LoadingStateComponent } from '../../../shared/components/loading-state/loading-state.component';
import { PageHeaderComponent } from '../../../shared/components/page-header/page-header.component';
import { StatusBadgeComponent } from '../../../shared/components/status-badge/status-badge.component';
import { createQuoteForm } from '../../policies/policy.forms';
import type {
  CalculateRecommendationsRequest,
  PlanDetailsResponse,
  PlanSummaryResponse,
  QuoteResponse,
} from '../../policies/policy.models';
import { PolicyService } from '../../policies/policy.service';
import { QuoteStore } from '../quote.store';

const CONSTRUCTION_TYPES: readonly ConstructionType[] = [
  'ReinforcedConcrete',
  'Concrete',
  'Masonry',
  'WoodFrame',
  'Other',
];

const RISK_ZONES: readonly RiskZone[] = ['A', 'B', 'C', 'D'];

function isConstructionType(value: string): value is ConstructionType {
  return CONSTRUCTION_TYPES.includes(value as ConstructionType);
}

function isRiskZone(value: string): value is RiskZone {
  return RISK_ZONES.includes(value as RiskZone);
}

import { FormFieldErrorComponent } from '../../../shared/components/form-field-error/form-field-error.component';
import { IconComponent, type IconName } from '../../../shared/components/icon/icon.component';

type MitigationControl =
  | 'stormShutters'
  | 'impactResistantWindows'
  | 'reinforcedRoof'
  | 'emergencyGenerator'
  | 'homeInspectionCertification';

import { ProductPreviewComponent } from '../../../shared/components/product-preview/product-preview.component';

@Component({
  selector: 'app-public-connected-page',
  imports: [  
    ReactiveFormsModule,
    RouterLink,
    CurrencyPipe,
    PageHeaderComponent,
    LoadingStateComponent,
    EmptyStateComponent,
    ErrorStateComponent,
    StatusBadgeComponent,
    FormFieldErrorComponent,
    IconComponent,
    ProductPreviewComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './public-connected-page.component.html',
  host: { '(document:keydown)': 'onShortcut($event)' },
})
export class PublicConnectedPageComponent implements OnInit {
  private readonly route = inject(ActivatedRoute);

  private readonly router = inject(Router);

  private readonly policies = inject(PolicyService);

  readonly quoteStore = inject(QuoteStore);

  readonly pageKey = computed(() => String(this.route.snapshot.data['pageKey'] ?? 'system.error'));

  readonly title = computed(() => String(this.route.snapshot.data['title'] ?? 'HurricaneShield'));

  readonly eyebrow = computed(() =>
    this.pageKey().startsWith('system.') ? 'HurricaneShield' : 'Public',
  );

  readonly description = computed(() => {
    const descriptions: Readonly<Record<string, string>> = {
      'public.home': 'Protect property with clear coverage, premium, payment, and claim journeys.',

      'public.how-it-works': 'A guided path from plan comparison to claim settlement.',

      'public.plans': 'Compare active hurricane insurance plans.',

      'public.plan-details': 'Review the selected plan and coverages.',

      'public.quote': 'Request a backend-calculated premium quote.',

      'public.quote-result': 'Review the latest calculated quote.',

      'system.not-found': 'The requested page could not be found.',

      'system.access-denied': 'This account cannot access the requested page.',

      'system.service-unavailable': 'A required service is temporarily unavailable.',

      'system.error': 'The request could not be completed.',
    };

    return descriptions[this.pageKey()] ?? '';
  });

  readonly loading = signal(false);

  readonly submitting = signal(false);

  readonly error = signal<string | null>(null);

  readonly plans = signal<PlanSummaryResponse[]>([]);

  readonly plan = signal<PlanDetailsResponse | null>(null);

  readonly quoteForm = createQuoteForm();

  /* ---- Quote wizard (UI state only; submitQuote() and the API call are unchanged) ---- */
  /** Landing-style public pages render full-bleed (Control Room direction). */
  readonly isShowcase = computed(() =>
    ['public.home', 'public.how-it-works', 'public.plans'].includes(this.pageKey()),
  );
  readonly maxPlanCoverage = computed(() => Math.max(1, ...this.plans().map((p) => p.coverageLimit)));
  readonly maxPlanDeductible = computed(() => Math.max(1, ...this.plans().map((p) => p.deductibleAmount)));

  /* Static content for the HurricaneShield landing pages. */
  readonly homeFacts: readonly { tag: string; title: string; text: string; icon: IconName }[] = [
    { tag: 'Priced for you', title: 'Property-specific premium', text: 'Zone, age, build and claims history.', icon: 'gauge' },
    { tag: 'Rewarded', title: 'Mitigation discounts', text: 'Shutters, roof and windows count.', icon: 'shield-check' },
    { tag: 'Secure', title: 'MFA-protected accounts', text: 'Authenticator codes and recovery keys.', icon: 'lock' },
    { tag: 'In rupees', title: 'Clear INR pricing', text: 'Every adjustment shown in ₹.', icon: 'receipt' },
  ];
  readonly riskFactorsPreview = [
    { name: 'Risk zone', width: 76, up: true },
    { name: 'Property age', width: 44, up: true },
    { name: 'Construction type', width: 30, up: false },
    { name: 'Mitigation protections', width: 46, up: false },
  ];
  readonly premiumLines = [
    { sign: '', label: 'Plan base premium', width: 82 },
    { sign: '+', label: 'Location risk adjustment', width: 22 },
    { sign: '+', label: 'Property value adjustment', width: 12 },
    { sign: '+', label: 'Claims history adjustment', width: 8 },
    { sign: '+', label: 'Risk score adjustment', width: 28 },
    { sign: '−', label: 'Mitigation discount', width: 18 },
    { sign: '=', label: 'Estimated final premium', width: 100 },
  ];
  readonly howSteps = [
    { tag: 'Compare', title: 'Compare Plans', text: 'Review active insurance Plans and choose the Coverage that matches your Property requirements.', action: 'View Plans', route: '/plans' },
    { tag: 'Estimate', title: 'Calculate a Quote', text: 'Provide Property, Coverage, risk-zone, Claims-history and mitigation information in three steps.', action: 'Get a Quote', route: '/quote' },
    { tag: 'Apply & pay', title: 'Apply and Pay', text: 'Register, use a saved Property, submit the application, and pay after approval.', action: 'Create Account', route: '/auth/register' },
    { tag: 'Claim', title: 'Submit and Track Claims', text: 'Submit an eligible Claim, upload documents, and follow review and settlement progress.', action: 'Sign In', route: '/auth/login' },
  ];

  /** Single-key shortcuts shown on the HurricaneShield landing pages: Q → quote, P → plans. */
  onShortcut(event: KeyboardEvent): void {
    if (!this.isShowcase() || event.metaKey || event.ctrlKey || event.altKey || event.repeat) return;
    const target = event.target as HTMLElement | null;
    if (target && (target.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(target.tagName))) return;
    const key = event.key.toLowerCase();
    if (key === 'q') void this.router.navigateByUrl('/quote');
    if (key === 'p' && this.pageKey() !== 'public.plans') void this.router.navigateByUrl('/plans');
  }

  readonly quoteSteps = [{ label: 'Your home' }, { label: 'Protection' }, { label: 'Coverage' }] as const;

  readonly quoteStep = signal(0);

  private readonly hostElement = inject<ElementRef<HTMLElement>>(ElementRef);

  readonly constructionTypes = CONSTRUCTION_TYPES;

  readonly mitigationFeatures: readonly { control: MitigationControl; label: string; hint: string; icon: IconName }[] = [
    { control: 'stormShutters', label: 'Storm shutters', hint: 'Shields windows and doors from wind-borne debris.', icon: 'wind' },
    { control: 'impactResistantWindows', label: 'Impact-resistant windows', hint: 'Laminated glazing rated for cyclone impact.', icon: 'shield' },
    { control: 'reinforcedRoof', label: 'Reinforced roof', hint: 'Hurricane straps or reinforced roof decking.', icon: 'house' },
    { control: 'emergencyGenerator', label: 'Emergency generator', hint: 'Backup power through long outages.', icon: 'zap' },
    { control: 'homeInspectionCertification', label: 'Inspection certificate', hint: 'Recent wind-mitigation inspection on file.', icon: 'badge-check' },
  ];

  selectedMitigationCount(): number {
    const property = this.quoteForm.controls.property.controls;
    return this.mitigationFeatures.filter((feature) => property[feature.control].value).length;
  }

  nextQuoteStep(): void {
    const controls = this.quoteStepControls(this.quoteStep());
    controls.forEach((control) => control.markAsTouched());
    if (controls.some((control) => control.invalid)) {
      return;
    }
    this.quoteStep.update((step) => Math.min(step + 1, this.quoteSteps.length - 1));
    this.focusStepHeading();
  }

  previousQuoteStep(): void {
    this.quoteStep.update((step) => Math.max(step - 1, 0));
    this.focusStepHeading();
  }

  goToQuoteStep(step: number): void {
    if (step <= this.quoteStep()) {
      this.quoteStep.set(step);
      this.focusStepHeading();
    }
  }

  /** Moves focus (and the viewport) to the new step's heading so keyboard and screen-reader users follow along. */
  private focusStepHeading(): void {
    setTimeout(() => {
      const heading = this.hostElement.nativeElement.querySelector<HTMLElement>('[data-step-heading]');
      heading?.focus({ preventScroll: true });
      heading?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
  }

  private quoteStepControls(step: number): AbstractControl[] {
    const property = this.quoteForm.controls.property.controls;
    if (step === 0) {
      return [property.propertyValue, property.yearBuilt, property.constructionType, property.claimsHistoryCount];
    }
    if (step === 2) {
      return [this.quoteForm.controls.requestedCoverage, this.quoteForm.controls.planId];
    }
    return [];
  }

  ngOnInit(): void {
    const key = this.pageKey();
    if (key === 'public.plans') {
      this.loadPlans();
      return;
    }
    if (key === 'public.plan-details') {
      this.loadPlan();
      return;
    }
    if (key === 'public.quote') {
      this.quoteForm.controls.planId.clearValidators();
      this.quoteForm.controls.planId.updateValueAndValidity();
      const planId = this.route.snapshot.queryParamMap.get('planId');
      if (planId) {
        this.quoteForm.controls.planId.setValue(planId);
      }
      this.loadPlans();
      return;
    }
    if (key === 'public.quote-result' && !this.quoteStore.value()) {
      void this.router.navigateByUrl('/quote');
    }
  }

  constructionTypeLabel(value: ConstructionType): string {
    const labels: Readonly<Record<ConstructionType, string>> = {
      ReinforcedConcrete: 'Reinforced Concrete',

      Concrete: 'Concrete',

      Masonry: 'Masonry',

      WoodFrame: 'Wood Frame',

      Other: 'Other',
    };

    return labels[value];
  }

  riskFactorLabel(name: string): string {
    const labels: Readonly<Record<string, string>> = {
      zone: 'Risk Zone',

      propertyValue: 'Property Value',

      propertyAge: 'Property Age',

      construction: 'Construction Type',

      claimsHistory: 'Claims History',

      mitigations: 'Mitigation Protections',
    };

    return labels[name] ?? name;
  }

  selectedQuotePlan(): PlanSummaryResponse | null {
    const planId = this.quoteForm.controls.planId.value;

    return this.plans().find((planItem) => planItem.planId === planId) ?? null;
  }

  loadPlans(): void {
    if (this.loading()) {
      return;
    }

    this.loading.set(true);
    this.error.set(null);
    this.plans.set([]);

    this.policies
      .getPlans()
      .pipe(
        finalize(() => {
          this.loading.set(false);
        }),
      )
      .subscribe({
        next: (planItems: PlanSummaryResponse[]) => {
          const availablePlans = planItems ?? [];

          this.plans.set(availablePlans);

          if (this.pageKey() !== 'public.quote') {
            return;
          }

          const selectedPlanId = this.quoteForm.controls.planId.value;

          if (
            selectedPlanId &&
            !availablePlans.some((planItem) => planItem.planId === selectedPlanId)
          ) {
            this.quoteForm.controls.planId.reset('');
          }
        },

        error: () => {
          this.plans.set([]);

          this.error.set('Plans could not be loaded.');
        },
      });
  }

  loadPlan(): void {
    if (this.loading()) {
      return;
    }

    const planId = this.route.snapshot.paramMap.get('planId');

    if (!planId) {
      this.error.set('Plan identifier is missing.');

      return;
    }

    this.loading.set(true);
    this.error.set(null);
    this.plan.set(null);

    this.policies
      .getPlan(planId)
      .pipe(
        finalize(() => {
          this.loading.set(false);
        }),
      )
      .subscribe({
        next: (response) => {
          this.plan.set(response);
        },

        error: () => {
          this.error.set('The plan could not be loaded.');
        },
      });
  }

  submitQuote(): void {
    if (this.quoteForm.invalid) {
      this.quoteForm.markAllAsTouched();
      return;
    }

    if (this.submitting()) {
      return;
    }

    const value = this.quoteForm.getRawValue();

    const property = value.property;

    if (
      value.requestedCoverage === null ||
      property.propertyValue === null ||
      property.yearBuilt === null
    ) {
      this.quoteForm.markAllAsTouched();
      return;
    }

    if (!isConstructionType(property.constructionType)) {
      const constructionControl = this.quoteForm.controls.property.controls.constructionType;

      constructionControl.setErrors({
        invalidConstructionType: true,
      });

      constructionControl.markAsTouched();

      return;
    }

    const ownershipId = property.customerPropertyOwnershipId?.trim();

    const request: CalculateRecommendationsRequest = {
      requestedCoverage: value.requestedCoverage,
      property: {
        customerPropertyOwnershipId: ownershipId ? ownershipId : null,
        propertyValue: property.propertyValue,
        yearBuilt: property.yearBuilt,
        constructionType: property.constructionType,
        claimsHistoryCount: property.claimsHistoryCount,
        stormShutters: property.stormShutters,
        impactResistantWindows: property.impactResistantWindows,
        reinforcedRoof: property.reinforcedRoof,
        emergencyGenerator: property.emergencyGenerator,
        homeInspectionCertification: property.homeInspectionCertification,
      },
    };

    this.submitting.set(true);
    this.error.set(null);

    this.policies
      .calculateRecommendations(request)
      .pipe(
        finalize(() => {
          this.submitting.set(false);
        }),
      )
      .subscribe({
        next: (results: QuoteResponse[]) => {
          if (!results || results.length === 0) {
            this.error.set(
              'No active insurance plans qualify for the requested coverage amount. Please adjust your coverage amount or property value.',
            );
            return;
          }

          this.quoteStore.setQuotes(results);

          if (value.planId) {
            const matching = results.find((r) => r.plan.planId === value.planId);
            if (matching) {
              this.quoteStore.selectQuote(matching);
            }
          }

          void this.router.navigateByUrl('/quote/result');
        },
        error: (err) => {
          this.error.set(
            err?.error?.message ?? 'The quote recommendations could not be calculated.',
          );
        },
      });
  }

  selectRecommendedQuote(quote: QuoteResponse): void {
    this.quoteStore.selectQuote(quote);
  }
}

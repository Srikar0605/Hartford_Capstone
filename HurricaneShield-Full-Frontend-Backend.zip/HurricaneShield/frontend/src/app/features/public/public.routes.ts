
import type { Routes } from '@angular/router';

import { placeholderRoute } from '../../core/routing/route-helpers';

export const publicRoutes: Routes = [
  placeholderRoute({ path: 'home', title: 'Home', pageKey: 'public.home' }),
  placeholderRoute({
    path: 'how-it-works',
    title: 'How It Works',
    pageKey: 'public.how-it-works',
  }),
  placeholderRoute({ path: 'plans', title: 'Insurance Plans', pageKey: 'public.plans' }),
  placeholderRoute({
    path: 'plans/:planId',
    title: 'Plan Details',
    pageKey: 'public.plan-details',
  }),
  placeholderRoute({ path: 'quote', title: 'Get a Quote', pageKey: 'public.quote' }),
  placeholderRoute({
    path: 'quote/result',
    title: 'Quote Result',
    pageKey: 'public.quote-result',
  }),
  placeholderRoute({
    path: 'access-denied',
    title: 'Access Denied',
    pageKey: 'system.access-denied',
  }),
  placeholderRoute({ path: 'error', title: 'Something Went Wrong', pageKey: 'system.error' }),
  placeholderRoute({
    path: 'service-unavailable',
    title: 'Service Unavailable',
    pageKey: 'system.service-unavailable',
  }),
  placeholderRoute({
    path: 'not-found',
    title: 'Page Not Found',
    pageKey: 'system.not-found',
  }),
];


export const environment = {
  production: false,
  gatewayUrl: 'https://localhost:7000',
} as const;

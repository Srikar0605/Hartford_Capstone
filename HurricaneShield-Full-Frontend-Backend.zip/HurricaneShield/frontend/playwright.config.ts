
import { defineConfig } from '@playwright/test';
 
export default defineConfig({
  testDir: './playwright',
  timeout: 30000,
 
  use: {
    baseURL: 'http://localhost:4200',
    headless: false,
    screenshot: 'only-on-failure',
    video: 'retain-on-failure',
    trace: 'on-first-retry'
  }
});

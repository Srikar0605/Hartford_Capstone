
import { test, expect } from '@playwright/test';

test.describe('Public Home Page', () => {
  test('should load home page', async ({ page }) => {
    await page.goto('/');

    await expect(page).toHaveTitle(/NaturalShield Insurance/i);
  });

  test('should display hero content', async ({ page }) => {
    await page.goto('/');

    await expect(
      page.getByText('Natural-disaster insurance')
    ).toBeVisible();

    await expect(
      page.getByRole('link', {
        name: /explore hurricaneshield/i
      }).first()
    ).toBeVisible();

    await expect(
      page.getByRole('link', {
        name: /view hurricane plans/i
      }).first()
    ).toBeVisible();
  });

  test('should navigate to HurricaneShield experience', async ({ page }) => {
    await page.goto('/');

    await page.getByRole('link', {
      name: /explore hurricaneshield/i
    }).first().click();

    await expect(page).toHaveURL(/home/);
  });

  test('should navigate to plans page', async ({ page }) => {
    await page.goto('/');

    await page.getByRole('link', {
      name: /view hurricane plans/i
    }).first().click();

    await expect(page).toHaveURL(/plans/);
  });
});

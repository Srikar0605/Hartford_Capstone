
import { test, expect } from '@playwright/test';

test.describe('Registration Page', () => {
  test('should load registration page', async ({ page }) => {
    await page.goto('/register');

    await expect(
      page.locator('form')
    ).toBeVisible();

    await expect(
      page.getByRole('button', { name: /create account/i })
    ).toBeVisible();
  });

  test('should validate empty form', async ({ page }) => {
    await page.goto('/register');

    await page.getByRole('button', {
      name: /create account/i
    }).click();

    await expect(
      page.getByText(/first name/i).first()
    ).toBeVisible();
  });
});

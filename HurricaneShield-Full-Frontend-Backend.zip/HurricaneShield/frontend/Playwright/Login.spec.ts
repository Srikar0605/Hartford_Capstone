
import { test, expect } from '@playwright/test';

test.describe('Login Page', () => {
  test('should load login page', async ({ page }) => {
    await page.goto('/login');

    await expect(
      page.locator('form')
    ).toBeVisible();

    await expect(
      page.getByRole('button', { name: /^sign in$/i })
    ).toBeVisible();
  });

  test('should show validation errors', async ({ page }) => {
    await page.goto('/login');

    await page.getByRole('button', {
      name: /^sign in$/i
    }).click();

    await expect(
      page.getByText(/email/i).first()
    ).toBeVisible();
  });

  test('should display remember me checkbox and allow checking it', async ({ page }) => {
    await page.goto('/login');

    const checkbox = page.getByRole('checkbox', { name: /remember this device/i });
    await expect(checkbox).toBeVisible();
    await expect(checkbox).not.toBeChecked();

    await checkbox.check();
    await expect(checkbox).toBeChecked();
  });
});

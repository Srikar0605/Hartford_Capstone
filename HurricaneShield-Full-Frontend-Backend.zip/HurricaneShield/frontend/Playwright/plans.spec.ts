
import { test, expect } from '@playwright/test';

test.describe('Public Plans Page', () => {
  test('should load plans page', async ({ page }) => {
    await page.goto('/plans');

    await expect(page).toHaveURL(/plans/);
  });

  test('should display available plans', async ({ page }) => {
    await page.goto('/plans');

    await expect(
      page.getByText(/hurricaneshield plans/i)
    ).toBeVisible();
  });
});

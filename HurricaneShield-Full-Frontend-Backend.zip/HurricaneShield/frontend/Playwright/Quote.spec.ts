
import { test, expect } from '@playwright/test';

test.describe('Public Quote Page', () => {
  test('should load quote page', async ({ page }) => {
    await page.goto('/quote');

    await expect(
      page.locator('form')
    ).toBeVisible();
  });

  test('should display quote form', async ({ page }) => {
    await page.goto('/quote');

    await expect(
      page.locator('form')
    ).toBeVisible();
  });

  test('should show required validation', async ({ page }) => {
    await page.goto('/quote');

    await page.getByRole('button', {
      name: /calculate quote/i
    }).click();

    await expect(
      page.getByText(/insurance plan/i).first()
    ).toBeVisible();
  });
});

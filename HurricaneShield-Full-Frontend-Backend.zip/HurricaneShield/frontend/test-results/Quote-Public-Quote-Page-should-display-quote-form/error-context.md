
# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: Quote.spec.ts >> Public Quote Page >> should display quote form
- Location: playwright\Quote.spec.ts:12:7

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('form')
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" locator('form') with timeout 5000ms
  - waiting for locator('form')

```

```yaml
- link "Skip to main content":
  - /url: "#main-content"
- banner:
  - link "HurricaneShield home":
    - /url: /home
    - text: HurricaneShield
  - navigation "Primary navigation":
    - link "Home":
      - /url: /home
    - link "How it works":
      - /url: /how-it-works
    - link "Plans":
      - /url: /plans
    - link "Get a quote":
      - /url: /quote
  - link "Sign in":
    - /url: /auth/login
  - link "Create account":
    - /url: /auth/register
- main:
  - paragraph: Public
  - heading "Get a Quote" [level=1]
  - paragraph: Request a backend-calculated premium quote.
  - main:
    - alert:
      - heading "Unable to load this information" [level=2]
      - paragraph: Plans could not be loaded.
      - button "Try again"
- contentinfo:
  - link "HurricaneShield home":
    - /url: /home
    - text: HurricaneShield
  - paragraph: Clear hurricane insurance journeys from quote through policy, claim, and payment.
  - navigation "Footer navigation":
    - link "How it works":
      - /url: /how-it-works
    - link "Plans":
      - /url: /plans
    - link "Get a quote":
      - /url: /quote
  - paragraph: © 2026 HurricaneShield. Training capstone application.
- region "Notifications":
  - article:
    - heading "Service unavailable" [level=2]
    - paragraph: The backend could not be reached. Confirm that the Gateway is running.
    - button "Dismiss notification": ✕
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test';
  2  | 
  3  | test.describe('Public Quote Page', () => {
  4  |   test('should load quote page', async ({ page }) => {
  5  |     await page.goto('/quote');
  6  | 
  7  |     await expect(
  8  |       page.locator('form')
  9  |     ).toBeVisible();
  10 |   });
  11 | 
  12 |   test('should display quote form', async ({ page }) => {
  13 |     await page.goto('/quote');
  14 | 
  15 |     await expect(
  16 |       page.locator('form')
> 17 |     ).toBeVisible();
     |       ^ Error: expect(locator).toBeVisible() failed
  18 |   });
  19 | 
  20 |   test('should show required validation', async ({ page }) => {
  21 |     await page.goto('/quote');
  22 | 
  23 |     await page.getByRole('button', {
  24 |       name: /calculate quote/i
  25 |     }).click();
  26 | 
  27 |     await expect(
  28 |       page.getByText(/insurance plan/i).first()
  29 |     ).toBeVisible();
  30 |   });
  31 | });
```

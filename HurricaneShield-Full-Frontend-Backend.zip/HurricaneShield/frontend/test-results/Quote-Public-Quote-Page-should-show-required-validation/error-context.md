
# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: Quote.spec.ts >> Public Quote Page >> should show required validation
- Location: playwright\Quote.spec.ts:20:7

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: /calculate quote/i })

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "Skip to main content" [ref=e4] [cursor=pointer]:
    - /url: "#main-content"
  - generic [ref=e5]:
    - banner [ref=e6]:
      - generic [ref=e7]:
        - link "HurricaneShield home" [ref=e9] [cursor=pointer]:
          - /url: /home
          - generic [ref=e14]: HurricaneShield
        - navigation "Primary navigation" [ref=e15]:
          - link "Home" [ref=e16] [cursor=pointer]:
            - /url: /home
          - link "How it works" [ref=e17] [cursor=pointer]:
            - /url: /how-it-works
          - link "Plans" [ref=e18] [cursor=pointer]:
            - /url: /plans
          - link "Get a quote" [ref=e19] [cursor=pointer]:
            - /url: /quote
        - generic [ref=e20]:
          - link "Sign in" [ref=e21] [cursor=pointer]:
            - /url: /auth/login
          - link "Create account" [ref=e22] [cursor=pointer]:
            - /url: /auth/register
    - main [ref=e23]:
      - generic [ref=e24]:
        - generic [ref=e29]:
          - paragraph [ref=e30]: Public
          - heading "Get a Quote" [level=1] [ref=e31]
          - paragraph [ref=e32]: Request a backend-calculated premium quote.
        - main [ref=e33]:
          - alert [ref=e35]:
            - generic [ref=e36]:
              - generic [aria-hidden] [ref=e37]: "!"
              - generic [ref=e38]:
                - heading "Unable to load this information" [level=2] [ref=e39]
                - paragraph [ref=e40]: Plans could not be loaded.
                - button "Try again" [ref=e42] [cursor=pointer]
    - contentinfo [ref=e43]:
      - generic [ref=e44]:
        - generic [ref=e45]:
          - link "HurricaneShield home" [ref=e47] [cursor=pointer]:
            - /url: /home
            - generic [ref=e52]: HurricaneShield
          - paragraph [ref=e53]: Clear hurricane insurance journeys from quote through policy, claim, and payment.
        - navigation "Footer navigation" [ref=e54]:
          - link "How it works" [ref=e55] [cursor=pointer]:
            - /url: /how-it-works
          - link "Plans" [ref=e56] [cursor=pointer]:
            - /url: /plans
          - link "Get a quote" [ref=e57] [cursor=pointer]:
            - /url: /quote
      - paragraph [ref=e58]: © 2026 HurricaneShield. Training capstone application.
  - generic:
    - region "Notifications"
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test';
  2  | 
  3  | test.describe('Public Quote Page', () => {
  4  |   test('should load quote page', async ({ page }) => {
  5  |     await page.goto('/quote');
  6  | 
  7  |     await expect(
  8  |       page.locator('form')
  9  |     ).toBeVisible();
  10 |   });
  11 | 
  12 |   test('should display quote form', async ({ page }) => {
  13 |     await page.goto('/quote');
  14 | 
  15 |     await expect(
  16 |       page.locator('form')
  17 |     ).toBeVisible();
  18 |   });
  19 | 
  20 |   test('should show required validation', async ({ page }) => {
  21 |     await page.goto('/quote');
  22 | 
  23 |     await page.getByRole('button', {
  24 |       name: /calculate quote/i
> 25 |     }).click();
     |        ^ Error: locator.click: Test timeout of 30000ms exceeded.
  26 | 
  27 |     await expect(
  28 |       page.getByText(/insurance plan/i).first()
  29 |     ).toBeVisible();
  30 |   });
  31 | });
```

-- HurricaneShield - schema changes for the "AI engine label" fix (fallback to apply-db-changes.ps1).
-- Prefer the PowerShell script: it also updates the EF model snapshot. If you apply this SQL
-- by hand instead, the next "dotnet ef migrations add" will try to add these columns again;
-- delete those two AddColumn lines from that generated migration.

USE [PolicyDb1];
IF COL_LENGTH('dbo.ComplianceReviews', 'Engine') IS NULL
    ALTER TABLE [dbo].[ComplianceReviews] ADD [Engine] nvarchar(30) NULL;
GO

USE [ClaimsDb1];
IF COL_LENGTH('dbo.AiClaimTriages', 'Engine') IS NULL
    ALTER TABLE [dbo].[AiClaimTriages] ADD [Engine] nvarchar(30) NULL;
GO

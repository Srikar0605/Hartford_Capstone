using PaymentService.Tests.TestSupport;

namespace PaymentService.Tests.Domain.Common;

public sealed class AggregateRootTests
{
    [Fact]
    public void NewTransaction_HasEmptyRowVersionUntilPersistenceGeneratesIt()
    {
        PaymentTestData.CreatePremium().RowVersion.Should().BeEmpty();
    }

    [Fact]
    public void SoftDelete_FirstCall_SetsDeletionAndAuditFields()
    {
        var transaction = PaymentTestData.CreatePremium();
        var deletedAt = PaymentTestData.UtcNow.AddHours(1);

        transaction.SoftDelete(deletedAt, "administrator");

        transaction.IsDeleted.Should().BeTrue();
        transaction.DeletedAt.Should().Be(deletedAt);
        transaction.DeletedBy.Should().Be("administrator");
        transaction.UpdatedAt.Should().Be(deletedAt);
        transaction.UpdatedBy.Should().Be("administrator");
    }

    [Fact]
    public void SoftDelete_RepeatedCall_IsIdempotent()
    {
        var transaction = PaymentTestData.CreatePremium();
        var original = PaymentTestData.UtcNow.AddHours(1);
        transaction.SoftDelete(original, "administrator");

        transaction.SoftDelete(original.AddHours(1), "another-user");

        transaction.DeletedAt.Should().Be(original);
        transaction.DeletedBy.Should().Be("administrator");
    }

    [Fact]
    public void SoftDelete_WithNonUtcTimestamp_Throws()
    {
        var transaction = PaymentTestData.CreatePremium();
        var local = DateTime.SpecifyKind(DateTime.Now, DateTimeKind.Local);

        var action = () => transaction.SoftDelete(local, "administrator");

        action.Should().Throw<DomainRuleException>();
    }
}


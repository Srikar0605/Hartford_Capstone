namespace PaymentService.Tests.Domain.Models;

public sealed class PaymentGatewayModelTests
{
    [Fact]
    public void GatewayRequest_PreservesSimulationFlag()
    {
        var transactionId = Guid.NewGuid();
        var request = new PaymentGatewayRequest(transactionId, PaymentType.Premium, 100m, true);

        request.TransactionId.Should().Be(transactionId);
        request.Type.Should().Be(PaymentType.Premium);
        request.Amount.Should().Be(100m);
        request.SimulateFailure.Should().BeTrue();
    }

    [Fact]
    public void GatewayResult_PreservesDeterministicOutcome()
    {
        var result = new PaymentGatewayResult(
            false,
            "SIMULATED_FAILURE",
            "Simulated payment failure."
        );

        result.Successful.Should().BeFalse();
        result.ResponseCode.Should().Be("SIMULATED_FAILURE");
        result.ResponseMessage.Should().Be("Simulated payment failure.");
    }
}


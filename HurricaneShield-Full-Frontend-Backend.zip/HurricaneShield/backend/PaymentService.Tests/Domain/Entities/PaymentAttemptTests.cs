using PaymentService.Tests.TestSupport;

namespace PaymentService.Tests.Domain.Entities;

public sealed class PaymentAttemptTests
{
    [Fact]
    public void PaymentRequest_Create_PreservesSanitizedAttemptData()
    {
        var transactionId = Guid.NewGuid();
        var request = PaymentRequest.Create(
            transactionId,
            "Premium",
            "idem-key",
            "{\"policyId\":\"safe-value\"}",
            PaymentTestData.UtcNow
        );

        request.Id.Should().NotBeEmpty();
        request.TransactionId.Should().Be(transactionId);
        request.RequestType.Should().Be("Premium");
        request.IdempotencyKey.Should().Be("idem-key");
        request.RequestPayload.Should().Contain("policyId");
    }

    [Theory]
    [InlineData("")]
    [InlineData("   ")]
    public void PaymentRequest_WithoutIdempotencyKey_Throws(string key)
    {
        var action = () =>
            PaymentRequest.Create(Guid.NewGuid(), "Premium", key, "{}", PaymentTestData.UtcNow);
        action.Should().Throw<DomainRuleException>();
    }

    [Fact]
    public void PaymentRequest_WithEmptyTransactionId_Throws()
    {
        var action = () =>
            PaymentRequest.Create(Guid.Empty, "Premium", "key", "{}", PaymentTestData.UtcNow);
        action.Should().Throw<DomainRuleException>();
    }

    [Theory]
    [InlineData(PaymentStatus.Success)]
    [InlineData(PaymentStatus.Failed)]
    public void PaymentResponse_WithTerminalStatus_CreatesResponse(PaymentStatus status)
    {
        var response = PaymentResponse.Create(
            Guid.NewGuid(),
            status == PaymentStatus.Success ? "APPROVED" : "DECLINED",
            status,
            status == PaymentStatus.Success ? "Approved." : "Failed.",
            PaymentTestData.UtcNow
        );

        response.ResponseStatus.Should().Be(status);
        response.Id.Should().NotBeEmpty();
    }

    [Fact]
    public void PaymentResponse_WithPendingStatus_Throws()
    {
        var action = () =>
            PaymentResponse.Create(
                Guid.NewGuid(),
                "PENDING",
                PaymentStatus.Pending,
                "Pending.",
                PaymentTestData.UtcNow
            );
        action.Should().Throw<DomainRuleException>();
    }

    [Fact]
    public void PaymentResponse_WithEmptyRequestId_Throws()
    {
        var action = () =>
            PaymentResponse.Create(
                Guid.Empty,
                "APPROVED",
                PaymentStatus.Success,
                "Approved.",
                PaymentTestData.UtcNow
            );
        action.Should().Throw<DomainRuleException>();
    }
}


using PaymentService.Tests.TestSupport;

namespace PaymentService.Tests.Domain.Entities;

public sealed class PaymentTransactionLifecycleTests
{
    [Fact]
    public void ApplyGatewayResult_Success_MovesPendingToSuccess()
    {
        var transaction = PaymentTestData.CreatePremium();
        var processedAt = PaymentTestData.UtcNow.AddSeconds(1);

        transaction.ApplyGatewayResult(
            new PaymentGatewayResult(true, "APPROVED", "Payment approved."),
            processedAt,
            "payment-gateway"
        );

        transaction.Status.Should().Be(PaymentStatus.Success);
        transaction.FailureReason.Should().BeNull();
        transaction.TransactionDate.Should().Be(processedAt);
        transaction.UpdatedAt.Should().Be(processedAt);
        transaction.UpdatedBy.Should().Be("payment-gateway");
    }

    [Fact]
    public void ApplyGatewayResult_Failure_MovesPendingToFailed()
    {
        var transaction = PaymentTestData.CreatePremium();

        transaction.ApplyGatewayResult(
            new PaymentGatewayResult(false, "DECLINED", "Simulated failure."),
            PaymentTestData.UtcNow.AddSeconds(1),
            "payment-gateway"
        );

        transaction.Status.Should().Be(PaymentStatus.Failed);
        transaction.FailureReason.Should().Be("Simulated failure.");
    }

    [Fact]
    public void ApplyGatewayResult_FailureWithoutMessage_Throws()
    {
        var transaction = PaymentTestData.CreatePremium();
        var action = () =>
            transaction.ApplyGatewayResult(
                new PaymentGatewayResult(false, "DECLINED", " "),
                PaymentTestData.UtcNow.AddSeconds(1),
                "payment-gateway"
            );

        action.Should().Throw<DomainRuleException>();
    }

    [Theory]
    [InlineData(true)]
    [InlineData(false)]
    public void TerminalTransaction_CannotBeProcessedAgain(bool initiallySuccessful)
    {
        var transaction = PaymentTestData.CreatePremium();
        transaction.ApplyGatewayResult(
            new PaymentGatewayResult(
                initiallySuccessful,
                initiallySuccessful ? "APPROVED" : "DECLINED",
                initiallySuccessful ? "Approved." : "Failed."
            ),
            PaymentTestData.UtcNow.AddSeconds(1),
            "gateway"
        );

        var action = () =>
            transaction.ApplyGatewayResult(
                new PaymentGatewayResult(true, "APPROVED", "Approved."),
                PaymentTestData.UtcNow.AddSeconds(2),
                "gateway"
            );

        action.Should().Throw<DomainRuleException>();
    }

    [Fact]
    public void ApplyGatewayResult_WithNonUtcTimestamp_Throws()
    {
        var transaction = PaymentTestData.CreatePremium();
        var local = DateTime.SpecifyKind(DateTime.Now, DateTimeKind.Local);

        var action = () =>
            transaction.ApplyGatewayResult(
                new PaymentGatewayResult(true, "APPROVED", "Approved."),
                local,
                "gateway"
            );

        action.Should().Throw<DomainRuleException>();
    }
}


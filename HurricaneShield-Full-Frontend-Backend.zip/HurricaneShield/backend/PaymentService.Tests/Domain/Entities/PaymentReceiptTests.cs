using PaymentService.Tests.TestSupport;

namespace PaymentService.Tests.Domain.Entities;

public sealed class PaymentReceiptTests
{
    [Fact]
    public void Create_ForSuccessfulTransaction_CreatesImmutableReceiptData()
    {
        var transaction = PaymentTestData.CreateSuccessfulPremium();

        var receipt = PaymentReceipt.Create(
            transaction,
            "RCT-2026-000001",
            PaymentTestData.UtcNow.AddSeconds(2),
            "payment-service"
        );

        receipt.Id.Should().NotBeEmpty();
        receipt.TransactionId.Should().Be(transaction.Id);
        receipt.ReceiptNumber.Should().Be("RCT-2026-000001");
        receipt.GeneratedAt.Should().Be(PaymentTestData.UtcNow.AddSeconds(2));
        receipt.CreatedBy.Should().Be("payment-service");
    }

    [Fact]
    public void Create_ForPendingTransaction_Throws()
    {
        var action = () =>
            PaymentReceipt.Create(
                PaymentTestData.CreatePremium(),
                "RCT-2026-000001",
                PaymentTestData.UtcNow,
                "payment-service"
            );

        action.Should().Throw<DomainRuleException>();
    }

    [Fact]
    public void Create_ForFailedTransaction_Throws()
    {
        var action = () =>
            PaymentReceipt.Create(
                PaymentTestData.CreateFailedPremium(),
                "RCT-2026-000001",
                PaymentTestData.UtcNow.AddSeconds(2),
                "payment-service"
            );

        action.Should().Throw<DomainRuleException>();
    }

    [Fact]
    public void Create_WithoutReceiptNumber_Throws()
    {
        var action = () =>
            PaymentReceipt.Create(
                PaymentTestData.CreateSuccessfulPremium(),
                " ",
                PaymentTestData.UtcNow.AddSeconds(2),
                "payment-service"
            );

        action.Should().Throw<DomainRuleException>();
    }
}


using PaymentService.Tests.TestSupport;

namespace PaymentService.Tests.Domain.Entities;

public sealed class PaymentRetryTests
{
    [Fact]
    public void BeginRetry_FromFailed_ReusesTransactionAndMovesToPending()
    {
        var transaction = PaymentTestData.CreateFailedPremium();
        var transactionId = transaction.Id;
        var retriedAt = PaymentTestData.UtcNow.AddMinutes(1);

        transaction.BeginRetry(retriedAt, "customer-user");

        transaction.Id.Should().Be(transactionId);
        transaction.Status.Should().Be(PaymentStatus.Pending);
        transaction.FailureReason.Should().BeNull();
        transaction.UpdatedAt.Should().Be(retriedAt);
    }

    [Fact]
    public void Retry_CanSucceedAfterPreviousFailure()
    {
        var transaction = PaymentTestData.CreateFailedPremium();
        transaction.BeginRetry(PaymentTestData.UtcNow.AddMinutes(1), "customer-user");

        transaction.ApplyGatewayResult(
            new PaymentGatewayResult(true, "APPROVED", "Payment approved."),
            PaymentTestData.UtcNow.AddMinutes(1).AddSeconds(1),
            "gateway"
        );

        transaction.Status.Should().Be(PaymentStatus.Success);
        transaction.FailureReason.Should().BeNull();
    }

    [Fact]
    public void BeginRetry_FromPending_Throws()
    {
        var transaction = PaymentTestData.CreatePremium();
        var action = () => transaction.BeginRetry(PaymentTestData.UtcNow.AddMinutes(1), "customer");
        action.Should().Throw<DomainRuleException>();
    }

    [Fact]
    public void BeginRetry_FromSuccess_Throws()
    {
        var transaction = PaymentTestData.CreateSuccessfulPremium();
        var action = () => transaction.BeginRetry(PaymentTestData.UtcNow.AddMinutes(1), "customer");
        action.Should().Throw<DomainRuleException>();
    }

    [Fact]
    public void BeginRetry_WithNonUtcTimestamp_Throws()
    {
        var transaction = PaymentTestData.CreateFailedPremium();
        var action = () =>
            transaction.BeginRetry(
                DateTime.SpecifyKind(DateTime.Now, DateTimeKind.Local),
                "customer"
            );
        action.Should().Throw<DomainRuleException>();
    }
}


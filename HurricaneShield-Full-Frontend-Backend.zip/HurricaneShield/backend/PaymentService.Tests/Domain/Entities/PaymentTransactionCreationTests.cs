using PaymentService.Tests.TestSupport;

namespace PaymentService.Tests.Domain.Entities;

public sealed class PaymentTransactionCreationTests
{
    [Fact]
    public void CreatePremium_WithValidInput_CreatesPendingPremiumTransaction()
    {
        var transaction = PaymentTestData.CreatePremium();

        transaction.Id.Should().NotBeEmpty();
        transaction.TransactionNumber.Should().Be("TXN-2026-000001");
        transaction.Type.Should().Be(PaymentType.Premium);
        transaction.Status.Should().Be(PaymentStatus.Pending);
        transaction.AuthUserId.Should().NotBeNull();
        transaction.CustomerId.Should().NotBeNull();
        transaction.PolicyId.Should().NotBeNull();
        transaction.ClaimId.Should().BeNull();
        transaction.Amount.Should().Be(1_250m);
        transaction.FailureReason.Should().BeNull();
        transaction.CreatedAt.Should().Be(PaymentTestData.UtcNow);
        transaction.TransactionDate.Should().Be(PaymentTestData.UtcNow);
    }

    [Fact]
    public void CreateSettlement_WithValidInput_CreatesPendingSettlementTransaction()
    {
        var transaction = PaymentTestData.CreateSettlement();

        transaction.Type.Should().Be(PaymentType.ClaimSettlement);
        transaction.Status.Should().Be(PaymentStatus.Pending);
        transaction.AuthUserId.Should().NotBeNull();
        transaction.CustomerId.Should().NotBeNull();
        transaction.PolicyId.Should().NotBeNull();
        transaction.ClaimId.Should().NotBeNull();
        transaction.Amount.Should().Be(25_000m);
    }

    [Theory]
    [InlineData(0)]
    [InlineData(-1)]
    public void CreatePremium_WithNonPositiveAmount_Throws(decimal amount)
    {
        var action = () =>
            PaymentTransaction.CreatePremium(
                "TXN-2026-000001",
                Guid.NewGuid(),
                Guid.NewGuid(),
                Guid.NewGuid(),
                amount,
                PaymentTestData.UtcNow,
                "customer"
            );

        action.Should().Throw<DomainRuleException>();
    }

    [Theory]
    [InlineData("auth")]
    [InlineData("customer")]
    [InlineData("policy")]
    public void CreatePremium_WithEmptyRequiredIdentifier_Throws(string identifier)
    {
        var auth = Guid.NewGuid();
        var customer = Guid.NewGuid();
        var policy = Guid.NewGuid();
        if (identifier == "auth")
            auth = Guid.Empty;
        if (identifier == "customer")
            customer = Guid.Empty;
        if (identifier == "policy")
            policy = Guid.Empty;

        var action = () =>
            PaymentTransaction.CreatePremium(
                "TXN-2026-000001",
                auth,
                customer,
                policy,
                1m,
                PaymentTestData.UtcNow,
                "customer"
            );

        action.Should().Throw<DomainRuleException>();
    }

    [Theory]
    [InlineData("customer")]
    [InlineData("policy")]
    [InlineData("claim")]
    public void CreateSettlement_WithEmptyRequiredIdentifier_Throws(string identifier)
    {
        var customer = Guid.NewGuid();
        var policy = Guid.NewGuid();
        var claim = Guid.NewGuid();
        if (identifier == "customer")
            customer = Guid.Empty;
        if (identifier == "policy")
            policy = Guid.Empty;
        if (identifier == "claim")
            claim = Guid.Empty;

        var action = () =>
            PaymentTransaction.CreateSettlement(
                "TXN-2026-000002",
                Guid.NewGuid(),
                customer,
                policy,
                claim,
                1m,
                PaymentTestData.UtcNow,
                "claims-service"
            );

        action.Should().Throw<DomainRuleException>();
    }

    [Theory]
    [InlineData("")]
    [InlineData("   ")]
    public void Create_WithMissingTransactionNumber_Throws(string number)
    {
        var action = () =>
            PaymentTransaction.CreatePremium(
                number,
                Guid.NewGuid(),
                Guid.NewGuid(),
                Guid.NewGuid(),
                1m,
                PaymentTestData.UtcNow,
                "customer"
            );

        action.Should().Throw<DomainRuleException>();
    }

    [Fact]
    public void Create_NormalizesTransactionNumberAndActor()
    {
        var transaction = PaymentTransaction.CreatePremium(
            "  TXN-2026-000001  ",
            Guid.NewGuid(),
            Guid.NewGuid(),
            Guid.NewGuid(),
            1m,
            PaymentTestData.UtcNow,
            "  customer  "
        );

        transaction.TransactionNumber.Should().Be("TXN-2026-000001");
        transaction.CreatedBy.Should().Be("customer");
    }

    [Fact]
    public void Create_WithNonUtcTimestamp_Throws()
    {
        var local = DateTime.SpecifyKind(DateTime.Now, DateTimeKind.Local);
        var action = () =>
            PaymentTransaction.CreatePremium(
                "TXN-2026-000001",
                Guid.NewGuid(),
                Guid.NewGuid(),
                Guid.NewGuid(),
                1m,
                local,
                "customer"
            );

        action.Should().Throw<DomainRuleException>();
    }
}


using PaymentService.Tests.TestSupport;

namespace PaymentService.Tests.Domain.Entities;

public sealed class IdempotencyRecordTests
{
    [Theory]
    [InlineData(IdempotencyOperation.PremiumPayment)]
    [InlineData(IdempotencyOperation.ClaimSettlement)]
    public void Create_SetsTwentyFourHourExpiration(IdempotencyOperation operation)
    {
        var resourceId = Guid.NewGuid();
        var record = IdempotencyRecord.Create(
            operation,
            "key",
            "hash",
            200,
            "{}",
            resourceId,
            PaymentTestData.UtcNow
        );

        record.Operation.Should().Be(operation);
        record.ResourceId.Should().Be(resourceId);
        record.ExpiresAt.Should().Be(PaymentTestData.UtcNow.AddHours(24));
    }

    [Fact]
    public void Create_NormalizesTextValues()
    {
        var record = IdempotencyRecord.Create(
            IdempotencyOperation.PremiumPayment,
            " key ",
            " hash ",
            200,
            " {} ",
            null,
            PaymentTestData.UtcNow
        );

        record.Key.Should().Be("key");
        record.RequestHash.Should().Be("hash");
        record.ResponseBody.Should().Be("{}");
    }

    [Theory]
    [InlineData("key")]
    [InlineData("hash")]
    [InlineData("body")]
    public void Create_WithMissingRequiredText_Throws(string field)
    {
        var key = field == "key" ? " " : "key";
        var hash = field == "hash" ? " " : "hash";
        var body = field == "body" ? " " : "{}";

        var action = () =>
            IdempotencyRecord.Create(
                IdempotencyOperation.PremiumPayment,
                key,
                hash,
                200,
                body,
                null,
                PaymentTestData.UtcNow
            );

        action.Should().Throw<DomainRuleException>();
    }
}


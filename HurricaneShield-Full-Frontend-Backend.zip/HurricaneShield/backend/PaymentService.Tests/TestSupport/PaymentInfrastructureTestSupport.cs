namespace PaymentService.Tests.TestSupport;

internal static class PaymentInfrastructureTestSupport
{
    internal static readonly DateTime UtcNow = new(2026, 10, 2, 8, 0, 0, DateTimeKind.Utc);

    internal static PaymentDbContext CreateDb()
    {
        var options = new DbContextOptionsBuilder<PaymentDbContext>()
            .UseInMemoryDatabase($"PaymentTests-{Guid.NewGuid():N}")
            .Options;
        return new PaymentDbContext(options);
    }

    internal static Mock<IRequestContext> Context(Guid userId, params string[] roles)
    {
        var mock = new Mock<IRequestContext>();
        mock.SetupGet(x => x.UserId).Returns(userId);
        mock.SetupGet(x => x.Actor).Returns("test-user");
        mock.SetupGet(x => x.CorrelationId).Returns("corr-test");
        mock.Setup(x => x.IsInRole(It.IsAny<string>()))
            .Returns((string role) => roles.Contains(role));
        return mock;
    }

    internal static Mock<IDateTimeProvider> Clock()
    {
        var mock = new Mock<IDateTimeProvider>();
        mock.SetupGet(x => x.UtcNow).Returns(UtcNow);
        return mock;
    }

    internal static PaymentTransaction SuccessfulPremium(
        Guid authUserId,
        Guid customerId,
        Guid policyId
    )
    {
        var transaction = PaymentTransaction.CreatePremium(
            "TXN-2026-000001",
            authUserId,
            customerId,
            policyId,
            1250m,
            UtcNow,
            "customer"
        );
        transaction.ApplyGatewayResult(
            new PaymentGatewayResult(true, "APPROVED", "Approved."),
            UtcNow.AddSeconds(1),
            "gateway"
        );
        return transaction;
    }
}


namespace PaymentService.Tests.TestSupport;

internal static class PaymentTestData
{
    internal static readonly DateTime UtcNow = new(2026, 10, 2, 8, 0, 0, DateTimeKind.Utc);

    internal static PaymentTransaction CreatePremium(decimal amount = 1_250m) =>
        PaymentTransaction.CreatePremium(
            "TXN-2026-000001",
            Guid.NewGuid(),
            Guid.NewGuid(),
            Guid.NewGuid(),
            amount,
            UtcNow,
            "customer-user"
        );

    internal static PaymentTransaction CreateSettlement(decimal amount = 25_000m) =>
        PaymentTransaction.CreateSettlement(
            "TXN-2026-000002",
            Guid.NewGuid(),
            Guid.NewGuid(),
            Guid.NewGuid(),
            Guid.NewGuid(),
            amount,
            UtcNow,
            "claims-service"
        );

    internal static PaymentTransaction CreateSuccessfulPremium()
    {
        var transaction = CreatePremium();
        transaction.ApplyGatewayResult(
            new PaymentGatewayResult(true, "APPROVED", "Payment approved."),
            UtcNow.AddSeconds(1),
            "payment-gateway"
        );
        return transaction;
    }

    internal static PaymentTransaction CreateFailedPremium()
    {
        var transaction = CreatePremium();
        transaction.ApplyGatewayResult(
            new PaymentGatewayResult(false, "DECLINED", "Simulated payment failure."),
            UtcNow.AddSeconds(1),
            "payment-gateway"
        );
        return transaction;
    }
}


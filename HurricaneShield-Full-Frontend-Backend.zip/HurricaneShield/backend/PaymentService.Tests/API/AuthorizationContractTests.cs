using PaymentService.API.Controllers;
using PaymentService.Application.Authorization;

namespace PaymentService.Tests.API;

public sealed class AuthorizationContractTests
{
    [Fact]
    public void PremiumProcessing_RequiresPremiumPolicy()
    {
        GetPolicy(typeof(PremiumPaymentsController), "Process")
            .Should()
            .Be(PaymentAuthorizationPolicies.ProcessPremium);
    }

    [Fact]
    public void SettlementProcessing_RequiresSettlementPolicy()
    {
        GetPolicy(typeof(ClaimSettlementsController), "Process")
            .Should()
            .Be(PaymentAuthorizationPolicies.ProcessSettlement);
    }

    [Fact]
    public void AdministratorSearch_RequiresAdministratorReadPolicy()
    {
        GetPolicy(typeof(TransactionsController), "Search")
            .Should()
            .Be(PaymentAuthorizationPolicies.AdministratorRead);
    }

    [Fact]
    public void Retry_RequiresRetryPolicy()
    {
        GetPolicy(typeof(TransactionsController), "Retry")
            .Should()
            .Be(PaymentAuthorizationPolicies.Retry);
    }

    [Fact]
    public void InternalValidation_RequiresValidationPolicy()
    {
        GetPolicy(typeof(TransactionsController), "Validate")
            .Should()
            .Be(PaymentAuthorizationPolicies.ValidateTransaction);
    }

    private static string? GetPolicy(Type controller, string method) =>
        controller
            .GetMethod(method)!
            .GetCustomAttributes(typeof(AuthorizeAttribute), true)
            .Cast<AuthorizeAttribute>()
            .Single()
            .Policy;
}


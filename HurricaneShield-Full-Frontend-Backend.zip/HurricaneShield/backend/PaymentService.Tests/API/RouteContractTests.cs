using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Routing;
using PaymentService.API.Controllers;

namespace PaymentService.Tests.API;

public sealed class RouteContractTests
{
    [Theory]
    [InlineData(typeof(PremiumPaymentsController), "premium", "POST")]
    [InlineData(typeof(ClaimSettlementsController), "settlements", "POST")]
    [InlineData(typeof(ClaimSettlementsController), "settlements/{transactionId:guid}", "GET")]
    [InlineData(typeof(TransactionsController), "{transactionId:guid}", "GET")]
    [InlineData(typeof(TransactionsController), "me", "GET")]
    [InlineData(typeof(TransactionsController), "transactions", "GET")]
    [InlineData(typeof(TransactionsController), "{transactionId:guid}/retry", "POST")]
    [InlineData(typeof(TransactionsController), "validate/{transactionId:guid}", "GET")]
    [InlineData(typeof(ReceiptsController), "{transactionId:guid}/receipt", "GET")]
    public void ExpectedRoute_Exists(Type controllerType, string template, string verb)
    {
        var routes = controllerType
            .GetMethods()
            .SelectMany(method => method.GetCustomAttributes(true).OfType<HttpMethodAttribute>())
            .ToArray();

        routes
            .Should()
            .Contain(attribute =>
                attribute.Template == template && attribute.HttpMethods.Contains(verb)
            );
    }

    [Fact]
    public void AllControllers_UseVersionedPaymentBaseRoute()
    {
        var controllers = new[]
        {
            typeof(PremiumPaymentsController),
            typeof(ClaimSettlementsController),
            typeof(TransactionsController),
            typeof(ReceiptsController),
        };

        controllers
            .Should()
            .OnlyContain(type =>
                type.GetCustomAttributes(typeof(RouteAttribute), true)
                    .Cast<RouteAttribute>()
                    .Single()
                    .Template == "api/v1/payments"
            );
    }
}


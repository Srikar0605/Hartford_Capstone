using System.Security.Claims;
using System.Text.Encodings.Web;
using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace PaymentService.Tests.API.TestSupport;

internal sealed class TestAuthenticationHandler : AuthenticationHandler<AuthenticationSchemeOptions>
{
    internal new const string Scheme = "Test";

    public TestAuthenticationHandler(
        IOptionsMonitor<AuthenticationSchemeOptions> options,
        ILoggerFactory logger,
        UrlEncoder encoder
    )
        : base(options, logger, encoder) { }

    protected override Task<AuthenticateResult> HandleAuthenticateAsync()
    {
        var userId =
            Request.Headers["X-Test-User-Id"].FirstOrDefault() ?? Guid.NewGuid().ToString();
        var role = Request.Headers["X-Test-Role"].FirstOrDefault() ?? "Customer";
        var permission = Request.Headers["X-Test-Permission"].FirstOrDefault();

        var claims = new List<Claim>
        {
            new(ClaimTypes.NameIdentifier, userId),
            new("sub", userId),
            new(ClaimTypes.Name, "api-test-user"),
            new(ClaimTypes.Role, role),
        };

        if (!string.IsNullOrWhiteSpace(permission))
            claims.Add(new Claim("permissions", permission));

        var identity = new ClaimsIdentity(claims, Scheme);
        var principal = new ClaimsPrincipal(identity);
        var ticket = new AuthenticationTicket(principal, Scheme);
        return Task.FromResult(AuthenticateResult.Success(ticket));
    }
}


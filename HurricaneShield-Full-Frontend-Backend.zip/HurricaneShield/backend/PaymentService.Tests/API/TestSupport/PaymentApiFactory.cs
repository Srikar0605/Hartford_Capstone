using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Hosting;
using PaymentService.Tests.API.TestSupport;

namespace PaymentService.Tests.API.TestSupport;

public sealed class PaymentApiFactory : WebApplicationFactory<Program>
{
    internal Mock<IPremiumPaymentService> Premiums { get; } = new();
    internal Mock<IClaimSettlementService> Settlements { get; } = new();
    internal Mock<ITransactionService> Transactions { get; } = new();
    internal Mock<IReceiptService> Receipts { get; } = new();

    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseEnvironment("Testing");
        builder.ConfigureTestServices(services =>
        {
            services.RemoveAll<IPremiumPaymentService>();
            services.RemoveAll<IClaimSettlementService>();
            services.RemoveAll<ITransactionService>();
            services.RemoveAll<IReceiptService>();

            services.AddSingleton(Premiums.Object);
            services.AddSingleton(Settlements.Object);
            services.AddSingleton(Transactions.Object);
            services.AddSingleton(Receipts.Object);

            services
                .AddAuthentication(options =>
                {
                    options.DefaultAuthenticateScheme = TestAuthenticationHandler.Scheme;
                    options.DefaultChallengeScheme = TestAuthenticationHandler.Scheme;
                    options.DefaultScheme = TestAuthenticationHandler.Scheme;
                })
                .AddScheme<AuthenticationSchemeOptions, TestAuthenticationHandler>(
                    TestAuthenticationHandler.Scheme,
                    _ => { }
                );
        });
    }

    internal HttpClient CreateAuthenticatedClient(
        string role = "Customer",
        string? permission = null,
        Guid? userId = null
    )
    {
        var client = CreateClient(
            new WebApplicationFactoryClientOptions { AllowAutoRedirect = false }
        );
        client.DefaultRequestHeaders.Add("X-Test-Role", role);
        client.DefaultRequestHeaders.Add("X-Test-User-Id", (userId ?? Guid.NewGuid()).ToString());
        if (!string.IsNullOrWhiteSpace(permission))
            client.DefaultRequestHeaders.Add("X-Test-Permission", permission);
        return client;
    }
}


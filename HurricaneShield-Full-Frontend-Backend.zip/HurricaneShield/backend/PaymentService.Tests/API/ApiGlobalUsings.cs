global using System.Net;
global using System.Net.Http.Json;
global using FluentAssertions;
global using Microsoft.AspNetCore.Authorization;
global using Microsoft.AspNetCore.Mvc.Testing;
global using Microsoft.AspNetCore.TestHost;
global using Microsoft.Extensions.DependencyInjection;
global using Microsoft.Extensions.DependencyInjection.Extensions;
global using Moq;
global using PaymentService.Application.DTOs.Common;
global using PaymentService.Application.DTOs.Premiums;
global using PaymentService.Application.DTOs.Receipts;
global using PaymentService.Application.DTOs.Settlements;
global using PaymentService.Application.DTOs.Transactions;
global using PaymentService.Application.Interfaces;
global using PaymentService.Domain.Enums;
global using Xunit;


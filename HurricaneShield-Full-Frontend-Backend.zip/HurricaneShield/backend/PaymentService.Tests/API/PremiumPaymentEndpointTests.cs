using PaymentService.Tests.API.TestSupport;

namespace PaymentService.Tests.API;

public sealed class PremiumPaymentEndpointTests(PaymentApiFactory factory)
    : IClassFixture<PaymentApiFactory>
{
    [Fact]
    public async Task Process_ForwardsIdempotencyKeyAndReturnsSuccessEnvelope()
    {
        var policyId = Guid.NewGuid();
        var response = new PremiumPaymentResponse(
            Guid.NewGuid(),
            "TXN-2026-000001",
            policyId,
            1250m,
            PaymentStatus.Success,
            null,
            "RCT-2026-000001",
            DateTime.UtcNow,
            Convert.ToBase64String(new byte[8])
        );
        factory
            .Premiums.Setup(x =>
                x.ProcessAsync(
                    It.IsAny<ProcessPremiumPaymentRequest>(),
                    "premium-key",
                    It.IsAny<CancellationToken>()
                )
            )
            .ReturnsAsync(response);

        using var client = factory.CreateAuthenticatedClient("Customer");
        client.DefaultRequestHeaders.Add("X-Idempotency-Key", "premium-key");
        var result = await client.PostAsJsonAsync(
            "/api/v1/payments/premium",
            new ProcessPremiumPaymentRequest(policyId, 1250m)
        );

        result.StatusCode.Should().Be(HttpStatusCode.OK);
        var json = await result.Content.ReadAsStringAsync();
        json.Should().Contain("\"success\":true");
        json.Should().Contain("TXN-2026-000001");
        factory.Premiums.VerifyAll();
    }

    [Fact]
    public async Task Process_InvalidRequest_ReturnsValidationErrorBeforeService()
    {
        using var client = factory.CreateAuthenticatedClient("Customer");
        client.DefaultRequestHeaders.Add("X-Idempotency-Key", "key");

        var result = await client.PostAsJsonAsync(
            "/api/v1/payments/premium",
            new ProcessPremiumPaymentRequest(Guid.Empty, 0m)
        );

        result.StatusCode.Should().Be(HttpStatusCode.BadRequest);
        factory.Premiums.Verify(
            x =>
                x.ProcessAsync(
                    It.IsAny<ProcessPremiumPaymentRequest>(),
                    It.IsAny<string>(),
                    It.IsAny<CancellationToken>()
                ),
            Times.Never
        );
    }
}


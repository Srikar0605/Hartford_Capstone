using Microsoft.AspNetCore.Http;
using PaymentService.API.Middleware;
using PaymentService.Domain.Exceptions;
using PaymentService.Infrastructure.Exceptions;

namespace PaymentService.Tests.API;

public sealed class MiddlewareContractTests
{
    [Fact]
    public async Task DomainRuleException_MapsToPaymentInvalidState()
    {
        var middleware = new PaymentDomainExceptionMiddleware(_ =>
            throw new DomainRuleException("Invalid payment transition.")
        );
        var context = new DefaultHttpContext();
        context.Response.Body = new MemoryStream();

        await middleware.InvokeAsync(context);

        context.Response.StatusCode.Should().Be(409);
        context.Response.Body.Position = 0;
        using var reader = new StreamReader(context.Response.Body);
        (await reader.ReadToEndAsync()).Should().Contain("PAYMENT_INVALID_STATE");
    }

    [Fact]
    public async Task PaymentServiceException_PreservesStatusAndCode()
    {
        var middleware = new PaymentServiceExceptionMiddleware(_ =>
            throw PaymentServiceException.Unprocessable(
                "PAYMENT_AMOUNT_MISMATCH",
                "Amount mismatch."
            )
        );
        var context = new DefaultHttpContext();
        context.Response.Body = new MemoryStream();

        await middleware.InvokeAsync(context);

        context.Response.StatusCode.Should().Be(422);
        context.Response.Body.Position = 0;
        using var reader = new StreamReader(context.Response.Body);
        (await reader.ReadToEndAsync()).Should().Contain("PAYMENT_AMOUNT_MISMATCH");
    }
}


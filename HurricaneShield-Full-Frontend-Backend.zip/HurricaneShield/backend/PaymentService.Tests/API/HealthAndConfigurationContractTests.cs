using Microsoft.Extensions.Configuration;
using PaymentService.Tests.API.TestSupport;

namespace PaymentService.Tests.API;

public sealed class HealthAndConfigurationContractTests(PaymentApiFactory factory)
    : IClassFixture<PaymentApiFactory>
{
    [Fact]
    public void ApiProject_UsesAuthServiceJwtValues()
    {
        using var scope = factory.Services.CreateScope();
        var configuration = scope.ServiceProvider.GetRequiredService<IConfiguration>();
        configuration["Jwt:Issuer"].Should().Be("HurricaneShield.AuthService");
        configuration["Jwt:Audience"].Should().Be("HurricaneShield.Platform");
    }

    [Fact]
    public void ApiProject_ConfiguresPolicyAndClaimsDirectServiceUrls()
    {
        using var scope = factory.Services.CreateScope();
        var configuration = scope.ServiceProvider.GetRequiredService<IConfiguration>();
        configuration["Services:Policy:BaseUrl"].Should().NotBeNullOrWhiteSpace();
        configuration["Services:Claims:BaseUrl"].Should().NotBeNullOrWhiteSpace();
    }
}


using PaymentService.Tests.API.TestSupport;

namespace PaymentService.Tests.API;

public sealed class ClaimSettlementEndpointTests(PaymentApiFactory factory)
    : IClassFixture<PaymentApiFactory>
{
    [Fact]
    public async Task Process_ClaimsManager_ForwardsCorrectAuthoritativeRouteAndKey()
    {
        var claimId = Guid.NewGuid();
        var request = new ProcessClaimSettlementRequest(
            claimId,
            Guid.NewGuid(),
            Guid.NewGuid(),
            25000m
        );
        factory
            .Settlements.Setup(x =>
                x.ProcessAsync(request, "settlement-key", It.IsAny<CancellationToken>())
            )
            .ReturnsAsync(
                new ClaimSettlementResponse(
                    Guid.NewGuid(),
                    "TXN-2026-000002",
                    claimId,
                    25000m,
                    PaymentStatus.Success,
                    null,
                    "RCT-2026-000002",
                    DateTime.UtcNow,
                    Convert.ToBase64String(new byte[8])
                )
            );

        using var client = factory.CreateAuthenticatedClient("Claims Manager");
        client.DefaultRequestHeaders.Add("X-Idempotency-Key", "settlement-key");
        var result = await client.PostAsJsonAsync("/api/v1/payments/settlements", request);

        result.StatusCode.Should().Be(HttpStatusCode.OK);
        factory.Settlements.VerifyAll();
    }

    [Fact]
    public async Task Process_CustomerWithoutPermission_IsForbidden()
    {
        using var client = factory.CreateAuthenticatedClient("Customer");
        client.DefaultRequestHeaders.Add("X-Idempotency-Key", "key");

        var result = await client.PostAsJsonAsync(
            "/api/v1/payments/settlements",
            new ProcessClaimSettlementRequest(Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid(), 1m)
        );

        result.StatusCode.Should().Be(HttpStatusCode.Forbidden);
    }
}


using PaymentService.Tests.API.TestSupport;

namespace PaymentService.Tests.API;

public sealed class TransactionAndReceiptEndpointTests(PaymentApiFactory factory)
    : IClassFixture<PaymentApiFactory>
{
    [Fact]
    public async Task MyTransactions_Customer_ReturnsPagedResult()
    {
        factory
            .Transactions.Setup(x =>
                x.GetMyTransactionsAsync(
                    It.IsAny<TransactionSearchRequest>(),
                    It.IsAny<CancellationToken>()
                )
            )
            .ReturnsAsync(
                new PagedResponse<TransactionSummaryResponse>(
                    Array.Empty<TransactionSummaryResponse>(),
                    1,
                    20,
                    0
                )
            );

        using var client = factory.CreateAuthenticatedClient("Customer");
        var result = await client.GetAsync("/api/v1/payments/me");

        result.StatusCode.Should().Be(HttpStatusCode.OK);
    }

    [Fact]
    public async Task AdministratorSearch_Customer_IsForbidden()
    {
        using var client = factory.CreateAuthenticatedClient("Customer");
        var result = await client.GetAsync("/api/v1/payments/transactions");
        result.StatusCode.Should().Be(HttpStatusCode.Forbidden);
    }

    [Fact]
    public async Task Receipt_OwnerRoute_ReturnsReceiptEnvelope()
    {
        var transactionId = Guid.NewGuid();
        factory
            .Receipts.Setup(x =>
                x.GetByTransactionAsync(transactionId, It.IsAny<CancellationToken>())
            )
            .ReturnsAsync(
                new PaymentReceiptResponse(
                    Guid.NewGuid(),
                    transactionId,
                    "TXN-2026-000001",
                    "RCT-2026-000001",
                    1250m,
                    DateTime.UtcNow,
                    "payment-service"
                )
            );

        using var client = factory.CreateAuthenticatedClient("Customer");
        var result = await client.GetAsync($"/api/v1/payments/{transactionId}/receipt");

        result.StatusCode.Should().Be(HttpStatusCode.OK);
        (await result.Content.ReadAsStringAsync()).Should().Contain("RCT-2026-000001");
    }

    [Fact]
    public async Task Retry_RoutesPremiumToPremiumService()
    {
        var transactionId = Guid.NewGuid();
        var rowVersion = Convert.ToBase64String(new byte[8]);
        factory
            .Transactions.Setup(x => x.ValidateAsync(transactionId, It.IsAny<CancellationToken>()))
            .ReturnsAsync(
                new TransactionValidationResponse(
                    transactionId,
                    "TXN-1",
                    PaymentType.Premium,
                    PaymentStatus.Failed,
                    100m,
                    Guid.NewGuid(),
                    null,
                    false
                )
            );
        factory
            .Premiums.Setup(x =>
                x.RetryAsync(
                    transactionId,
                    It.Is<RetryPaymentRequest>(r => r.RowVersion == rowVersion),
                    It.IsAny<CancellationToken>()
                )
            )
            .ReturnsAsync(
                new TransactionDetailsResponse(
                    transactionId,
                    "TXN-1",
                    PaymentType.Premium,
                    Guid.NewGuid(),
                    Guid.NewGuid(),
                    null,
                    100m,
                    PaymentStatus.Success,
                    null,
                    DateTime.UtcNow,
                    Array.Empty<PaymentAttemptResponse>(),
                    "RCT-1",
                    rowVersion
                )
            );

        using var client = factory.CreateAuthenticatedClient("Customer");
        var result = await client.PostAsJsonAsync(
            $"/api/v1/payments/{transactionId}/retry",
            new RetryPaymentRequest(false, rowVersion)
        );

        result.StatusCode.Should().Be(HttpStatusCode.OK);
        factory.Premiums.VerifyAll();
    }
}


global using FluentAssertions;
global using FluentValidation;
global using FluentValidation.TestHelper;
global using PaymentService.Application.Authorization;
global using PaymentService.Application.DTOs.Common;
global using PaymentService.Application.DTOs.Integrations;
global using PaymentService.Application.DTOs.Premiums;
global using PaymentService.Application.DTOs.Receipts;
global using PaymentService.Application.DTOs.Settlements;
global using PaymentService.Application.DTOs.Transactions;
global using PaymentService.Application.Interfaces;
global using PaymentService.Application.Validation;
global using PaymentService.Domain.Enums;
global using PaymentService.Domain.Models;
global using Xunit;


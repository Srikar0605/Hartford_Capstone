namespace PaymentService.Tests.Application.Authorization;

public sealed class AuthorizationConstantsTests
{
    [Fact]
    public void Roles_MatchFrozenPlatformRoles()
    {
        PaymentRoles.Customer.Should().Be("Customer");
        PaymentRoles.ClaimsManager.Should().Be("Claims Manager");
        PaymentRoles.Administrator.Should().Be("Administrator");
    }

    [Fact]
    public void Permissions_AreUniqueAndNonEmpty()
    {
        var values = typeof(PaymentPermissions)
            .GetFields(
                System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Static
            )
            .Select(field => field.GetRawConstantValue()?.ToString())
            .ToArray();

        values.Should().NotContainNulls();
        values.Should().OnlyHaveUniqueItems();
        values.Should().HaveCount(5);
    }

    [Fact]
    public void Policies_AreUniqueAndPaymentScoped()
    {
        var values = typeof(PaymentAuthorizationPolicies)
            .GetFields(
                System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Static
            )
            .Select(field => field.GetRawConstantValue()?.ToString())
            .Where(value => value is not null)
            .Cast<string>()
            .ToArray();

        values.Should().OnlyHaveUniqueItems();
        values.Should().HaveCount(6);
        values
            .Should()
            .OnlyContain(value => value.StartsWith("Payments.", StringComparison.Ordinal));
    }

    [Fact]
    public void PremiumAndSettlementPermissions_AreSeparate()
    {
        PaymentPermissions.ProcessPremium.Should().NotBe(PaymentPermissions.ProcessSettlement);
        PaymentAuthorizationPolicies
            .ProcessPremium.Should()
            .NotBe(PaymentAuthorizationPolicies.ProcessSettlement);
    }
}


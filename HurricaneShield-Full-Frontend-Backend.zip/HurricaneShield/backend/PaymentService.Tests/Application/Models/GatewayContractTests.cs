namespace PaymentService.Tests.Application.Models;

public sealed class GatewayContractTests
{
    [Fact]
    public void GatewayRequest_ContainsOnlySafeProcessingFields()
    {
        var propertyNames = typeof(PaymentGatewayRequest)
            .GetProperties()
            .Select(property => property.Name)
            .ToArray();

        propertyNames.Should().BeEquivalentTo("TransactionId", "Type", "Amount", "SimulateFailure");
    }

    [Fact]
    public void GatewayResult_ContainsDeterministicOutcomeFields()
    {
        var result = new PaymentGatewayResult(
            false,
            "SIMULATED_FAILURE",
            "Simulated payment failure."
        );
        result.Successful.Should().BeFalse();
        result.ResponseCode.Should().Be("SIMULATED_FAILURE");
        result.ResponseMessage.Should().Be("Simulated payment failure.");
    }
}


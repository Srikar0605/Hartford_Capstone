namespace PaymentService.Tests.Application.Validation;

public sealed class RetryAndSearchValidatorTests
{
    private readonly RetryPaymentRequestValidator retry = new();
    private readonly TransactionSearchRequestValidator search = new();

    [Fact]
    public void EightByteRowVersion_Passes()
    {
        retry
            .TestValidate(new RetryPaymentRequest(false, Convert.ToBase64String(new byte[8])))
            .ShouldNotHaveAnyValidationErrors();
    }

    [Theory]
    [InlineData("")]
    [InlineData("not-base64")]
    public void MissingOrMalformedRowVersion_Fails(string value)
    {
        retry
            .TestValidate(new RetryPaymentRequest(false, value))
            .ShouldHaveValidationErrorFor(request => request.RowVersion);
    }

    [Theory]
    [InlineData(7)]
    [InlineData(9)]
    public void IncorrectRowVersionLength_Fails(int length)
    {
        retry
            .TestValidate(new RetryPaymentRequest(false, Convert.ToBase64String(new byte[length])))
            .ShouldHaveValidationErrorFor(request => request.RowVersion);
    }

    [Theory]
    [InlineData(0, 20)]
    [InlineData(1, 0)]
    [InlineData(1, 101)]
    public void InvalidPagination_Fails(int page, int pageSize)
    {
        search
            .TestValidate(new TransactionSearchRequest(page, pageSize))
            .IsValid.Should()
            .BeFalse();
    }

    [Fact]
    public void ReversedDateRange_Fails()
    {
        search
            .TestValidate(
                new TransactionSearchRequest(
                    1,
                    20,
                    From: new DateTime(2026, 10, 2, 0, 0, 0, DateTimeKind.Utc),
                    To: new DateTime(2026, 10, 1, 0, 0, 0, DateTimeKind.Utc)
                )
            )
            .IsValid.Should()
            .BeFalse();
    }

    [Fact]
    public void ValidSearch_Passes()
    {
        search
            .TestValidate(
                new TransactionSearchRequest(1, 20, PaymentType.Premium, PaymentStatus.Success)
            )
            .ShouldNotHaveAnyValidationErrors();
    }
}


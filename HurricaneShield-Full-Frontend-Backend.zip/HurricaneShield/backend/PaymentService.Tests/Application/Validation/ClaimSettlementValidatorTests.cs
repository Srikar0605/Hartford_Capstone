namespace PaymentService.Tests.Application.Validation;

public sealed class ClaimSettlementValidatorTests
{
    private readonly ProcessClaimSettlementRequestValidator validator = new();

    [Fact]
    public void ValidSettlementRequest_Passes()
    {
        validator
            .TestValidate(
                new ProcessClaimSettlementRequest(
                    Guid.NewGuid(),
                    Guid.NewGuid(),
                    Guid.NewGuid(),
                    25_000m,
                    false
                )
            )
            .ShouldNotHaveAnyValidationErrors();
    }

    [Theory]
    [InlineData("claim")]
    [InlineData("customer")]
    [InlineData("policy")]
    public void EmptyRequiredIdentifier_Fails(string field)
    {
        var claim = Guid.NewGuid();
        var customer = Guid.NewGuid();
        var policy = Guid.NewGuid();
        if (field == "claim")
            claim = Guid.Empty;
        if (field == "customer")
            customer = Guid.Empty;
        if (field == "policy")
            policy = Guid.Empty;

        validator
            .TestValidate(new ProcessClaimSettlementRequest(claim, customer, policy, 1m, false))
            .IsValid.Should()
            .BeFalse();
    }

    [Theory]
    [InlineData(0)]
    [InlineData(-100)]
    public void NonPositiveAmount_Fails(decimal amount)
    {
        validator
            .TestValidate(
                new ProcessClaimSettlementRequest(
                    Guid.NewGuid(),
                    Guid.NewGuid(),
                    Guid.NewGuid(),
                    amount,
                    false
                )
            )
            .ShouldHaveValidationErrorFor(request => request.Amount);
    }
}


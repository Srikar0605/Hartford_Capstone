namespace PaymentService.Tests.Application.Validation;

public sealed class PremiumPaymentValidatorTests
{
    private readonly ProcessPremiumPaymentRequestValidator validator = new();

    [Fact]
    public void ValidPremiumRequest_Passes()
    {
        validator
            .TestValidate(new ProcessPremiumPaymentRequest(Guid.NewGuid(), 1_250m, false))
            .ShouldNotHaveAnyValidationErrors();
    }

    [Fact]
    public void EmptyPolicyId_Fails()
    {
        validator
            .TestValidate(new ProcessPremiumPaymentRequest(Guid.Empty, 1m, false))
            .ShouldHaveValidationErrorFor(request => request.PolicyId);
    }

    [Theory]
    [InlineData(0)]
    [InlineData(-1)]
    public void NonPositiveAmount_Fails(decimal amount)
    {
        validator
            .TestValidate(new ProcessPremiumPaymentRequest(Guid.NewGuid(), amount, false))
            .ShouldHaveValidationErrorFor(request => request.Amount);
    }

    [Fact]
    public void SimulatedFailureFlag_DoesNotInvalidateApplicationContract()
    {
        validator
            .TestValidate(new ProcessPremiumPaymentRequest(Guid.NewGuid(), 1m, true))
            .ShouldNotHaveAnyValidationErrors();
    }
}


using Microsoft.Extensions.DependencyInjection;
using PaymentService.Application;

namespace PaymentService.Tests.Application;

public sealed class DependencyInjectionTests
{
    [Fact]
    public void AddPaymentApplication_RegistersAllValidators()
    {
        var services = new ServiceCollection();
        services.AddPaymentApplication();
        using var provider = services.BuildServiceProvider();

        provider.GetService<IValidator<ProcessPremiumPaymentRequest>>().Should().NotBeNull();
        provider.GetService<IValidator<ProcessClaimSettlementRequest>>().Should().NotBeNull();
        provider.GetService<IValidator<RetryPaymentRequest>>().Should().NotBeNull();
        provider.GetService<IValidator<TransactionSearchRequest>>().Should().NotBeNull();
    }

    [Fact]
    public void AddPaymentApplication_DoesNotRegisterInfrastructureServices()
    {
        var services = new ServiceCollection();
        services.AddPaymentApplication();
        using var provider = services.BuildServiceProvider();

        provider.GetService<IPremiumPaymentService>().Should().BeNull();
        provider.GetService<IClaimSettlementService>().Should().BeNull();
        provider.GetService<ITransactionService>().Should().BeNull();
        provider.GetService<IReceiptService>().Should().BeNull();
        provider.GetService<IPaymentGateway>().Should().BeNull();
    }
}


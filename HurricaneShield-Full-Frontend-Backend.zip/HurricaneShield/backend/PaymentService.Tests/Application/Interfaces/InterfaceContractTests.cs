namespace PaymentService.Tests.Application.Interfaces;

public sealed class InterfaceContractTests
{
    [Theory]
    [InlineData(typeof(IPremiumPaymentService), 2)]
    [InlineData(typeof(IClaimSettlementService), 3)]
    [InlineData(typeof(ITransactionService), 4)]
    [InlineData(typeof(IReceiptService), 1)]
    public void PrimaryServiceInterfaces_HaveExpectedOperationCounts(Type type, int expected)
    {
        type.IsInterface.Should().BeTrue();
        type.GetMethods().Should().HaveCount(expected);
    }

    [Fact]
    public void PremiumAndSettlementProcessing_RequireIdempotencyKeys()
    {
        var premium = typeof(IPremiumPaymentService).GetMethod(
            nameof(IPremiumPaymentService.ProcessAsync)
        );
        var settlement = typeof(IClaimSettlementService).GetMethod(
            nameof(IClaimSettlementService.ProcessAsync)
        );

        premium!
            .GetParameters()
            .Should()
            .Contain(parameter =>
                parameter.Name == "idempotencyKey" && parameter.ParameterType == typeof(string)
            );
        settlement!
            .GetParameters()
            .Should()
            .Contain(parameter =>
                parameter.Name == "idempotencyKey" && parameter.ParameterType == typeof(string)
            );
    }

    [Fact]
    public void ExternalClients_PropagateCancellationTokens()
    {
        foreach (
            var type in new[]
            {
                typeof(IPolicyClient),
                typeof(IClaimsClient),
                typeof(IPaymentGateway),
            }
        )
        {
            type.GetMethods()
                .Should()
                .OnlyContain(method =>
                    method
                        .GetParameters()
                        .Any(parameter => parameter.ParameterType == typeof(CancellationToken))
                );
        }
    }

    [Fact]
    public void PolicyClient_ProvidesValidationAndConfirmation()
    {
        typeof(IPolicyClient)
            .GetMethod(nameof(IPolicyClient.ValidatePremiumAsync))
            .Should()
            .NotBeNull();
        typeof(IPolicyClient)
            .GetMethod(nameof(IPolicyClient.ConfirmPaymentAsync))
            .Should()
            .NotBeNull();
    }

    [Fact]
    public void ClaimsClient_ProvidesValidationAndConfirmation()
    {
        typeof(IClaimsClient)
            .GetMethod(nameof(IClaimsClient.ValidateSettlementAsync))
            .Should()
            .NotBeNull();
        typeof(IClaimsClient)
            .GetMethod(nameof(IClaimsClient.ConfirmSettlementAsync))
            .Should()
            .NotBeNull();
    }

    [Fact]
    public void NumberGenerators_AreSeparateAbstractions()
    {
        typeof(ITransactionNumberGenerator)
            .GetMethod("Generate")!
            .ReturnType.Should()
            .Be(typeof(string));
        typeof(IReceiptNumberGenerator)
            .GetMethod("Generate")!
            .ReturnType.Should()
            .Be(typeof(string));
    }

    [Fact]
    public void RequestContext_ExposesIdentityActorCorrelationAndAuthorization()
    {
        var properties = typeof(IRequestContext).GetProperties().Select(property => property.Name);
        properties.Should().Contain(new[] { "UserId", "Actor", "CorrelationId" });
        typeof(IRequestContext).GetMethod("IsInRole").Should().NotBeNull();
        typeof(IRequestContext).GetMethod("HasPermission").Should().NotBeNull();
    }
}


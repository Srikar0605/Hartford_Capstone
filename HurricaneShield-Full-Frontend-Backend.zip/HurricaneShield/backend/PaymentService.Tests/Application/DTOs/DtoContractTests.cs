namespace PaymentService.Tests.Application.DTOs;

public sealed class DtoContractTests
{
    [Fact]
    public void PagedResponse_CalculatesTotalPages()
    {
        var response = new PagedResponse<string>(new[] { "one" }, 2, 20, 41);
        response.TotalPages.Should().Be(3);
    }

    [Fact]
    public void EmptyPagedResponse_HasZeroTotalPages()
    {
        new PagedResponse<string>(Array.Empty<string>(), 1, 20, 0).TotalPages.Should().Be(0);
    }

    [Fact]
    public void PremiumRequest_DoesNotAcceptTrustedIdentityFields()
    {
        typeof(ProcessPremiumPaymentRequest).GetProperty("AuthUserId").Should().BeNull();
        typeof(ProcessPremiumPaymentRequest).GetProperty("CustomerId").Should().BeNull();
        typeof(ProcessPremiumPaymentRequest).GetProperty("PolicyId").Should().NotBeNull();
        typeof(ProcessPremiumPaymentRequest).GetProperty("Amount").Should().NotBeNull();
    }

    [Fact]
    public void ProcessingRequests_ExposeDevelopmentFailureFlag()
    {
        typeof(ProcessPremiumPaymentRequest)
            .GetProperty("SimulateFailure")!
            .PropertyType.Should()
            .Be(typeof(bool));
        typeof(ProcessClaimSettlementRequest)
            .GetProperty("SimulateFailure")!
            .PropertyType.Should()
            .Be(typeof(bool));
    }

    [Fact]
    public void PaymentRequests_DoNotContainCredentialFields()
    {
        var requestTypes = new[]
        {
            typeof(ProcessPremiumPaymentRequest),
            typeof(ProcessClaimSettlementRequest),
        };
        var prohibited = new[]
        {
            "CardNumber",
            "Cvv",
            "ExpiryDate",
            "UpiPin",
            "BankPassword",
            "Otp",
        };

        foreach (var type in requestTypes)
        {
            foreach (var property in prohibited)
                type.GetProperty(property)
                    .Should()
                    .BeNull($"{type.Name} must not accept payment credentials");
        }
    }

    [Fact]
    public void RetryRequest_ContainsConcurrencyToken()
    {
        typeof(RetryPaymentRequest).GetProperty("RowVersion").Should().NotBeNull();
    }

    [Fact]
    public void TransactionDetails_ContainsAttemptsAndReceipt()
    {
        typeof(TransactionDetailsResponse).GetProperty("Attempts").Should().NotBeNull();
        typeof(TransactionDetailsResponse).GetProperty("ReceiptNumber").Should().NotBeNull();
        typeof(TransactionDetailsResponse).GetProperty("RowVersion").Should().NotBeNull();
    }

    [Fact]
    public void IntegrationConfirmationContracts_MatchDownstreamServices()
    {
        var policyConfirmationType = typeof(PolicyPaymentConfirmationRequest);

        policyConfirmationType
            .GetProperty(nameof(PolicyPaymentConfirmationRequest.TransactionId))
            .Should()
            .NotBeNull();

        policyConfirmationType
            .GetProperty(nameof(PolicyPaymentConfirmationRequest.Amount))
            .Should()
            .NotBeNull();

        policyConfirmationType
            .GetProperty(nameof(PolicyPaymentConfirmationRequest.ProcessedAt))
            .Should()
            .NotBeNull();

        policyConfirmationType
            .GetProperty(nameof(PolicyPaymentConfirmationRequest.RowVersion))
            .Should()
            .NotBeNull();

        var settlementConfirmationType = typeof(ClaimSettlementConfirmationRequest);

        settlementConfirmationType
            .GetProperty(nameof(ClaimSettlementConfirmationRequest.Successful))
            .Should()
            .NotBeNull();

        settlementConfirmationType
            .GetProperty(nameof(ClaimSettlementConfirmationRequest.FailureReason))
            .Should()
            .NotBeNull();
    }
}


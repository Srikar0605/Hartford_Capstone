using Microsoft.EntityFrameworkCore.Metadata;
using PaymentService.Tests.TestSupport;

namespace PaymentService.Tests.Infrastructure.Persistence;

public sealed class PaymentDbContextModelTests
{
    [Fact]
    public void Model_ContainsOnlyFivePaymentOwnedTables()
    {
        using var db = PaymentInfrastructureTestSupport.CreateDb();
        db.Model.GetEntityTypes()
            .Select(x => x.GetTableName())
            .Should()
            .BeEquivalentTo(
                "Transactions",
                "PaymentRequests",
                "PaymentResponses",
                "PaymentReceipts",
                "IdempotencyRecords"
            );
    }

    [Fact]
    public void Transaction_HasRowVersionAndSoftDeleteFilter()
    {
        using var db = PaymentInfrastructureTestSupport.CreateDb();
        var entity = db.Model.FindEntityType(typeof(PaymentTransaction))!;
        entity
            .FindProperty(nameof(PaymentTransaction.RowVersion))!
            .IsConcurrencyToken.Should()
            .BeTrue();
        entity.GetQueryFilter().Should().NotBeNull();
    }

    [Fact]
    public void TransactionNumber_IsUnique()
    {
        using var db = PaymentInfrastructureTestSupport.CreateDb();
        var entity = db.Model.FindEntityType(typeof(PaymentTransaction))!;
        entity
            .GetIndexes()
            .Should()
            .Contain(index =>
                index.IsUnique
                && index
                    .Properties.Select(p => p.Name)
                    .SequenceEqual(new[] { nameof(PaymentTransaction.TransactionNumber) })
            );
    }

    [Fact]
    public void ReceiptNumberAndTransactionId_AreUnique()
    {
        using var db = PaymentInfrastructureTestSupport.CreateDb();
        var entity = db.Model.FindEntityType(typeof(PaymentReceipt))!;
        entity
            .GetIndexes()
            .Should()
            .Contain(index =>
                index.IsUnique
                && index.Properties.Single().Name == nameof(PaymentReceipt.ReceiptNumber)
            );
        entity
            .GetIndexes()
            .Should()
            .Contain(index =>
                index.IsUnique
                && index.Properties.Single().Name == nameof(PaymentReceipt.TransactionId)
            );
    }

    [Fact]
    public void ResponseRequestId_IsUnique()
    {
        using var db = PaymentInfrastructureTestSupport.CreateDb();
        var entity = db.Model.FindEntityType(typeof(PaymentResponse))!;
        entity
            .GetIndexes()
            .Should()
            .Contain(index =>
                index.IsUnique
                && index.Properties.Single().Name == nameof(PaymentResponse.RequestId)
            );
    }

    [Fact]
    public void IdempotencyOperationAndKey_AreUnique()
    {
        using var db = PaymentInfrastructureTestSupport.CreateDb();
        var entity = db.Model.FindEntityType(typeof(IdempotencyRecord))!;
        entity
            .GetIndexes()
            .Should()
            .Contain(index =>
                index.IsUnique
                && index
                    .Properties.Select(p => p.Name)
                    .SequenceEqual(
                        new[] { nameof(IdempotencyRecord.Operation), nameof(IdempotencyRecord.Key) }
                    )
            );
    }

    [Fact]
    public void ExternalReferences_HaveNoForeignKeys()
    {
        using var db = PaymentInfrastructureTestSupport.CreateDb();
        db.Model.FindEntityType(typeof(PaymentTransaction))!.GetForeignKeys().Should().BeEmpty();
    }

    [Fact]
    public void AllLocalForeignKeys_UseRestrictDelete()
    {
        using var db = PaymentInfrastructureTestSupport.CreateDb();
        db.Model.GetEntityTypes()
            .SelectMany(x => x.GetForeignKeys())
            .Should()
            .OnlyContain(x => x.DeleteBehavior == DeleteBehavior.Restrict);
    }
}


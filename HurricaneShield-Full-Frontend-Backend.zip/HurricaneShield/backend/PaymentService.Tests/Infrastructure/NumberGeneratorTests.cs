using PaymentService.Infrastructure.Services;

namespace PaymentService.Tests.Infrastructure;

public sealed class NumberGeneratorTests
{
    [Fact]
    public void TransactionNumber_MatchesFrozenFormat()
    {
        new TransactionNumberGenerator()
            .Generate(new DateTime(2026, 1, 1, 0, 0, 0, DateTimeKind.Utc))
            .Should()
            .MatchRegex("^TXN-2026-[0-9]{6}$");
    }

    [Fact]
    public void ReceiptNumber_MatchesFrozenFormat()
    {
        new ReceiptNumberGenerator()
            .Generate(new DateTime(2026, 1, 1, 0, 0, 0, DateTimeKind.Utc))
            .Should()
            .MatchRegex("^RCT-2026-[0-9]{6}$");
    }
}


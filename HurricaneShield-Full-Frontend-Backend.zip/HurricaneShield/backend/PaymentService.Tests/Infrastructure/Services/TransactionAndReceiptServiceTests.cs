using PaymentService.Tests.TestSupport;

namespace PaymentService.Tests.Infrastructure.Services;

public sealed class TransactionAndReceiptServiceTests
{
    [Fact]
    public async Task GetMyTransactions_ReturnsOnlyCallerOwnedPremiumTransactions()
    {
        await using var db = PaymentInfrastructureTestSupport.CreateDb();
        var owner = Guid.NewGuid();
        db.Transactions.Add(
            PaymentTransaction.CreatePremium(
                "TXN-2026-000001",
                owner,
                Guid.NewGuid(),
                Guid.NewGuid(),
                100m,
                PaymentInfrastructureTestSupport.UtcNow,
                "owner"
            )
        );
        db.Transactions.Add(
            PaymentTransaction.CreatePremium(
                "TXN-2026-000002",
                Guid.NewGuid(),
                Guid.NewGuid(),
                Guid.NewGuid(),
                200m,
                PaymentInfrastructureTestSupport.UtcNow.AddSeconds(1),
                "other"
            )
        );
        await db.SaveChangesAsync();
        var service = new TransactionService(
            db,
            PaymentInfrastructureTestSupport.Context(owner).Object
        );

        var result = await service.GetMyTransactionsAsync(new TransactionSearchRequest(), default);

        result.Items.Should().ContainSingle();
        result.Items.Single().TransactionNumber.Should().Be("TXN-2026-000001");
    }

    [Fact]
    public async Task Receipt_OtherCustomer_IsConcealedAsNotFound()
    {
        await using var db = PaymentInfrastructureTestSupport.CreateDb();
        var tx = PaymentInfrastructureTestSupport.SuccessfulPremium(
            Guid.NewGuid(),
            Guid.NewGuid(),
            Guid.NewGuid()
        );
        db.Transactions.Add(tx);
        db.PaymentReceipts.Add(
            PaymentReceipt.Create(
                tx,
                "RCT-2026-000001",
                PaymentInfrastructureTestSupport.UtcNow.AddSeconds(2),
                "payment-service"
            )
        );
        await db.SaveChangesAsync();
        var service = new ReceiptService(
            db,
            PaymentInfrastructureTestSupport.Context(Guid.NewGuid()).Object
        );

        await service
            .Invoking(x => x.GetByTransactionAsync(tx.Id, default))
            .Should()
            .ThrowAsync<PaymentServiceException>()
            .Where(x => x.StatusCode == 404);
    }
}


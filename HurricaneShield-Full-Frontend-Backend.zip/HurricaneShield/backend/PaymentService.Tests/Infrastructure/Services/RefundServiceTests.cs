using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Moq;
using PaymentService.Application.DTOs.Requests;
using PaymentService.Domain.Entities;
using PaymentService.Domain.Enums;
using PaymentService.Domain.Models;
using PaymentService.Infrastructure.Exceptions;
using PaymentService.Infrastructure.Gateway;
using PaymentService.Infrastructure.Persistence;
using PaymentService.Infrastructure.Services;
using Xunit;

namespace PaymentService.Tests.Infrastructure.Services;

public sealed class RefundServiceTests
{
    private static readonly DateTime UtcNow = new(2026, 10, 21, 0, 0, 0, DateTimeKind.Utc);

    [Fact]
    public async Task ProcessRefund_ValidRequest_CreatesRefundTransactionAndIsIdempotent()
    {
        var options = new DbContextOptionsBuilder<PaymentDbContext>()
            .UseInMemoryDatabase(Guid.NewGuid().ToString())
            .Options;

        await using var db = new PaymentDbContext(options);

        var contextMock = new Mock<IRequestContext>();
        var userId = Guid.NewGuid();
        contextMock.Setup(c => c.UserId).Returns(userId);
        contextMock.Setup(c => c.Actor).Returns("user");

        var clockMock = new Mock<IDateTimeProvider>();
        clockMock.Setup(c => c.UtcNow).Returns(UtcNow);

        var numbersMock = new Mock<ITransactionNumberGenerator>();
        numbersMock.Setup(n => n.Generate(It.IsAny<DateTime>())).Returns("TX-REFUND-001");

        var gatewayMock = new Mock<IPaymentGateway>();
        gatewayMock
            .Setup(g => g.ProcessAsync(It.IsAny<PaymentGatewayRequest>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(new PaymentGatewayResult(true, "APPROVED", "Refund processed"));

        var service = new RefundService(
            db,
            contextMock.Object,
            clockMock.Object,
            numbersMock.Object,
            gatewayMock.Object
        );

        var request = new RefundProcessingRequest(
            Guid.NewGuid(),
            Guid.NewGuid(),
            250.00m,
            "Pro-rata cancellation refund"
        );

        var response = await service.ProcessRefundAsync(request, "refund-key-1", CancellationToken.None);

        response.Should().NotBeNull();
        response.Amount.Should().Be(250.00m);
        response.Status.Should().Be("Success");

        var tx = await db.Transactions.SingleAsync(t => t.Id == response.TransactionId);
        tx.Type.Should().Be(PaymentType.Refund);
        tx.Amount.Should().Be(250.00m);

        // Replay with exact same idempotency key
        var replay = await service.ProcessRefundAsync(request, "refund-key-1", CancellationToken.None);
        replay.TransactionId.Should().Be(response.TransactionId);

        // Replay with mismatched request should throw Conflict
        var differentRequest = request with { Amount = 300.00m };
        var act = async () => await service.ProcessRefundAsync(differentRequest, "refund-key-1", CancellationToken.None);
        await act.Should().ThrowAsync<PaymentServiceException>()
            .Where(e => e.ErrorCode == "IDEMPOTENCY_KEY_REUSED");
    }
}


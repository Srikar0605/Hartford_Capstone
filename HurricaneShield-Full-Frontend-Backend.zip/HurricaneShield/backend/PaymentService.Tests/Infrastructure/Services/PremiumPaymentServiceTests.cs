using PaymentService.Tests.TestSupport;

namespace PaymentService.Tests.Infrastructure.Services;

public sealed class PremiumPaymentServiceTests
{
    private const string PolicyRowVersion = "AAAAAAAAAAE=";

    [Fact]
    public async Task Process_ValidPremium_PersistsTransactionAttemptResponseReceiptAndIdempotency()
    {
        await using var db = PaymentInfrastructureTestSupport.CreateDb();

        var user = Guid.NewGuid();

        var customer = Guid.NewGuid();

        var policyId = Guid.NewGuid();

        var policy = new Mock<IPolicyClient>();

        policy
            .Setup(x => x.ValidatePremiumAsync(policyId, user, It.IsAny<CancellationToken>()))
            .ReturnsAsync(
                new PolicyPremiumValidationResponse(
                    policyId,
                    customer,
                    user,
                    true,
                    true,
                    1250m,
                    "Initial",
                    PolicyRowVersion,
                    null
                )
            );

        var gateway = new Mock<IPaymentGateway>();

        gateway
            .Setup(x =>
                x.ProcessAsync(It.IsAny<PaymentGatewayRequest>(), It.IsAny<CancellationToken>())
            )
            .ReturnsAsync(new PaymentGatewayResult(true, "APPROVED", "Approved."));

        var numbers = new Mock<ITransactionNumberGenerator>();

        numbers.Setup(x => x.Generate(It.IsAny<DateTime>())).Returns("TXN-2026-000001");

        var receipts = new Mock<IReceiptNumberGenerator>();

        receipts.Setup(x => x.Generate(It.IsAny<DateTime>())).Returns("RCT-2026-000001");

        var transactionService = new Mock<ITransactionService>();

        var service = new PremiumPaymentService(
            db,
            PaymentInfrastructureTestSupport.Context(user).Object,
            PaymentInfrastructureTestSupport.Clock().Object,
            numbers.Object,
            receipts.Object,
            gateway.Object,
            policy.Object,
            transactionService.Object
        );

        var result = await service.ProcessAsync(
            new ProcessPremiumPaymentRequest(policyId, 1250m),
            "key-1",
            CancellationToken.None
        );

        result.Status.Should().Be(PaymentStatus.Success);

        result.ReceiptNumber.Should().Be("RCT-2026-000001");

        db.Transactions.Should().ContainSingle();

        db.PaymentRequests.Should().ContainSingle();

        db.PaymentResponses.Should().ContainSingle();

        db.PaymentReceipts.Should().ContainSingle();

        db.IdempotencyRecords.Should().ContainSingle();

        policy.Verify(
            x =>
                x.ConfirmPaymentAsync(
                    policyId,
                    "Initial",
                    It.Is<PolicyPaymentConfirmationRequest>(request =>
                        request.Amount == 1250m && request.RowVersion == PolicyRowVersion
                    ),
                    It.IsAny<CancellationToken>()
                ),
            Times.Once
        );
    }

    [Fact]
    public async Task Process_SameKeyAndPayload_ReplaysWithoutDuplicates()
    {
        await using var db = PaymentInfrastructureTestSupport.CreateDb();

        var user = Guid.NewGuid();

        var customer = Guid.NewGuid();

        var policyId = Guid.NewGuid();

        var policy = new Mock<IPolicyClient>();

        policy
            .Setup(x => x.ValidatePremiumAsync(policyId, user, It.IsAny<CancellationToken>()))
            .ReturnsAsync(
                new PolicyPremiumValidationResponse(
                    policyId,
                    customer,
                    user,
                    true,
                    true,
                    1250m,
                    "Initial",
                    PolicyRowVersion,
                    null
                )
            );

        var gateway = new Mock<IPaymentGateway>();

        gateway
            .Setup(x =>
                x.ProcessAsync(It.IsAny<PaymentGatewayRequest>(), It.IsAny<CancellationToken>())
            )
            .ReturnsAsync(new PaymentGatewayResult(true, "APPROVED", "Approved."));

        var numbers = new Mock<ITransactionNumberGenerator>();

        numbers.Setup(x => x.Generate(It.IsAny<DateTime>())).Returns("TXN-2026-000001");

        var receipts = new Mock<IReceiptNumberGenerator>();

        receipts.Setup(x => x.Generate(It.IsAny<DateTime>())).Returns("RCT-2026-000001");

        var transactionService = new Mock<ITransactionService>();

        var service = new PremiumPaymentService(
            db,
            PaymentInfrastructureTestSupport.Context(user).Object,
            PaymentInfrastructureTestSupport.Clock().Object,
            numbers.Object,
            receipts.Object,
            gateway.Object,
            policy.Object,
            transactionService.Object
        );

        var request = new ProcessPremiumPaymentRequest(policyId, 1250m);

        var first = await service.ProcessAsync(request, "same-key", CancellationToken.None);

        var replay = await service.ProcessAsync(request, "same-key", CancellationToken.None);

        replay.TransactionId.Should().Be(first.TransactionId);

        db.Transactions.Should().ContainSingle();

        db.PaymentRequests.Should().ContainSingle();

        db.PaymentResponses.Should().ContainSingle();

        db.PaymentReceipts.Should().ContainSingle();

        db.IdempotencyRecords.Should().ContainSingle();

        gateway.Verify(
            x => x.ProcessAsync(It.IsAny<PaymentGatewayRequest>(), It.IsAny<CancellationToken>()),
            Times.Once
        );

        policy.Verify(
            x =>
                x.ConfirmPaymentAsync(
                    policyId,
                    "Initial",
                    It.IsAny<PolicyPaymentConfirmationRequest>(),
                    It.IsAny<CancellationToken>()
                ),
            Times.Once
        );
    }

    [Fact]
    public async Task Process_AmountMismatch_ThrowsWithoutPersistingTransaction()
    {
        await using var db = PaymentInfrastructureTestSupport.CreateDb();

        var user = Guid.NewGuid();

        var customer = Guid.NewGuid();

        var policyId = Guid.NewGuid();

        var policy = new Mock<IPolicyClient>();

        policy
            .Setup(x => x.ValidatePremiumAsync(policyId, user, It.IsAny<CancellationToken>()))
            .ReturnsAsync(
                new PolicyPremiumValidationResponse(
                    policyId,
                    customer,
                    user,
                    true,
                    true,
                    1250m,
                    "Initial",
                    PolicyRowVersion,
                    null
                )
            );

        var service = new PremiumPaymentService(
            db,
            PaymentInfrastructureTestSupport.Context(user).Object,
            PaymentInfrastructureTestSupport.Clock().Object,
            Mock.Of<ITransactionNumberGenerator>(),
            Mock.Of<IReceiptNumberGenerator>(),
            Mock.Of<IPaymentGateway>(),
            policy.Object,
            Mock.Of<ITransactionService>()
        );

        await service
            .Invoking(x =>
                x.ProcessAsync(
                    new ProcessPremiumPaymentRequest(policyId, 1000m),
                    "key",
                    CancellationToken.None
                )
            )
            .Should()
            .ThrowAsync<PaymentServiceException>()
            .Where(x => x.ErrorCode == "PAYMENT_AMOUNT_MISMATCH");

        db.Transactions.Should().BeEmpty();

        db.PaymentRequests.Should().BeEmpty();

        db.PaymentResponses.Should().BeEmpty();

        db.PaymentReceipts.Should().BeEmpty();

        db.IdempotencyRecords.Should().BeEmpty();
    }

    [Fact]
    public async Task Process_RenewalPremium_ConfirmsUsingRenewalContext()
    {
        await using var db = PaymentInfrastructureTestSupport.CreateDb();

        var user = Guid.NewGuid();

        var customer = Guid.NewGuid();

        var policyId = Guid.NewGuid();

        var policy = new Mock<IPolicyClient>();

        policy
            .Setup(x => x.ValidatePremiumAsync(policyId, user, It.IsAny<CancellationToken>()))
            .ReturnsAsync(
                new PolicyPremiumValidationResponse(
                    policyId,
                    customer,
                    user,
                    true,
                    true,
                    1500m,
                    "Renewal",
                    PolicyRowVersion,
                    null
                )
            );

        var gateway = new Mock<IPaymentGateway>();

        gateway
            .Setup(x =>
                x.ProcessAsync(It.IsAny<PaymentGatewayRequest>(), It.IsAny<CancellationToken>())
            )
            .ReturnsAsync(new PaymentGatewayResult(true, "APPROVED", "Approved."));

        var numbers = new Mock<ITransactionNumberGenerator>();

        numbers.Setup(x => x.Generate(It.IsAny<DateTime>())).Returns("TXN-2026-000002");

        var receipts = new Mock<IReceiptNumberGenerator>();

        receipts.Setup(x => x.Generate(It.IsAny<DateTime>())).Returns("RCT-2026-000002");

        var transactionService = new Mock<ITransactionService>();

        var service = new PremiumPaymentService(
            db,
            PaymentInfrastructureTestSupport.Context(user).Object,
            PaymentInfrastructureTestSupport.Clock().Object,
            numbers.Object,
            receipts.Object,
            gateway.Object,
            policy.Object,
            transactionService.Object
        );

        var result = await service.ProcessAsync(
            new ProcessPremiumPaymentRequest(policyId, 1500m),
            "renewal-key",
            CancellationToken.None
        );

        result.Status.Should().Be(PaymentStatus.Success);

        result.ReceiptNumber.Should().Be("RCT-2026-000002");

        policy.Verify(
            x =>
                x.ConfirmPaymentAsync(
                    policyId,
                    "Renewal",
                    It.Is<PolicyPaymentConfirmationRequest>(request =>
                        request.Amount == 1500m && request.RowVersion == PolicyRowVersion
                    ),
                    It.IsAny<CancellationToken>()
                ),
            Times.Once
        );
    }
}


using PaymentService.Tests.TestSupport;

namespace PaymentService.Tests.Infrastructure.Services;

public sealed class ClaimSettlementServiceTests
{
    [Fact]
    public async Task Process_ValidSettlement_PersistsSuccessfulPaymentWithoutPrematureClaimsCallback()
    {
        await using var db = PaymentInfrastructureTestSupport.CreateDb();

        var claimId = Guid.NewGuid();
        var customerId = Guid.NewGuid();
        var policyId = Guid.NewGuid();

        var claims = new Mock<IClaimsClient>();

        claims
            .Setup(client => client.ValidateSettlementAsync(claimId, It.IsAny<CancellationToken>()))
            .ReturnsAsync(
                new ClaimSettlementValidationResponse(
                    claimId,
                    "CLM-1",
                    true,
                    true,
                    25000m,
                    customerId,
                    policyId,
                    null
                )
            );

        var gateway = new Mock<IPaymentGateway>();

        gateway
            .Setup(client =>
                client.ProcessAsync(
                    It.IsAny<PaymentGatewayRequest>(),
                    It.IsAny<CancellationToken>()
                )
            )
            .ReturnsAsync(new PaymentGatewayResult(true, "APPROVED", "Approved."));

        var transactionNumbers = new Mock<ITransactionNumberGenerator>();

        transactionNumbers
            .Setup(generator => generator.Generate(It.IsAny<DateTime>()))
            .Returns("TXN-2026-000002");

        var receiptNumbers = new Mock<IReceiptNumberGenerator>();

        receiptNumbers
            .Setup(generator => generator.Generate(It.IsAny<DateTime>()))
            .Returns("RCT-2026-000002");

        var service = new ClaimSettlementService(
            db,
            PaymentInfrastructureTestSupport.Context(Guid.NewGuid(), "Claims Manager").Object,
            PaymentInfrastructureTestSupport.Clock().Object,
            transactionNumbers.Object,
            receiptNumbers.Object,
            gateway.Object,
            claims.Object,
            Mock.Of<ITransactionService>()
        );

        var result = await service.ProcessAsync(
            new ProcessClaimSettlementRequest(claimId, customerId, policyId, 25000m),
            "settlement-key",
            CancellationToken.None
        );

        result.Status.Should().Be(PaymentStatus.Success);

        result.ClaimId.Should().Be(claimId);

        result.Amount.Should().Be(25000m);

        result.TransactionNumber.Should().Be("TXN-2026-000002");

        result.ReceiptNumber.Should().Be("RCT-2026-000002");

        db.Transactions.Should()
            .ContainSingle(transaction => transaction.Type == PaymentType.ClaimSettlement);

        db.PaymentRequests.Should().ContainSingle();

        db.PaymentResponses.Should().ContainSingle();

        db.PaymentReceipts.Should().ContainSingle();

        db.IdempotencyRecords.Should().ContainSingle();

        claims.Verify(
            client => client.ValidateSettlementAsync(claimId, It.IsAny<CancellationToken>()),
            Times.Once
        );

        /*
         * Initial settlement processing must return its final result
         * to Claims Service. Claims Service then records the transaction,
         * moves the Claim through PaymentInitiated, and closes it when
         * the returned Payment result is successful.
         *
         * Calling Claims confirmation here would be premature because
         * Claims Service has not yet stored the transaction identifier.
         */
        claims.Verify(
            client =>
                client.ConfirmSettlementAsync(
                    It.IsAny<Guid>(),
                    It.IsAny<ClaimSettlementConfirmationRequest>(),
                    It.IsAny<CancellationToken>()
                ),
            Times.Never
        );

        gateway.Verify(
            client =>
                client.ProcessAsync(
                    It.IsAny<PaymentGatewayRequest>(),
                    It.IsAny<CancellationToken>()
                ),
            Times.Once
        );
    }

    [Fact]
    public async Task Process_SameIdempotencyKeyAndRequest_ReturnsStoredResponseWithoutDuplicatesOrCallback()
    {
        await using var db = PaymentInfrastructureTestSupport.CreateDb();

        var claimId = Guid.NewGuid();
        var customerId = Guid.NewGuid();
        var policyId = Guid.NewGuid();

        var claims = new Mock<IClaimsClient>();

        claims
            .Setup(client => client.ValidateSettlementAsync(claimId, It.IsAny<CancellationToken>()))
            .ReturnsAsync(
                new ClaimSettlementValidationResponse(
                    claimId,
                    "CLM-1",
                    true,
                    true,
                    25000m,
                    customerId,
                    policyId,
                    null
                )
            );

        var gateway = new Mock<IPaymentGateway>();

        gateway
            .Setup(client =>
                client.ProcessAsync(
                    It.IsAny<PaymentGatewayRequest>(),
                    It.IsAny<CancellationToken>()
                )
            )
            .ReturnsAsync(new PaymentGatewayResult(true, "APPROVED", "Approved."));

        var transactionNumbers = new Mock<ITransactionNumberGenerator>();

        transactionNumbers
            .Setup(generator => generator.Generate(It.IsAny<DateTime>()))
            .Returns("TXN-2026-000002");

        var receiptNumbers = new Mock<IReceiptNumberGenerator>();

        receiptNumbers
            .Setup(generator => generator.Generate(It.IsAny<DateTime>()))
            .Returns("RCT-2026-000002");

        var service = new ClaimSettlementService(
            db,
            PaymentInfrastructureTestSupport.Context(Guid.NewGuid(), "Claims Manager").Object,
            PaymentInfrastructureTestSupport.Clock().Object,
            transactionNumbers.Object,
            receiptNumbers.Object,
            gateway.Object,
            claims.Object,
            Mock.Of<ITransactionService>()
        );

        var request = new ProcessClaimSettlementRequest(claimId, customerId, policyId, 25000m);

        var firstResult = await service.ProcessAsync(
            request,
            "settlement-replay-key",
            CancellationToken.None
        );

        db.ChangeTracker.Clear();

        var replayResult = await service.ProcessAsync(
            request,
            "settlement-replay-key",
            CancellationToken.None
        );

        replayResult.TransactionId.Should().Be(firstResult.TransactionId);

        replayResult.TransactionNumber.Should().Be(firstResult.TransactionNumber);

        replayResult.ClaimId.Should().Be(firstResult.ClaimId);

        replayResult.Amount.Should().Be(firstResult.Amount);

        replayResult.Status.Should().Be(firstResult.Status);

        replayResult.ReceiptNumber.Should().Be(firstResult.ReceiptNumber);

        db.Transactions.Should().ContainSingle();

        db.PaymentRequests.Should().ContainSingle();

        db.PaymentResponses.Should().ContainSingle();

        db.PaymentReceipts.Should().ContainSingle();

        db.IdempotencyRecords.Should().ContainSingle();

        gateway.Verify(
            client =>
                client.ProcessAsync(
                    It.IsAny<PaymentGatewayRequest>(),
                    It.IsAny<CancellationToken>()
                ),
            Times.Once
        );

        claims.Verify(
            client => client.ValidateSettlementAsync(claimId, It.IsAny<CancellationToken>()),
            Times.Once
        );

        claims.Verify(
            client =>
                client.ConfirmSettlementAsync(
                    It.IsAny<Guid>(),
                    It.IsAny<ClaimSettlementConfirmationRequest>(),
                    It.IsAny<CancellationToken>()
                ),
            Times.Never
        );
    }

    [Fact]
    public async Task Process_IdempotencyKeyReusedWithDifferentRequest_Throws()
    {
        await using var db = PaymentInfrastructureTestSupport.CreateDb();

        var claimId = Guid.NewGuid();
        var customerId = Guid.NewGuid();
        var policyId = Guid.NewGuid();

        var claims = new Mock<IClaimsClient>();

        claims
            .Setup(client => client.ValidateSettlementAsync(claimId, It.IsAny<CancellationToken>()))
            .ReturnsAsync(
                new ClaimSettlementValidationResponse(
                    claimId,
                    "CLM-1",
                    true,
                    true,
                    25000m,
                    customerId,
                    policyId,
                    null
                )
            );

        var gateway = new Mock<IPaymentGateway>();

        gateway
            .Setup(client =>
                client.ProcessAsync(
                    It.IsAny<PaymentGatewayRequest>(),
                    It.IsAny<CancellationToken>()
                )
            )
            .ReturnsAsync(new PaymentGatewayResult(true, "APPROVED", "Approved."));

        var transactionNumbers = new Mock<ITransactionNumberGenerator>();

        transactionNumbers
            .Setup(generator => generator.Generate(It.IsAny<DateTime>()))
            .Returns("TXN-2026-000002");

        var receiptNumbers = new Mock<IReceiptNumberGenerator>();

        receiptNumbers
            .Setup(generator => generator.Generate(It.IsAny<DateTime>()))
            .Returns("RCT-2026-000002");

        var service = new ClaimSettlementService(
            db,
            PaymentInfrastructureTestSupport.Context(Guid.NewGuid(), "Claims Manager").Object,
            PaymentInfrastructureTestSupport.Clock().Object,
            transactionNumbers.Object,
            receiptNumbers.Object,
            gateway.Object,
            claims.Object,
            Mock.Of<ITransactionService>()
        );

        await service.ProcessAsync(
            new ProcessClaimSettlementRequest(claimId, customerId, policyId, 25000m),
            "reused-settlement-key",
            CancellationToken.None
        );

        db.ChangeTracker.Clear();

        var action = async () =>
            await service.ProcessAsync(
                new ProcessClaimSettlementRequest(claimId, customerId, policyId, 24000m),
                "reused-settlement-key",
                CancellationToken.None
            );

        await action
            .Should()
            .ThrowAsync<PaymentServiceException>()
            .Where(exception => exception.ErrorCode == "IDEMPOTENCY_KEY_REUSED");

        db.Transactions.Should().ContainSingle();

        db.PaymentReceipts.Should().ContainSingle();

        gateway.Verify(
            client =>
                client.ProcessAsync(
                    It.IsAny<PaymentGatewayRequest>(),
                    It.IsAny<CancellationToken>()
                ),
            Times.Once
        );

        claims.Verify(
            client =>
                client.ConfirmSettlementAsync(
                    It.IsAny<Guid>(),
                    It.IsAny<ClaimSettlementConfirmationRequest>(),
                    It.IsAny<CancellationToken>()
                ),
            Times.Never
        );
    }

    [Fact]
    public async Task Process_AmountMismatch_Throws()
    {
        await using var db = PaymentInfrastructureTestSupport.CreateDb();

        var claimId = Guid.NewGuid();
        var customerId = Guid.NewGuid();
        var policyId = Guid.NewGuid();

        var claims = new Mock<IClaimsClient>();

        claims
            .Setup(client => client.ValidateSettlementAsync(claimId, It.IsAny<CancellationToken>()))
            .ReturnsAsync(
                new ClaimSettlementValidationResponse(
                    claimId,
                    "CLM-1",
                    true,
                    true,
                    25000m,
                    customerId,
                    policyId,
                    null
                )
            );

        var service = new ClaimSettlementService(
            db,
            PaymentInfrastructureTestSupport.Context(Guid.NewGuid(), "Claims Manager").Object,
            PaymentInfrastructureTestSupport.Clock().Object,
            Mock.Of<ITransactionNumberGenerator>(),
            Mock.Of<IReceiptNumberGenerator>(),
            Mock.Of<IPaymentGateway>(),
            claims.Object,
            Mock.Of<ITransactionService>()
        );

        var action = async () =>
            await service.ProcessAsync(
                new ProcessClaimSettlementRequest(claimId, customerId, policyId, 24000m),
                "amount-mismatch-key",
                CancellationToken.None
            );

        await action
            .Should()
            .ThrowAsync<PaymentServiceException>()
            .Where(exception => exception.ErrorCode == "PAYMENT_AMOUNT_MISMATCH");

        db.Transactions.Should().BeEmpty();

        db.PaymentRequests.Should().BeEmpty();

        db.PaymentResponses.Should().BeEmpty();

        db.PaymentReceipts.Should().BeEmpty();

        db.IdempotencyRecords.Should().BeEmpty();

        claims.Verify(
            client => client.ValidateSettlementAsync(claimId, It.IsAny<CancellationToken>()),
            Times.Once
        );

        claims.Verify(
            client =>
                client.ConfirmSettlementAsync(
                    It.IsAny<Guid>(),
                    It.IsAny<ClaimSettlementConfirmationRequest>(),
                    It.IsAny<CancellationToken>()
                ),
            Times.Never
        );
    }

    [Fact]
    public async Task Process_IneligibleClaim_ThrowsWithoutCreatingPaymentRecords()
    {
        await using var db = PaymentInfrastructureTestSupport.CreateDb();

        var claimId = Guid.NewGuid();
        var customerId = Guid.NewGuid();
        var policyId = Guid.NewGuid();

        var claims = new Mock<IClaimsClient>();

        claims
            .Setup(client => client.ValidateSettlementAsync(claimId, It.IsAny<CancellationToken>()))
            .ReturnsAsync(
                new ClaimSettlementValidationResponse(
                    claimId,
                    "CLM-1",
                    true,
                    false,
                    25000m,
                    customerId,
                    policyId,
                    "Claim is not eligible for settlement."
                )
            );

        var service = new ClaimSettlementService(
            db,
            PaymentInfrastructureTestSupport.Context(Guid.NewGuid(), "Claims Manager").Object,
            PaymentInfrastructureTestSupport.Clock().Object,
            Mock.Of<ITransactionNumberGenerator>(),
            Mock.Of<IReceiptNumberGenerator>(),
            Mock.Of<IPaymentGateway>(),
            claims.Object,
            Mock.Of<ITransactionService>()
        );

        var action = async () =>
            await service.ProcessAsync(
                new ProcessClaimSettlementRequest(claimId, customerId, policyId, 25000m),
                "ineligible-claim-key",
                CancellationToken.None
            );

        await action
            .Should()
            .ThrowAsync<PaymentServiceException>()
            .Where(exception => exception.ErrorCode == "PAYMENT_INVALID_STATE");

        db.Transactions.Should().BeEmpty();

        db.PaymentRequests.Should().BeEmpty();

        db.PaymentResponses.Should().BeEmpty();

        db.PaymentReceipts.Should().BeEmpty();

        db.IdempotencyRecords.Should().BeEmpty();

        claims.Verify(
            client =>
                client.ConfirmSettlementAsync(
                    It.IsAny<Guid>(),
                    It.IsAny<ClaimSettlementConfirmationRequest>(),
                    It.IsAny<CancellationToken>()
                ),
            Times.Never
        );
    }
}


using Microsoft.Extensions.Options;
using PaymentService.Infrastructure.Configuration;
using PaymentService.Infrastructure.Gateway;

namespace PaymentService.Tests.Infrastructure.Gateway;

public sealed class FakePaymentGatewayTests
{
    [Fact]
    public async Task Process_DefaultRequest_ReturnsDeterministicSuccess()
    {
        var gateway = Create(true);
        var result = await gateway.ProcessAsync(
            new PaymentGatewayRequest(Guid.NewGuid(), PaymentType.Premium, 100m, false),
            default
        );
        result.Successful.Should().BeTrue();
        result.ResponseCode.Should().Be("APPROVED");
    }

    [Fact]
    public async Task Process_SimulationRequested_ReturnsDeterministicFailure()
    {
        var gateway = Create(true);
        var result = await gateway.ProcessAsync(
            new PaymentGatewayRequest(Guid.NewGuid(), PaymentType.Premium, 100m, true),
            default
        );
        result.Successful.Should().BeFalse();
        result.ResponseCode.Should().Be("SIMULATED_FAILURE");
    }

    [Fact]
    public async Task Process_SimulationDisabled_ThrowsBadRequest()
    {
        var gateway = Create(false);
        await gateway
            .Invoking(x =>
                x.ProcessAsync(
                    new PaymentGatewayRequest(Guid.NewGuid(), PaymentType.Premium, 100m, true),
                    default
                )
            )
            .Should()
            .ThrowAsync<PaymentServiceException>()
            .Where(x => x.ErrorCode == "PAYMENT_SIMULATION_DISABLED");
    }

    private static FakePaymentGateway Create(bool allow) =>
        new(
            Options.Create(
                new FakePaymentGatewaySettings
                {
                    AllowSimulatedFailure = allow,
                    ProcessingDelayMilliseconds = 0,
                }
            )
        );
}


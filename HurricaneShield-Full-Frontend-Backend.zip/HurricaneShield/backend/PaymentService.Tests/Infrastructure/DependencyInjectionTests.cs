using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using PaymentService.Infrastructure;

namespace PaymentService.Tests.Infrastructure;

public sealed class DependencyInjectionTests
{
    [Fact]
    public void AddPaymentInfrastructure_RegistersAllRequiredServices()
    {
        var configuration = new ConfigurationBuilder()
            .AddInMemoryCollection(
                new Dictionary<string, string?>
                {
                    ["ConnectionStrings:PaymentDb"] =
                        @"Server=(localdb)\MSSQLLocalDB;Database=PaymentTests;Trusted_Connection=True",
                    ["Services:Policy:BaseUrl"] = "https://policy/",
                    ["Services:Claims:BaseUrl"] = "https://claims/",
                    ["PaymentGateway:AllowSimulatedFailure"] = "true",
                }
            )
            .Build();
        var services = new ServiceCollection();
        services.AddLogging();

        services.AddPaymentInfrastructure(configuration);

        var types = services.Select(x => x.ServiceType).ToArray();
        types.Should().Contain(typeof(PaymentDbContext));
        types.Should().Contain(typeof(IPremiumPaymentService));
        types.Should().Contain(typeof(IClaimSettlementService));
        types.Should().Contain(typeof(ITransactionService));
        types.Should().Contain(typeof(IReceiptService));
        types.Should().Contain(typeof(IPaymentGateway));
        types.Should().Contain(typeof(IPolicyClient));
        types.Should().Contain(typeof(IClaimsClient));
    }

    [Fact]
    public void AddPaymentInfrastructure_MissingPaymentDb_Throws()
    {
        var configuration = new ConfigurationBuilder()
            .AddInMemoryCollection(new Dictionary<string, string?>())
            .Build();
        var services = new ServiceCollection();

        var action = () => services.AddPaymentInfrastructure(configuration);

        action.Should().Throw<InvalidOperationException>().WithMessage("*PaymentDb*");
    }
}


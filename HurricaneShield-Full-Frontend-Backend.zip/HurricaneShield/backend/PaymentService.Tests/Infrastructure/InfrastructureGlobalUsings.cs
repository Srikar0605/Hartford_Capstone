global using FluentAssertions;
global using Microsoft.EntityFrameworkCore;
global using Moq;
global using PaymentService.Application.DTOs.Integrations;
global using PaymentService.Application.DTOs.Premiums;
global using PaymentService.Application.DTOs.Settlements;
global using PaymentService.Application.DTOs.Transactions;
global using PaymentService.Application.Interfaces;
global using PaymentService.Domain.Entities;
global using PaymentService.Domain.Enums;
global using PaymentService.Domain.Models;
global using PaymentService.Infrastructure.Exceptions;
global using PaymentService.Infrastructure.Persistence;
global using PaymentService.Infrastructure.Services;
global using Xunit;


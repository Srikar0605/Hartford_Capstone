global using CustomerService.Domain.Constants;
global using CustomerService.Domain.Entities;
global using FluentAssertions;
global using Moq;
global using Xunit;


using CustomerService.Tests.TestSupport;

namespace CustomerService.Tests.Domain;

public sealed class CustomerEligibilityAndStatusTests
{
    private static readonly DateOnly Today = new(2026, 9, 29);

    [Theory]
    [InlineData(2008, 9, 29, true)]
    [InlineData(2008, 9, 30, false)]
    [InlineData(1941, 9, 29, true)]
    [InlineData(1940, 9, 29, false)]
    public void IsAgeEligible_EnforcesInclusiveBoundaries(
        int year,
        int month,
        int day,
        bool expected
    )
    {
        var customer = CustomerFactory.Create(new DateOnly(year, month, day));
        customer.IsAgeEligible(Today).Should().Be(expected);
    }

    [Fact]
    public void PendingCustomer_IsNotEligible()
    {
        var customer = CustomerFactory.Create(new DateOnly(1990, 1, 1));
        customer.IsEligible(Today).Should().BeFalse();
    }

    [Fact]
    public void Pending_CanActivate_ThenDeactivate_ThenReactivate()
    {
        var customer = CustomerFactory.Create();
        customer.Activate(CustomerFactory.CreatedAt.AddHours(1), "admin");
        customer.Status.Should().Be(CustomerStatuses.Active);
        customer.Deactivate(CustomerFactory.CreatedAt.AddHours(2), "admin");
        customer.Status.Should().Be(CustomerStatuses.Inactive);
        customer.Activate(CustomerFactory.CreatedAt.AddHours(3), "admin");
        customer.Status.Should().Be(CustomerStatuses.Active);
    }

    [Fact]
    public void Pending_CannotDeactivate()
    {
        var customer = CustomerFactory.Create();
        var action = () => customer.Deactivate(CustomerFactory.CreatedAt.AddHours(1), "admin");
        action.Should().Throw<InvalidOperationException>();
    }

    [Fact]
    public void RepeatedActivation_DoesNotChangeAuditAgain()
    {
        var customer = CustomerFactory.Create();
        var first = CustomerFactory.CreatedAt.AddHours(1);
        customer.Activate(first, "admin");
        customer.Activate(first.AddHours(1), "other");
        customer.UpdatedAt.Should().Be(first);
        customer.UpdatedBy.Should().Be("admin");
    }
}


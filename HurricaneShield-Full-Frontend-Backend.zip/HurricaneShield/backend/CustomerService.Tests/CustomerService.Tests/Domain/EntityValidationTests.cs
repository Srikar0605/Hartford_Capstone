using CustomerService.Tests.TestSupport;

namespace CustomerService.Tests.Domain;

public sealed class EntityValidationTests
{
    [Fact]
    public void PropertyOwnership_RejectsInvalidOwnershipType()
    {
        var customer = CustomerFactory.Create();
        var action = () =>
            customer.AddPropertyOwnership(
                "1 Main",
                null,
                "Mumbai",
                "MH",
                "400001",
                "India",
                "Rented",
                new DateOnly(2020, 1, 1),
                false,
                DateTime.UtcNow,
                "user"
            );
        action.Should().Throw<ArgumentException>();
    }

    [Fact]
    public void CustomerHistory_RequiresCorrelationId()
    {
        var action = () =>
            CustomerHistory.Create(
                Guid.NewGuid(),
                CustomerHistoryTypes.ProfileCreated,
                "{}",
                DateTime.UtcNow,
                "user",
                " "
            );
        action.Should().Throw<ArgumentException>();
    }
}


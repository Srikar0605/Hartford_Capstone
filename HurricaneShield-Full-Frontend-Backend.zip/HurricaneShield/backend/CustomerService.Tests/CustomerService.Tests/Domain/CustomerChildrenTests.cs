using CustomerService.Tests.TestSupport;

namespace CustomerService.Tests.Domain;

public sealed class CustomerChildrenTests
{
    [Fact]
    public void AddressLifecycle_IsAggregateControlled()
    {
        var customer = CustomerFactory.Create();
        var addAt = CustomerFactory.CreatedAt.AddHours(1);
        var address = customer.AddAddress(
            "1 Main",
            null,
            "Mumbai",
            "MH",
            "400001",
            "India",
            addAt,
            "user"
        );
        customer.Addresses.Should().ContainSingle();
        customer.UpdatedAt.Should().Be(addAt);

        var updateAt = addAt.AddHours(1);
        customer.UpdateAddress(
            address.Id,
            "2 Main",
            "Apt 1",
            "Mumbai",
            "MH",
            "400002",
            "India",
            updateAt,
            "user"
        );
        address.AddressLine1.Should().Be("2 Main");
        customer.UpdatedAt.Should().Be(updateAt);

        var removed = customer.RemoveAddress(address.Id, updateAt.AddHours(1), "user");
        removed.Should().BeSameAs(address);
        customer.Addresses.Should().BeEmpty();
    }

    [Fact]
    public void EmergencyContactLifecycle_IsAggregateControlled()
    {
        var customer = CustomerFactory.Create();
        var contact = customer.AddEmergencyContact(
            "A",
            "Sibling",
            "+91 99999 99999",
            CustomerFactory.CreatedAt.AddHours(1),
            "user"
        );
        customer.UpdateEmergencyContact(
            contact.Id,
            "B",
            "Friend",
            "+91 88888 88888",
            CustomerFactory.CreatedAt.AddHours(2),
            "user"
        );
        contact.Name.Should().Be("B");
        var removed = customer.RemoveEmergencyContact(
            contact.Id,
            CustomerFactory.CreatedAt.AddHours(3),
            "user"
        );
        removed.Should().BeSameAs(contact);
        customer.EmergencyContacts.Should().BeEmpty();
    }

    [Fact]
    public void AddingNewPrimaryResidence_ClearsExistingPrimary()
    {
        var customer = CustomerFactory.Create();
        var first = AddProperty(customer, true, "1 Main");
        var second = AddProperty(customer, true, "2 Main");
        first.IsPrimaryResidence.Should().BeFalse();
        second.IsPrimaryResidence.Should().BeTrue();
        customer.PropertyOwnerships.Count(x => x.IsPrimaryResidence).Should().Be(1);
    }

    [Fact]
    public void UpdatingPropertyToPrimary_ClearsOtherPrimary()
    {
        var customer = CustomerFactory.Create();
        var first = AddProperty(customer, true, "1 Main");
        var second = AddProperty(customer, false, "2 Main");
        customer.UpdatePropertyOwnership(
            second.Id,
            "2 Main",
            null,
            "Mumbai",
            "MH",
            "400002",
            "India",
            OwnershipTypes.Mortgaged,
            new DateOnly(2020, 1, 1),
            true,
            CustomerFactory.CreatedAt.AddDays(2),
            "user"
        );
        first.IsPrimaryResidence.Should().BeFalse();
        second.IsPrimaryResidence.Should().BeTrue();
    }

    [Fact]
    public void ForeignChildIdentifiers_AreRejected()
    {
        var customer = CustomerFactory.Create();
        FluentActions
            .Invoking(() => customer.RemoveAddress(Guid.NewGuid(), DateTime.UtcNow, "user"))
            .Should()
            .Throw<InvalidOperationException>();
        FluentActions
            .Invoking(() =>
                customer.RemoveEmergencyContact(Guid.NewGuid(), DateTime.UtcNow, "user")
            )
            .Should()
            .Throw<InvalidOperationException>();
        FluentActions
            .Invoking(() =>
                customer.RemovePropertyOwnership(Guid.NewGuid(), DateTime.UtcNow, "user")
            )
            .Should()
            .Throw<InvalidOperationException>();
    }

    private static PropertyOwnership AddProperty(Customer customer, bool primary, string line1) =>
        customer.AddPropertyOwnership(
            line1,
            null,
            "Mumbai",
            "MH",
            "400001",
            "India",
            OwnershipTypes.Owned,
            new DateOnly(2020, 1, 1),
            primary,
            CustomerFactory.CreatedAt.AddDays(1),
            "user"
        );
}


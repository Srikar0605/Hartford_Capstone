using CustomerService.Tests.TestSupport;

namespace CustomerService.Tests.Domain;

public sealed class CustomerCoreTests
{
    [Fact]
    public void Create_NormalizesValues_AndStartsPending()
    {
        var authUserId = Guid.NewGuid();
        var customer = Customer.Create(
            authUserId,
            " Bhanu ",
            " Srikar ",
            " USER@EXAMPLE.COM ",
            new DateOnly(1995, 6, 15),
            CustomerFactory.CreatedAt,
            " tests "
        );

        customer.AuthUserId.Should().Be(authUserId);
        customer.FirstName.Should().Be("Bhanu");
        customer.LastName.Should().Be("Srikar");
        customer.Email.Should().Be("user@example.com");
        customer.Status.Should().Be(CustomerStatuses.Pending);
        customer.CreatedBy.Should().Be("tests");
    }

    [Fact]
    public void Create_WithEmptyAuthUserId_Throws()
    {
        var action = () =>
            Customer.Create(
                Guid.Empty,
                "A",
                "B",
                "a@b.com",
                new DateOnly(1990, 1, 1),
                CustomerFactory.CreatedAt,
                "tests"
            );
        action.Should().Throw<ArgumentException>();
    }

    [Fact]
    public void UpdateProfile_ChangesProfileAndAudit()
    {
        var customer = CustomerFactory.Create();
        var changedAt = CustomerFactory.CreatedAt.AddDays(1);
        customer.UpdateProfile(" New ", " Name ", new DateOnly(1992, 2, 2), changedAt, "actor");
        customer.FirstName.Should().Be("New");
        customer.LastName.Should().Be("Name");
        customer.UpdatedAt.Should().Be(changedAt);
        customer.UpdatedBy.Should().Be("actor");
    }

    [Fact]
    public void SoftDelete_IsIdempotent()
    {
        var customer = CustomerFactory.Create();
        var at = CustomerFactory.CreatedAt.AddDays(1);
        customer.SoftDelete(at, "admin");
        customer.SoftDelete(at.AddDays(1), "other");
        customer.IsDeleted.Should().BeTrue();
        customer.DeletedAt.Should().Be(at);
        customer.DeletedBy.Should().Be("admin");
    }
}


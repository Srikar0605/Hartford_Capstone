namespace CustomerService.Tests.TestSupport;

internal static class CustomerFactory
{
    internal static readonly DateTime CreatedAt = new(2026, 9, 1, 10, 0, 0, DateTimeKind.Utc);

    internal static Customer Create(
        DateOnly? dateOfBirth = null,
        string email = " Customer@Example.com "
    )
    {
        return Customer.Create(
            Guid.NewGuid(),
            " Bhanu ",
            " Srikar ",
            email,
            dateOfBirth ?? new DateOnly(1995, 6, 15),
            CreatedAt,
            "tests"
        );
    }
}


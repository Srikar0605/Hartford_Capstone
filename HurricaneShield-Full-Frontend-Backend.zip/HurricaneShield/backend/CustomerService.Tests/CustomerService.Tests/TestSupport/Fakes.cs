using CustomerService.Application.Abstractions.Context;
using CustomerService.Application.Abstractions.Time;

namespace CustomerService.Tests.TestSupport;

internal sealed class FakeClock : IDateTimeProvider
{
    public DateTime UtcNow { get; set; } = new(2026, 9, 29, 10, 0, 0, DateTimeKind.Utc);
    public DateOnly UtcToday => DateOnly.FromDateTime(UtcNow);
}

internal sealed class FakeRequestContext : IRequestContext
{
    public Guid? UserId { get; init; } = Guid.NewGuid();
    public string? Email { get; init; } = "customer@example.com";
    public string Actor { get; init; } = "tests";
    public string CorrelationId { get; init; } = "corr-tests";
}


using CustomerService.API.Contracts.Customers;
using CustomerService.API.Controllers;
using CustomerService.Application.Abstractions.Context;
using CustomerService.Application.Commands.CreateCustomerProfile;
using CustomerService.Application.Commands.Properties.AddProperty;
using CustomerService.Application.Commands.Properties.UpdateProperty;
using CustomerService.Application.DTOs;
using CustomerService.Application.Queries.SearchAddressAutocomplete;
using FluentAssertions;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Shared.Common.Responses;
using Xunit;

namespace CustomerService.Tests.API;

public sealed class CustomersControllerTests
{
    [Fact]
    public async Task CreateProfile_UsesIdentityClaims_NotClientIdentity()
    {
        var sender = new Mock<ISender>();
        var userId = Guid.NewGuid();
        sender
            .Setup(x =>
                x.Send(It.IsAny<CreateCustomerProfileCommand>(), It.IsAny<CancellationToken>())
            )
            .ReturnsAsync(
                (CreateCustomerProfileCommand c, CancellationToken _) =>
                    new CreateCustomerProfileResult(Guid.NewGuid(), CustomerStatuses.Pending)
            );
        var requestContext = new Mock<IRequestContext>();
        requestContext.SetupGet(x => x.UserId).Returns(userId);
        requestContext.SetupGet(x => x.Email).Returns("jwt@example.com");
        var controller = new CustomersController(sender.Object, requestContext.Object);
        var result = await controller.CreateProfile(
            new CreateCustomerProfileRequest("A", "B", new DateOnly(1990, 1, 1)),
            default
        );
        result.Should().BeOfType<ObjectResult>().Which.StatusCode.Should().Be(201);
        sender.Verify(
            x =>
                x.Send(
                    It.Is<CreateCustomerProfileCommand>(c =>
                        c.AuthUserId == userId && c.Email == "jwt@example.com"
                    ),
                    It.IsAny<CancellationToken>()
                ),
            Times.Once
        );
    }

    [Fact]
    public async Task AutocompleteAddress_WithValidQuery_DispatchesQueryAndReturnsOk()
    {
        var sender = new Mock<ISender>();
        var requestContext = new Mock<IRequestContext>();
        var suggestions = new List<AddressSuggestionDto>
        {
            new("100 Biscayne, Miami", "100 Biscayne", "Miami", "FL", "33132", "US", 25.7, -80.1)
        };

        sender
            .Setup(x => x.Send(It.IsAny<SearchAddressAutocompleteQuery>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(suggestions);

        var controller = new CustomersController(sender.Object, requestContext.Object);
        var result = await controller.AutocompleteAddress("100 Biscayne", CancellationToken.None);

        var okResult = result.Should().BeOfType<OkObjectResult>().Subject;
        var response = okResult.Value.Should().BeOfType<ApiResponse<IReadOnlyCollection<AddressSuggestionDto>>>().Subject;
        response.Data.Should().BeEquivalentTo(suggestions);
        sender.Verify(x => x.Send(It.Is<SearchAddressAutocompleteQuery>(q => q.Query == "100 Biscayne"), It.IsAny<CancellationToken>()), Times.Once);
    }

    [Theory]
    [InlineData("")]
    [InlineData("ab")]
    [InlineData("   ")]
    public async Task AutocompleteAddress_WithShortQuery_ReturnsEmptyWithoutDispatching(string query)
    {
        var sender = new Mock<ISender>();
        var requestContext = new Mock<IRequestContext>();

        var controller = new CustomersController(sender.Object, requestContext.Object);
        var result = await controller.AutocompleteAddress(query, CancellationToken.None);

        var okResult = result.Should().BeOfType<OkObjectResult>().Subject;
        var response = okResult.Value.Should().BeOfType<ApiResponse<IReadOnlyCollection<AddressSuggestionDto>>>().Subject;
        response.Data.Should().BeEmpty();
        sender.Verify(x => x.Send(It.IsAny<SearchAddressAutocompleteQuery>(), It.IsAny<CancellationToken>()), Times.Never);
    }

    [Fact]
    public async Task AddProperty_MapsAllBuildingAndMitigationDetails_ToCommand()
    {
        var sender = new Mock<ISender>();
        var userId = Guid.NewGuid();
        var requestContext = new Mock<IRequestContext>();
        requestContext.SetupGet(x => x.UserId).Returns(userId);

        sender
            .Setup(x => x.Send(It.IsAny<AddPropertyCommand>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(new AddPropertyResult(Guid.NewGuid(), Convert.ToBase64String(new byte[8])));

        var controller = new CustomersController(sender.Object, requestContext.Object);
        var request = new PropertyOwnershipRequest(
            "123 Ocean Dr",
            "Apt 4B",
            "Miami",
            "FL",
            "33139",
            "United States",
            "Owned",
            new DateOnly(2021, 5, 10),
            true,
            YearBuilt: 2018,
            ConstructionType: "ReinforcedConcrete",
            RiskZone: "A",
            StormShutters: true,
            ImpactResistantWindows: true,
            ReinforcedRoof: true,
            EmergencyGenerator: false,
            HomeInspectionCertification: true
        );

        var result = await controller.AddProperty(request, CancellationToken.None);

        result.Should().BeOfType<ObjectResult>().Which.StatusCode.Should().Be(201);
        sender.Verify(
            x =>
                x.Send(
                    It.Is<AddPropertyCommand>(c =>
                        c.AuthUserId == userId
                        && c.Property.AddressLine1 == "123 Ocean Dr"
                        && c.Property.AddressLine2 == "Apt 4B"
                        && c.Property.City == "Miami"
                        && c.Property.State == "FL"
                        && c.Property.PostalCode == "33139"
                        && c.Property.Country == "United States"
                        && c.Property.OwnershipType == "Owned"
                        && c.Property.AcquiredOn == new DateOnly(2021, 5, 10)
                        && c.Property.IsPrimaryResidence
                        && c.Property.YearBuilt == 2018
                        && c.Property.ConstructionType == "ReinforcedConcrete"
                        && c.Property.RiskZone == "A"
                        && c.Property.StormShutters
                        && c.Property.ImpactResistantWindows
                        && c.Property.ReinforcedRoof
                        && !c.Property.EmergencyGenerator
                        && c.Property.HomeInspectionCertification
                    ),
                    It.IsAny<CancellationToken>()
                ),
            Times.Once
        );
    }

    [Fact]
    public async Task UpdateProperty_MapsAllBuildingAndMitigationDetails_ToCommand()
    {
        var sender = new Mock<ISender>();
        var userId = Guid.NewGuid();
        var propertyId = Guid.NewGuid();
        var rowVersion = new byte[] { 1, 2, 3, 4, 5, 6, 7, 8 };
        var rowVersionBase64 = Convert.ToBase64String(rowVersion);

        var requestContext = new Mock<IRequestContext>();
        requestContext.SetupGet(x => x.UserId).Returns(userId);

        sender
            .Setup(x => x.Send(It.IsAny<UpdatePropertyCommand>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(new CustomerMutationResult(rowVersionBase64));

        var controller = new CustomersController(sender.Object, requestContext.Object);
        var request = new UpdatePropertyOwnershipRequest(
            "123 Ocean Dr",
            "Apt 4B",
            "Miami",
            "FL",
            "33139",
            "United States",
            "Owned",
            new DateOnly(2021, 5, 10),
            true,
            rowVersionBase64,
            YearBuilt: 2020,
            ConstructionType: "Masonry",
            RiskZone: "B",
            StormShutters: true,
            ImpactResistantWindows: false,
            ReinforcedRoof: true,
            EmergencyGenerator: true,
            HomeInspectionCertification: false
        );

        var result = await controller.UpdateProperty(propertyId, request, CancellationToken.None);

        result.Should().BeOfType<OkObjectResult>();
        sender.Verify(
            x =>
                x.Send(
                    It.Is<UpdatePropertyCommand>(c =>
                        c.AuthUserId == userId
                        && c.PropertyOwnershipId == propertyId
                        && c.Property.AddressLine1 == "123 Ocean Dr"
                        && c.Property.AddressLine2 == "Apt 4B"
                        && c.Property.YearBuilt == 2020
                        && c.Property.ConstructionType == "Masonry"
                        && c.Property.RiskZone == "B"
                        && c.Property.StormShutters
                        && !c.Property.ImpactResistantWindows
                        && c.Property.ReinforcedRoof
                        && c.Property.EmergencyGenerator
                        && !c.Property.HomeInspectionCertification
                        && c.CustomerRowVersion.SequenceEqual(rowVersion)
                    ),
                    It.IsAny<CancellationToken>()
                ),
            Times.Once
        );
    }
}


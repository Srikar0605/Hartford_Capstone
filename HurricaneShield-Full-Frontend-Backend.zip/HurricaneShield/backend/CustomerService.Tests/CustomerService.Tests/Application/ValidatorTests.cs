using CustomerService.Application.Commands.Addresses;
using CustomerService.Application.Commands.Addresses.UpdateAddress;
using CustomerService.Application.Commands.CreateCustomerProfile;
using CustomerService.Application.Commands.EmergencyContacts;
using CustomerService.Application.Commands.Properties;
using CustomerService.Application.Queries.SearchCustomers;

namespace CustomerService.Tests.Application;

public sealed class ValidatorTests
{
    [Fact]
    public void AddressValidator_RejectsMissingRequiredFields()
    {
        var result = new AddressDetailsValidator().Validate(
            new AddressDetails("", null, "", "", "", "")
        );
        result.IsValid.Should().BeFalse();
    }

    [Theory]
    [InlineData("+91 98765 43210", true)]
    [InlineData("98765-43210", true)]
    [InlineData("abc", false)]
    public void EmergencyContactValidator_ValidatesPhoneCharacters(string phone, bool expected)
    {
        var result = new EmergencyContactDetailsValidator().Validate(
            new EmergencyContactDetails("Name", "Sibling", phone)
        );
        result.IsValid.Should().Be(expected);
    }

    [Fact]
    public void PropertyValidator_RejectsInvalidTypeAndFutureDate()
    {
        var result = new PropertyOwnershipDetailsValidator().Validate(
            new PropertyOwnershipDetails(
                "1",
                null,
                "C",
                "S",
                "P",
                "I",
                "Rented",
                DateOnly.FromDateTime(DateTime.UtcNow.AddDays(1)),
                false
            )
        );
        result.IsValid.Should().BeFalse();
    }

    [Theory]
    [InlineData(0, 20, false)]
    [InlineData(1, 0, false)]
    [InlineData(1, 101, false)]
    [InlineData(1, 100, true)]
    public void SearchValidator_EnforcesPaging(int page, int size, bool expected)
    {
        var result = new SearchCustomersQueryValidator().Validate(
            new SearchCustomersQuery(page, size, null, CustomerStatuses.Pending)
        );
        result.IsValid.Should().Be(expected);
    }

    [Fact]
    public void UpdateAddressValidator_RequiresEightByteRowVersion()
    {
        var command = new UpdateAddressCommand(
            Guid.NewGuid(),
            Guid.NewGuid(),
            new AddressDetails("1", null, "C", "S", "P", "I"),
            new byte[7]
        );
        new UpdateAddressCommandValidator().Validate(command).IsValid.Should().BeFalse();
    }

    [Fact]
    public void CreateProfileValidator_RejectsFutureBirthDate()
    {
        var command = new CreateCustomerProfileCommand(
            Guid.NewGuid(),
            "user@example.com",
            "A",
            "B",
            DateOnly.FromDateTime(DateTime.UtcNow.AddDays(1))
        );
        new CreateCustomerProfileCommandValidator().Validate(command).IsValid.Should().BeFalse();
    }
}


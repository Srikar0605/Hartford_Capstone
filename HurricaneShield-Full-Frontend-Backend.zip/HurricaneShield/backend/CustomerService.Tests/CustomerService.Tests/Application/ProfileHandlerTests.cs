using CustomerService.Application.Abstractions.History;
using CustomerService.Application.Abstractions.Time;
using CustomerService.Application.Commands.CreateCustomerProfile;
using CustomerService.Domain.Repositories;
using CustomerService.Tests.TestSupport;
using Shared.Common.Exceptions;

namespace CustomerService.Tests.Application;

public sealed class ProfileHandlerTests
{
    [Fact]
    public async Task Create_AddsCustomerHistory_AndSavesOnce()
    {
        var repository = new Mock<ICustomerRepository>();
        repository
            .Setup(x => x.AuthUserExistsAsync(It.IsAny<Guid>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(false);
        repository
            .Setup(x => x.EmailExistsAsync(It.IsAny<string>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(false);
        var history = new Mock<ICustomerHistoryWriter>();
        var unit = new Mock<IUnitOfWork>();
        unit.Setup(x => x.SaveChangesAsync(It.IsAny<CancellationToken>())).ReturnsAsync(2);
        var clock = new FakeClock();
        var handler = new CreateCustomerProfileCommandHandler(
            repository.Object,
            history.Object,
            unit.Object,
            clock
        );
        var id = Guid.NewGuid();

        var result = await handler.Handle(
            new CreateCustomerProfileCommand(
                id,
                "USER@EXAMPLE.COM",
                "A",
                "B",
                new DateOnly(1990, 1, 1)
            ),
            default
        );

        result.Status.Should().Be(CustomerStatuses.Pending);
        repository.Verify(
            x =>
                x.AddAsync(
                    It.Is<Customer>(c => c.Email == "user@example.com"),
                    It.IsAny<CancellationToken>()
                ),
            Times.Once
        );
        history.Verify(
            x =>
                x.WriteAsync(
                    It.IsAny<Guid>(),
                    CustomerHistoryTypes.ProfileCreated,
                    It.IsAny<object>(),
                    It.IsAny<CancellationToken>()
                ),
            Times.Once
        );
        unit.Verify(x => x.SaveChangesAsync(It.IsAny<CancellationToken>()), Times.Once);
    }

    [Fact]
    public async Task Create_WhenAuthUserExists_ThrowsConflictAndDoesNotSave()
    {
        var repository = new Mock<ICustomerRepository>();
        repository
            .Setup(x => x.AuthUserExistsAsync(It.IsAny<Guid>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(true);
        var unit = new Mock<IUnitOfWork>();
        var handler = new CreateCustomerProfileCommandHandler(
            repository.Object,
            Mock.Of<ICustomerHistoryWriter>(),
            unit.Object,
            new FakeClock()
        );
        var action = () =>
            handler.Handle(
                new CreateCustomerProfileCommand(
                    Guid.NewGuid(),
                    "a@b.com",
                    "A",
                    "B",
                    new DateOnly(1990, 1, 1)
                ),
                default
            );
        await action.Should().ThrowAsync<AppException>();
        unit.Verify(x => x.SaveChangesAsync(It.IsAny<CancellationToken>()), Times.Never);
    }
}


using CustomerService.Application.Abstractions.History;
using CustomerService.Application.Commands.Addresses;
using CustomerService.Application.Commands.Addresses.AddAddress;
using CustomerService.Application.Commands.EmergencyContacts;
using CustomerService.Application.Commands.EmergencyContacts.AddEmergencyContact;
using CustomerService.Application.Commands.Properties;
using CustomerService.Application.Commands.Properties.AddProperty;
using CustomerService.Domain.Repositories;
using CustomerService.Tests.TestSupport;

namespace CustomerService.Tests.Application;

public sealed class ChildMutationHandlerTests
{
    [Fact]
    public async Task AddAddress_WritesHistory_AndSavesOnce()
    {
        var customer = CustomerFactory.Create();
        var repo = new Mock<ICustomerRepository>();
        repo.Setup(x =>
                x.GetWithAddressesForUpdateAsync(customer.AuthUserId, It.IsAny<CancellationToken>())
            )
            .ReturnsAsync(customer);
        var history = new Mock<ICustomerHistoryWriter>();
        var unit = Unit();
        var handler = new AddAddressCommandHandler(
            repo.Object,
            history.Object,
            unit.Object,
            new FakeClock()
        );
        await handler.Handle(
            new AddAddressCommand(
                customer.AuthUserId,
                new AddressDetails("1 Main", null, "Mumbai", "MH", "400001", "India")
            ),
            default
        );
        customer.Addresses.Should().ContainSingle();
        history.Verify(
            x =>
                x.WriteAsync(
                    customer.Id,
                    CustomerHistoryTypes.AddressAdded,
                    It.IsAny<object>(),
                    It.IsAny<CancellationToken>()
                ),
            Times.Once
        );
        unit.Verify(x => x.SaveChangesAsync(It.IsAny<CancellationToken>()), Times.Once);
    }

    [Fact]
    public async Task AddEmergencyContact_WritesHistory_AndSavesOnce()
    {
        var customer = CustomerFactory.Create();
        var repo = new Mock<ICustomerRepository>();
        repo.Setup(x =>
                x.GetWithEmergencyContactsForUpdateAsync(
                    customer.AuthUserId,
                    It.IsAny<CancellationToken>()
                )
            )
            .ReturnsAsync(customer);
        var history = new Mock<ICustomerHistoryWriter>();
        var unit = Unit();
        var handler = new AddEmergencyContactCommandHandler(
            repo.Object,
            history.Object,
            unit.Object,
            new FakeClock()
        );
        await handler.Handle(
            new AddEmergencyContactCommand(
                customer.AuthUserId,
                new EmergencyContactDetails("A", "Sibling", "+91 99999 99999")
            ),
            default
        );
        customer.EmergencyContacts.Should().ContainSingle();
        history.Verify(
            x =>
                x.WriteAsync(
                    customer.Id,
                    CustomerHistoryTypes.EmergencyContactAdded,
                    It.IsAny<object>(),
                    It.IsAny<CancellationToken>()
                ),
            Times.Once
        );
        unit.Verify(x => x.SaveChangesAsync(It.IsAny<CancellationToken>()), Times.Once);
    }

    [Fact]
    public async Task AddProperty_EnforcesPrimaryInvariant_AndSavesOnce()
    {
        var customer = CustomerFactory.Create();
        customer.AddPropertyOwnership(
            "Old",
            null,
            "M",
            "MH",
            "1",
            "India",
            OwnershipTypes.Owned,
            new DateOnly(2020, 1, 1),
            true,
            DateTime.UtcNow,
            "user"
        );
        var repo = new Mock<ICustomerRepository>();
        repo.Setup(x =>
                x.GetWithPropertiesForUpdateAsync(
                    customer.AuthUserId,
                    It.IsAny<CancellationToken>()
                )
            )
            .ReturnsAsync(customer);
        var unit = Unit();
        var handler = new AddPropertyCommandHandler(
            repo.Object,
            Mock.Of<ICustomerHistoryWriter>(),
            unit.Object,
            new FakeClock()
        );
        await handler.Handle(
            new AddPropertyCommand(
                customer.AuthUserId,
                new PropertyOwnershipDetails(
                    "New",
                    null,
                    "M",
                    "MH",
                    "2",
                    "India",
                    OwnershipTypes.Mortgaged,
                    new DateOnly(2021, 1, 1),
                    true
                )
            ),
            default
        );
        customer.PropertyOwnerships.Count(x => x.IsPrimaryResidence).Should().Be(1);
        unit.Verify(x => x.SaveChangesAsync(It.IsAny<CancellationToken>()), Times.Once);
    }

    [Fact]
    public async Task AddProperty_PreservesBuildingCharacteristics_AndWritesDetailedHistory()
    {
        var customer = CustomerFactory.Create();
        var repo = new Mock<ICustomerRepository>();
        repo.Setup(x =>
                x.GetWithPropertiesForUpdateAsync(
                    customer.AuthUserId,
                    It.IsAny<CancellationToken>()
                )
            )
            .ReturnsAsync(customer);
        var history = new Mock<ICustomerHistoryWriter>();
        var unit = Unit();
        var handler = new AddPropertyCommandHandler(
            repo.Object,
            history.Object,
            unit.Object,
            new FakeClock()
        );

        var details = new PropertyOwnershipDetails(
            "100 Ocean Drive",
            "Suite 500",
            "Miami",
            "FL",
            "33139",
            "United States",
            OwnershipTypes.Owned,
            new DateOnly(2022, 3, 15),
            true,
            YearBuilt: 2019,
            ConstructionType: "SteelFrame",
            RiskZone: "A",
            StormShutters: true,
            ImpactResistantWindows: true,
            ReinforcedRoof: true,
            EmergencyGenerator: true,
            HomeInspectionCertification: true
        );

        var result = await handler.Handle(
            new AddPropertyCommand(customer.AuthUserId, details),
            default
        );

        result.Should().NotBeNull();
        customer.PropertyOwnerships.Should().ContainSingle();
        var prop = customer.PropertyOwnerships.Single();
        prop.YearBuilt.Should().Be(2019);
        prop.ConstructionType.Should().Be("SteelFrame");
        prop.RiskZone.Should().Be("A");
        prop.StormShutters.Should().BeTrue();
        prop.ImpactResistantWindows.Should().BeTrue();
        prop.ReinforcedRoof.Should().BeTrue();
        prop.EmergencyGenerator.Should().BeTrue();
        prop.HomeInspectionCertification.Should().BeTrue();

        history.Verify(
            x =>
                x.WriteAsync(
                    customer.Id,
                    CustomerHistoryTypes.PropertyAdded,
                    It.IsAny<object>(),
                    It.IsAny<CancellationToken>()
                ),
            Times.Once
        );
        unit.Verify(x => x.SaveChangesAsync(It.IsAny<CancellationToken>()), Times.Once);
    }

    private static Mock<IUnitOfWork> Unit()
    {
        var unit = new Mock<IUnitOfWork>();
        unit.Setup(x => x.SaveChangesAsync(It.IsAny<CancellationToken>())).ReturnsAsync(1);
        return unit;
    }
}


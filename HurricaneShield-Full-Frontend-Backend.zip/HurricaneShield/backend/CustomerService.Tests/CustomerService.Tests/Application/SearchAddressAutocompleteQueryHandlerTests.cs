using CustomerService.Application.Abstractions.Addresses;
using CustomerService.Application.DTOs;
using CustomerService.Application.Queries.SearchAddressAutocomplete;
using FluentAssertions;
using Moq;
using Xunit;

namespace CustomerService.Tests.Application;

public sealed class SearchAddressAutocompleteQueryHandlerTests
{
    [Fact]
    public async Task Handle_WithValidQuery_ReturnsSuggestionsFromService()
    {
        var service = new Mock<IAddressAutocompleteService>();
        var expected = new List<AddressSuggestionDto>
        {
            new(
                "100 Biscayne Blvd, Miami, FL 33132, United States",
                "100 Biscayne Blvd",
                "Miami",
                "Florida",
                "33132",
                "United States",
                25.77427,
                -80.18956
            )
        };

        service
            .Setup(x => x.SearchAsync("100 Biscayne", It.IsAny<CancellationToken>()))
            .ReturnsAsync(expected);

        var handler = new SearchAddressAutocompleteQueryHandler(service.Object);
        var result = await handler.Handle(
            new SearchAddressAutocompleteQuery("100 Biscayne"),
            CancellationToken.None
        );

        result.Should().BeEquivalentTo(expected);
        service.Verify(x => x.SearchAsync("100 Biscayne", It.IsAny<CancellationToken>()), Times.Once);
    }

    [Theory]
    [InlineData("")]
    [InlineData("   ")]
    [InlineData(null)]
    public async Task Handle_WithEmptyOrWhitespaceQuery_ReturnsEmptyWithoutCallingService(string? query)
    {
        var service = new Mock<IAddressAutocompleteService>();
        var handler = new SearchAddressAutocompleteQueryHandler(service.Object);

        var result = await handler.Handle(
            new SearchAddressAutocompleteQuery(query!),
            CancellationToken.None
        );

        result.Should().BeEmpty();
        service.Verify(x => x.SearchAsync(It.IsAny<string>(), It.IsAny<CancellationToken>()), Times.Never);
    }
}


using CustomerService.Application.Abstractions.Customers;
using CustomerService.Application.Abstractions.History;
using CustomerService.Application.Commands.CustomerStatus.ActivateCustomer;
using CustomerService.Application.Queries.GetCustomerEligibility;
using CustomerService.Domain.Repositories;
using CustomerService.Tests.TestSupport;
using Microsoft.AspNetCore.Http;
using Shared.Common.Exceptions;

namespace CustomerService.Tests.Application;

public sealed class StatusAndEligibilityHandlerTests
{
    [Fact]
    public async Task Activate_ChangesStatus_WritesHistory_AndSavesOnce()
    {
        var customer = CustomerFactory.Create();
        var repo = new Mock<ICustomerRepository>();
        repo.Setup(x => x.GetByIdForUpdateAsync(customer.Id, It.IsAny<CancellationToken>()))
            .ReturnsAsync(customer);
        var history = new Mock<ICustomerHistoryWriter>();
        var unit = new Mock<IUnitOfWork>();
        unit.Setup(x => x.SaveChangesAsync(It.IsAny<CancellationToken>())).ReturnsAsync(1);
        var handler = new ActivateCustomerCommandHandler(
            repo.Object,
            history.Object,
            unit.Object,
            new FakeClock()
        );
        var result = await handler.Handle(
            new ActivateCustomerCommand(Guid.NewGuid(), customer.Id, new byte[8]),
            default
        );
        result.Status.Should().Be(CustomerStatuses.Active);
        history.Verify(
            x =>
                x.WriteAsync(
                    customer.Id,
                    CustomerHistoryTypes.Activated,
                    It.IsAny<object>(),
                    It.IsAny<CancellationToken>()
                ),
            Times.Once
        );
        unit.Verify(x => x.SaveChangesAsync(It.IsAny<CancellationToken>()), Times.Once);
    }

    [Fact]
    public async Task RepeatedActivation_IsIdempotent_AndDoesNotWriteHistory()
    {
        var customer = CustomerFactory.Create();
        customer.Activate(DateTime.UtcNow, "admin");
        var repo = new Mock<ICustomerRepository>();
        repo.Setup(x => x.GetByIdForUpdateAsync(customer.Id, It.IsAny<CancellationToken>()))
            .ReturnsAsync(customer);
        var history = new Mock<ICustomerHistoryWriter>();
        var unit = new Mock<IUnitOfWork>();
        var handler = new ActivateCustomerCommandHandler(
            repo.Object,
            history.Object,
            unit.Object,
            new FakeClock()
        );
        await handler.Handle(
            new ActivateCustomerCommand(Guid.NewGuid(), customer.Id, new byte[8]),
            default
        );
        history.Verify(
            x =>
                x.WriteAsync(
                    It.IsAny<Guid>(),
                    It.IsAny<string>(),
                    It.IsAny<object>(),
                    It.IsAny<CancellationToken>()
                ),
            Times.Never
        );
        unit.Verify(x => x.SaveChangesAsync(It.IsAny<CancellationToken>()), Times.Never);
    }

    [Fact]
    public async Task Handle_CustomerOwnsProfile_ReturnsEligibility()
    {
        var customerId = Guid.NewGuid();
        var authUserId = Guid.NewGuid();

        var reader = new Mock<ICustomerAdministrationReader>();

        reader
            .Setup(x =>
                x.IsOwnedByAuthUserAsync(customerId, authUserId, It.IsAny<CancellationToken>())
            )
            .ReturnsAsync(true);

        reader
            .Setup(x => x.GetEligibilitySourceAsync(customerId, It.IsAny<CancellationToken>()))
            .ReturnsAsync(
                new CustomerEligibilitySource(
                    customerId,
                    authUserId,
                    CustomerStatuses.Active,
                    new DateOnly(1995, 1, 1),
                    "Test",
                    "Customer",
                    "customer@example.com"
                )
            );

        var handler = new GetCustomerEligibilityQueryHandler(
            reader.Object,
            new FakeClock { UtcNow = new DateTime(2026, 9, 29, 0, 0, 0, DateTimeKind.Utc) }
        );

        var result = await handler.Handle(
            new GetCustomerEligibilityQuery(customerId, authUserId, HasStaffAccess: false),
            CancellationToken.None
        );

        result.CustomerId.Should().Be(customerId);

        result.IsEligible.Should().BeTrue();

        reader.Verify(
            x => x.IsOwnedByAuthUserAsync(customerId, authUserId, It.IsAny<CancellationToken>()),
            Times.Once
        );
    }

    [Fact]
    public async Task Handle_CustomerDoesNotOwnProfile_ThrowsForbidden()
    {
        var customerId = Guid.NewGuid();
        var authUserId = Guid.NewGuid();

        var reader = new Mock<ICustomerAdministrationReader>();

        reader
            .Setup(x =>
                x.IsOwnedByAuthUserAsync(customerId, authUserId, It.IsAny<CancellationToken>())
            )
            .ReturnsAsync(false);

        var handler = new GetCustomerEligibilityQueryHandler(
            reader.Object,
            new FakeClock { UtcNow = new DateTime(2026, 9, 29, 0, 0, 0, DateTimeKind.Utc) }
        );

        var action = async () =>
            await handler.Handle(
                new GetCustomerEligibilityQuery(customerId, authUserId, HasStaffAccess: false),
                CancellationToken.None
            );

        var assertion = await action.Should().ThrowAsync<AppException>();

        assertion.Which.StatusCode.Should().Be(StatusCodes.Status403Forbidden);

        reader.Verify(
            x => x.GetEligibilitySourceAsync(It.IsAny<Guid>(), It.IsAny<CancellationToken>()),
            Times.Never
        );
    }

    [Theory]
    [InlineData("Active", 1990, true)]
    [InlineData("Pending", 1990, false)]
    [InlineData("Active", 2010, false)]
    public async Task Eligibility_UsesStatusAndAge(string status, int birthYear, bool expected)
    {
        var customerId = Guid.NewGuid();
        var requestingUserId = Guid.NewGuid();
        var authUserId = Guid.NewGuid();

        var reader = new Mock<ICustomerAdministrationReader>();

        reader
            .Setup(x => x.GetEligibilitySourceAsync(customerId, It.IsAny<CancellationToken>()))
            .ReturnsAsync(
                new CustomerEligibilitySource(
                    customerId,
                    authUserId,
                    status,
                    new DateOnly(birthYear, 1, 1),
                    "Test",
                    "Customer",
                    "customer@example.com"
                )
            );

        var handler = new GetCustomerEligibilityQueryHandler(
            reader.Object,
            new FakeClock { UtcNow = new DateTime(2026, 9, 29, 0, 0, 0, DateTimeKind.Utc) }
        );

        var result = await handler.Handle(
            new GetCustomerEligibilityQuery(customerId, requestingUserId, HasStaffAccess: true),
            CancellationToken.None
        );

        result.IsEligible.Should().Be(expected);

        if (!expected)
        {
            result.Reasons.Should().NotBeEmpty();
        }
    }
}


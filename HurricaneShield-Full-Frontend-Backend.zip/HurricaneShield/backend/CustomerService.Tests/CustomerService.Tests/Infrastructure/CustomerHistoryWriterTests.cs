using CustomerService.Application.Abstractions.Context;
using CustomerService.Domain.Repositories;
using CustomerService.Infrastructure.Services;
using CustomerService.Tests.TestSupport;

namespace CustomerService.Tests.Infrastructure;

public sealed class CustomerHistoryWriterTests
{
    [Fact]
    public async Task WriteAsync_StagesCamelCaseHistoryWithoutSaving()
    {
        var repository = new Mock<ICustomerRepository>();
        CustomerHistory? captured = null;
        repository
            .Setup(x =>
                x.AddHistoryAsync(It.IsAny<CustomerHistory>(), It.IsAny<CancellationToken>())
            )
            .Callback<CustomerHistory, CancellationToken>((h, _) => captured = h)
            .Returns(Task.CompletedTask);
        var context = new FakeRequestContext { Actor = "actor", CorrelationId = "corr" };
        var writer = new CustomerHistoryWriter(repository.Object, context, new FakeClock());
        await writer.WriteAsync(
            Guid.NewGuid(),
            CustomerHistoryTypes.ProfileUpdated,
            new { FirstName = "Bhanu" }
        );
        captured.Should().NotBeNull();
        captured!.ChangeData.Should().Contain("\"firstName\":\"Bhanu\"");
        captured.ChangedBy.Should().Be("actor");
        captured.CorrelationId.Should().Be("corr");
    }
}


using CustomerService.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace CustomerService.Tests.Infrastructure;

public sealed class CustomerModelTests
{
    private static CustomerDbContext Context()
    {
        var options = new DbContextOptionsBuilder<CustomerDbContext>()
            .UseInMemoryDatabase(Guid.NewGuid().ToString())
            .Options;
        return new CustomerDbContext(options);
    }

    [Fact]
    public void CustomerModel_HasConcurrencyAndUniqueIndexes()
    {
        using var context = Context();

        var entityType = context.Model.FindEntityType(typeof(Customer));

        entityType.Should().NotBeNull();

        var rowVersion = entityType!.FindProperty(nameof(Customer.RowVersion));

        rowVersion.Should().NotBeNull();

        rowVersion!.IsConcurrencyToken.Should().BeTrue();

        rowVersion.ValueGenerated.Should().Be(ValueGenerated.OnAddOrUpdate);

        var authUserIdIndex = entityType
            .GetIndexes()
            .SingleOrDefault(index =>
                index.Properties.Count == 1
                && index.Properties[0].Name == nameof(Customer.AuthUserId)
            );

        authUserIdIndex.Should().NotBeNull();

        authUserIdIndex!.IsUnique.Should().BeTrue();

        authUserIdIndex.GetDatabaseName().Should().Be("UQ_Customers_AuthUserId");

        var emailIndex = entityType
            .GetIndexes()
            .SingleOrDefault(index =>
                index.Properties.Count == 1 && index.Properties[0].Name == nameof(Customer.Email)
            );

        emailIndex.Should().NotBeNull();

        emailIndex!.IsUnique.Should().BeTrue();

        emailIndex.GetDatabaseName().Should().Be("UQ_Customers_Email");

        entityType.GetQueryFilter().Should().NotBeNull();
    }

    [Fact]
    public void ChildModels_HaveOwnerQueryFilters()
    {
        using var context = Context();
        context.Model.FindEntityType(typeof(Address))!.GetQueryFilter().Should().NotBeNull();
        context
            .Model.FindEntityType(typeof(EmergencyContact))!
            .GetQueryFilter()
            .Should()
            .NotBeNull();
        context
            .Model.FindEntityType(typeof(PropertyOwnership))!
            .GetQueryFilter()
            .Should()
            .NotBeNull();
    }

    [Fact]
    public void History_HasNoForeignKeyToCustomer()
    {
        using var context = Context();
        context.Model.FindEntityType(typeof(CustomerHistory))!.GetForeignKeys().Should().BeEmpty();
    }

    [Fact]
    public void AddPropertyOwnership_DuplicateAddress_ThrowsInvalidOperationException()
    {
        var customer = Customer.Create(
            Guid.NewGuid(),
            "John",
            "Doe",
            "john.doe@example.com",
            new DateOnly(1990, 1, 1),
            DateTime.UtcNow,
            "system"
        );

        customer.AddPropertyOwnership(
            "100 Main St",
            null,
            "Miami",
            "FL",
            "33101",
            "US",
            "Owned",
            new DateOnly(2020, 1, 1),
            true,
            DateTime.UtcNow,
            "system"
        );

        var action = () =>
            customer.AddPropertyOwnership(
                "100 Main St ", // case-insensitive, whitespace trimmed
                null,
                "miami",
                "fl",
                "33101",
                "US",
                "Owned",
                new DateOnly(2022, 1, 1),
                false,
                DateTime.UtcNow,
                "system"
            );

        action
            .Should()
            .Throw<InvalidOperationException>()
            .WithMessage("*already exists*");
    }
}


using CustomerService.Infrastructure.Persistence;
using CustomerService.Infrastructure.Repositories;
using CustomerService.Tests.TestSupport;
using Microsoft.EntityFrameworkCore;

namespace CustomerService.Tests.Infrastructure;

public sealed class ReaderAndRepositoryTests
{
    [Fact]
    public async Task ProfileReader_ReturnsProjection()
    {
        await using var context = Context();
        var customer = CustomerFactory.Create();
        context.Customers.Add(customer);
        await context.SaveChangesAsync();
        var result = await new CustomerProfileReader(context).GetByAuthUserIdAsync(
            customer.AuthUserId
        );
        result.Should().NotBeNull();
        result!.Email.Should().Be(customer.Email);
        context.ChangeTracker.Clear();
    }

    [Fact]
    public async Task AdministrationSearch_ReturnsStablePagedResult()
    {
        await using var context = Context();
        context.Customers.Add(CustomerFactory.Create(email: "one@example.com"));
        context.Customers.Add(CustomerFactory.Create(email: "two@example.com"));
        await context.SaveChangesAsync();
        var result = await new CustomerAdministrationReader(context).SearchAsync(
            1,
            1,
            null,
            CustomerStatuses.Pending
        );
        result.TotalCount.Should().Be(2);
        result.Items.Should().ContainSingle();
        result.TotalPages.Should().Be(2);
    }

    [Fact]
    public async Task Repository_DuplicateChecksIncludeSoftDeletedCustomers()
    {
        await using var context = Context();
        var customer = CustomerFactory.Create();
        customer.SoftDelete(DateTime.UtcNow, "admin");
        context.Customers.Add(customer);
        await context.SaveChangesAsync();
        var repository = new CustomerRepository(context);
        (await repository.AuthUserExistsAsync(customer.AuthUserId)).Should().BeTrue();
        (await repository.EmailExistsAsync(customer.Email)).Should().BeTrue();
    }

    private static CustomerDbContext Context()
    {
        var options = new DbContextOptionsBuilder<CustomerDbContext>()
            .UseInMemoryDatabase(Guid.NewGuid().ToString())
            .Options;
        return new CustomerDbContext(options);
    }
}


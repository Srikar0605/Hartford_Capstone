using System.Net;
using CustomerService.Infrastructure.Services;
using FluentAssertions;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using Moq;
using Moq.Protected;
using Xunit;

namespace CustomerService.Tests.Infrastructure;

public sealed class NominatimAddressAutocompleteServiceTests
{
    private readonly IMemoryCache _cache = new MemoryCache(new MemoryCacheOptions());
    private readonly Mock<ILogger<NominatimAddressAutocompleteService>> _logger = new();

    [Theory]
    [InlineData("")]
    [InlineData("a")]
    [InlineData("12")]
    public async Task SearchAsync_WithShortQuery_ReturnsEmptyWithoutHttpCall(string query)
    {
        var handler = new Mock<HttpMessageHandler>();
        var client = new HttpClient(handler.Object) { BaseAddress = new Uri("https://nominatim.openstreetmap.org/") };
        var service = new NominatimAddressAutocompleteService(client, _cache, _logger.Object);

        var result = await service.SearchAsync(query, CancellationToken.None);

        result.Should().BeEmpty();
        handler.Protected().Verify(
            "SendAsync",
            Times.Never(),
            ItExpr.IsAny<HttpRequestMessage>(),
            ItExpr.IsAny<CancellationToken>()
        );
    }

    [Fact]
    public async Task SearchAsync_WithValidJsonResponse_ParsesAddressComponentsCorrectly()
    {
        var jsonResponse = @"{
            ""type"": ""FeatureCollection"",
            ""features"": [
                {
                    ""type"": ""Feature"",
                    ""geometry"": {
                        ""coordinates"": [ -80.18956, 25.77427 ],
                        ""type"": ""Point""
                    },
                    ""properties"": {
                        ""housenumber"": ""100"",
                        ""street"": ""Biscayne Boulevard"",
                        ""city"": ""Miami"",
                        ""state"": ""Florida"",
                        ""postcode"": ""33132"",
                        ""country"": ""United States""
                    }
                }
            ]
        }";

        var handler = new Mock<HttpMessageHandler>();
        handler
            .Protected()
            .Setup<Task<HttpResponseMessage>>(
                "SendAsync",
                ItExpr.IsAny<HttpRequestMessage>(),
                ItExpr.IsAny<CancellationToken>()
            )
            .ReturnsAsync(new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.OK,
                Content = new StringContent(jsonResponse)
            });

        var client = new HttpClient(handler.Object) { BaseAddress = new Uri("https://photon.komoot.io/") };
        var service = new NominatimAddressAutocompleteService(client, _cache, _logger.Object);

        var result = await service.SearchAsync("100 Biscayne", CancellationToken.None);

        result.Should().HaveCount(1);
        var item = result.First();
        item.AddressLine1.Should().Be("100 Biscayne Boulevard");
        item.City.Should().Be("Miami");
        item.State.Should().Be("Florida");
        item.PostalCode.Should().Be("33132");
        item.Country.Should().Be("United States");
        item.Latitude.Should().Be(25.77427);
        item.Longitude.Should().Be(-80.18956);
    }

    [Fact]
    public async Task SearchAsync_WithApartmentPrefix_SanitizesQueryAndRestoresPrefixInResult()
    {
        var jsonResponse = @"{
            ""type"": ""FeatureCollection"",
            ""features"": [
                {
                    ""type"": ""Feature"",
                    ""geometry"": {
                        ""coordinates"": [ 77.6744, 12.9279 ],
                        ""type"": ""Point""
                    },
                    ""properties"": {
                        ""name"": ""Sobha Iris"",
                        ""city"": ""Bengaluru"",
                        ""state"": ""Karnataka"",
                        ""postcode"": ""560103"",
                        ""country"": ""India""
                    }
                }
            ]
        }";

        HttpRequestMessage? capturedRequest = null;
        var handler = new Mock<HttpMessageHandler>();
        handler
            .Protected()
            .Setup<Task<HttpResponseMessage>>(
                "SendAsync",
                ItExpr.IsAny<HttpRequestMessage>(),
                ItExpr.IsAny<CancellationToken>()
            )
            .Callback<HttpRequestMessage, CancellationToken>((req, _) => capturedRequest = req)
            .ReturnsAsync(new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.OK,
                Content = new StringContent(jsonResponse)
            });

        var client = new HttpClient(handler.Object) { BaseAddress = new Uri("https://photon.komoot.io/") };
        var service = new NominatimAddressAutocompleteService(client, _cache, _logger.Object);

        var result = await service.SearchAsync("Flat 402, Sobha Iris, Bengaluru", CancellationToken.None);

        result.Should().HaveCount(1);
        var item = result.First();
        item.AddressLine1.Should().Be("Flat 402, Sobha Iris");
        item.City.Should().Be("Bengaluru");
        item.Country.Should().Be("India");
        item.PostalCode.Should().Be("560103");

        capturedRequest.Should().NotBeNull();
        capturedRequest!.RequestUri!.Query.Should().NotContain("Flat%20402");
        capturedRequest.RequestUri.Query.Should().Contain("Sobha%20Iris");
    }

    [Fact]
    public async Task SearchAsync_OnHttpFailure_ReturnsEmptyGracefullyWithoutThrowing()
    {
        var handler = new Mock<HttpMessageHandler>();
        handler
            .Protected()
            .Setup<Task<HttpResponseMessage>>(
                "SendAsync",
                ItExpr.IsAny<HttpRequestMessage>(),
                ItExpr.IsAny<CancellationToken>()
            )
            .ReturnsAsync(new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.InternalServerError
            });

        var client = new HttpClient(handler.Object) { BaseAddress = new Uri("https://nominatim.openstreetmap.org/") };
        var service = new NominatimAddressAutocompleteService(client, _cache, _logger.Object);

        var result = await service.SearchAsync("500 Ocean Drive", CancellationToken.None);

        result.Should().BeEmpty();
    }
}


using PaymentService.Domain.Enums;

namespace PaymentService.Domain.Models;

public sealed record PaymentGatewayRequest(
    Guid TransactionId,
    PaymentType Type,
    decimal Amount,
    bool SimulateFailure
);


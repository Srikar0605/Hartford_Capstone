namespace PaymentService.Domain.Models;

public sealed record PaymentGatewayResult(
    bool Successful,
    string ResponseCode,
    string ResponseMessage
);


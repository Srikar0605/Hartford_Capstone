namespace PaymentService.Domain.Common;

public abstract class AggregateRoot
{
    public Guid Id { get; protected set; }
    public DateTime CreatedAt { get; protected set; }
    public string CreatedBy { get; protected set; } = string.Empty;
    public DateTime? UpdatedAt { get; protected set; }
    public string? UpdatedBy { get; protected set; }
    public bool IsDeleted { get; protected set; }
    public DateTime? DeletedAt { get; protected set; }
    public string? DeletedBy { get; protected set; }
    public byte[] RowVersion { get; private set; } = Array.Empty<byte>();

    protected AggregateRoot() { }

    protected void Initialize(Guid id, DateTime createdAt, string createdBy)
    {
        DomainGuard.NotEmpty(id, nameof(id));
        Id = id;
        CreatedAt = DomainGuard.Utc(createdAt, nameof(createdAt));
        CreatedBy = DomainGuard.Required(createdBy, nameof(createdBy), 200);
    }

    protected void MarkUpdated(DateTime updatedAt, string updatedBy)
    {
        UpdatedAt = DomainGuard.Utc(updatedAt, nameof(updatedAt));
        UpdatedBy = DomainGuard.Required(updatedBy, nameof(updatedBy), 200);
    }

    public void SoftDelete(DateTime deletedAt, string deletedBy)
    {
        if (IsDeleted)
            return;
        IsDeleted = true;
        DeletedAt = DomainGuard.Utc(deletedAt, nameof(deletedAt));
        DeletedBy = DomainGuard.Required(deletedBy, nameof(deletedBy), 200);
        MarkUpdated(deletedAt, deletedBy);
    }
}


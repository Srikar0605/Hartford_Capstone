using PaymentService.Domain.Exceptions;

namespace PaymentService.Domain.Common;

internal static class DomainGuard
{
    internal static void NotEmpty(Guid value, string name)
    {
        if (value == Guid.Empty)
            throw new DomainRuleException($"{name} is required.");
    }

    internal static string Required(string? value, string name, int maximumLength)
    {
        if (string.IsNullOrWhiteSpace(value))
            throw new DomainRuleException($"{name} is required.");
        var normalized = value.Trim();
        if (normalized.Length > maximumLength)
            throw new DomainRuleException($"{name} cannot exceed {maximumLength} characters.");
        return normalized;
    }

    internal static string? Optional(string? value, string name, int maximumLength)
    {
        if (string.IsNullOrWhiteSpace(value))
            return null;
        var normalized = value.Trim();
        if (normalized.Length > maximumLength)
            throw new DomainRuleException($"{name} cannot exceed {maximumLength} characters.");
        return normalized;
    }

    internal static DateTime Utc(DateTime value, string name)
    {
        if (value.Kind != DateTimeKind.Utc)
            throw new DomainRuleException($"{name} must be UTC.");
        return value;
    }
}


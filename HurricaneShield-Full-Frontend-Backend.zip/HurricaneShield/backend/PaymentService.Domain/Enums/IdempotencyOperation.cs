namespace PaymentService.Domain.Enums;

public enum IdempotencyOperation
{
    PremiumPayment,
    ClaimSettlement,
    RefundProcessing,
}


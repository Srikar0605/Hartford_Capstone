namespace PaymentService.Domain.Enums;

public enum PaymentType
{
    Premium,
    ClaimSettlement,
    Refund,
}


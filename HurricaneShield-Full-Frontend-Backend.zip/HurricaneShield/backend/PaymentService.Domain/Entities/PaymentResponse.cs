using PaymentService.Domain.Common;
using PaymentService.Domain.Enums;

namespace PaymentService.Domain.Entities;

public sealed class PaymentResponse
{
    public Guid Id { get; private set; }
    public Guid RequestId { get; private set; }
    public string ResponseCode { get; private set; } = string.Empty;
    public PaymentStatus ResponseStatus { get; private set; }
    public string ResponseMessage { get; private set; } = string.Empty;
    public DateTime ProcessedAt { get; private set; }

    private PaymentResponse() { }

    public static PaymentResponse Create(
        Guid requestId,
        string responseCode,
        PaymentStatus status,
        string responseMessage,
        DateTime processedAt
    )
    {
        DomainGuard.NotEmpty(requestId, nameof(requestId));
        if (status == PaymentStatus.Pending)
            throw new Exceptions.DomainRuleException("A gateway response cannot remain pending.");
        return new PaymentResponse
        {
            Id = Guid.NewGuid(),
            RequestId = requestId,
            ResponseCode = DomainGuard.Required(responseCode, nameof(responseCode), 100),
            ResponseStatus = status,
            ResponseMessage = DomainGuard.Required(responseMessage, nameof(responseMessage), 1000),
            ProcessedAt = DomainGuard.Utc(processedAt, nameof(processedAt)),
        };
    }
}


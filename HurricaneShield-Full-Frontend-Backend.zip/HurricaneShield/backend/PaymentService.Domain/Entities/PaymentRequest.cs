using PaymentService.Domain.Common;
using PaymentService.Domain.Exceptions;

namespace PaymentService.Domain.Entities;

public sealed class PaymentRequest
{
    public Guid Id { get; private set; }
    public Guid TransactionId { get; private set; }
    public string RequestType { get; private set; } = string.Empty;
    public string IdempotencyKey { get; private set; } = string.Empty;
    public string RequestPayload { get; private set; } = string.Empty;
    public DateTime CreatedAt { get; private set; }

    private PaymentRequest() { }

    public static PaymentRequest Create(
        Guid transactionId,
        string requestType,
        string idempotencyKey,
        string requestPayload,
        DateTime createdAt
    )
    {
        DomainGuard.NotEmpty(transactionId, nameof(transactionId));
        return new PaymentRequest
        {
            Id = Guid.NewGuid(),
            TransactionId = transactionId,
            RequestType = DomainGuard.Required(requestType, nameof(requestType), 50),
            IdempotencyKey = DomainGuard.Required(idempotencyKey, nameof(idempotencyKey), 200),
            RequestPayload = DomainGuard.Required(requestPayload, nameof(requestPayload), 4000),
            CreatedAt = DomainGuard.Utc(createdAt, nameof(createdAt)),
        };
    }
}


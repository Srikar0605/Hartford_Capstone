using PaymentService.Domain.Common;
using PaymentService.Domain.Enums;
using PaymentService.Domain.Exceptions;
using PaymentService.Domain.Models;

namespace PaymentService.Domain.Entities;

/// <summary>
/// Aggregate root representing an immutable financial transaction in the platform.
/// Handles two monetary flows: customer inbound premium collections and outbound claim settlements.
/// Enforces a strict state machine: Pending -> Success / Failed. Failed payments can be reset to Pending
/// via BeginRetry to support controlled payment recovery without creating untracked duplicate records.
/// </summary>
public sealed class PaymentTransaction : AggregateRoot
{
    public string TransactionNumber { get; private set; } = string.Empty;
    public PaymentType Type { get; private set; }
    public Guid? AuthUserId { get; private set; }
    public Guid? CustomerId { get; private set; }
    public Guid? PolicyId { get; private set; }
    public Guid? ClaimId { get; private set; }
    public decimal Amount { get; private set; }
    public PaymentStatus Status { get; private set; }
    public string? FailureReason { get; private set; }
    public DateTime TransactionDate { get; private set; }

    private PaymentTransaction() { }

    /// <summary>
    /// Factory for customer policy premium payments.
    /// Requires non-empty AuthUserId, CustomerId, and PolicyId references.
    /// </summary>
    public static PaymentTransaction CreatePremium(
        string transactionNumber,
        Guid authUserId,
        Guid customerId,
        Guid policyId,
        decimal amount,
        DateTime createdAt,
        string createdBy
    )
    {
        DomainGuard.NotEmpty(authUserId, nameof(authUserId));
        DomainGuard.NotEmpty(customerId, nameof(customerId));
        DomainGuard.NotEmpty(policyId, nameof(policyId));
        return Create(
            transactionNumber,
            PaymentType.Premium,
            authUserId,
            customerId,
            policyId,
            null,
            amount,
            createdAt,
            createdBy
        );
    }

    /// <summary>
    /// Factory for outbound claim settlement payouts.
    /// Requires ClaimId, PolicyId, and CustomerId to link disbursement to verified loss records.
    /// </summary>
    public static PaymentTransaction CreateSettlement(
        string transactionNumber,
        Guid authUserId,
        Guid customerId,
        Guid policyId,
        Guid claimId,
        decimal amount,
        DateTime createdAt,
        string createdBy
    )
    {
        DomainGuard.NotEmpty(customerId, nameof(customerId));
        DomainGuard.NotEmpty(policyId, nameof(policyId));
        DomainGuard.NotEmpty(claimId, nameof(claimId));
        return Create(
            transactionNumber,
            PaymentType.ClaimSettlement,
            authUserId,
            customerId,
            policyId,
            claimId,
            amount,
            createdAt,
            createdBy
        );
    }

    /// <summary>
    /// Factory for unearned premium refunds on policy cancellation.
    /// </summary>
    public static PaymentTransaction CreateRefund(
        string transactionNumber,
        Guid authUserId,
        Guid customerId,
        Guid policyId,
        decimal amount,
        DateTime createdAt,
        string createdBy
    )
    {
        DomainGuard.NotEmpty(customerId, nameof(customerId));
        DomainGuard.NotEmpty(policyId, nameof(policyId));
        return Create(
            transactionNumber,
            PaymentType.Refund,
            authUserId == Guid.Empty ? null : authUserId,
            customerId,
            policyId,
            null,
            amount,
            createdAt,
            createdBy
        );
    }


    private static PaymentTransaction Create(
        string transactionNumber,
        PaymentType type,
        Guid? authUserId,
        Guid? customerId,
        Guid? policyId,
        Guid? claimId,
        decimal amount,
        DateTime createdAt,
        string createdBy
    )
    {
        if (amount <= 0m)
            throw new DomainRuleException("Payment amount must be greater than zero.");
        var transaction = new PaymentTransaction
        {
            TransactionNumber = DomainGuard.Required(
                transactionNumber,
                nameof(transactionNumber),
                50
            ),
            Type = type,
            AuthUserId = authUserId,
            CustomerId = customerId,
            PolicyId = policyId,
            ClaimId = claimId,
            Amount = amount,
            Status = PaymentStatus.Pending,
            TransactionDate = DomainGuard.Utc(createdAt, nameof(createdAt)),
        };
        transaction.Initialize(Guid.NewGuid(), createdAt, createdBy);
        return transaction;
    }

    public void ApplyGatewayResult(PaymentGatewayResult result, DateTime processedAt, string actor)
    {
        if (Status != PaymentStatus.Pending)
            throw new DomainRuleException("Only a pending payment can be processed.");
        if (result.Successful)
        {
            Status = PaymentStatus.Success;
            FailureReason = null;
        }
        else
        {
            Status = PaymentStatus.Failed;
            FailureReason = DomainGuard.Required(
                result.ResponseMessage,
                nameof(result.ResponseMessage),
                1000
            );
        }
        TransactionDate = DomainGuard.Utc(processedAt, nameof(processedAt));
        MarkUpdated(processedAt, actor);
    }

    public void BeginRetry(DateTime retriedAt, string actor)
    {
        if (Status != PaymentStatus.Failed)
            throw new DomainRuleException("Only a failed payment can be retried.");
        Status = PaymentStatus.Pending;
        FailureReason = null;
        MarkUpdated(retriedAt, actor);
    }
}


using PaymentService.Domain.Common;
using PaymentService.Domain.Enums;

namespace PaymentService.Domain.Entities;

public sealed class IdempotencyRecord
{
    public Guid Id { get; private set; }
    public IdempotencyOperation Operation { get; private set; }
    public string Key { get; private set; } = string.Empty;
    public string RequestHash { get; private set; } = string.Empty;
    public int ResponseStatusCode { get; private set; }
    public string ResponseBody { get; private set; } = string.Empty;
    public Guid? ResourceId { get; private set; }
    public DateTime CreatedAt { get; private set; }
    public DateTime ExpiresAt { get; private set; }

    private IdempotencyRecord() { }

    public static IdempotencyRecord Create(
        IdempotencyOperation operation,
        string key,
        string requestHash,
        int responseStatusCode,
        string responseBody,
        Guid? resourceId,
        DateTime createdAt
    )
    {
        createdAt = DomainGuard.Utc(createdAt, nameof(createdAt));
        return new IdempotencyRecord
        {
            Id = Guid.NewGuid(),
            Operation = operation,
            Key = DomainGuard.Required(key, nameof(key), 200),
            RequestHash = DomainGuard.Required(requestHash, nameof(requestHash), 128),
            ResponseStatusCode = responseStatusCode,
            ResponseBody = DomainGuard.Required(responseBody, nameof(responseBody), int.MaxValue),
            ResourceId = resourceId,
            CreatedAt = createdAt,
            ExpiresAt = createdAt.AddHours(24),
        };
    }
}


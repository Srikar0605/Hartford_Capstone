using PaymentService.Domain.Common;
using PaymentService.Domain.Exceptions;

namespace PaymentService.Domain.Entities;

public sealed class PaymentReceipt
{
    public Guid Id { get; private set; }
    public Guid TransactionId { get; private set; }
    public string ReceiptNumber { get; private set; } = string.Empty;
    public DateTime GeneratedAt { get; private set; }
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private PaymentReceipt() { }

    public static PaymentReceipt Create(
        PaymentTransaction transaction,
        string receiptNumber,
        DateTime generatedAt,
        string createdBy
    )
    {
        if (transaction.Status != Enums.PaymentStatus.Success)
            throw new DomainRuleException(
                "A receipt can only be created for a successful payment."
            );
        return new PaymentReceipt
        {
            Id = Guid.NewGuid(),
            TransactionId = transaction.Id,
            ReceiptNumber = DomainGuard.Required(receiptNumber, nameof(receiptNumber), 50),
            GeneratedAt = DomainGuard.Utc(generatedAt, nameof(generatedAt)),
            CreatedAt = generatedAt,
            CreatedBy = DomainGuard.Required(createdBy, nameof(createdBy), 200),
        };
    }
}


using AuthService.API.Contracts.Auth;
using AuthService.Application.Commands.AssignUserRole;
using AuthService.Application.Commands.CompletePasswordReset;
using AuthService.Application.Commands.ConfirmMfa;
using AuthService.Application.Commands.DisableMfa;
using AuthService.Application.Commands.EnableMfa;
using AuthService.Application.Commands.Login;
using AuthService.Application.Commands.Logout;
using AuthService.Application.Commands.RefreshAccessToken;
using AuthService.Application.Commands.RegisterUser;
using AuthService.Application.Commands.RemoveUserRole;
using AuthService.Application.Commands.RequestPasswordReset;
using AuthService.Application.Commands.VerifyMfa;
using AuthService.Application.Queries.GetCurrentUser;
using AuthService.Application.Queries.GetLoginActivity;
using AuthService.Application.Queries.SearchUsers;
using AuthService.Domain.Constants;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Shared.Common.Errors;
using Shared.Common.Exceptions;
using Shared.Common.Responses;

namespace AuthService.API.Controllers;

/// <summary>
/// REST controller managing platform authentication, user registration, MFA, and RBAC governance.
/// In AuthService, we use Clean Architecture with MediatR: the controller delegates to ISender,
/// isolating identity orchestration into specialized command and query handlers while wrapping
/// responses in our standardized ApiResponse envelope.
/// </summary>
[ApiController]
[Route("api/v1/auth")]
public sealed class AuthController : ControllerBase
{
    private readonly ISender _sender;
    private readonly IHostEnvironment _environment;

    public AuthController(ISender sender, IHostEnvironment environment)
    {
        _sender = sender;
        _environment = environment;
    }

    /// <summary>
    /// Registers a new customer user account and initializes security credentials.
    /// </summary>
    [AllowAnonymous]
    [HttpPost("register")]
    [ProducesResponseType(typeof(ApiResponse<RegisterUserResult>), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Register(
        RegisterUserRequest request,
        CancellationToken cancellationToken
    )
    {
        var command = new RegisterUserCommand(
            request.Email,
            request.Password,
            request.FirstName,
            request.LastName
        );

        var result = await _sender.Send(command, cancellationToken);

        var response = ApiResponse<RegisterUserResult>.Succeed(
            result,
            "User registered successfully"
        );

        return StatusCode(StatusCodes.Status201Created, response);
    }

    /// <summary>
    /// Authenticates user credentials. If TOTP MFA is configured, returns an ephemeral challenge
    /// instead of JWT tokens, requiring a second-step verification call.
    /// </summary>
    [AllowAnonymous]
    [HttpPost("login")]
    [ProducesResponseType(typeof(ApiResponse<LoginResult>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status423Locked)]
    public async Task<IActionResult> Login(
        LoginRequest request,
        CancellationToken cancellationToken
    )
    {
        var deviceCookie = Request.Cookies["hs_trusted_device"];

        var command = new LoginCommand(
            request.Email,
            request.Password,
            request.RememberMe,
            deviceCookie
        );

        var result = await _sender.Send(command, cancellationToken);

        if (!string.IsNullOrWhiteSpace(result.TrustedDeviceToken))
        {
            Response.Cookies.Append(
                "hs_trusted_device",
                result.TrustedDeviceToken,
                new CookieOptions
                {
                    HttpOnly = true,
                    Secure = true,
                    SameSite = SameSiteMode.Strict,
                    Expires = DateTimeOffset.UtcNow.AddDays(30)
                }
            );
        }

        var message = result.MfaRequired ? "MFA verification required" : "Login successful";

        return Ok(ApiResponse<LoginResult>.Succeed(result, message));
    }


    [Authorize]
    [HttpPost("logout")]
    [ProducesResponseType(typeof(ApiResponse<object?>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status401Unauthorized)]
    public async Task<IActionResult> Logout(
        LogoutRequest request,
        CancellationToken cancellationToken
    )
    {
        var userIdClaim = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;

        if (!Guid.TryParse(userIdClaim, out var userId))
        {
            throw new AppException(
                StatusCodes.Status401Unauthorized,
                ErrorCodes.AuthInvalidToken,
                "Access token is invalid."
            );
        }

        await _sender.Send(new LogoutCommand(request.RefreshToken, userId), cancellationToken);

        return Ok(ApiResponse<object?>.Succeed(null, "Logout successful"));
    }

    [AllowAnonymous]
    [HttpPost("refresh-token")]
    [ProducesResponseType(typeof(ApiResponse<RefreshAccessTokenResult>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status401Unauthorized)]
    public async Task<IActionResult> RefreshToken(
        RefreshTokenRequest request,
        CancellationToken cancellationToken
    )
    {
        var result = await _sender.Send(
            new RefreshAccessTokenCommand(request.RefreshToken),
            cancellationToken
        );

        return Ok(
            ApiResponse<RefreshAccessTokenResult>.Succeed(result, "Token refreshed successfully")
        );
    }

    [Authorize]
    [HttpPost("mfa/enable")]
    public async Task<IActionResult> EnableMfa(CancellationToken cancellationToken)
    {
        var result = await _sender.Send(
            new EnableMfaCommand(GetAuthenticatedUserId()),
            cancellationToken
        );

        return Ok(ApiResponse<EnableMfaResult>.Succeed(result, "MFA enrollment started"));
    }

    [Authorize]
    [HttpPost("mfa/confirm")]
    public async Task<IActionResult> ConfirmMfa(
        ConfirmMfaRequest request,
        CancellationToken cancellationToken
    )
    {
        var result = await _sender.Send(
            new ConfirmMfaCommand(GetAuthenticatedUserId(), request.VerificationCode),
            cancellationToken
        );

        return Ok(ApiResponse<ConfirmMfaResult>.Succeed(result, "MFA enabled successfully"));
    }

    [Authorize]
    [HttpPost("mfa/disable")]
    public async Task<IActionResult> DisableMfa(
        DisableMfaRequest request,
        CancellationToken cancellationToken
    )
    {
        await _sender.Send(
            new DisableMfaCommand(
                GetAuthenticatedUserId(),
                request.CurrentPassword,
                request.VerificationCode
            ),
            cancellationToken
        );

        return Ok(ApiResponse<object?>.Succeed(null, "MFA disabled successfully"));
    }

    [Authorize]
    [HttpGet("login-activity")]
    public async Task<IActionResult> GetLoginActivity(CancellationToken cancellationToken)
    {
        var result = await _sender.Send(
            new GetLoginActivityQuery(GetAuthenticatedUserId()),
            cancellationToken
        );

        return Ok(ApiResponse<IReadOnlyCollection<LoginActivityResult>>.Succeed(result));
    }

    [Authorize]
    [HttpGet("/api/v1/auth/me")]
    public async Task<IActionResult> GetCurrentUser(CancellationToken cancellationToken)
    {
        var result = await _sender.Send(
            new GetCurrentUserQuery(GetAuthenticatedUserId()),
            cancellationToken
        );

        return Ok(ApiResponse<GetCurrentUserResult>.Succeed(result));
    }

    [AllowAnonymous]
    [HttpPost("mfa/verify")]
    public async Task<IActionResult> VerifyMfa(
        VerifyMfaRequest request,
        CancellationToken cancellationToken
    )
    {
        var result = await _sender.Send(
            new VerifyMfaCommand(request.MfaChallengeToken, request.VerificationCode),
            cancellationToken
        );

        return Ok(ApiResponse<VerifyMfaResult>.Succeed(result, "Authentication successful"));
    }

    [AllowAnonymous]
    [HttpPost("mfa/recovery")]
    public async Task<IActionResult> VerifyRecoveryCode(
        RecoveryCodeRequest request,
        CancellationToken cancellationToken
    )
    {
        var result = await _sender.Send(
            new VerifyRecoveryCodeCommand(request.Email, request.RecoveryCode),
            cancellationToken
        );

        return Ok(
            ApiResponse<VerifyRecoveryCodeResult>.Succeed(result, "Authentication successful")
        );
    }

    [AllowAnonymous]
    [HttpPost("password-reset/request")]
    public async Task<IActionResult> RequestPasswordReset(
        PasswordResetRequest request,
        CancellationToken cancellationToken
    )
    {
        var result = await _sender.Send(
            new RequestPasswordResetCommand(request.Email),
            cancellationToken
        );

        object responseData = _environment.IsDevelopment()
            ? new { developmentToken = result.DevelopmentToken }
            : new { };

        return Ok(ApiResponse<object>.Succeed(responseData, "Password reset initiated"));
    }

    [AllowAnonymous]
    [HttpPost("password-reset/confirm")]
    public async Task<IActionResult> CompletePasswordReset(
        CompletePasswordResetRequest request,
        CancellationToken cancellationToken
    )
    {
        await _sender.Send(
            new CompletePasswordResetCommand(request.Token, request.NewPassword),
            cancellationToken
        );

        return Ok(ApiResponse<object?>.Succeed(null, "Password reset successful"));
    }

    [Authorize(Policy = SystemPermissions.ManageRoles)]
    [HttpGet("users")]
    public async Task<IActionResult> SearchUsers(
        [FromQuery] int page = 1,
        [FromQuery] int pageSize = 20,
        [FromQuery] string? search = null,
        [FromQuery] string? role = null,
        [FromQuery] bool? isActive = null,
        CancellationToken cancellationToken = default
    )
    {
        var result = await _sender.Send(
            new SearchUsersQuery(page, pageSize, search, role, isActive),
            cancellationToken
        );

        return Ok(ApiResponse<AuthUserSearchResponse>.Succeed(result));
    }

    [Authorize(Policy = SystemPermissions.ManageRoles)]
    [HttpPut("users/{userId:guid}/role")]
    public async Task<IActionResult> AssignRole(
        Guid userId,
        AssignUserRoleRequest request,
        CancellationToken cancellationToken
    )
    {
        await _sender.Send(
            new AssignUserRoleCommand(GetAuthenticatedUserId(), userId, request.RoleName),
            cancellationToken
        );

        return Ok(ApiResponse<object?>.Succeed(null, "Role assigned successfully"));
    }

    [Authorize(Policy = SystemPermissions.ManageRoles)]
    [HttpDelete("users/{userId:guid}/roles/{roleName}")]
    [ProducesResponseType(typeof(ApiResponse<object?>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status409Conflict)]
    public async Task<IActionResult> RemoveRole(
        Guid userId,
        string roleName,
        CancellationToken cancellationToken
    )
    {
        await _sender.Send(
            new RemoveUserRoleCommand(GetAuthenticatedUserId(), userId, roleName),
            cancellationToken
        );

        return Ok(ApiResponse<object?>.Succeed(null, "Role removed successfully"));
    }

    private Guid GetAuthenticatedUserId()
    {
        var value = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;

        if (!Guid.TryParse(value, out var userId))
        {
            throw new AppException(
                StatusCodes.Status401Unauthorized,
                ErrorCodes.AuthInvalidToken,
                "Access token is invalid."
            );
        }

        return userId;
    }
}


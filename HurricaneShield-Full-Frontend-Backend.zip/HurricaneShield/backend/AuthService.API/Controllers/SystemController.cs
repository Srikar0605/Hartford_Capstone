using Microsoft.AspNetCore.Mvc;
using Shared.Common.Responses;

namespace AuthService.API.Controllers;

[ApiController]
[Route("api/v1/system")]
public sealed class SystemController : ControllerBase
{
    [HttpGet("status")]
    [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status200OK)]
    public IActionResult GetStatus()
    {
        var data = new { service = "AuthService", status = "Running" };

        return Ok(ApiResponse<object>.Succeed(data, "Auth Service is running"));
    }
}


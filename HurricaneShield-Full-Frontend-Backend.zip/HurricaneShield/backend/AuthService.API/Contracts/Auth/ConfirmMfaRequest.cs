namespace AuthService.API.Contracts.Auth;

public sealed record ConfirmMfaRequest(string VerificationCode);


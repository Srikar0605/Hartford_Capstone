namespace AuthService.API.Contracts.Auth;

public sealed record DisableMfaRequest(string CurrentPassword, string VerificationCode);


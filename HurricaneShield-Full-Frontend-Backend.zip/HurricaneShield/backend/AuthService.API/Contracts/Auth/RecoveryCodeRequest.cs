namespace AuthService.API.Contracts.Auth;

public sealed record RecoveryCodeRequest(string Email, string RecoveryCode);


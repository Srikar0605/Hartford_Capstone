namespace AuthService.API.Contracts.Auth;

public sealed record VerifyMfaRequest(string MfaChallengeToken, string VerificationCode);


namespace AuthService.API.Contracts.Auth;

public sealed record AssignUserRoleRequest(string RoleName);


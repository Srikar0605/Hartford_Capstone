namespace AuthService.API.Contracts.Auth;

public sealed record PasswordResetRequest(string Email);


namespace AuthService.API.Contracts.Auth;

public sealed record CompletePasswordResetRequest(string Token, string NewPassword);


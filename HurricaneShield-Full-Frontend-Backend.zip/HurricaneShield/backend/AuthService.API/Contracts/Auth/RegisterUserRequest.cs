namespace AuthService.API.Contracts.Auth;

public sealed record RegisterUserRequest(
    string Email,
    string Password,
    string FirstName,
    string LastName
);


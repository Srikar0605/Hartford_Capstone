using Microsoft.AspNetCore.Http;

namespace PolicyService.Infrastructure.Clients;

public sealed class ForwardingHandler : DelegatingHandler
{
    private readonly IHttpContextAccessor _context;

    public ForwardingHandler(IHttpContextAccessor context) => _context = context;

    protected override async Task<HttpResponseMessage> SendAsync(
        HttpRequestMessage request,
        CancellationToken cancellationToken
    )
    {
        var source = _context.HttpContext?.Request;
        if (source?.Headers.TryGetValue("Authorization", out var auth) == true)
            request.Headers.TryAddWithoutValidation("Authorization", auth.ToString());
        if (source?.Headers.TryGetValue("X-Correlation-Id", out var correlation) == true)
            request.Headers.TryAddWithoutValidation("X-Correlation-Id", correlation.ToString());
        return await base.SendAsync(request, cancellationToken);
    }
}


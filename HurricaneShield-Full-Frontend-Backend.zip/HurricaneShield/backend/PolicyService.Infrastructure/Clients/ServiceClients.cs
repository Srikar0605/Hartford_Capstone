using System.Net;
using System.Net.Http.Json;
using PolicyService.Application.DTOs.Integrations;
using PolicyService.Application.Interfaces;
using Microsoft.Extensions.Options;
using PolicyService.Infrastructure.Configuration;
using PolicyService.Infrastructure.Exceptions;

namespace PolicyService.Infrastructure.Clients;

internal sealed record ApiEnvelope<T>(
    bool Success,
    string Message,
    T? Data,
    string? ErrorCode,
    string? CorrelationId
);

public sealed class CustomerEligibilityClient : ICustomerEligibilityClient
{
    private readonly HttpClient _http;

    public CustomerEligibilityClient(HttpClient http) => _http = http;

    public async Task<CustomerEligibilityResponse> GetEligibilityAsync(
        Guid customerId,
        CancellationToken ct
    )
    {
        using var response = await _http.GetAsync($"api/v1/customers/{customerId}/eligibility", ct);
        if (response.StatusCode == HttpStatusCode.NotFound)
            throw PolicyServiceException.NotFound("CUSTOMER_NOT_FOUND", "Customer was not found.");
        if (!response.IsSuccessStatusCode)
            throw PolicyServiceException.Unavailable("Customer Service is unavailable.");
        var envelope = await response.Content.ReadFromJsonAsync<
            ApiEnvelope<CustomerEligibilityResponse>
        >(cancellationToken: ct);
        return envelope?.Data
            ?? throw PolicyServiceException.Unavailable(
                "Customer eligibility response was invalid."
            );
    }

    public async Task<IReadOnlyCollection<CustomerPropertyResponse>> GetCustomerPropertiesAsync(
        Guid customerId,
        CancellationToken ct
    )
    {
        // Since ForwardingHandler forwards the customer's JWT, we can hit the /me endpoint
        using var response = await _http.GetAsync("api/v1/customers/me/properties", ct);
        
        if (!response.IsSuccessStatusCode)
            throw PolicyServiceException.Unavailable("Customer Service is unavailable.");
            
        var envelope = await response.Content.ReadFromJsonAsync<
            ApiEnvelope<IReadOnlyCollection<CustomerPropertyResponse>>
        >(cancellationToken: ct);
        
        return envelope?.Data
            ?? throw PolicyServiceException.Unavailable("Customer properties response was invalid.");
    }
}

public sealed class ClaimsCoverageClient : IClaimsCoverageClient
{
    private readonly HttpClient _http;

    public ClaimsCoverageClient(HttpClient http) => _http = http;

    public async Task<ClaimsCoverageConsumptionResponse> GetConsumedCoverageAsync(
        Guid policyId,
        Guid coverageTypeId,
        CancellationToken ct
    )
    {
        using var response = await _http.GetAsync(
            $"api/v1/claims/coverage-consumption?policyId={policyId}&coverageTypeId={coverageTypeId}",
            ct
        );
        if (!response.IsSuccessStatusCode)
            throw PolicyServiceException.Unavailable("Claims Service is unavailable.");
        var envelope = await response.Content.ReadFromJsonAsync<
            ApiEnvelope<ClaimsCoverageConsumptionResponse>
        >(cancellationToken: ct);
        return envelope?.Data
            ?? throw PolicyServiceException.Unavailable("Claims coverage response was invalid.");
    }

    // Add these usings to ServiceClients.cs if they are not already present:
    // using System.Net.Http.Json;
    // using PolicyService.Application.DTOs.Integrations;

    // Add this method inside ClaimsCoverageClient:
    public async Task<ClaimHistoryCountResponse> GetClaimHistoryCountAsync(
        IReadOnlyCollection<Guid> policyIds,
        CancellationToken ct
    )
    {
        using var response = await _http.PostAsJsonAsync(
            "api/v1/claims/history/count",
            new ClaimHistoryCountRequest(policyIds),
            ct
        );

        if (!response.IsSuccessStatusCode)
            throw PolicyServiceException.Unavailable("Claims Service is unavailable.");

        var envelope = await response.Content.ReadFromJsonAsync<
            ApiEnvelope<ClaimHistoryCountResponse>
        >(cancellationToken: ct);

        return envelope?.Data
            ?? throw PolicyServiceException.Unavailable("Claims history response was invalid.");
    }
}

public sealed class PaymentClient : IPaymentClient
{
    private readonly HttpClient _http;
    private readonly string _internalServiceKey;

    public PaymentClient(HttpClient http, IOptions<InternalServicesSettings> internalServices)
    {
        _http = http;
        _internalServiceKey = internalServices.Value.ApiKey;
    }

    public async Task<RefundIssueResponse> IssueRefundAsync(
        RefundIssueRequest request,
        string idempotencyKey,
        CancellationToken ct
    )
    {
        using var message = new HttpRequestMessage(HttpMethod.Post, "api/v1/payments/refund")
        {
            Content = JsonContent.Create(request),
        };
        message.Headers.Add("X-Idempotency-Key", idempotencyKey);
        // PaymentService only accepts refunds from administrators or from this service.
        if (!string.IsNullOrWhiteSpace(_internalServiceKey))
            message.Headers.Add("X-Internal-Service-Key", _internalServiceKey);

        using var response = await _http.SendAsync(message, ct);

        if (!response.IsSuccessStatusCode)
        {
            var errorBody = await response.Content.ReadAsStringAsync(ct);
            throw PolicyServiceException.Unavailable($"Failed to process refund in PaymentService: {errorBody}");
        }

        var envelope = await response.Content.ReadFromJsonAsync<ApiEnvelope<RefundIssueResponse>>(
            cancellationToken: ct
        );

        return envelope?.Data
            ?? throw PolicyServiceException.Unavailable("Payment refund response was invalid.");
    }
}


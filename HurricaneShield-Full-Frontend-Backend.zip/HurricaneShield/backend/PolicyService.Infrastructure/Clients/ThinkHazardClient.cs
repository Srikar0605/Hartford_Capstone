using System.Net.Http.Json;
using System.Text.Json;
using Microsoft.Extensions.Logging;
using PolicyService.Application.Interfaces;

namespace PolicyService.Infrastructure.Clients;

public sealed class ThinkHazardClient : IThinkHazardClient
{
    private readonly HttpClient _httpClient;
    private readonly ILogger<ThinkHazardClient> _logger;

    public ThinkHazardClient(HttpClient httpClient, ILogger<ThinkHazardClient> logger)
    {
        _httpClient = httpClient;
        _logger = logger;
    }

    public async Task<ThinkHazardResponse> GetRiskLevelAsync(double latitude, double longitude, CancellationToken ct)
    {
        try
        {
            // Note: ThinkHazard API typically uses an admin division ID (ADM1/ADM2), but for this
            // capstone simulation we simulate a deterministic response based on coordinates to avoid
            // complex polygon point-in-polygon mapping.
            // A real integration would query a geospatial API first to get the ADM boundary.
            
            // Deterministic simulation based on latitude
            if (latitude < 25)
            {
                return new ThinkHazardResponse("High"); // Simulate High risk (e.g. South FL)
            }
            if (latitude < 30)
            {
                return new ThinkHazardResponse("Medium"); 
            }
            
            return new ThinkHazardResponse("Low");
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to reach ThinkHazard API. Defaulting to High risk.");
            return new ThinkHazardResponse("High");
        }
    }
}


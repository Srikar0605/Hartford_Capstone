using Microsoft.Extensions.Logging;
using PolicyService.Application.Interfaces;

namespace PolicyService.Infrastructure.Clients;

public sealed class GdacsClient : IGdacsClient
{
    private readonly HttpClient _httpClient;
    private readonly ILogger<GdacsClient> _logger;

    public GdacsClient(HttpClient httpClient, ILogger<GdacsClient> logger)
    {
        _httpClient = httpClient;
        _logger = logger;
    }

    public async Task<GdacsResponse> GetActiveAlertsAsync(double latitude, double longitude, CancellationToken ct)
    {
        try
        {
            // A real integration would parse the GDACS GeoRSS feed (https://www.gdacs.org/xml/rss.xml)
            // and check if the coordinates fall within an active alert polygon.
            // For the capstone simulation, we will deterministically trigger an alert for a specific coordinate range
            // (e.g., longitude between -80 and -81, simulating a storm hitting the coast)
            
            if (longitude >= -81.0 && longitude <= -80.0 && latitude >= 25.0 && latitude <= 28.0)
            {
                _logger.LogWarning("GDACS active alert triggered for coordinates {Latitude}, {Longitude}", latitude, longitude);
                return new GdacsResponse(HasActiveAlert: true);
            }

            return new GdacsResponse(HasActiveAlert: false);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to check GDACS. Assuming no active alerts.");
            return new GdacsResponse(HasActiveAlert: false);
        }
    }
}


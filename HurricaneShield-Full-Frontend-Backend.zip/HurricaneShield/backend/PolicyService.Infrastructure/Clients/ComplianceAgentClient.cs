﻿using System.Text.Json;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using PolicyService.Application.Interfaces;
using PolicyService.Domain.Enums;
using PolicyService.Domain.Models;

namespace PolicyService.Infrastructure.Clients;

public sealed class ComplianceAgentClient : IComplianceAgentClient
{
    private readonly ILogger<ComplianceAgentClient> _logger;
    private readonly IVectorKnowledgeBase _vectorDb;
    private readonly IConfiguration _config;
    private readonly HttpClient _httpClient;

    private static readonly Lazy<string> InstructionsLazy = new(() =>
    {
        try
        {
            var basePath = AppContext.BaseDirectory;
            var directPath = Path.Combine(basePath, "AgentInstructions", "UnderwritingAgentInstructions.txt");
            if (File.Exists(directPath))
                return File.ReadAllText(directPath);

            var candidate = Directory.GetFiles(Directory.GetCurrentDirectory(), "UnderwritingAgentInstructions.txt", SearchOption.AllDirectories).FirstOrDefault();
            if (candidate != null && File.Exists(candidate))
                return File.ReadAllText(candidate);
        }
        catch
        {
            // Ignore error and use fallback
        }

        return "You are HurricaneShield's Autonomous Underwriting Compliance Agent. You operate as a headless underwriting compliance service.";
    });

    public ComplianceAgentClient(
        ILogger<ComplianceAgentClient> logger,
        IVectorKnowledgeBase vectorDb,
        IConfiguration config,
        HttpClient httpClient
    )
    {
        _logger = logger;
        _vectorDb = vectorDb;
        _config = config;
        _httpClient = httpClient;
    }

    public async Task<ComplianceAgentResponse> EvaluatePolicyAsync(
        PropertyRiskInput property,
        decimal requestedCoverage,
        CancellationToken ct
    )
    {
        _logger.LogInformation(
            "Starting C# Autonomous Underwriting Agent evaluation for Property Year: {Year}, Zone: {Zone}, Construction: {Construction}",
            property.YearBuilt,
            property.RiskZone,
            property.ConstructionType
        );

        // Step 1: RETRIEVAL - Formulate query and retrieve context from the Vector Knowledge Base
        var searchQuery = $"{property.ConstructionType} {property.RiskZone} year {property.YearBuilt} coverage {requestedCoverage} roof windows mitigation";
        var retrievedKnowledgeContext = await _vectorDb.RetrieveContextAsync(searchQuery, topK: 3, ct);

        _logger.LogInformation("Retrieved Knowledge Context from Vector Database:\n{Context}", retrievedKnowledgeContext);

        // Step 2: Check for configured Gemini API Key or Vertex AI Enterprise settings
        var useVertexAiConfig = _config["Gemini:UseVertexAi"];
        var useVertexAi = useVertexAiConfig != null 
            ? bool.Parse(useVertexAiConfig) 
            : string.Equals(Environment.GetEnvironmentVariable("GOOGLE_GENAI_USE_VERTEXAI"), "true", StringComparison.OrdinalIgnoreCase);

        var geminiApiKey = _config["Gemini:ApiKey"] ?? Environment.GetEnvironmentVariable("GEMINI_API_KEY");

        if (useVertexAi)
        {
            try
            {
                return (await CallVertexAiUnderwritingAsync(property, requestedCoverage, retrievedKnowledgeContext, ct)) with { Engine = AiEngines.Gemini };
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Live Vertex AI Enterprise call failed for Underwriting. Falling back to local RAG evaluation engine.");
            }
        }
        else if (!string.IsNullOrWhiteSpace(geminiApiKey))
        {
            try
            {
                // Call live Gemini API with JSON schema enforcement
                return (await CallLiveGeminiModelAsync(property, requestedCoverage, retrievedKnowledgeContext, geminiApiKey, ct)) with { Engine = AiEngines.Gemini };
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Live Gemini API call failed. Falling back to local RAG evaluation engine.");
            }
        }

        // Step 3: Local RAG Evaluation Engine (Evaluates against the retrieved vector chunks directly)
        return EvaluateAgainstRetrievedContext(property, requestedCoverage, retrievedKnowledgeContext) with { Engine = AiEngines.RuleBased };
    }

    private async Task<ComplianceAgentResponse> CallVertexAiUnderwritingAsync(
        PropertyRiskInput property,
        decimal requestedCoverage,
        string retrievedContext,
        CancellationToken ct
    )
    {
        var project = _config["Gemini:ProjectId"] 
            ?? Environment.GetEnvironmentVariable("GOOGLE_CLOUD_PROJECT") 
            ?? "higsbx-indintq326sbx";

        var location = _config["Gemini:Location"] 
            ?? Environment.GetEnvironmentVariable("GOOGLE_CLOUD_LOCATION") 
            ?? "global";

        var model = _config["Gemini:Model"] ?? "gemini-3.5-flash";

        var endpoint = $"https://aiplatform.googleapis.com/v1/projects/{project}/locations/{location}/publishers/google/models/{model}:generateContent";

        var credential = await Google.Apis.Auth.OAuth2.GoogleCredential.GetApplicationDefaultAsync();
        if (credential.IsCreateScopedRequired)
        {
            credential = credential.CreateScoped("https://www.googleapis.com/auth/cloud-platform");
        }
        var token = await credential.UnderlyingCredential.GetAccessTokenForRequestAsync(cancellationToken: ct);

        var systemInstruction = InstructionsLazy.Value;

        var userPrompt = $@"
Evaluate the following property application:
- Property Value: ₹{property.PropertyValue:N2}
- Requested Coverage: ₹{requestedCoverage:N2}
- Year Built: {property.YearBuilt}
- Construction Type: {property.ConstructionType}
- Risk Zone: {property.RiskZone}
- Storm Shutters: {property.StormShutters}
- Impact Resistant Windows: {property.ImpactResistantWindows}
- Reinforced Roof: {property.ReinforcedRoof}
- Emergency Generator: {property.EmergencyGenerator}
- Home Inspection Certified: {property.HomeInspectionCertification}

--- KNOWLEDGE BASE CONTEXT (FROM VECTOR DATABASE) ---
{retrievedContext}
";

        var payload = new
        {
            system_instruction = new
            {
                parts = new[] { new { text = systemInstruction } }
            },
            contents = new[]
            {
                new
                {
                    role = "user",
                    parts = new[] { new { text = userPrompt } }
                }
            },
            generationConfig = new
            {
                response_mime_type = "application/json"
            }
        };

        using var requestMessage = new HttpRequestMessage(HttpMethod.Post, endpoint)
        {
            Content = new StringContent(JsonSerializer.Serialize(payload), System.Text.Encoding.UTF8, "application/json")
        };

        requestMessage.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);

        using var response = await _httpClient.SendAsync(requestMessage, ct);
        response.EnsureSuccessStatusCode();

        var responseJson = await response.Content.ReadAsStringAsync(ct);
        using var doc = JsonDocument.Parse(responseJson);

        var candidateText = doc.RootElement
            .GetProperty("candidates")[0]
            .GetProperty("content")
            .GetProperty("parts")[0]
            .GetProperty("text")
            .GetString();

        if (string.IsNullOrWhiteSpace(candidateText))
        {
            throw new InvalidOperationException("Gemini returned an empty response.");
        }

        var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
        return JsonSerializer.Deserialize<ComplianceAgentResponse>(candidateText, options)
            ?? throw new InvalidOperationException("Failed to deserialize Gemini response.");
    }

    private async Task<ComplianceAgentResponse> CallLiveGeminiModelAsync(
        PropertyRiskInput property,
        decimal requestedCoverage,
        string retrievedContext,
        string apiKey,
        CancellationToken ct
    )
    {
        var model = _config["Gemini:Model"] ?? "gemini-3.5-flash";
        var endpoint = $"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={apiKey}";

        var systemInstruction = InstructionsLazy.Value;

        var userPrompt = $@"
Evaluate the following property application:
- Property Value: ₹{property.PropertyValue:N2}
- Requested Coverage: ₹{requestedCoverage:N2}
- Year Built: {property.YearBuilt}
- Construction Type: {property.ConstructionType}
- Risk Zone: {property.RiskZone}
- Storm Shutters: {property.StormShutters}
- Impact Resistant Windows: {property.ImpactResistantWindows}
- Reinforced Roof: {property.ReinforcedRoof}
- Emergency Generator: {property.EmergencyGenerator}
- Home Inspection Certified: {property.HomeInspectionCertification}

--- KNOWLEDGE BASE CONTEXT (FROM VECTOR DATABASE) ---
{retrievedContext}
";

        var payload = new
        {
            system_instruction = new
            {
                parts = new[] { new { text = systemInstruction } }
            },
            contents = new[]
            {
                new
                {
                    role = "user",
                    parts = new[] { new { text = userPrompt } }
                }
            },
            generationConfig = new
            {
                response_mime_type = "application/json"
            }
        };

        using var requestMessage = new HttpRequestMessage(HttpMethod.Post, endpoint)
        {
            Content = new StringContent(JsonSerializer.Serialize(payload), System.Text.Encoding.UTF8, "application/json")
        };

        using var response = await _httpClient.SendAsync(requestMessage, ct);
        response.EnsureSuccessStatusCode();

        var responseJson = await response.Content.ReadAsStringAsync(ct);
        using var doc = JsonDocument.Parse(responseJson);

        var candidateText = doc.RootElement
            .GetProperty("candidates")[0]
            .GetProperty("content")
            .GetProperty("parts")[0]
            .GetProperty("text")
            .GetString();

        if (string.IsNullOrWhiteSpace(candidateText))
        {
            throw new InvalidOperationException("Gemini returned an empty response.");
        }

        var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
        return JsonSerializer.Deserialize<ComplianceAgentResponse>(candidateText, options)
            ?? throw new InvalidOperationException("Failed to deserialize Gemini response.");
    }

    private static ComplianceAgentResponse EvaluateAgainstRetrievedContext(
        PropertyRiskInput property,
        decimal requestedCoverage,
        string retrievedContext
    )
    {
        var violations = new List<string>();
        var missingDiscounts = new List<string>();
        var recommendedActions = new List<string>();
        var citations = new List<string>
        {
            "FL-Building-Code-Wind-Mitigation.txt",
            "HurricaneShield-Underwriting-Guidelines.txt",
            "State-Mandatory-Discounts.txt"
        };

        // RAG Rule 1: FBC 1609.1.1 (Coastal Zone A opening protection)
        if (retrievedContext.Contains("1609.1.1") && property.RiskZone == RiskZone.A && !property.StormShutters && !property.ImpactResistantWindows)
        {
            violations.Add("FBC Sec 1609.1.1: Missing impact-resistant windows or verified storm shutters in coastal Risk Zone A.");
            recommendedActions.Add("Require proof of storm shutter installation prior to policy binding.");
        }

        // RAG Rule 2: FBC 1609.1.2 (Pre-2001 roof strapping)
        if (retrievedContext.Contains("1609.1.2") && property.YearBuilt < 2001 && (property.RiskZone == RiskZone.A || property.RiskZone == RiskZone.B))
        {
            violations.Add($"FBC Sec 1609.1.2: Structure built in {property.YearBuilt} (prior to 2001) in Risk Zone {property.RiskZone} requires mandatory roof strapping verification.");
            recommendedActions.Add("Request official roof geometry and truss tie-down inspection form.");
        }

        // RAG Rule 3: Rule UW-205 (Wood frame prohibition in Zone A)
        if (retrievedContext.Contains("UW-205") && property.ConstructionType == ConstructionType.WoodFrame && property.RiskZone == RiskZone.A)
        {
            violations.Add("Rule UW-205: Wood frame construction in Risk Zone A is strictly prohibited by HurricaneShield coastal underwriting rules.");
            recommendedActions.Add("Issue formal underwriting declination due to non-compliant structural construction.");
        }

        // RAG Rule 4: Rule UW-101 (Coverage limit escalation)
        if (retrievedContext.Contains("UW-101") && requestedCoverage > 1_500_000m && (property.RiskZone == RiskZone.A || property.RiskZone == RiskZone.B))
        {
            violations.Add("Rule UW-101: Coverage value exceeding ₹1,500,000 in coastal Risk Zone requires senior underwriter sign-off.");
            recommendedActions.Add("Escalate to Senior Underwriter for treaty reinsurance approval.");
        }

        // Statutory Discounts: Statute 627.0629
        if (retrievedContext.Contains("627.0629"))
        {
            if (property.ImpactResistantWindows)
            {
                missingDiscounts.Add("Statute 627.0629: Verified 5% baseline premium reduction for Impact Resistant Windows.");
            }

            if (property.ReinforcedRoof)
            {
                missingDiscounts.Add("Statute 627.0629: Verified 10% baseline premium reduction for Reinforced Roof mitigation.");
            }

            if (property.HomeInspectionCertification)
            {
                missingDiscounts.Add("Statute 627.0629: Verified 3% safety reduction for Home Inspection Certification.");
            }
        }

        bool isCompliant = violations.Count == 0;
        decimal confidenceScore = isCompliant ? 99.2m : 94.8m;

        string summary = isCompliant
            ? "Property complies with all applicable Florida Wind Mitigation Building Codes and HurricaneShield underwriting guidelines."
            : $"Automated RAG check detected {violations.Count} underwriting code violation(s). Human underwriter verification required.";

        string riskAssessment = isCompliant
            ? "Favorable coastal risk profile with validated mitigation compliance."
            : $"High-risk operational exposure. Property construction ({property.ConstructionType}) and vintage ({property.YearBuilt}) in Zone {property.RiskZone} present structural wind intrusion vulnerabilities.";

        return new ComplianceAgentResponse(
            isCompliant,
            confidenceScore,
            summary,
            violations,
            missingDiscounts,
            riskAssessment,
            recommendedActions,
            citations
        );
    }
}


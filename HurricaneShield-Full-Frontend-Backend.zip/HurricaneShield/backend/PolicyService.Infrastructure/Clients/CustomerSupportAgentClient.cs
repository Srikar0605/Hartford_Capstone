﻿using System.Text.Json;
using System.Text.RegularExpressions;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using PolicyService.Application.DTOs.System;
using PolicyService.Application.Interfaces;

namespace PolicyService.Infrastructure.Clients;

public sealed class CustomerSupportAgentClient : ICustomerSupportAgentClient
{
    private readonly ILogger<CustomerSupportAgentClient> _logger;
    private readonly IConfiguration _config;
    private readonly HttpClient _httpClient;

    private static readonly Lazy<string> InstructionsLazy = new(() =>
    {
        try
        {
            var basePath = AppContext.BaseDirectory;
            var directPath = Path.Combine(basePath, "AgentInstructions", "CustomerSupportInstructions.txt");
            if (File.Exists(directPath))
                return File.ReadAllText(directPath);

            var candidate = Directory.GetFiles(Directory.GetCurrentDirectory(), "CustomerSupportInstructions.txt", SearchOption.AllDirectories).FirstOrDefault();
            if (candidate != null && File.Exists(candidate))
                return File.ReadAllText(candidate);
        }
        catch
        {
            // Fallback
        }

        return "You are 'ShieldBot', the official customer support AI for HurricaneShield Property & Casualty Insurance. Assist policyholders politely and professionally.";
    });

    public CustomerSupportAgentClient(
        ILogger<CustomerSupportAgentClient> logger,
        IConfiguration config,
        HttpClient httpClient
    )
    {
        _logger = logger;
        _config = config;
        _httpClient = httpClient;
    }

    public async Task<string> SendMessageAsync(
        IReadOnlyCollection<ChatMessageDto> history,
        string newMessage,
        string? platformContext = null,
        CancellationToken ct = default
    )
    {
        _logger.LogInformation("Processing customer support chat turn. History count: {Count}, HasContext: {HasContext}", history.Count, !string.IsNullOrWhiteSpace(platformContext));

        var useVertexAiConfig = _config["Gemini:UseVertexAi"];
        var useVertexAi = useVertexAiConfig != null 
            ? bool.Parse(useVertexAiConfig) 
            : string.Equals(Environment.GetEnvironmentVariable("GOOGLE_GENAI_USE_VERTEXAI"), "true", StringComparison.OrdinalIgnoreCase);

        var geminiApiKey = _config["Gemini:ApiKey"] ?? Environment.GetEnvironmentVariable("GEMINI_API_KEY");

        if (useVertexAi)
        {
            try
            {
                return await CallVertexAiChatAsync(history, newMessage, platformContext, ct);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Live Vertex AI Enterprise call failed. Falling back to local conversational engine.");
            }
        }
        else if (!string.IsNullOrWhiteSpace(geminiApiKey))
        {
            try
            {
                return await CallLiveGeminiChatAsync(history, newMessage, geminiApiKey, platformContext, ct);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Live Gemini chat call failed. Falling back to local conversational engine.");
            }
        }

        return GenerateLocalSupportResponse(history, newMessage, platformContext);
    }

    private async Task<string> CallVertexAiChatAsync(
        IReadOnlyCollection<ChatMessageDto> history,
        string newMessage,
        string? platformContext,
        CancellationToken ct
    )
    {
        var project = _config["Gemini:ProjectId"] 
            ?? Environment.GetEnvironmentVariable("GOOGLE_CLOUD_PROJECT") 
            ?? "higsbx-indintq326sbx";

        var location = _config["Gemini:Location"] 
            ?? Environment.GetEnvironmentVariable("GOOGLE_CLOUD_LOCATION") 
            ?? "global";

        var model = _config["Gemini:Model"] ?? "gemini-3.5-flash";

        var endpoint = $"https://aiplatform.googleapis.com/v1/projects/{project}/locations/{location}/publishers/google/models/{model}:generateContent";

        var credential = await Google.Apis.Auth.OAuth2.GoogleCredential.GetApplicationDefaultAsync();
        if (credential.IsCreateScopedRequired)
        {
            credential = credential.CreateScoped("https://www.googleapis.com/auth/cloud-platform");
        }
        var token = await credential.UnderlyingCredential.GetAccessTokenForRequestAsync(cancellationToken: ct);

        var contents = new List<object>();

        foreach (var msg in history)
        {
            var role = msg.Role.Equals("user", StringComparison.OrdinalIgnoreCase) ? "user" : "model";
            contents.Add(new
            {
                role = role,
                parts = new[] { new { text = msg.Content } }
            });
        }

        contents.Add(new
        {
            role = "user",
            parts = new[] { new { text = newMessage } }
        });

        var combinedInstruction = string.IsNullOrWhiteSpace(platformContext)
            ? InstructionsLazy.Value
            : $"{InstructionsLazy.Value}\n\n{platformContext}";

        var payload = new
        {
            system_instruction = new
            {
                parts = new[] { new { text = combinedInstruction } }
            },
            contents = contents
        };

        using var requestMessage = new HttpRequestMessage(HttpMethod.Post, endpoint)
        {
            Content = new StringContent(JsonSerializer.Serialize(payload), System.Text.Encoding.UTF8, "application/json")
        };

        requestMessage.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);

        using var response = await _httpClient.SendAsync(requestMessage, ct);
        response.EnsureSuccessStatusCode();

        var responseJson = await response.Content.ReadAsStringAsync(ct);
        using var doc = JsonDocument.Parse(responseJson);

        var reply = doc.RootElement
            .GetProperty("candidates")[0]
            .GetProperty("content")
            .GetProperty("parts")[0]
            .GetProperty("text")
            .GetString();

        return reply ?? "I am here to help. How can I assist you with your HurricaneShield policy today?";
    }

    private async Task<string> CallLiveGeminiChatAsync(
        IReadOnlyCollection<ChatMessageDto> history,
        string newMessage,
        string apiKey,
        string? platformContext,
        CancellationToken ct
    )
    {
        var configuredModel = _config["Gemini:Model"] ?? "gemini-3.5-flash";
        // Fallback is configurable; the default is Google's rolling alias for the current Flash model,
        // so it keeps working when a pinned model version is retired.
        var fallbackModel = _config["Gemini:FallbackModel"] ?? "gemini-flash-latest";

        try
        {
            return await ExecuteGeminiApiCallAsync(configuredModel, history, newMessage, apiKey, platformContext, ct);
        }
        catch (HttpRequestException ex) when (!string.Equals(configuredModel, fallbackModel, StringComparison.OrdinalIgnoreCase))
        {
            _logger.LogWarning(ex, "Configured model {Model} failed. Retrying with {FallbackModel}...", configuredModel, fallbackModel);
            return await ExecuteGeminiApiCallAsync(fallbackModel, history, newMessage, apiKey, platformContext, ct);
        }
    }

    private async Task<string> ExecuteGeminiApiCallAsync(
        string model,
        IReadOnlyCollection<ChatMessageDto> history,
        string newMessage,
        string apiKey,
        string? platformContext,
        CancellationToken ct
    )
    {
        var endpoint = $"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={apiKey}";

        var contents = new List<object>();

        foreach (var msg in history)
        {
            var role = msg.Role.Equals("user", StringComparison.OrdinalIgnoreCase) ? "user" : "model";
            contents.Add(new
            {
                role = role,
                parts = new[] { new { text = msg.Content } }
            });
        }

        contents.Add(new
        {
            role = "user",
            parts = new[] { new { text = newMessage } }
        });

        var combinedInstruction = string.IsNullOrWhiteSpace(platformContext)
            ? InstructionsLazy.Value
            : $"{InstructionsLazy.Value}\n\n{platformContext}";

        var payload = new
        {
            system_instruction = new
            {
                parts = new[] { new { text = combinedInstruction } }
            },
            contents = contents
        };

        using var requestMessage = new HttpRequestMessage(HttpMethod.Post, endpoint)
        {
            Content = new StringContent(JsonSerializer.Serialize(payload), System.Text.Encoding.UTF8, "application/json")
        };

        using var response = await _httpClient.SendAsync(requestMessage, ct);
        response.EnsureSuccessStatusCode();

        var responseJson = await response.Content.ReadAsStringAsync(ct);
        using var doc = JsonDocument.Parse(responseJson);

        var reply = doc.RootElement
            .GetProperty("candidates")[0]
            .GetProperty("content")
            .GetProperty("parts")[0]
            .GetProperty("text")
            .GetString();

        return reply ?? "I am here to help. How can I assist you with your HurricaneShield policy today?";
    }

    private static string GenerateLocalSupportResponse(
        IReadOnlyCollection<ChatMessageDto> history, 
        string newMessage, 
        string? platformContext
    )
    {
        var lower = newMessage.Trim().ToLowerInvariant();

        // 1. Math / Trivia / Fun queries
        if (lower.Contains("2+2") || lower.Contains("2 + 2"))
        {
            return "2 + 2 is 4! While math is simple, evaluating coastal hurricane risk zones and statutory wind mitigation credits is where I really excel. How can I help with your insurance today?";
        }

        if (lower.StartsWith("who are you") || lower.Contains("what are you") || lower == "who r u")
        {
            return "I am **ShieldBot**, your HurricaneShield virtual assistant. I'm here 24/7 to help you understand our coastal coverage options, file claims, calculate mitigation credits, and navigate the platform.";
        }

        if (lower.StartsWith("who am i") || lower.Contains("my name") || lower.Contains("my account"))
        {
            if (platformContext != null && platformContext.Contains("User Status: Authenticated"))
            {
                return "You are logged into your HurricaneShield account! You can view your personal profile, active policies, and properties directly from your **Dashboard** or **Profile** menu.";
            }

            return "You are currently browsing HurricaneShield as a guest. If you have an account, please sign in to view your personalized policies and properties.";
        }

        // 2. Greetings
        if (Regex.IsMatch(lower, @"^(hi|hello|hey|howdy|greetings|good morning|good afternoon|good evening)\b"))
        {
            return history.Count > 0
                ? "Hello again! What else can I assist you with regarding your coverage, quotes, or claims?"
                : "Hello! I am ShieldBot, your HurricaneShield virtual assistant. How can I help you today with quotes, coverage, claims, or storm preparation?";
        }

        // 3. Exact Insurance Plans Offered
        if (lower.Contains("what policies do u offer") || lower.Contains("what policies do you offer") || lower.Contains("what plans") || lower.Contains("policy options") || lower.Contains("available policies"))
        {
            return "HurricaneShield offers four specialized property insurance plans:\n\n" +
                   "• **HurricaneShield Legacy (HS-LEGACY):** Base Premium ₹700.00 | Coverage Limit up to ₹200,000.00\n" +
                   "• **HurricaneShield Essential (HS-ESSENTIAL):** Base Premium ₹850.00 | Coverage Limit up to ₹300,000.00\n" +
                   "• **HurricaneShield Plus (HS-PLUS):** Base Premium ₹1,450.00 | Coverage Limit up to ₹650,000.00\n" +
                   "• **HurricaneShield Premier (HS-PREMIER):** Base Premium ₹2,400.00 | Coverage Limit up to ₹1,200,000.00\n\n" +
                   "All plans include Dwelling Protection, Personal Property, and Debris Removal, with optional riders for Water Intrusion and Living Expenses. Visit our **Plans** page or click **Get a Quote** to calculate your exact rate!";
        }

        // 4. User Policy Expiration & Status
        if (lower.Contains("when will my policies expire") || lower.Contains("when will my policy expire") || lower.Contains("my policies") || lower.Contains("my policy expire") || lower.Contains("expiration"))
        {
            if (platformContext != null && platformContext.Contains("Policy Number:"))
            {
                // Extract policy details from platform context
                return "Based on your active account records:\n\n" +
                       ExtractPoliciesSummary(platformContext) + "\n\n" +
                       "You can manage your policy, download documents, or renew directly from your **Customer Dashboard**!";
            }

            if (platformContext != null && platformContext.Contains("Anonymous / Guest"))
            {
                return "You are currently browsing as a guest. Please sign in to your HurricaneShield account so I can look up your active policies and exact expiration dates!";
            }

            return "You do not currently have any active policies on file. Visit our **Plans** page or click **Get a Quote** to get your home protected!";
        }

        // 5. Platform Overview
        if (lower.Contains("what is this platform") || lower.Contains("about this platform") || lower.Contains("what do you do") || lower.Contains("what is hurricaneshield"))
        {
            return "HurricaneShield is a real-time insurtech platform designed to protect coastal homeowners from hurricane and storm damage. We offer:\n\n" +
                   "• **Automated Risk Zone Assignment:** Real-time hazard indexing via ThinkHazard & GDACS.\n" +
                   "• **Transparent Quoting:** Instant, customized premiums with statutory discounts for wind-mitigation features.\n" +
                   "• **Autonomous Claims Triage:** Straight-Through Processing (STP) that approves eligible minor claims under ₹50,000 instantly without adjuster delays.\n" +
                   "• **Underwriting Compliance (RAG):** AI pre-checks against state building codes and mitigation requirements.";
        }

        // 6. How to insure / get coverage
        if (lower.Contains("insure my house") || lower.Contains("how do i insure") || lower.Contains("how to insure") || lower.Contains("get insurance") || lower.Contains("buy insurance") || lower.Contains("purchase insurance"))
        {
            return "Insuring your home against hurricane damage is easy on HurricaneShield:\n\n" +
                   "1. Click **Get a Quote** in the navigation bar.\n" +
                   "2. Enter your property details (year built, construction type, and wind mitigation features like shutters or reinforced roofs).\n" +
                   "3. Our system automatically checks coastal hazard maps to assign your Risk Zone (A, B, C, or D) and calculates your premium with all legal discounts applied.\n" +
                   "4. Select your preferred coverage (Legacy, Essential, Plus, or Premier) and bind your policy!";
        }

        // 7. Weather definition (What is a hurricane)
        if (lower.Contains("what is hurricane") || lower.Contains("what is a hurricane") || lower.Contains("define hurricane"))
        {
            return "A hurricane is a powerful tropical cyclone with sustained winds exceeding 74 mph (Category 1 through Category 5). These storms cause catastrophic storm surges, destructive wind shear, and severe flooding.\n\n" +
                   "HurricaneShield connects directly to the Global Disaster Alert and Coordination System (GDACS) and the National Hurricane Center to track tropical storm trajectories and alert homeowners before landfall.";
        }

        // 8. Specific Moratorium / Freeze inquiries
        if (lower.Contains("moratorium") || lower.Contains("binding freeze") || lower.Contains("binding restriction") || lower.Contains("can i buy during a storm") || lower.Contains("frozen"))
        {
            return "To prevent adverse selection, HurricaneShield activates an automated **Binding Moratorium** whenever the National Hurricane Center (NHC) or GDACS issues an active tropical storm or hurricane watch/warning for a region. While a moratorium is active, existing policies remain fully protected, but no new policies can be bound until the threat clears.";
        }

        // 9. Quoting / Pricing
        if (lower.Contains("quote") || lower.Contains("price") || lower.Contains("cost") || lower.Contains("premium") || lower.Contains("estimate") || lower.Contains("apply"))
        {
            return "You can generate an instant, binding quote in under 2 minutes by visiting our **Get a Quote** page. Your premium depends on your property value, construction materials (e.g. Masonry vs Wood Frame), and your coastal Risk Zone.";
        }

        // 10. Claims
        if (lower.Contains("claim") || lower.Contains("damage") || lower.Contains("loss") || lower.Contains("file claim") || lower.Contains("reimbursement"))
        {
            return "Filing a claim with HurricaneShield is available 24/7:\n\n" +
                   "• Log in and navigate to **My Claims** > **File a Claim**.\n" +
                   "• Describe the damage and attach photos or receipts.\n" +
                   "• **Instant AI Triage:** Eligible claims under ₹50,000 with low complexity are approved automatically via our Straight-Through Processing (STP) engine, triggering payment immediately!";
        }

        // 11. Statutory Discounts / Wind Mitigation
        if (lower.Contains("discount") || lower.Contains("shutter") || lower.Contains("window") || lower.Contains("roof") || lower.Contains("mitigation"))
        {
            return "Under Florida Statute 627.0629, HurricaneShield mandates significant premium credits for wind mitigation:\n\n" +
                   "• **Impact-Resistant Windows:** 5% baseline credit.\n" +
                   "• **Reinforced Roof / Secondary Water Barrier:** 10% baseline credit.\n" +
                   "• **Certified Home Inspection:** 3% safety credit.\n\n" +
                   "Make sure to check these boxes during your quote application to lower your annual premium!";
        }

        // 12. Human Support / Contact
        if (lower.Contains("contact") || lower.Contains("human") || lower.Contains("agent") || lower.Contains("representative") || lower.Contains("phone") || lower.Contains("call") || lower.Contains("email"))
        {
            return "Our customer support specialists are ready to assist you! You can reach us:\n\n" +
                   "• **Phone:** 1-800-555-0199 (Mon-Fri, 8am - 8pm EST)\n" +
                   "• **Email:** support@hurricaneshield.com\n" +
                   "• **Emergency Claims Line:** 24/7 hotline available in your Customer Portal.";
        }

        // 13. Contextual fallback for unclassified questions
        if (history.Count > 0)
        {
            return "I want to be sure I give you the most accurate help. Could you clarify whether your inquiry is about:\n\n" +
                   "1. **Getting an instant quote**\n" +
                   "2. **Our 4 Insurance Plans** (Legacy, Essential, Plus, Premier)\n" +
                   "3. **Filing or checking a claim**\n" +
                   "4. **Wind mitigation premium discounts**";
        }

        return "Hello! I am ShieldBot, your HurricaneShield virtual assistant. I can help answer questions regarding our hurricane insurance coverage, filing claims, wind mitigation discounts, or binding restrictions. What would you like to know?";
    }

    private static string ExtractPoliciesSummary(string platformContext)
    {
        var lines = platformContext.Split('\n');
        var policyLines = new List<string>();
        foreach (var line in lines)
        {
            if (line.TrimStart().StartsWith("- Policy Number:") || 
                line.TrimStart().StartsWith("Plan Name:") || 
                line.TrimStart().StartsWith("Status:") || 
                line.TrimStart().StartsWith("Expiration Date:"))
            {
                policyLines.Add("• " + line.Trim());
            }
        }
        return string.Join("\n", policyLines);
    }
}


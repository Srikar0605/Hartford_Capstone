namespace PolicyService.Infrastructure.Exceptions;

public sealed class PolicyServiceException : Exception
{
    public PolicyServiceException(string errorCode, string message, int statusCode)
        : base(message)
    {
        ErrorCode = errorCode;
        StatusCode = statusCode;
    }

    public string ErrorCode { get; }
    public int StatusCode { get; }

    public static PolicyServiceException NotFound(string code, string message) =>
        new(code, message, 404);

    public static PolicyServiceException Conflict(string code, string message) =>
        new(code, message, 409);

    public static PolicyServiceException Unprocessable(string code, string message) =>
        new(code, message, 422);

    public static PolicyServiceException Forbidden(string message) =>
        new("AUTH_FORBIDDEN", message, 403);

    public static PolicyServiceException Unavailable(string message) =>
        new("SERVICE_UNAVAILABLE", message, 503);
}


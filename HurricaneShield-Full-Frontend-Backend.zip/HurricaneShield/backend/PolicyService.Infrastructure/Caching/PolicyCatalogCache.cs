using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Options;
using PolicyService.Infrastructure.Configuration;

namespace PolicyService.Infrastructure.Caching;

public interface IPolicyCatalogCache
{
    Task<T> GetOrCreateAsync<T>(string key, Func<Task<T>> factory);
    void Remove(string key);
    void RemoveCatalog();
}

public sealed class PolicyCatalogCache : IPolicyCatalogCache
{
    public const string ActivePlans = "policy:catalog:active-plans";
    public const string CoverageTypes = "policy:catalog:coverage-types";
    private readonly IMemoryCache _cache;
    private readonly TimeSpan _ttl;

    public PolicyCatalogCache(IMemoryCache cache, IOptions<CatalogCacheSettings> settings)
    {
        _cache = cache;
        _ttl = TimeSpan.FromMinutes(settings.Value.TtlMinutes);
    }

    public async Task<T> GetOrCreateAsync<T>(string key, Func<Task<T>> factory)
    {
        if (_cache.TryGetValue(key, out T? value) && value is not null)
            return value;
        value = await factory();
        _cache.Set(key, value, _ttl);
        return value;
    }

    public void Remove(string key) => _cache.Remove(key);

    public void RemoveCatalog()
    {
        _cache.Remove(ActivePlans);
        _cache.Remove(CoverageTypes);
    }

    public static string Plan(Guid id) => $"policy:catalog:plan:{id:N}";
}


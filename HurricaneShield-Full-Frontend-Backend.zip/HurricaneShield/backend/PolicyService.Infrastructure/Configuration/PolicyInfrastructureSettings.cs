namespace PolicyService.Infrastructure.Configuration;

public sealed class CustomerServiceSettings
{
    public const string SectionName = "Services:Customer";
    public string BaseUrl { get; set; } = string.Empty;
    public int TimeoutSeconds { get; set; } = 5;
}

public sealed class ClaimsServiceSettings
{
    public const string SectionName = "Services:Claims";
    public string BaseUrl { get; set; } = string.Empty;
    public int TimeoutSeconds { get; set; } = 5;
}

public sealed class PaymentServiceSettings
{
    public const string SectionName = "Services:Payment";
    public string BaseUrl { get; set; } = string.Empty;
    public int TimeoutSeconds { get; set; } = 5;
}

/// <summary>Shared key PolicyService presents to PaymentService for internal-only calls (refunds).</summary>
public sealed class InternalServicesSettings
{
    public const string SectionName = "InternalServices";
    public string ApiKey { get; set; } = string.Empty;
}

public sealed class CatalogCacheSettings
{
    public const string SectionName = "Caching:PolicyCatalog";
    public int TtlMinutes { get; set; } = 30;
}


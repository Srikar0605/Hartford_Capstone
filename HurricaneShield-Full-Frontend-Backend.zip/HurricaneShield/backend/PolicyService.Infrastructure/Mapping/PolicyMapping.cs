using PolicyService.Application.DTOs.CoverageTypes;
using PolicyService.Application.DTOs.Plans;
using PolicyService.Application.DTOs.Policies;
using PolicyService.Domain.Entities;

namespace PolicyService.Infrastructure.Mapping;

internal static class PolicyMapping
{
    internal static string RowVersion(byte[] value) => Convert.ToBase64String(value);

    internal static PlanSummaryResponse ToSummary(this InsurancePlan x) =>
        new(
            x.Id,
            x.PlanCode,
            x.PlanName,
            x.Description,
            x.BasePremium,
            x.CoverageLimit,
            x.DeductibleAmount
        );

    internal static PlanAdministrationResponse ToAdmin(this InsurancePlan x) =>
        new(
            x.Id,
            x.PlanCode,
            x.PlanName,
            x.Description,
            x.BasePremium,
            x.CoverageLimit,
            x.DeductibleAmount,
            x.IsActive,
            x.CreatedAt,
            x.UpdatedAt,
            RowVersion(x.RowVersion)
        );

    internal static CoverageTypeResponse ToResponse(this CoverageType x) =>
        new(
            x.Id,
            x.Name,
            x.Description,
            x.IsActive,
            x.CreatedAt,
            x.UpdatedAt,
            RowVersion(x.RowVersion)
        );

    internal static PolicyMutationResponse ToMutation(this Policy x) =>
        new(
            x.Id,
            x.PolicyNumber,
            x.Status,
            x.PremiumDue,
            x.CurrentVersionNumber,
            x.PaymentTransactionId,
            RowVersion(x.RowVersion)
        );
}


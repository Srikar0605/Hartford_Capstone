using PolicyService.Application.Interfaces;
using PolicyService.Domain.Enums;
using PolicyService.Infrastructure.Exceptions;

namespace PolicyService.Infrastructure.Services;

public sealed class RiskZoneEvaluator : IRiskZoneEvaluator
{
    private readonly IThinkHazardClient _thinkHazardClient;
    private readonly IGdacsClient _gdacsClient;

    public RiskZoneEvaluator(IThinkHazardClient thinkHazardClient, IGdacsClient gdacsClient)
    {
        _thinkHazardClient = thinkHazardClient;
        _gdacsClient = gdacsClient;
    }

    public async Task<RiskZone> EvaluateRiskZoneAsync(double latitude, double longitude, CancellationToken ct)
    {
        var gdacsResponse = await _gdacsClient.GetActiveAlertsAsync(latitude, longitude, ct);
        
        if (gdacsResponse.HasActiveAlert)
        {
            // Real insurance companies enforce binding moratoriums during active threats.
            throw PolicyServiceException.Conflict("BINDING_RESTRICTION", "An active disaster alert (GDACS) is present for this location. New policies cannot be bound at this time.");
        }

        var hazardResponse = await _thinkHazardClient.GetRiskLevelAsync(latitude, longitude, ct);

        return hazardResponse.HazardLevel switch
        {
            "High" => RiskZone.A, // Highest baseline risk
            "Medium" => RiskZone.B,
            "Low" => RiskZone.C,
            _ => RiskZone.C
        };
    }
}


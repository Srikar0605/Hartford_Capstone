using Microsoft.EntityFrameworkCore;
using PolicyService.Application.DTOs.Common;
using PolicyService.Application.DTOs.Plans;
using PolicyService.Application.Interfaces;
using PolicyService.Domain.Entities;
using PolicyService.Domain.Models;
using PolicyService.Infrastructure.Caching;
using PolicyService.Infrastructure.Exceptions;
using PolicyService.Infrastructure.Mapping;
using PolicyService.Infrastructure.Persistence;

namespace PolicyService.Infrastructure.Services;

public sealed class PlanService : IPlanService
{
    private readonly PolicyDbContext _db;
    private readonly IRequestContext _ctx;
    private readonly IDateTimeProvider _clock;
    private readonly IPolicyCatalogCache _cache;

    public PlanService(
        PolicyDbContext db,
        IRequestContext ctx,
        IDateTimeProvider clock,
        IPolicyCatalogCache cache
    )
    {
        _db = db;
        _ctx = ctx;
        _clock = clock;
        _cache = cache;
    }

    public Task<IReadOnlyCollection<PlanSummaryResponse>> GetActivePlansAsync(
        CancellationToken ct
    ) =>
        _cache.GetOrCreateAsync(
            IPolicyCatalogCacheKey.ActivePlans,
            async () =>
                (IReadOnlyCollection<PlanSummaryResponse>)
                    await _db
                        .InsurancePlans.AsNoTracking()
                        .Where(x => x.IsActive)
                        .OrderBy(x => x.PlanName)
                        .ThenBy(x => x.Id)
                        .Select(x => new PlanSummaryResponse(
                            x.Id,
                            x.PlanCode,
                            x.PlanName,
                            x.Description,
                            x.BasePremium,
                            x.CoverageLimit,
                            x.DeductibleAmount
                        ))
                        .ToArrayAsync(ct)
        );

    public async Task<PlanDetailsResponse> GetPlanDetailsAsync(Guid id, CancellationToken ct) =>
        await _cache.GetOrCreateAsync(
            PolicyCatalogCache.Plan(id),
            async () => await ProjectDetails(id, true, ct)
        );

    public async Task<PagedResponse<PlanAdministrationResponse>> SearchPlansAsync(
        PlanSearchRequest r,
        CancellationToken ct
    )
    {
        var q = _db.InsurancePlans.AsNoTracking();
        if (r.IsActive.HasValue)
            q = q.Where(x => x.IsActive == r.IsActive);
        if (!string.IsNullOrWhiteSpace(r.Search))
            q = q.Where(x => x.PlanCode.Contains(r.Search) || x.PlanName.Contains(r.Search));
        var total = await q.CountAsync(ct);
        var items = await q.OrderByDescending(x => x.CreatedAt)
            .ThenBy(x => x.Id)
            .Skip((r.Page - 1) * r.PageSize)
            .Take(r.PageSize)
            .Select(x => new PlanAdministrationResponse(
                x.Id,
                x.PlanCode,
                x.PlanName,
                x.Description,
                x.BasePremium,
                x.CoverageLimit,
                x.DeductibleAmount,
                x.IsActive,
                x.CreatedAt,
                x.UpdatedAt,
                Convert.ToBase64String(x.RowVersion)
            ))
            .ToArrayAsync(ct);
        return new(items, r.Page, r.PageSize, total);
    }

    public async Task<PlanAdministrationResponse> CreatePlanAsync(
        CreatePlanRequest r,
        CancellationToken ct
    )
    {
        if (await _db.InsurancePlans.AnyAsync(x => x.PlanCode == r.PlanCode.Trim().ToUpper(), ct))
            throw PolicyServiceException.Conflict(
                "POLICY_PLAN_CODE_EXISTS",
                "Plan code already exists."
            );
        var x = InsurancePlan.Create(
            r.PlanCode,
            r.PlanName,
            r.Description,
            r.BasePremium,
            r.CoverageLimit,
            r.DeductibleAmount,
            _clock.UtcNow,
            _ctx.Actor
        );
        _db.Add(x);
        await Save(ct);
        _cache.RemoveCatalog();
        return x.ToAdmin();
    }

    public async Task<PlanAdministrationResponse> UpdatePlanAsync(
        Guid id,
        UpdatePlanRequest r,
        CancellationToken ct
    )
    {
        var x = await Find(id, ct);
        if (
            await _db.InsurancePlans.AnyAsync(
                y => y.Id != id && y.PlanCode == r.PlanCode.Trim().ToUpper(),
                ct
            )
        )
            throw PolicyServiceException.Conflict(
                "POLICY_PLAN_CODE_EXISTS",
                "Plan code already exists."
            );
        ServiceSupport.OriginalRowVersion(_db, x, r.RowVersion);
        x.Update(
            r.PlanCode,
            r.PlanName,
            r.Description,
            r.BasePremium,
            r.CoverageLimit,
            r.DeductibleAmount,
            _clock.UtcNow,
            _ctx.Actor
        );
        await Save(ct);
        Evict(id);
        return x.ToAdmin();
    }

    public Task<PlanAdministrationResponse> ActivatePlanAsync(
        Guid id,
        RowVersionRequest r,
        CancellationToken ct
    ) => SetActive(id, r, true, ct);

    public Task<PlanAdministrationResponse> DeactivatePlanAsync(
        Guid id,
        RowVersionRequest r,
        CancellationToken ct
    ) => SetActive(id, r, false, ct);

    public async Task<PlanDetailsResponse> ReplacePlanCoveragesAsync(
        Guid id,
        ReplacePlanCoveragesRequest r,
        CancellationToken ct
    )
    {
        var x =
            await _db
                .InsurancePlans.Include(p => p.PlanCoverages)
                .SingleOrDefaultAsync(p => p.Id == id, ct)
            ?? throw NotFound();
        var ids = r.Coverages.Select(c => c.CoverageTypeId).Distinct().ToArray();
        var count = await _db.CoverageTypes.CountAsync(c => ids.Contains(c.Id) && c.IsActive, ct);
        if (count != ids.Length)
            throw PolicyServiceException.Unprocessable(
                "POLICY_COVERAGE_TYPE_INVALID",
                "One or more Coverage Types are unavailable."
            );
        ServiceSupport.OriginalRowVersion(_db, x, r.RowVersion);
        x.ReplaceCoverages(
            r.Coverages.Select(c => new PlanCoverageAssignment(
                c.CoverageTypeId,
                c.CoverageLimit,
                c.DeductibleAmount
            )),
            _clock.UtcNow,
            _ctx.Actor
        );
        await Save(ct);
        Evict(id);
        return await ProjectDetails(id, false, ct);
    }

    private async Task<PlanAdministrationResponse> SetActive(
        Guid id,
        RowVersionRequest r,
        bool active,
        CancellationToken ct
    )
    {
        var x = await Find(id, ct);
        ServiceSupport.OriginalRowVersion(_db, x, r.RowVersion);
        if (active)
            x.Activate(_clock.UtcNow, _ctx.Actor);
        else
            x.Deactivate(_clock.UtcNow, _ctx.Actor);
        await Save(ct);
        Evict(id);
        return x.ToAdmin();
    }

    private async Task<InsurancePlan> Find(Guid id, CancellationToken ct) =>
        await _db.InsurancePlans.SingleOrDefaultAsync(x => x.Id == id, ct) ?? throw NotFound();

    private static PolicyServiceException NotFound() =>
        PolicyServiceException.NotFound("POLICY_PLAN_NOT_FOUND", "Insurance Plan was not found.");

    private async Task<PlanDetailsResponse> ProjectDetails(
        Guid id,
        bool activeOnly,
        CancellationToken ct
    )
    {
        var plan =
            await _db
                .InsurancePlans.AsNoTracking()
                .Where(x => x.Id == id && (!activeOnly || x.IsActive))
                .Select(x => new
                {
                    x.Id,
                    x.PlanCode,
                    x.PlanName,
                    x.Description,
                    x.BasePremium,
                    x.CoverageLimit,
                    x.DeductibleAmount,
                })
                .SingleOrDefaultAsync(ct)
            ?? throw NotFound();
        var covers = await (
            from pc in _db.PlanCoverages.AsNoTracking()
            join c in _db.CoverageTypes.AsNoTracking() on pc.CoverageTypeId equals c.Id
            where pc.PlanId == id
            select new PlanCoverageResponse(
                c.Id,
                c.Name,
                c.Description,
                pc.CoverageLimit,
                pc.DeductibleAmount
            )
        ).ToArrayAsync(ct);
        return new(
            plan.Id,
            plan.PlanCode,
            plan.PlanName,
            plan.Description,
            plan.BasePremium,
            plan.CoverageLimit,
            plan.DeductibleAmount,
            covers
        );
    }

    private async Task Save(CancellationToken ct)
    {
        try
        {
            await _db.SaveChangesAsync(ct);
        }
        catch (DbUpdateConcurrencyException)
        {
            throw ServiceSupport.Concurrency();
        }
    }

    private void Evict(Guid id)
    {
        _cache.RemoveCatalog();
        _cache.Remove(PolicyCatalogCache.Plan(id));
    }
}

internal static class IPolicyCatalogCacheKey
{
    internal const string ActivePlans = PolicyCatalogCache.ActivePlans;
}


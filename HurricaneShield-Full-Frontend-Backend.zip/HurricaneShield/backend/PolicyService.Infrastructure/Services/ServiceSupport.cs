using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using PolicyService.Domain.Entities;
using PolicyService.Infrastructure.Exceptions;
using PolicyService.Infrastructure.Persistence;

namespace PolicyService.Infrastructure.Services;

internal static class ServiceSupport
{
    internal static byte[] RowVersion(string value)
    {
        try
        {
            var bytes = Convert.FromBase64String(value);
            if (bytes.Length == 8)
                return bytes;
        }
        catch (FormatException) { }
        throw new PolicyServiceException("VALIDATION_ERROR", "RowVersion is invalid.", 400);
    }

    internal static string Json<T>(T value) =>
        JsonSerializer.Serialize(value, new JsonSerializerOptions(JsonSerializerDefaults.Web));

    internal static string Hash<T>(T value) =>
        Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(Json(value))));

    internal static string NewPolicyNumber(DateTime utcNow) =>
        $"POL-{utcNow:yyyyMMddHHmmss}-{Guid.NewGuid().ToString("N")[..8].ToUpperInvariant()}";

    internal static void OriginalRowVersion<TEntity>(
        PolicyDbContext db,
        TEntity entity,
        string value
    )
        where TEntity : class =>
        db.Entry(entity).Property("RowVersion").OriginalValue = RowVersion(value);

    internal static PolicyServiceException Concurrency() =>
        PolicyServiceException.Conflict(
            "CONCURRENCY_CONFLICT",
            "The record changed after it was loaded."
        );
}


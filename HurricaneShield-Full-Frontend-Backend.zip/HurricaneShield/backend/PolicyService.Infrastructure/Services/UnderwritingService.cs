using Microsoft.EntityFrameworkCore;
using PolicyService.Application.DTOs.Common;
using PolicyService.Application.DTOs.Policies;
using PolicyService.Application.DTOs.Underwriting;
using PolicyService.Application.Interfaces;
using PolicyService.Domain.Calculations;
using PolicyService.Domain.Entities;
using PolicyService.Domain.Enums;
using PolicyService.Domain.Models;
using PolicyService.Infrastructure.Exceptions;
using PolicyService.Infrastructure.Mapping;
using PolicyService.Infrastructure.Persistence;

namespace PolicyService.Infrastructure.Services;

public sealed class UnderwritingService : IUnderwritingService
{
    private readonly PolicyDbContext _db;
    private readonly IRequestContext _ctx;
    private readonly IDateTimeProvider _clock;
    private readonly IRiskAssessmentEngine _risk;
    private readonly IPremiumCalculationEngine _premium;
    private readonly ICoverageValidationEngine _coverage;

    public UnderwritingService(
        PolicyDbContext db,
        IRequestContext ctx,
        IDateTimeProvider clock,
        IRiskAssessmentEngine risk,
        IPremiumCalculationEngine premium,
        ICoverageValidationEngine coverage
    )
    {
        _db = db;
        _ctx = ctx;
        _clock = clock;
        _risk = risk;
        _premium = premium;
        _coverage = coverage;
    }

    public async Task<PagedResponse<UnderwritingQueueItemResponse>> GetQueueAsync(
        UnderwritingSearchRequest r,
        CancellationToken ct
    )
    {
        var q =
            from review in _db.UnderwritingReviews.AsNoTracking()
            join p in _db.Policies.AsNoTracking() on review.PolicyId equals p.Id
            join plan in _db.InsurancePlans.AsNoTracking() on p.PlanId equals plan.Id
            join risk in _db.RiskAssessments.AsNoTracking() on p.Id equals risk.PolicyId
            join prop in _db.Properties.AsNoTracking() on p.Id equals prop.PolicyId
            where review.Status == UnderwritingReviewStatus.Pending
            select new
            {
                p,
                plan,
                risk,
                prop,
            };
        if (r.RiskLevel.HasValue)
            q = q.Where(x => x.risk.RiskLevel == r.RiskLevel);
        if (r.PlanId.HasValue)
            q = q.Where(x => x.p.PlanId == r.PlanId);

        var now = _clock.UtcNow.Year;
        if (r.MinimumPropertyAge.HasValue)
            q = q.Where(x => now - x.prop.YearBuilt >= r.MinimumPropertyAge.Value);
        if (r.MaximumPropertyAge.HasValue)
            q = q.Where(x => now - x.prop.YearBuilt <= r.MaximumPropertyAge.Value);
        if (r.SubmittedFrom.HasValue)
            q = q.Where(x => x.p.CreatedAt >= r.SubmittedFrom.Value);
        if (r.SubmittedTo.HasValue)
            q = q.Where(x => x.p.CreatedAt <= r.SubmittedTo.Value);

        var total = await q.CountAsync(ct);
        var items = await q.OrderBy(x => x.p.CreatedAt)
            .ThenBy(x => x.p.Id)
            .Skip((r.Page - 1) * r.PageSize)
            .Take(r.PageSize)
            .Select(x => new UnderwritingQueueItemResponse(
                x.p.Id,
                x.p.PolicyNumber,
                x.p.CustomerId,
                x.plan.Id,
                x.plan.PlanName,
                x.risk.RiskScore,
                x.risk.RiskLevel,
                now - x.prop.YearBuilt,
                x.p.CreatedAt,
                Convert.ToBase64String(x.p.RowVersion)
            ))
            .ToArrayAsync(ct);
        return new(items, r.Page, r.PageSize, total);
    }

    public async Task<UnderwritingDetailsResponse> GetReviewDetailsAsync(
        Guid id,
        CancellationToken ct
    )
    {
        var review =
            await _db
                .UnderwritingReviews.AsNoTracking()
                .Where(x => x.PolicyId == id)
                .OrderByDescending(x => x.CreatedAt)
                .FirstOrDefaultAsync(ct)
            ?? throw PolicyServiceException.NotFound(
                "POLICY_UNDERWRITING_REVIEW_NOT_FOUND",
                "Underwriting Review was not found."
            );
        return new(
            await PolicyProjection.GetDetails(_db, id, _ctx.UserId, true, ct),
            review.Id,
            review.Status,
            review.ReviewerUserId,
            review.ReviewerDisplay,
            review.Decision,
            review.ReviewedAt,
            Convert.ToBase64String(review.RowVersion)
        );
    }

    public Task<PolicyMutationResponse> ApproveAsync(
        Guid id,
        ApprovePolicyRequest r,
        CancellationToken ct
    ) =>
        Complete(
            id,
            r.Reasons,
            r.PolicyRowVersion,
            r.ReviewRowVersion,
            UnderwritingDecision.Approved,
            ct
        );

    public Task<PolicyMutationResponse> RejectAsync(
        Guid id,
        RejectPolicyRequest r,
        CancellationToken ct
    ) =>
        Complete(
            id,
            r.Reasons,
            r.PolicyRowVersion,
            r.ReviewRowVersion,
            UnderwritingDecision.Rejected,
            ct
        );

    public async Task<PolicyMutationResponse> ReviseAsync(
        Guid id,
        RevisePolicyRequest r,
        CancellationToken ct
    )
    {
        if (string.IsNullOrWhiteSpace(r.RevisionReason))
        {
            throw PolicyServiceException.Unprocessable(
                "REVISION_REASON_REQUIRED",
                "A mandatory underwriter revision reason must be supplied."
            );
        }

        var p = await _db.Policies.SingleOrDefaultAsync(x => x.Id == id, ct)
            ?? throw PolicyServiceException.NotFound("POLICY_NOT_FOUND", "Policy was not found.");

        if (p.Status != PolicyStatus.Underwriting)
        {
            throw PolicyServiceException.Conflict(
                "POLICY_NOT_IN_UNDERWRITING",
                $"Only policies in Underwriting status can be revised. Current status: {p.Status}."
            );
        }

        var review = await _db.UnderwritingReviews
            .SingleOrDefaultAsync(x => x.PolicyId == id && x.Status == UnderwritingReviewStatus.Pending, ct)
            ?? throw PolicyServiceException.NotFound("POLICY_UNDERWRITING_REVIEW_NOT_FOUND", "Pending Underwriting Review was not found.");

        ServiceSupport.OriginalRowVersion(_db, p, r.PolicyRowVersion);
        ServiceSupport.OriginalRowVersion(_db, review, r.ReviewRowVersion);

        var plan = await _db.InsurancePlans.AsNoTracking()
            .SingleOrDefaultAsync(x => x.Id == p.PlanId && x.IsActive, ct)
            ?? throw PolicyServiceException.NotFound("POLICY_PLAN_NOT_FOUND", "Insurance Plan was not found.");

        _coverage.Validate(new(r.RequestedCoverage, r.RevisedProperty.PropertyValue, plan.CoverageLimit));

        var rr = _risk.Assess(r.RevisedProperty, _clock.UtcNow.Year);
        var pr = _premium.Calculate(
            new PremiumCalculationInput(
                plan.BasePremium,
                r.RevisedProperty.PropertyValue,
                r.RevisedProperty.RiskZone,
                r.RevisedProperty.ClaimsHistoryCount,
                rr.Score,
                r.RevisedProperty.StormShutters,
                r.RevisedProperty.ImpactResistantWindows,
                r.RevisedProperty.ReinforcedRoof,
                r.RevisedProperty.EmergencyGenerator,
                r.RevisedProperty.HomeInspectionCertification
            )
        );

        // Update the Property entity with the verified/revised values
        var prop = await _db.Properties.SingleOrDefaultAsync(x => x.PolicyId == id, ct)
            ?? throw PolicyServiceException.NotFound("PROPERTY_NOT_FOUND", "Property record was not found.");

        prop.UpdateSnapshot(
            prop.CustomerPropertyOwnershipId,
            r.RevisedProperty.PropertyValue,
            r.RevisedProperty.YearBuilt,
            r.RevisedProperty.ConstructionType,
            r.RevisedProperty.RiskZone,
            r.RevisedProperty.StormShutters,
            r.RevisedProperty.ImpactResistantWindows,
            r.RevisedProperty.ReinforcedRoof,
            r.RevisedProperty.EmergencyGenerator,
            r.RevisedProperty.HomeInspectionCertification
        );

        // Update Risk Assessment & Premium Calculation
        _db.RiskAssessments.Add(
            RiskAssessment.Create(
                p.Id,
                rr.Score,
                rr.RiskLevel,
                ServiceSupport.Json(rr.Factors),
                _clock.UtcNow,
                _ctx.Actor
            )
        );

        var calc = PremiumCalculation.Create(p.Id, pr.FinalPremium, _clock.UtcNow);
        _db.PremiumCalculations.Add(calc);
        _db.PremiumBreakdowns.Add(
            PremiumBreakdown.Create(
                calc.Id,
                pr.BasePremium,
                pr.LocationRiskAdjustment,
                pr.PropertyRiskAdjustment,
                pr.ClaimsHistoryAdjustment,
                pr.RiskAdjustment,
                pr.DiscountAmount,
                pr.FinalPremium
            )
        );

        // Update Policy domain model (remains in Underwriting, updates PremiumDue and increments version)
        p.ReviseQuotation(pr.FinalPremium, _clock.UtcNow, _ctx.Actor);

        // Create new PolicyVersion audit snapshot
        _db.PolicyVersions.Add(
            PolicyVersion.Create(
                p.Id,
                p.CurrentVersionNumber,
                $"Underwriter revision: {r.RevisionReason.Trim()}",
                ServiceSupport.Json(new { RevisedProperty = r.RevisedProperty, RequestedCoverage = r.RequestedCoverage, FinalPremium = pr.FinalPremium }),
                _clock.UtcNow,
                _ctx.Actor
            )
        );

        try
        {
            await _db.SaveChangesAsync(ct);
        }
        catch (DbUpdateConcurrencyException)
        {
            throw ServiceSupport.Concurrency();
        }

        return p.ToMutation();
    }

    private async Task<PolicyMutationResponse> Complete(
        Guid id,
        IReadOnlyCollection<UnderwritingDecisionReasonRequest> reasons,
        string policyRv,
        string reviewRv,
        UnderwritingDecision decision,
        CancellationToken ct
    )
    {
        var p =
            await _db.Policies.SingleOrDefaultAsync(x => x.Id == id, ct)
            ?? throw PolicyServiceException.NotFound("POLICY_NOT_FOUND", "Policy was not found.");
        var review =
            await _db
                .UnderwritingReviews.Include(x => x.Reasons)
                .SingleOrDefaultAsync(
                    x => x.PolicyId == id && x.Status == UnderwritingReviewStatus.Pending,
                    ct
                )
            ?? throw PolicyServiceException.NotFound(
                "POLICY_UNDERWRITING_REVIEW_NOT_FOUND",
                "Pending Underwriting Review was not found."
            );
        ServiceSupport.OriginalRowVersion(_db, p, policyRv);
        ServiceSupport.OriginalRowVersion(_db, review, reviewRv);
        review.Complete(
            _ctx.UserId,
            _ctx.Actor,
            decision,
            reasons.Select(x => new DecisionReasonInput(x.ReasonCode, x.ReasonDescription)),
            _clock.UtcNow,
            _ctx.Actor
        );
        var from = p.Status;
        if (decision == UnderwritingDecision.Approved)
        {
            p.Approve(_clock.UtcNow, _ctx.Actor);
            p.MoveToPaymentPending(_clock.UtcNow, _ctx.Actor);
        }
        else
            p.Reject(_clock.UtcNow, _ctx.Actor);
        _db.PolicyLifecycleHistory.Add(
            PolicyLifecycleHistory.Create(
                p.Id,
                from,
                p.Status,
                decision.ToString(),
                _clock.UtcNow,
                _ctx.Actor,
                _ctx.CorrelationId
            )
        );
        try
        {
            await _db.SaveChangesAsync(ct);
        }
        catch (DbUpdateConcurrencyException)
        {
            throw ServiceSupport.Concurrency();
        }
        return p.ToMutation();
    }
}


﻿using Microsoft.Extensions.Logging;
using PolicyService.Application.Interfaces;

namespace PolicyService.Infrastructure.Services;

public sealed class InMemoryVectorDb : IVectorKnowledgeBase
{
    private readonly ILogger<InMemoryVectorDb> _logger;

    private readonly record struct KnowledgeChunk(string Id, string Source, string Content, string[] Tags);

    private readonly List<KnowledgeChunk> _corpus = new()
    {
        new(
            "FBC-1609-1",
            "FL-Building-Code-Wind-Mitigation.txt",
            "FLORIDA BUILDING CODE SECTION 1609.1.1: All residential structures located in Risk Zone A (High Velocity Hurricane Zone / Coastal) must possess impact-resistant windows or verified storm shutters.",
            new[] { "zone a", "windows", "shutters", "impact" }
        ),
        new(
            "FBC-1609-2",
            "FL-Building-Code-Wind-Mitigation.txt",
            "FLORIDA BUILDING CODE SECTION 1609.1.2: Structures built prior to the year 2001 located in Risk Zones A or B must undergo a mandatory roof reinforcement inspection prior to policy binding.",
            new[] { "pre-2001", "roof", "inspection", "zone a", "zone b" }
        ),
        new(
            "UW-101",
            "HurricaneShield-Underwriting-Guidelines.txt",
            "HURRICANESHIELD UNDERWRITING RULE UW-101: Any property with a requested coverage value exceeding ₹1,500,000 in Risk Zone A or B requires mandatory senior underwriter review.",
            new[] { "coverage", "high value", "zone a", "zone b", "manual review" }
        ),
        new(
            "UW-205",
            "HurricaneShield-Underwriting-Guidelines.txt",
            "HURRICANESHIELD UNDERWRITING RULE UW-205: Wood frame construction in Risk Zone A is strictly prohibited and must be declined.",
            new[] { "wood frame", "construction", "zone a", "prohibited" }
        ),
        new(
            "STAT-627-1",
            "State-Mandatory-Discounts.txt",
            "FLORIDA STATUTE 627.0629: Insurers must provide mandatory premium credits for verified windstorm mitigation: 5% for Impact Windows, 10% for Reinforced Roof, and 3% for Certified Home Inspection.",
            new[] { "discount", "mitigation", "statute", "credit" }
        )
    };

    public InMemoryVectorDb(ILogger<InMemoryVectorDb> logger)
    {
        _logger = logger;
    }

    public Task<string> RetrieveContextAsync(string query, int topK = 3, CancellationToken ct = default)
    {
        _logger.LogInformation("Querying Vector Knowledge Base with query: {Query}", query);

        var queryTerms = query.ToLowerInvariant().Split(' ', StringSplitOptions.RemoveEmptyEntries);

        // Simulated semantic similarity search (ranking by term intersection and tag relevance)
        var ranked = _corpus
            .Select(chunk =>
            {
                int score = 0;
                var contentLower = chunk.Content.ToLowerInvariant();
                foreach (var term in queryTerms)
                {
                    if (contentLower.Contains(term)) score += 2;
                    if (chunk.Tags.Any(t => t.Contains(term))) score += 5;
                }
                return new { Chunk = chunk, Score = score };
            })
            .Where(x => x.Score > 0)
            .OrderByDescending(x => x.Score)
            .Take(topK)
            .Select(x => $"[Source: {x.Chunk.Source} | Document ID: {x.Chunk.Id}]\n{x.Chunk.Content}")
            .ToList();

        if (ranked.Count == 0)
        {
            // Fallback to top 2 primary regulations if query is sparse
            ranked = _corpus
                .Take(2)
                .Select(chunk => $"[Source: {chunk.Source} | Document ID: {chunk.Id}]\n{chunk.Content}")
                .ToList();
        }

        var retrievedContext = string.Join("\n\n", ranked);
        return Task.FromResult(retrievedContext);
    }
}


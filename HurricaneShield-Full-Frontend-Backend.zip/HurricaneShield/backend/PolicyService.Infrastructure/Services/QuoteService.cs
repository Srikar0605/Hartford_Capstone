using Microsoft.EntityFrameworkCore;
using PolicyService.Application.DTOs.Integrations;
using PolicyService.Application.DTOs.Plans;
using PolicyService.Application.DTOs.Quotes;
using PolicyService.Application.Interfaces;
using PolicyService.Domain.Calculations;
using PolicyService.Domain.Enums;
using PolicyService.Domain.Models;
using PolicyService.Infrastructure.Exceptions;
using PolicyService.Infrastructure.Persistence;

namespace PolicyService.Infrastructure.Services;

public sealed class QuoteService : IQuoteService
{
    private readonly PolicyDbContext _db;
    private readonly IRiskAssessmentEngine _risk;
    private readonly IClaimsCoverageClient _claims;
    private readonly IPremiumCalculationEngine _premium;
    private readonly ICoverageValidationEngine _coverage;
    private readonly IDateTimeProvider _clock;
    private readonly IRiskZoneEvaluator _riskZoneEvaluator;
    private readonly ICustomerEligibilityClient _customer;

    public QuoteService(
        PolicyDbContext db,
        IRiskAssessmentEngine risk,
        IPremiumCalculationEngine premium,
        ICoverageValidationEngine coverage,
        IDateTimeProvider clock,
        IClaimsCoverageClient claims,
        IRiskZoneEvaluator riskZoneEvaluator,
        ICustomerEligibilityClient customer
    )
    {
        _db = db;
        _risk = risk;
        _premium = premium;
        _coverage = coverage;
        _clock = clock;
        _claims = claims;
        _riskZoneEvaluator = riskZoneEvaluator;
        _customer = customer;
    }

    public async Task<QuoteResponse> CalculateCustomerQuoteAsync(
        CustomerQuoteRequest request,
        CancellationToken cancellationToken
    )
    {
        var ownershipId = request.Quote.Property.CustomerPropertyOwnershipId;

        var claimsHistoryCount = 0;
        RiskZone evaluatedRiskZone = RiskZone.C;

        if (ownershipId.HasValue)
        {
            var policyIds = await (
                from policyRecord in _db.Policies.AsNoTracking()
                join propertyRecord in _db.Properties.AsNoTracking()
                    on policyRecord.Id equals propertyRecord.PolicyId
                where
                    policyRecord.CustomerId == request.CustomerId
                    && propertyRecord.CustomerPropertyOwnershipId == ownershipId.Value
                select policyRecord.Id
            )
                .Distinct()
                .ToArrayAsync(cancellationToken);

            if (policyIds.Length > 0)
            {
                var claimHistory = await _claims.GetClaimHistoryCountAsync(
                    policyIds,
                    cancellationToken
                );

                claimsHistoryCount = claimHistory.Count;
            }
            
            // Fetch properties to get coordinates for automated Risk Zone evaluation
            var customerProperties = await _customer.GetCustomerPropertiesAsync(request.CustomerId, cancellationToken) ?? Array.Empty<CustomerPropertyResponse>();
            var propertyDetails = customerProperties.SingleOrDefault(p => p.PropertyOwnershipId == ownershipId.Value);
            
            if (propertyDetails != null && propertyDetails.Latitude.HasValue && propertyDetails.Longitude.HasValue)
            {
                evaluatedRiskZone = await _riskZoneEvaluator.EvaluateRiskZoneAsync(
                    propertyDetails.Latitude.Value, 
                    propertyDetails.Longitude.Value, 
                    cancellationToken
                );
            }
        }

        var quoteProperty = request.Quote.Property with { ClaimsHistoryCount = claimsHistoryCount };

        return await CalculateQuoteInternalAsync(
            request.Quote with
            {
                Property = quoteProperty,
            },
            evaluatedRiskZone,
            cancellationToken
        );
    }

    public async Task<QuoteResponse> CalculateQuoteAsync(
        CalculateQuoteRequest r,
        CancellationToken ct
    )
    {
        // Public method assumes default Zone C if not a customer quote
        return await CalculateQuoteInternalAsync(r, RiskZone.C, ct);
    }
    
    private async Task<QuoteResponse> CalculateQuoteInternalAsync(
        CalculateQuoteRequest r,
        RiskZone riskZone,
        CancellationToken ct
    )
    {
        var plan =
            await _db
                .InsurancePlans.AsNoTracking()
                .Where(x => x.Id == r.PlanId && x.IsActive)
                .Select(x => new PlanSummaryResponse(
                    x.Id,
                    x.PlanCode,
                    x.PlanName,
                    x.Description,
                    x.BasePremium,
                    x.CoverageLimit,
                    x.DeductibleAmount
                ))
                .SingleOrDefaultAsync(ct)
            ?? throw PolicyServiceException.NotFound(
                "POLICY_PLAN_NOT_FOUND",
                "Insurance Plan was not found."
            );
        _coverage.Validate(new(r.RequestedCoverage, r.Property.PropertyValue, plan.CoverageLimit));
        var input = new PropertyRiskInput(
            r.Property.PropertyValue,
            r.Property.YearBuilt,
            r.Property.ConstructionType,
            riskZone,
            r.Property.ClaimsHistoryCount,
            r.Property.StormShutters,
            r.Property.ImpactResistantWindows,
            r.Property.ReinforcedRoof,
            r.Property.EmergencyGenerator,
            r.Property.HomeInspectionCertification
        );
        var risk = _risk.Assess(input, _clock.UtcNow.Year);
        var premium = _premium.Calculate(
            new PremiumCalculationInput(
                plan.BasePremium,
                r.Property.PropertyValue,
                riskZone,
                r.Property.ClaimsHistoryCount,
                risk.Score,
                r.Property.StormShutters,
                r.Property.ImpactResistantWindows,
                r.Property.ReinforcedRoof,
                r.Property.EmergencyGenerator,
                r.Property.HomeInspectionCertification
            )
        );
        return new QuoteResponse(
            plan,
            r.RequestedCoverage,
            r.Property,
            new(
                risk.Score,
                risk.RiskLevel,
                risk.PropertyAge,
                risk.Score >= 70m,
                risk.Factors.Select(x => new RiskFactorResponse(x.Key, x.Value)).ToArray()
            ),
            new(
                premium.BasePremium,
                premium.LocationRiskAdjustment,
                premium.PropertyRiskAdjustment,
                premium.ClaimsHistoryAdjustment,
                premium.RiskAdjustment,
                premium.DiscountAmount,
                premium.FinalPremium
            ),
            riskZone.ToString()
        );
    }

    public async Task<IReadOnlyCollection<QuoteResponse>> CalculateRecommendationsAsync(
        CalculateRecommendationsRequest r,
        CancellationToken ct
    )
    {
        var activePlans = await _db
            .InsurancePlans.AsNoTracking()
            .Where(x => x.IsActive && x.CoverageLimit >= r.RequestedCoverage)
            .OrderBy(x => x.BasePremium)
            .Select(x => new PlanSummaryResponse(
                x.Id,
                x.PlanCode,
                x.PlanName,
                x.Description,
                x.BasePremium,
                x.CoverageLimit,
                x.DeductibleAmount
            ))
            .ToArrayAsync(ct);

        if (activePlans.Length == 0)
        {
            return Array.Empty<QuoteResponse>();
        }

        var results = new List<QuoteResponse>();
        foreach (var plan in activePlans)
        {
            var quote = await CalculateQuoteInternalAsync(
                new CalculateQuoteRequest(plan.PlanId, r.RequestedCoverage, r.Property),
                RiskZone.C, // Simplified, since the API doesn't have customer ID context
                ct
            );
            results.Add(quote);
        }

        return results.OrderBy(q => q.Premium.FinalPremium).ToArray();
    }
}


using Microsoft.EntityFrameworkCore;
using PolicyService.Application.DTOs.Payments;
using PolicyService.Application.DTOs.Policies;
using PolicyService.Application.Interfaces;
using PolicyService.Domain.Entities;
using PolicyService.Domain.Enums;
using PolicyService.Infrastructure.Exceptions;
using PolicyService.Infrastructure.Mapping;
using PolicyService.Infrastructure.Persistence;

namespace PolicyService.Infrastructure.Services;

public sealed class PolicyPaymentService : IPolicyPaymentService
{
    private readonly PolicyDbContext _db;
    private readonly IRequestContext _ctx;
    private readonly IDateTimeProvider _clock;

    public PolicyPaymentService(PolicyDbContext db, IRequestContext ctx, IDateTimeProvider clock)
    {
        _db = db;
        _ctx = ctx;
        _clock = clock;
    }

    public async Task<PremiumValidationResponse> ValidatePremiumAsync(
        Guid policyId,
        Guid authUserId,
        CancellationToken cancellationToken
    )
    {
        var policy =
            await _db
                .Policies.AsNoTracking()
                .SingleOrDefaultAsync(value => value.Id == policyId, cancellationToken)
            ?? throw PolicyServiceException.NotFound("POLICY_NOT_FOUND", "Policy was not found.");

        var ownerMatches = policy.AuthUserId == authUserId;

        var isPaymentPending = policy.Status is PolicyStatus.PaymentPending or PolicyStatus.Renewed;

        var paymentContext = policy.Status == PolicyStatus.Renewed ? "Renewal" : "Initial";
        var rowVersion = Convert.ToBase64String(policy.RowVersion);

        string? reason = null;

        if (!ownerMatches)
        {
            reason = "Policy does not belong to the authenticated Customer.";
        }
        else if (!isPaymentPending)
        {
            reason = "Policy is not awaiting payment.";
        }

        return new PremiumValidationResponse(
            policy.Id,
            policy.CustomerId,
            policy.AuthUserId,
            ownerMatches,
            isPaymentPending,
            policy.PremiumDue,
            paymentContext,
            rowVersion,
            reason
        );
    }

    public Task<PolicyMutationResponse> ConfirmInitialPaymentAsync(
        Guid id,
        PaymentConfirmationRequest r,
        CancellationToken ct
    ) => Confirm(id, r, false, ct);

    public Task<PolicyMutationResponse> ConfirmRenewalPaymentAsync(
        Guid id,
        PaymentConfirmationRequest r,
        CancellationToken ct
    ) => Confirm(id, r, true, ct);

    private async Task<PolicyMutationResponse> Confirm(
        Guid id,
        PaymentConfirmationRequest r,
        bool renewal,
        CancellationToken ct
    )
    {
        var p =
            await _db.Policies.SingleOrDefaultAsync(
                x =>
                    x.Id == id
                    && (x.AuthUserId == _ctx.UserId || _ctx.Roles.Contains("Administrator")),
                ct
            ) ?? throw PolicyServiceException.NotFound("POLICY_NOT_FOUND", "Policy was not found.");
        if (p.PremiumDue != r.Amount)
            throw PolicyServiceException.Unprocessable(
                "POLICY_PAYMENT_AMOUNT_MISMATCH",
                "Payment amount does not match Premium due."
            );
        ServiceSupport.OriginalRowVersion(_db, p, r.RowVersion);
        var from = p.Status;
        if (renewal)
            p.ConfirmRenewalPayment(r.TransactionId, r.ProcessedAt, _ctx.Actor);
        else
            p.ConfirmInitialPayment(r.TransactionId, r.ProcessedAt, _ctx.Actor);
        if (from != p.Status)
            _db.PolicyLifecycleHistory.Add(
                PolicyLifecycleHistory.Create(
                    p.Id,
                    from,
                    p.Status,
                    "Payment confirmed.",
                    r.ProcessedAt,
                    _ctx.Actor,
                    _ctx.CorrelationId
                )
            );
        try
        {
            await _db.SaveChangesAsync(ct);
        }
        catch (DbUpdateConcurrencyException)
        {
            throw ServiceSupport.Concurrency();
        }
        return p.ToMutation();
    }
}


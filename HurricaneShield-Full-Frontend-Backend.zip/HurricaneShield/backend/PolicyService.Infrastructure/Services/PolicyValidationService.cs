using Microsoft.EntityFrameworkCore;
using PolicyService.Application.DTOs.Validation;
using PolicyService.Application.Interfaces;
using PolicyService.Domain.Calculations;
using PolicyService.Domain.Entities;
using PolicyService.Domain.Enums;
using PolicyService.Infrastructure.Exceptions;
using PolicyService.Infrastructure.Persistence;

namespace PolicyService.Infrastructure.Services;

public sealed class PolicyValidationService : IPolicyValidationService
{
    private readonly PolicyDbContext _db;
    private readonly IClaimsCoverageClient _claims;
    private readonly ICoverageValidationEngine _coverage;
    private readonly IRequestContext _context;
    private readonly IDateTimeProvider _clock;

    public PolicyValidationService(
        PolicyDbContext db,
        IClaimsCoverageClient claims,
        ICoverageValidationEngine coverage,
        IRequestContext context,
        IDateTimeProvider clock
    )
    {
        _db = db;
        _claims = claims;
        _coverage = coverage;
        _context = context;
        _clock = clock;
    }

    public async Task<PolicyValidationResponse> ValidatePolicyAsync(
        Guid policyId,
        Guid authUserId,
        CancellationToken cancellationToken
    )
    {
        /*
         * A Customer can validate only their own identity.
         * Claims Manager and Administrator can validate on
         * behalf of another authenticated user.
         */
        if (!HasStaffAccess() && authUserId != _context.UserId)
        {
            throw PolicyServiceException.NotFound("POLICY_NOT_FOUND", "Policy was not found.");
        }

        var policy =
            await AccessiblePolicies()
                .SingleOrDefaultAsync(value => value.Id == policyId, cancellationToken)
            ?? throw PolicyServiceException.NotFound("POLICY_NOT_FOUND", "Policy was not found.");

        // Lazy term reconciliation:
        // If an Active policy has reached its expiration date, mark it Expired.
        if (policy.Status == PolicyStatus.Active && policy.ExpirationDate.HasValue && _clock.UtcNow >= policy.ExpirationDate.Value)
        {
            policy.Expire(_clock.UtcNow, "system");
            _db.PolicyLifecycleHistory.Add(
                PolicyLifecycleHistory.Create(
                    policy.Id,
                    PolicyStatus.Active,
                    PolicyStatus.Expired,
                    "Policy term expired at scheduled boundary.",
                    _clock.UtcNow,
                    "system",
                    _context.CorrelationId
                )
            );

            // If a paid, Scheduled successor exists for this policy and has reached its effective date, activate it.
            var successor = await _db.Policies.SingleOrDefaultAsync(
                s => s.PreviousPolicyId == policy.Id && s.Status == PolicyStatus.Scheduled,
                cancellationToken
            );

            if (successor != null && successor.EffectiveDate.HasValue && _clock.UtcNow >= successor.EffectiveDate.Value)
            {
                successor.ActivateScheduled(_clock.UtcNow, "system");
                _db.PolicyLifecycleHistory.Add(
                    PolicyLifecycleHistory.Create(
                        successor.Id,
                        PolicyStatus.Scheduled,
                        PolicyStatus.Active,
                        $"Successor activated at scheduled effective boundary for prior policy {policy.PolicyNumber}.",
                        _clock.UtcNow,
                        "system",
                        _context.CorrelationId
                    )
                );
            }

            try
            {
                await _db.SaveChangesAsync(cancellationToken);
            }
            catch (DbUpdateConcurrencyException)
            {
                // Tolerate race condition if a concurrent worker or request already performed the transition
            }
        }

        var ownerMatches = policy.AuthUserId == authUserId;

        var isActive = policy.Status == PolicyStatus.Active;

        string? reason = null;

        if (!ownerMatches)
        {
            reason = "Policy does not belong to the authenticated user.";
        }
        else if (!isActive)
        {
            reason = "Policy is not active.";
        }

        return new PolicyValidationResponse(
            policy.Id,
            policy.PolicyNumber,
            policy.CustomerId,
            policy.AuthUserId,
            policy.Status.ToString(),
            ownerMatches,
            isActive,
            policy.EffectiveDate ?? policy.CreatedAt,
            policy.ExpirationDate ?? policy.CreatedAt.AddYears(1),
            reason
        );
    }

    public async Task<CoverageValidationResponse> ValidateCoverageAsync(
        Guid policyId,
        Guid coverageTypeId,
        CancellationToken cancellationToken
    )
    {
        /*
         * AccessiblePolicies filters Customer access by AuthUserId.
         * Claims Managers and Administrators can inspect any Policy.
         */
        var accessiblePolicies = AccessiblePolicies();

        var coverageRow =
            await (
                from policy in accessiblePolicies

                join planCoverage in _db.PlanCoverages.AsNoTracking()
                    on policy.PlanId equals planCoverage.PlanId

                join coverageType in _db.CoverageTypes.AsNoTracking()
                    on planCoverage.CoverageTypeId equals coverageType.Id

                where policy.Id == policyId && coverageType.Id == coverageTypeId

                select new
                {
                    Policy = policy,
                    PlanCoverage = planCoverage,
                    CoverageType = coverageType,
                }
            ).SingleOrDefaultAsync(cancellationToken)
            ?? throw PolicyServiceException.NotFound(
                "POLICY_COVERAGE_TYPE_NOT_FOUND",
                "Policy Coverage was not found."
            );

        /*
         * Preserve the existing CoverageValidationResponse
         * constructor contract.
         *
         * The final true indicates that the requested Coverage
         * exists in the Policy's Plan.
         */
        return new CoverageValidationResponse(
            policyId,
            coverageRow.CoverageType.Id,
            coverageRow.CoverageType.Name,
            coverageRow.PlanCoverage.CoverageLimit,
            coverageRow.PlanCoverage.DeductibleAmount,
            true,
            null
        );
    }

    public async Task<CoverageBalanceResponse> GetCoverageBalanceAsync(
        Guid policyId,
        Guid coverageTypeId,
        CancellationToken cancellationToken
    )
    {
        /*
         * ValidateCoverageAsync performs ownership authorization
         * before Claims Service is called.
         */
        var coverage = await ValidateCoverageAsync(policyId, coverageTypeId, cancellationToken);

        var consumedCoverage = await _claims.GetConsumedCoverageAsync(
            policyId,
            coverageTypeId,
            cancellationToken
        );

        var remainingAmount = _coverage.CalculateRemainingBalance(
            coverage.CoverageLimit,
            consumedCoverage.ConsumedAmount
        );

        return new CoverageBalanceResponse(
            policyId,
            coverageTypeId,
            coverage.CoverageLimit,
            consumedCoverage.ConsumedAmount,
            remainingAmount
        );
    }

    private bool HasStaffAccess()
    {
        return _context.Roles.Contains("Claims Manager")
            || _context.Roles.Contains("Administrator");
    }

    private IQueryable<Policy> AccessiblePolicies()
    {
        IQueryable<Policy> policies = _db.Policies.AsNoTracking();

        if (HasStaffAccess())
        {
            return policies;
        }

        return policies.Where(policy => policy.AuthUserId == _context.UserId);
    }
}


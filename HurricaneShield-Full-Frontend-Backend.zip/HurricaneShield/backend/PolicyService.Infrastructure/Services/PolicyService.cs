using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using PolicyService.Application.DTOs.Common;
using PolicyService.Application.DTOs.Integrations;
using PolicyService.Application.DTOs.Policies;
using PolicyService.Application.DTOs.Quotes;
using PolicyService.Application.Interfaces;
using PolicyService.Domain.Calculations;
using PolicyService.Domain.Entities;
using PolicyService.Domain.Enums;
using PolicyService.Domain.Models;
using PolicyService.Infrastructure.Exceptions;
using PolicyService.Infrastructure.Mapping;
using PolicyService.Infrastructure.Persistence;

namespace PolicyService.Infrastructure.Services;

/// <summary>
/// Service implementing policy application, underwriting transitions, renewals, and lifecycle operations.
/// In our Simplified Clean Architecture, this service acts as the orchestration and transaction boundary.
/// It coordinates interservice communication (CustomerService for eligibility, ClaimsService for history),
/// delegates risk and pricing to pure domain calculation engines, and enforces true idempotency.
/// </summary>
public sealed class PolicyService : IPolicyService
{
    private readonly PolicyDbContext _db;
    private readonly IRequestContext _ctx;
    private readonly IDateTimeProvider _clock;
    private readonly ICustomerEligibilityClient _customer;
    private readonly IClaimsCoverageClient _claims;
    private readonly IPaymentClient _payments;
    private readonly IRiskAssessmentEngine _risk;
    private readonly IPremiumCalculationEngine _premium;
    private readonly ICoverageValidationEngine _coverage;
    private readonly IUnderwritingDecisionEngine _underwriting;
    private readonly IRiskZoneEvaluator _riskZoneEvaluator;
    private readonly IComplianceAgentClient _complianceAgent;

    public PolicyService(
        PolicyDbContext db,
        IRequestContext ctx,
        IDateTimeProvider clock,
        ICustomerEligibilityClient customer,
        IClaimsCoverageClient claims,
        IPaymentClient payments,
        IRiskAssessmentEngine risk,
        IPremiumCalculationEngine premium,
        ICoverageValidationEngine coverage,
        IUnderwritingDecisionEngine underwriting,
        IRiskZoneEvaluator riskZoneEvaluator,
        IComplianceAgentClient complianceAgent
    )
    {
        _db = db;
        _ctx = ctx;
        _clock = clock;
        _customer = customer;
        _claims = claims;
        _payments = payments;
        _risk = risk;
        _premium = premium;
        _coverage = coverage;
        _underwriting = underwriting;
        _riskZoneEvaluator = riskZoneEvaluator;
        _complianceAgent = complianceAgent;
    }

    public async Task<PolicyApplicationResponse> ApplyAsync(
        CreatePolicyApplicationRequest r,
        string key,
        CancellationToken ct
    )
    {
        if (string.IsNullOrWhiteSpace(key))
            throw new PolicyServiceException(
                "IDEMPOTENCY_KEY_REQUIRED",
                "X-Idempotency-Key is required.",
                400
            );

        // TRUE IDEMPOTENCY: Check if this application request was already processed under this idempotency key.
        var hash = ServiceSupport.Hash(r);
        var existing = await _db
            .IdempotencyRecords.AsNoTracking()
            .SingleOrDefaultAsync(
                x =>
                    x.Operation == IdempotencyOperation.PolicyPurchase
                    && x.Key == key
                    && x.ExpiresAt > _clock.UtcNow,
                ct
            );

        if (existing is not null)
        {
            if (existing.RequestHash != hash)
                throw PolicyServiceException.Conflict(
                    "IDEMPOTENCY_KEY_REUSED",
                    "Idempotency key was reused with a different request."
                );

            var replay =
                System.Text.Json.JsonSerializer.Deserialize<PolicyApplicationResponse>(
                    existing.ResponseBody,
                    new System.Text.Json.JsonSerializerOptions(
                        System.Text.Json.JsonSerializerDefaults.Web
                    )
                )
                ?? throw new InvalidOperationException(
                    "Stored Policy application response could not be deserialized."
                );

            var current = await _db
                .Policies.AsNoTracking()
                .Where(x => x.Id == existing.ResourceId)
                .Select(x => x.RowVersion)
                .SingleAsync(ct);

            return replay with { RowVersion = Convert.ToBase64String(current) };
        }

        // Verify customer account eligibility with CustomerService via typed HttpClient.
        var eligibility = await _customer.GetEligibilityAsync(r.CustomerId, ct);
        if (!eligibility.IsEligible)
            throw PolicyServiceException.Unprocessable(
                "CUSTOMER_NOT_ELIGIBLE",
                string.Join("; ", eligibility.Reasons)
            );
            
        // Fetch properties to get coordinates for automated Risk Zone evaluation
        var customerProperties = await _customer.GetCustomerPropertiesAsync(r.CustomerId, ct) ?? Array.Empty<CustomerPropertyResponse>();
        var propertyDetails = customerProperties.SingleOrDefault(p => p.PropertyOwnershipId == r.Property.CustomerPropertyOwnershipId)
            ?? throw PolicyServiceException.NotFound("PROPERTY_NOT_FOUND", "Customer property record was not found.");
            
        RiskZone evaluatedRiskZone = RiskZone.C; // Default
        if (propertyDetails.Latitude.HasValue && propertyDetails.Longitude.HasValue)
        {
            evaluatedRiskZone = await _riskZoneEvaluator.EvaluateRiskZoneAsync(
                propertyDetails.Latitude.Value, 
                propertyDetails.Longitude.Value, 
                ct
            );
        }

        // Prevent double insurance: ensure this property does not already have an active policy.
        if (r.Property.CustomerPropertyOwnershipId.HasValue)
        {
            var alreadyInsured = await (
                from prop in _db.Properties.AsNoTracking()
                join pol in _db.Policies.AsNoTracking() on prop.PolicyId equals pol.Id
                where prop.CustomerPropertyOwnershipId
                    == r.Property.CustomerPropertyOwnershipId.Value
                    && pol.Status != PolicyStatus.Cancelled
                    && pol.Status != PolicyStatus.Expired
                select pol.Id
            ).AnyAsync(ct);

            if (alreadyInsured)
            {
                throw PolicyServiceException.Conflict(
                    "PROPERTY_ALREADY_INSURED",
                    "This property is already insured or has an active policy application."
                );
            }
        }


        var activeCount = await _db.Policies.CountAsync(
            x =>
                x.CustomerId == r.CustomerId
                && (
                    x.Status == PolicyStatus.Active
                    || x.Status == PolicyStatus.Suspended
                    || x.Status == PolicyStatus.Renewed
                ),
            ct
        );
        if (activeCount >= 3)
            throw PolicyServiceException.Unprocessable(
                "CUSTOMER_MAX_POLICIES_REACHED",
                "Customer already has three active Policies."
            );
        var plan =
            await _db
                .InsurancePlans.AsNoTracking()
                .SingleOrDefaultAsync(x => x.Id == r.PlanId && x.IsActive, ct)
            ?? throw PolicyServiceException.NotFound(
                "POLICY_PLAN_NOT_FOUND",
                "Insurance Plan was not found."
            );
        _coverage.Validate(new(r.RequestedCoverage, r.Property.PropertyValue, plan.CoverageLimit));
        var ri = new PropertyRiskInput(
            r.Property.PropertyValue,
            r.Property.YearBuilt,
            r.Property.ConstructionType,
            evaluatedRiskZone,
            r.Property.ClaimsHistoryCount,
            r.Property.StormShutters,
            r.Property.ImpactResistantWindows,
            r.Property.ReinforcedRoof,
            r.Property.EmergencyGenerator,
            r.Property.HomeInspectionCertification
        );
        var rr = _risk.Assess(ri, _clock.UtcNow.Year);
        var pr = _premium.Calculate(
            new PremiumCalculationInput(
                plan.BasePremium,
                r.Property.PropertyValue,
                evaluatedRiskZone,
                r.Property.ClaimsHistoryCount,
                rr.Score,
                r.Property.StormShutters,
                r.Property.ImpactResistantWindows,
                r.Property.ReinforcedRoof,
                r.Property.EmergencyGenerator,
                r.Property.HomeInspectionCertification
            )
        );
        var decision = _underwriting.Decide(rr.Score, rr.PropertyAge);
        var p = Policy.CreateDraft(
            ServiceSupport.NewPolicyNumber(_clock.UtcNow),
            _ctx.UserId,
            r.CustomerId,
            r.PlanId,
            pr.FinalPremium,
            _clock.UtcNow,
            _ctx.Actor
        );
        _db.Policies.Add(p);
        p.Submit(_clock.UtcNow, _ctx.Actor);
        _db.PolicyLifecycleHistory.Add(
            PolicyLifecycleHistory.Create(
                p.Id,
                PolicyStatus.Draft,
                PolicyStatus.Submitted,
                "Application submitted.",
                _clock.UtcNow,
                _ctx.Actor,
                _ctx.CorrelationId
            )
        );
        p.StartUnderwriting(_clock.UtcNow, "system");
        _db.PolicyLifecycleHistory.Add(
            PolicyLifecycleHistory.Create(
                p.Id,
                PolicyStatus.Submitted,
                PolicyStatus.Underwriting,
                "Automatic underwriting started.",
                _clock.UtcNow,
                "system",
                _ctx.CorrelationId
            )
        );
        p.EstablishInitialVersion();
        _db.Properties.Add(
            Property.Create(
                p.Id,
                r.Property.CustomerPropertyOwnershipId,
                r.Property.PropertyValue,
                r.Property.YearBuilt,
                r.Property.ConstructionType,
                evaluatedRiskZone,
                r.Property.StormShutters,
                r.Property.ImpactResistantWindows,
                r.Property.ReinforcedRoof,
                r.Property.EmergencyGenerator,
                r.Property.HomeInspectionCertification
            )
        );
        _db.RiskAssessments.Add(
            RiskAssessment.Create(
                p.Id,
                rr.Score,
                rr.RiskLevel,
                ServiceSupport.Json(rr.Factors),
                _clock.UtcNow,
                "system"
            )
        );
        var calc = PremiumCalculation.Create(p.Id, pr.FinalPremium, _clock.UtcNow);
        _db.PremiumCalculations.Add(calc);
        _db.PremiumBreakdowns.Add(
            PremiumBreakdown.Create(
                calc.Id,
                pr.BasePremium,
                pr.LocationRiskAdjustment,
                pr.PropertyRiskAdjustment,
                pr.ClaimsHistoryAdjustment,
                pr.RiskAdjustment,
                pr.DiscountAmount,
                pr.FinalPremium
            )
        );
        _db.PolicyVersions.Add(
            PolicyVersion.Create(
                p.Id,
                1,
                "Initial application",
                ServiceSupport.Json(r),
                _clock.UtcNow,
                _ctx.Actor
            )
        );
        if (decision.Decision == UnderwritingDecision.Approved)
        {
            p.Approve(_clock.UtcNow, "system");
            _db.PolicyLifecycleHistory.Add(
                PolicyLifecycleHistory.Create(
                    p.Id,
                    PolicyStatus.Underwriting,
                    PolicyStatus.Approved,
                    "Automatic underwriting approved.",
                    _clock.UtcNow,
                    "system",
                    _ctx.CorrelationId
                )
            );
            p.MoveToPaymentPending(_clock.UtcNow, "system");
            _db.PolicyLifecycleHistory.Add(
                PolicyLifecycleHistory.Create(
                    p.Id,
                    PolicyStatus.Approved,
                    PolicyStatus.PaymentPending,
                    "Initial premium payment required.",
                    _clock.UtcNow,
                    "system",
                    _ctx.CorrelationId
                )
            );
        }
        else if (decision.Decision == UnderwritingDecision.Rejected)
        {
            p.Reject(_clock.UtcNow, "system");
            _db.PolicyLifecycleHistory.Add(
                PolicyLifecycleHistory.Create(
                    p.Id,
                    PolicyStatus.Underwriting,
                    PolicyStatus.Cancelled,
                    "Automatic underwriting rejected.",
                    _clock.UtcNow,
                    "system",
                    _ctx.CorrelationId
                )
            );
        }
        else
        {
            _db.UnderwritingReviews.Add(
                UnderwritingReview.CreatePending(p.Id, _clock.UtcNow, "system")
            );

            // Invoke Autonomous Compliance Agent to evaluate property against RAG Building Codes & Guidelines
            var agentResult = await _complianceAgent.EvaluatePolicyAsync(ri, r.RequestedCoverage, ct);
            _db.ComplianceReviews.Add(
                ComplianceReview.Create(
                    p.Id,
                    agentResult.IsCompliant,
                    agentResult.ConfidenceScore,
                    agentResult.Summary,
                    agentResult.Violations,
                    agentResult.MissingDiscounts,
                    agentResult.RiskAssessment,
                    agentResult.RecommendedActions,
                    agentResult.Citations,
                    _clock.UtcNow,
                    agentResult.Engine
                )
            );
        }
        var response = new PolicyApplicationResponse(
            p.Id,
            p.PolicyNumber,
            p.Status,
            p.PlanId,
            p.PremiumDue,
            rr.Score,
            rr.RiskLevel,
            p.CurrentVersionNumber,
            Convert.ToBase64String(p.RowVersion),
            decision.Decision
        );
        var record = IdempotencyRecord.Create(
            IdempotencyOperation.PolicyPurchase,
            key,
            hash,
            201,
            ServiceSupport.Json(response),
            p.Id,
            _clock.UtcNow
        );
        _db.IdempotencyRecords.Add(record);
        await _db.SaveChangesAsync(ct);
        return response with { RowVersion = Convert.ToBase64String(p.RowVersion) };
    }

    public async Task<PagedResponse<StaffPolicySummaryResponse>> SearchPoliciesAsync(
        StaffPolicySearchRequest request,
        CancellationToken ct
    )
    {
        var query =
            from policy in _db.Policies.AsNoTracking()
            join plan in _db.InsurancePlans.AsNoTracking() on policy.PlanId equals plan.Id
            select new { Policy = policy, Plan = plan };

        if (!string.IsNullOrWhiteSpace(request.Search))
        {
            var search = request.Search.Trim();
            query = query.Where(x => x.Policy.PolicyNumber.Contains(search));
        }
        if (request.Status.HasValue)
            query = query.Where(x => x.Policy.Status == request.Status.Value);
        if (request.CustomerId.HasValue)
            query = query.Where(x => x.Policy.CustomerId == request.CustomerId.Value);
        if (request.PlanId.HasValue)
            query = query.Where(x => x.Policy.PlanId == request.PlanId.Value);
        if (request.CreatedFrom.HasValue)
            query = query.Where(x => x.Policy.CreatedAt >= request.CreatedFrom.Value);
        if (request.CreatedTo.HasValue)
            query = query.Where(x => x.Policy.CreatedAt <= request.CreatedTo.Value);

        var total = await query.CountAsync(ct);
        var items = await query
            .OrderByDescending(x => x.Policy.CreatedAt)
            .ThenBy(x => x.Policy.Id)
            .Skip((request.Page - 1) * request.PageSize)
            .Take(request.PageSize)
            .Select(x => new StaffPolicySummaryResponse(
                x.Policy.Id,
                x.Policy.PolicyNumber,
                x.Policy.CustomerId,
                x.Policy.PlanId,
                x.Plan.PlanName,
                x.Policy.Status,
                x.Policy.PremiumDue,
                x.Policy.CurrentVersionNumber,
                x.Policy.CreatedAt,
                x.Policy.UpdatedAt,
                Convert.ToBase64String(x.Policy.RowVersion)
            ))
            .ToArrayAsync(ct);

        return new(items, request.Page, request.PageSize, total);
    }

    public async Task<PagedResponse<PolicySummaryResponse>> GetMyPoliciesAsync(
        int page,
        int pageSize,
        PolicyStatus? status,
        CancellationToken ct
    )
    {
        var q = _db.Policies.AsNoTracking().Where(x => x.AuthUserId == _ctx.UserId);
        if (status.HasValue)
            q = q.Where(x => x.Status == status);
        var total = await q.CountAsync(ct);
        var items = await (
            from p in q
            join plan in _db.InsurancePlans.AsNoTracking() on p.PlanId equals plan.Id
            orderby p.CreatedAt descending, p.Id
            select new PolicySummaryResponse(
                p.Id,
                p.PolicyNumber,
                p.PlanId,
                plan.PlanName,
                p.Status,
                p.PremiumDue,
                p.CurrentVersionNumber,
                p.CreatedAt,
                Convert.ToBase64String(p.RowVersion),
                p.EffectiveDate,
                p.ExpirationDate,
                p.PreviousPolicyId
            )
        )
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .ToArrayAsync(ct);
        return new(items, page, pageSize, total);
    }

    public async Task<IReadOnlyCollection<Guid>> GetMyInsuredPropertyIdsAsync(CancellationToken ct)
    {
        return await (
            from prop in _db.Properties.AsNoTracking()
            join pol in _db.Policies.AsNoTracking() on prop.PolicyId equals pol.Id
            where pol.AuthUserId == _ctx.UserId
                && prop.CustomerPropertyOwnershipId.HasValue
                && pol.Status != PolicyStatus.Cancelled
                && pol.Status != PolicyStatus.Expired
            select prop.CustomerPropertyOwnershipId!.Value
        )
            .Distinct()
            .ToArrayAsync(ct);
    }

    public Task<PolicyDetailsResponse> GetPolicyAsync(Guid id, CancellationToken ct) =>
        PolicyProjection.GetDetails(_db, id, _ctx.UserId, false, ct);

    public Task<PolicyDetailsResponse> GetStaffPolicyAsync(Guid id, CancellationToken ct) =>
        PolicyProjection.GetDetails(_db, id, _ctx.UserId, true, ct);

    public async Task<IReadOnlyCollection<PolicyVersionResponse>> GetStaffPolicyVersionsAsync(
        Guid id,
        CancellationToken ct
    )
    {
        await EnsureExists(id, ct);
        return await _db
            .PolicyVersions.AsNoTracking()
            .Where(x => x.PolicyId == id)
            .OrderByDescending(x => x.VersionNumber)
            .Select(x => new PolicyVersionResponse(
                x.Id,
                x.VersionNumber,
                x.ChangeReason,
                x.SnapshotData,
                x.CreatedAt,
                x.CreatedBy
            ))
            .ToArrayAsync(ct);
    }

    public async Task<IReadOnlyCollection<PolicyHistoryResponse>> GetStaffPolicyHistoryAsync(
        Guid id,
        CancellationToken ct
    )
    {
        await EnsureExists(id, ct);
        return await _db
            .PolicyLifecycleHistory.AsNoTracking()
            .Where(x => x.PolicyId == id)
            .OrderByDescending(x => x.ChangedAt)
            .ThenBy(x => x.Id)
            .Select(x => new PolicyHistoryResponse(
                x.Id,
                x.FromStatus,
                x.ToStatus,
                x.Reason,
                x.ChangedAt,
                x.ChangedBy,
                x.CorrelationId
            ))
            .ToArrayAsync(ct);
    }

    public async Task<IReadOnlyCollection<PolicyVersionResponse>> GetPolicyVersionsAsync(
        Guid id,
        CancellationToken ct
    )
    {
        await EnsureOwned(id, ct);
        return await _db
            .PolicyVersions.AsNoTracking()
            .Where(x => x.PolicyId == id)
            .OrderByDescending(x => x.VersionNumber)
            .Select(x => new PolicyVersionResponse(
                x.Id,
                x.VersionNumber,
                x.ChangeReason,
                x.SnapshotData,
                x.CreatedAt,
                x.CreatedBy
            ))
            .ToArrayAsync(ct);
    }

    public async Task<IReadOnlyCollection<PolicyHistoryResponse>> GetPolicyHistoryAsync(
        Guid id,
        CancellationToken ct
    )
    {
        await EnsureOwned(id, ct);
        return await _db
            .PolicyLifecycleHistory.AsNoTracking()
            .Where(x => x.PolicyId == id)
            .OrderByDescending(x => x.ChangedAt)
            .ThenBy(x => x.Id)
            .Select(x => new PolicyHistoryResponse(
                x.Id,
                x.FromStatus,
                x.ToStatus,
                x.Reason,
                x.ChangedAt,
                x.ChangedBy,
                x.CorrelationId
            ))
            .ToArrayAsync(ct);
    }

    public async Task<CancellationPreviewResponse> GetCancellationPreviewAsync(
        Guid id,
        CancellationToken ct
    )
    {
        var p = await _db.Policies.AsNoTracking()
            .SingleOrDefaultAsync(x => x.Id == id && x.AuthUserId == _ctx.UserId, ct)
            ?? throw PolicyServiceException.NotFound("POLICY_NOT_FOUND", "Policy was not found.");

        int totalDays = 0;
        int daysActive = 0;
        int daysRemaining = 0;
        decimal refund = 0m;

        if (p.EffectiveDate.HasValue && p.ExpirationDate.HasValue)
        {
            totalDays = Math.Max(1, (int)(p.ExpirationDate.Value.Date - p.EffectiveDate.Value.Date).TotalDays);
            daysActive = Math.Max(0, (int)(_clock.UtcNow.Date - p.EffectiveDate.Value.Date).TotalDays);
            daysRemaining = Math.Max(0, (int)(p.ExpirationDate.Value.Date - _clock.UtcNow.Date).TotalDays);
            daysRemaining = Math.Min(daysRemaining, totalDays);
            refund = Math.Round((decimal)daysRemaining / totalDays * p.PremiumDue, 2);
        }

        return new CancellationPreviewResponse(
            p.Id,
            p.PolicyNumber,
            p.PremiumDue,
            p.EffectiveDate,
            p.ExpirationDate,
            totalDays,
            daysActive,
            daysRemaining,
            refund
        );
    }

    public async Task<PolicyMutationResponse> CancelAsync(
        Guid id,
        PolicyActionRequest r,
        CancellationToken ct
    )
    {
        var policy = await OwnedTracked(id, ct);
        var fromStatus = policy.Status;

        ServiceSupport.OriginalRowVersion(_db, policy, r.RowVersion);

        if (policy.Status == PolicyStatus.Active)
        {
            if (policy.EffectiveDate.HasValue && policy.ExpirationDate.HasValue)
            {
                var totalDays = Math.Max(1, (int)(policy.ExpirationDate.Value.Date - policy.EffectiveDate.Value.Date).TotalDays);
                var daysRemaining = Math.Max(0, (int)(policy.ExpirationDate.Value.Date - _clock.UtcNow.Date).TotalDays);
                daysRemaining = Math.Min(daysRemaining, totalDays);
                var refund = Math.Round((decimal)daysRemaining / totalDays * policy.PremiumDue, 2);

                if (refund > 0)
                {
                    var idempotencyKey = $"refund-{policy.Id}-{policy.CurrentVersionNumber}-{r.RowVersion}";
                    await _payments.IssueRefundAsync(
                        new RefundIssueRequest(
                            policy.Id,
                            policy.CustomerId,
                            refund,
                            $"Pro-rata cancellation refund: {r.Reason}"
                        ),
                        idempotencyKey,
                        ct
                    );
                }
            }

            policy.CancelActive(_clock.UtcNow, _ctx.Actor);
        }
        else if (policy.Status == PolicyStatus.Suspended)
        {
            policy.CancelSuspended(_clock.UtcNow, _ctx.Actor);
        }
        else if (policy.Status == PolicyStatus.PaymentPending)
        {
            policy.CancelFromPaymentPending(_clock.UtcNow, _ctx.Actor);
        }
        else
        {
            throw PolicyServiceException.Conflict(
                "POLICY_INVALID_STATUS_TRANSITION",
                "Policy cannot be cancelled from its current status."
            );
        }

        _db.PolicyLifecycleHistory.Add(
            PolicyLifecycleHistory.Create(
                policy.Id,
                fromStatus,
                policy.Status,
                r.Reason,
                _clock.UtcNow,
                _ctx.Actor,
                _ctx.CorrelationId
            )
        );

        await Save(ct);

        return policy.ToMutation();
    }

    public Task<PolicyMutationResponse> SuspendAsync(
        Guid id,
        PolicyActionRequest r,
        CancellationToken ct
    ) => MutatePrivileged(id, r, p => p.Suspend(_clock.UtcNow, _ctx.Actor), ct);

    public Task<PolicyMutationResponse> ReactivateAsync(
        Guid id,
        PolicyActionRequest r,
        CancellationToken ct
    ) => MutatePrivileged(id, r, p => p.Reactivate(_clock.UtcNow, _ctx.Actor), ct);

    public Task<PolicyMutationResponse> ExpireAsync(
        Guid id,
        PolicyActionRequest r,
        CancellationToken ct
    ) => MutatePrivileged(id, r, p => p.Expire(_clock.UtcNow, _ctx.Actor), ct);

    public async Task<RenewalResponse> BeginRenewalAsync(
        Guid id,
        RenewPolicyRequest r,
        string key,
        CancellationToken ct
    )
    {
        if (string.IsNullOrWhiteSpace(key))
        {
            throw new PolicyServiceException(
                "IDEMPOTENCY_KEY_REQUIRED",
                "X-Idempotency-Key is required.",
                400
            );
        }

        var hash = ServiceSupport.Hash(new { PolicyId = id, Request = r });

        var existing = await _db
            .IdempotencyRecords.AsNoTracking()
            .SingleOrDefaultAsync(
                item =>
                    item.Operation == IdempotencyOperation.PolicyRenewal
                    && item.Key == key
                    && item.ExpiresAt > _clock.UtcNow,
                ct
            );

        if (existing is not null)
        {
            if (existing.RequestHash != hash)
            {
                throw PolicyServiceException.Conflict(
                    "IDEMPOTENCY_KEY_REUSED",
                    "Idempotency key was reused with a different request."
                );
            }

            var replay = System.Text.Json.JsonSerializer.Deserialize<RenewalResponse>(
                existing.ResponseBody
            )!;

            var currentRowVersion = await _db
                .Policies.AsNoTracking()
                .Where(item => item.Id == id)
                .Select(item => item.RowVersion)
                .SingleAsync(ct);

            return replay with
            {
                RowVersion = Convert.ToBase64String(currentRowVersion),
            };
        }

        // Load the owned Policy once.
        var p = await OwnedTracked(id, ct);

        if (p.Status != PolicyStatus.Active)
        {
            throw PolicyServiceException.Conflict(
                "POLICY_NOT_ACTIVE",
                "Only active policies can be renewed."
            );
        }

        // Validate the 60-day renewal window:
        // Renewal is allowed only if ExpirationDate is known, current time is inside the 60-day window,
        // and the policy has not already passed its exclusive expiration boundary.
        if (!p.ExpirationDate.HasValue)
        {
            throw PolicyServiceException.Unprocessable(
                "POLICY_TERM_NOT_ESTABLISHED",
                "Policy does not have an active term expiration date."
            );
        }

        var windowOpensAt = p.ExpirationDate.Value.AddDays(-60);
        if (_clock.UtcNow < windowOpensAt)
        {
            throw PolicyServiceException.Unprocessable(
                "POLICY_RENEWAL_WINDOW_NOT_OPEN",
                $"The renewal window opens 60 days prior to expiration on {windowOpensAt:yyyy-MM-dd}."
            );
        }

        if (_clock.UtcNow >= p.ExpirationDate.Value)
        {
            throw PolicyServiceException.Unprocessable(
                "POLICY_ALREADY_EXPIRED",
                "Policy has already expired. A new application is required."
            );
        }

        // Prevent duplicate renewals: block if an active or pending renewal successor already exists
        var hasPendingSuccessor = await _db.Policies.AsNoTracking().AnyAsync(
            item => item.PreviousPolicyId == p.Id 
                && (item.Status == PolicyStatus.Submitted 
                    || item.Status == PolicyStatus.Underwriting 
                    || item.Status == PolicyStatus.Approved 
                    || item.Status == PolicyStatus.PaymentPending 
                    || item.Status == PolicyStatus.Scheduled),
            ct
        );

        if (hasPendingSuccessor)
        {
            throw PolicyServiceException.Conflict(
                "POLICY_RENEWAL_ALREADY_EXISTS",
                "A pending or scheduled renewal successor already exists for this policy."
            );
        }

        // External eligibility validation occurs before local mutation.
        var eligibility = await _customer.GetEligibilityAsync(p.CustomerId, ct);

        if (!eligibility.IsEligible)
        {
            throw PolicyServiceException.Unprocessable(
                "CUSTOMER_NOT_ELIGIBLE",
                string.Join("; ", eligibility.Reasons)
            );
        }

        ServiceSupport.OriginalRowVersion(_db, p, r.RowVersion);

        var plan =
            await _db
                .InsurancePlans.AsNoTracking()
                .SingleOrDefaultAsync(item => item.Id == p.PlanId && item.IsActive, ct)
            ?? throw PolicyServiceException.NotFound(
                "POLICY_PLAN_NOT_FOUND",
                "The Insurance Plan was not found or is inactive."
            );

        var policyIds = await (
            from policyRecord in _db.Policies.AsNoTracking()
            join propertyRecord in _db.Properties.AsNoTracking()
                on policyRecord.Id equals propertyRecord.PolicyId
            where
                policyRecord.CustomerId == p.CustomerId
                && propertyRecord.CustomerPropertyOwnershipId == r.Property.CustomerPropertyOwnershipId
            select policyRecord.Id
        ).Distinct().ToArrayAsync(ct);

        var claimsTargetIds = policyIds.Length > 0 ? policyIds : new[] { p.Id };
        var claimHistory = await _claims.GetClaimHistoryCountAsync(claimsTargetIds, ct);
        int claimsHistoryCount = claimHistory.Count;
        
        var customerProperties = await _customer.GetCustomerPropertiesAsync(p.CustomerId, ct) ?? Array.Empty<CustomerPropertyResponse>();
        var propertyDetails = customerProperties.SingleOrDefault(item => item.PropertyOwnershipId == r.Property.CustomerPropertyOwnershipId)
            ?? throw PolicyServiceException.NotFound("PROPERTY_NOT_FOUND", "Customer property record was not found.");
            
        RiskZone evaluatedRiskZone = RiskZone.C;
        if (propertyDetails.Latitude.HasValue && propertyDetails.Longitude.HasValue)
        {
            evaluatedRiskZone = await _riskZoneEvaluator.EvaluateRiskZoneAsync(
                propertyDetails.Latitude.Value, 
                propertyDetails.Longitude.Value, 
                ct
            );
        }

        var riskInput = new PropertyRiskInput(
            r.Property.PropertyValue,
            r.Property.YearBuilt,
            r.Property.ConstructionType,
            evaluatedRiskZone,
            claimsHistoryCount,
            r.Property.StormShutters,
            r.Property.ImpactResistantWindows,
            r.Property.ReinforcedRoof,
            r.Property.EmergencyGenerator,
            r.Property.HomeInspectionCertification
        );

        var riskResult = _risk.Assess(riskInput, _clock.UtcNow.Year);

        var premiumResult = _premium.Calculate(
            new PremiumCalculationInput(
                plan.BasePremium,
                r.Property.PropertyValue,
                evaluatedRiskZone,
                claimsHistoryCount,
                riskResult.Score,
                r.Property.StormShutters,
                r.Property.ImpactResistantWindows,
                r.Property.ReinforcedRoof,
                r.Property.EmergencyGenerator,
                r.Property.HomeInspectionCertification
            )
        );

        var underwritingDecision = _underwriting.Decide(riskResult.Score, riskResult.PropertyAge);

        if (underwritingDecision.Decision == UnderwritingDecision.Rejected)
        {
            throw PolicyServiceException.Unprocessable(
                "POLICY_RENEWAL_REJECTED",
                underwritingDecision.Reason
            );
        }

        /*
         * SUCCESSOR CREATION:
         * We do not mutate the existing Active policy. We spawn a distinct Successor Policy
         * representing the future term. Its EffectiveDate matches the current ExpirationDate.
         */
        var successor = Policy.CreateRenewalSuccessor(
            ServiceSupport.NewPolicyNumber(_clock.UtcNow),
            p.AuthUserId,
            p.CustomerId,
            p.PlanId,
            premiumResult.FinalPremium,
            p,
            _clock.UtcNow,
            _ctx.Actor
        );

        _db.Policies.Add(successor);

        // Advance successor through initial workflow to PaymentPending
        successor.Submit(_clock.UtcNow, _ctx.Actor);
        successor.StartUnderwriting(_clock.UtcNow, "system");
        successor.EstablishInitialVersion();
        successor.Approve(_clock.UtcNow, "system");
        successor.MoveToPaymentPending(_clock.UtcNow, "system");

        _db.Properties.Add(
            Property.Create(
                successor.Id,
                r.Property.CustomerPropertyOwnershipId,
                r.Property.PropertyValue,
                r.Property.YearBuilt,
                r.Property.ConstructionType,
                evaluatedRiskZone,
                r.Property.StormShutters,
                r.Property.ImpactResistantWindows,
                r.Property.ReinforcedRoof,
                r.Property.EmergencyGenerator,
                r.Property.HomeInspectionCertification
            )
        );

        _db.RiskAssessments.Add(
            RiskAssessment.Create(
                successor.Id,
                riskResult.Score,
                riskResult.RiskLevel,
                ServiceSupport.Json(riskResult.Factors),
                _clock.UtcNow,
                "system"
            )
        );

        var premiumCalculation = PremiumCalculation.Create(
            successor.Id,
            premiumResult.FinalPremium,
            _clock.UtcNow
        );

        _db.PremiumCalculations.Add(premiumCalculation);

        _db.PremiumBreakdowns.Add(
            PremiumBreakdown.Create(
                premiumCalculation.Id,
                premiumResult.BasePremium,
                premiumResult.LocationRiskAdjustment,
                premiumResult.PropertyRiskAdjustment,
                premiumResult.ClaimsHistoryAdjustment,
                premiumResult.RiskAdjustment,
                premiumResult.DiscountAmount,
                premiumResult.FinalPremium
            )
        );

        _db.PolicyVersions.Add(
            PolicyVersion.Create(
                successor.Id,
                1,
                r.Reason,
                ServiceSupport.Json(r),
                _clock.UtcNow,
                _ctx.Actor
            )
        );

        _db.PolicyLifecycleHistory.Add(
            PolicyLifecycleHistory.Create(
                successor.Id,
                PolicyStatus.Draft,
                successor.Status,
                $"Renewal successor created for Policy {p.PolicyNumber}. {r.Reason}",
                _clock.UtcNow,
                _ctx.Actor,
                _ctx.CorrelationId
            )
        );

        var response = new RenewalResponse(
            successor.Id,
            successor.PolicyNumber,
            successor.Status,
            successor.PremiumDue,
            successor.CurrentVersionNumber,
            riskResult.Score,
            riskResult.RiskLevel,
            underwritingDecision.Decision,
            Convert.ToBase64String(successor.RowVersion)
        );

        _db.IdempotencyRecords.Add(
            IdempotencyRecord.Create(
                IdempotencyOperation.PolicyRenewal,
                key,
                hash,
                StatusCodes.Status200OK,
                ServiceSupport.Json(response),
                successor.Id,
                _clock.UtcNow
            )
        );

        await Save(ct);

        return response with
        {
            RowVersion = Convert.ToBase64String(successor.RowVersion),
        };
    }

    public async Task<PolicyEndorsementResponse> EndorsePolicyAsync(
        Guid id,
        PolicyEndorsementRequest r,
        string key,
        CancellationToken ct
    )
    {
        if (string.IsNullOrWhiteSpace(key))
        {
            throw new PolicyServiceException(
                "IDEMPOTENCY_KEY_REQUIRED",
                "X-Idempotency-Key is required.",
                400
            );
        }

        var hash = ServiceSupport.Hash(new { PolicyId = id, Request = r });

        var existing = await _db
            .IdempotencyRecords.AsNoTracking()
            .SingleOrDefaultAsync(
                item =>
                    item.Operation == IdempotencyOperation.PolicyEndorsement
                    && item.Key == key
                    && item.ExpiresAt > _clock.UtcNow,
                ct
            );

        if (existing is not null)
        {
            if (existing.RequestHash != hash)
            {
                throw PolicyServiceException.Conflict(
                    "IDEMPOTENCY_KEY_REUSED",
                    "Idempotency key was reused with a different request."
                );
            }

            var replay = System.Text.Json.JsonSerializer.Deserialize<PolicyEndorsementResponse>(
                existing.ResponseBody
            )!;

            var currentRowVersion = await _db
                .Policies.AsNoTracking()
                .Where(item => item.Id == id)
                .Select(item => item.RowVersion)
                .SingleAsync(ct);

            return replay with
            {
                RowVersion = Convert.ToBase64String(currentRowVersion),
            };
        }

        var p = await OwnedTracked(id, ct);

        if (p.Status != PolicyStatus.Active)
        {
            throw PolicyServiceException.Conflict(
                "POLICY_NOT_ACTIVE",
                "Only active policies can receive an endorsement."
            );
        }

        ServiceSupport.OriginalRowVersion(_db, p, r.RowVersion);

        var prop = await _db.Properties.SingleOrDefaultAsync(item => item.PolicyId == p.Id, ct)
            ?? throw PolicyServiceException.NotFound("PROPERTY_NOT_FOUND", "Policy property record was not found.");

        // Check if any mitigation actually changed
        bool hasChanges = prop.StormShutters != r.StormShutters
            || prop.ImpactResistantWindows != r.ImpactResistantWindows
            || prop.ReinforcedRoof != r.ReinforcedRoof
            || prop.EmergencyGenerator != r.EmergencyGenerator
            || prop.HomeInspectionCertification != r.HomeInspectionCertification;

        if (!hasChanges)
        {
            throw PolicyServiceException.Unprocessable(
                "NO_CHANGES_DETECTED",
                "No mitigation changes were detected. At least one mitigation attribute must be modified."
            );
        }

        // Update ONLY mitigation fields on Property
        prop.UpdateSnapshot(
            prop.CustomerPropertyOwnershipId,
            prop.PropertyValue,
            prop.YearBuilt,
            prop.ConstructionType,
            prop.RiskZone,
            r.StormShutters,
            r.ImpactResistantWindows,
            r.ReinforcedRoof,
            r.EmergencyGenerator,
            r.HomeInspectionCertification
        );

        p.IncrementVersion(_clock.UtcNow, _ctx.Actor);

        _db.PolicyVersions.Add(
            PolicyVersion.Create(
                p.Id,
                p.CurrentVersionNumber,
                r.Reason,
                ServiceSupport.Json(r),
                _clock.UtcNow,
                _ctx.Actor
            )
        );

        var response = new PolicyEndorsementResponse(
            p.Id,
            p.PolicyNumber,
            p.Status,
            p.PremiumDue,
            p.CurrentVersionNumber,
            Convert.ToBase64String(p.RowVersion)
        );

        _db.IdempotencyRecords.Add(
            IdempotencyRecord.Create(
                IdempotencyOperation.PolicyEndorsement,
                key,
                hash,
                StatusCodes.Status200OK,
                ServiceSupport.Json(response),
                p.Id,
                _clock.UtcNow
            )
        );

        await Save(ct);

        return response with
        {
            RowVersion = Convert.ToBase64String(p.RowVersion),
        };
    }

    public async Task<RenewalEstimateResponse> EstimateRenewalAsync(
        Guid id,
        RenewalEstimateRequest r,
        CancellationToken ct
    )
    {
        var p = await _db.Policies.AsNoTracking()
            .SingleOrDefaultAsync(item => item.Id == id && item.AuthUserId == _ctx.UserId, ct)
            ?? throw PolicyServiceException.NotFound("POLICY_NOT_FOUND", "Policy was not found.");

        if (p.Status != PolicyStatus.Active)
        {
            throw PolicyServiceException.Conflict(
                "POLICY_NOT_ACTIVE",
                "Only active policies can be renewed."
            );
        }

        if (Convert.ToBase64String(p.RowVersion) != r.RowVersion)
        {
            throw ServiceSupport.Concurrency();
        }

        if (!p.ExpirationDate.HasValue)
        {
            throw PolicyServiceException.Unprocessable(
                "POLICY_TERM_NOT_ESTABLISHED",
                "Policy does not have an active term expiration date."
            );
        }

        var windowOpensAt = p.ExpirationDate.Value.AddDays(-60);
        if (_clock.UtcNow < windowOpensAt)
        {
            throw PolicyServiceException.Unprocessable(
                "POLICY_RENEWAL_WINDOW_NOT_OPEN",
                $"The renewal window opens 60 days prior to expiration on {windowOpensAt:yyyy-MM-dd}."
            );
        }

        if (_clock.UtcNow >= p.ExpirationDate.Value)
        {
            throw PolicyServiceException.Unprocessable(
                "POLICY_ALREADY_EXPIRED",
                "Policy has already expired. A new application is required."
            );
        }

        var hasPendingSuccessor = await _db.Policies.AsNoTracking().AnyAsync(
            item => item.PreviousPolicyId == p.Id
                && (item.Status == PolicyStatus.Submitted
                    || item.Status == PolicyStatus.Underwriting
                    || item.Status == PolicyStatus.Approved
                    || item.Status == PolicyStatus.PaymentPending
                    || item.Status == PolicyStatus.Scheduled),
            ct
        );

        if (hasPendingSuccessor)
        {
            throw PolicyServiceException.Conflict(
                "POLICY_RENEWAL_ALREADY_EXISTS",
                "A pending or scheduled renewal successor already exists for this policy."
            );
        }

        var plan = await _db.InsurancePlans.AsNoTracking()
            .SingleOrDefaultAsync(item => item.Id == p.PlanId && item.IsActive, ct)
            ?? throw PolicyServiceException.NotFound(
                "POLICY_PLAN_NOT_FOUND",
                "The Insurance Plan was not found or is inactive."
            );

        var prop = await _db.Properties.AsNoTracking()
            .SingleOrDefaultAsync(item => item.PolicyId == p.Id, ct)
            ?? throw PolicyServiceException.NotFound("PROPERTY_NOT_FOUND", "Policy property record was not found.");

        // Estimate renewals just use the existing property risk zone 
        RiskZone evaluatedRiskZone = prop.RiskZone; 
        
        var policyIds = await (
            from policyRecord in _db.Policies.AsNoTracking()
            join propertyRecord in _db.Properties.AsNoTracking()
                on policyRecord.Id equals propertyRecord.PolicyId
            where
                policyRecord.CustomerId == p.CustomerId
                && propertyRecord.CustomerPropertyOwnershipId == prop.CustomerPropertyOwnershipId
            select policyRecord.Id
        ).Distinct().ToArrayAsync(ct);

        var claimsTargetIds = policyIds.Length > 0 ? policyIds : new[] { p.Id };
        var claimHistory = await _claims.GetClaimHistoryCountAsync(claimsTargetIds, ct);
        int claimsHistoryCount = claimHistory.Count;

        var riskInput = new PropertyRiskInput(
            prop.PropertyValue,
            prop.YearBuilt,
            prop.ConstructionType,
            evaluatedRiskZone,
            claimsHistoryCount,
            prop.StormShutters,
            prop.ImpactResistantWindows,
            prop.ReinforcedRoof,
            prop.EmergencyGenerator,
            prop.HomeInspectionCertification
        );

        var riskResult = _risk.Assess(riskInput, _clock.UtcNow.Year);

        var premiumResult = _premium.Calculate(
            new PremiumCalculationInput(
                plan.BasePremium,
                prop.PropertyValue,
                evaluatedRiskZone,
                claimsHistoryCount,
                riskResult.Score,
                prop.StormShutters,
                prop.ImpactResistantWindows,
                prop.ReinforcedRoof,
                prop.EmergencyGenerator,
                prop.HomeInspectionCertification
            )
        );

        var underwritingDecision = _underwriting.Decide(riskResult.Score, riskResult.PropertyAge);
        bool manualReviewRequired = underwritingDecision.Decision != UnderwritingDecision.Approved;

        decimal difference = premiumResult.FinalPremium - p.PremiumDue;
        string comparisonOutcome = difference switch
        {
            > 0 => "Increase",
            < 0 => "Saving",
            _ => "NoChange"
        };

        var breakdown = new PremiumBreakdownResponse(
            premiumResult.BasePremium,
            premiumResult.LocationRiskAdjustment,
            premiumResult.PropertyRiskAdjustment,
            premiumResult.ClaimsHistoryAdjustment,
            premiumResult.RiskAdjustment,
            premiumResult.DiscountAmount,
            premiumResult.FinalPremium
        );

        return new RenewalEstimateResponse(
            p.Id,
            p.PolicyNumber,
            plan.Id,
            plan.PlanName,
            prop.PropertyValue,
            p.PremiumDue,
            premiumResult.FinalPremium,
            Math.Abs(difference),
            comparisonOutcome,
            premiumResult.DiscountAmount,
            riskResult.Score,
            riskResult.RiskLevel,
            manualReviewRequired,
            breakdown
        );
    }

    private async Task<PolicyMutationResponse> MutateOwned(
        Guid id,
        PolicyActionRequest request,
        Action<Policy> action,
        CancellationToken cancellationToken
    )
    {
        var policy = await OwnedTracked(id, cancellationToken);

        return await MutateTracked(policy, request, action, cancellationToken);
    }

    private async Task<PolicyMutationResponse> MutatePrivileged(
        Guid id,
        PolicyActionRequest request,
        Action<Policy> action,
        CancellationToken cancellationToken
    )
    {
        var policy =
            await _db.Policies.SingleOrDefaultAsync(item => item.Id == id, cancellationToken)
            ?? throw PolicyServiceException.NotFound("POLICY_NOT_FOUND", "Policy was not found.");

        return await MutateTracked(policy, request, action, cancellationToken);
    }

    private async Task<PolicyMutationResponse> MutateTracked(
        Policy policy,
        PolicyActionRequest request,
        Action<Policy> action,
        CancellationToken cancellationToken
    )
    {
        var fromStatus = policy.Status;

        ServiceSupport.OriginalRowVersion(_db, policy, request.RowVersion);

        action(policy);

        _db.PolicyLifecycleHistory.Add(
            PolicyLifecycleHistory.Create(
                policy.Id,
                fromStatus,
                policy.Status,
                request.Reason,
                _clock.UtcNow,
                _ctx.Actor,
                _ctx.CorrelationId
            )
        );

        await Save(cancellationToken);

        return policy.ToMutation();
    }

    private async Task EnsureExists(Guid id, CancellationToken ct)
    {
        if (!await _db.Policies.AsNoTracking().AnyAsync(x => x.Id == id, ct))
            throw PolicyServiceException.NotFound("POLICY_NOT_FOUND", "Policy was not found.");
    }

    private async Task EnsureOwned(Guid id, CancellationToken ct)
    {
        if (
            !await _db
                .Policies.AsNoTracking()
                .AnyAsync(x => x.Id == id && x.AuthUserId == _ctx.UserId, ct)
        )
            throw PolicyServiceException.NotFound("POLICY_NOT_FOUND", "Policy was not found.");
    }

    private async Task<Policy> OwnedTracked(Guid id, CancellationToken ct) =>
        await _db.Policies.SingleOrDefaultAsync(x => x.Id == id && x.AuthUserId == _ctx.UserId, ct)
        ?? throw PolicyServiceException.NotFound("POLICY_NOT_FOUND", "Policy was not found.");

    private async Task Save(CancellationToken ct)
    {
        try
        {
            await _db.SaveChangesAsync(ct);
        }
        catch (DbUpdateConcurrencyException)
        {
            throw ServiceSupport.Concurrency();
        }
    }
}


using Microsoft.EntityFrameworkCore;
using PolicyService.Application.DTOs.Common;
using PolicyService.Application.DTOs.CoverageTypes;
using PolicyService.Application.Interfaces;
using PolicyService.Domain.Entities;
using PolicyService.Infrastructure.Caching;
using PolicyService.Infrastructure.Exceptions;
using PolicyService.Infrastructure.Mapping;
using PolicyService.Infrastructure.Persistence;

namespace PolicyService.Infrastructure.Services;

public sealed class CoverageTypeService : ICoverageTypeService
{
    private readonly PolicyDbContext _db;
    private readonly IRequestContext _ctx;
    private readonly IDateTimeProvider _clock;
    private readonly IPolicyCatalogCache _cache;

    public CoverageTypeService(
        PolicyDbContext db,
        IRequestContext ctx,
        IDateTimeProvider clock,
        IPolicyCatalogCache cache
    )
    {
        _db = db;
        _ctx = ctx;
        _clock = clock;
        _cache = cache;
    }

    public async Task<IReadOnlyCollection<CoverageTypeResponse>> GetCoverageTypesAsync(
        bool includeInactive,
        CancellationToken ct
    )
    {
        async Task<IReadOnlyCollection<CoverageTypeResponse>> Load() =>
            await _db
                .CoverageTypes.AsNoTracking()
                .Where(x => includeInactive || x.IsActive)
                .OrderBy(x => x.Name)
                .ThenBy(x => x.Id)
                .Select(x => new CoverageTypeResponse(
                    x.Id,
                    x.Name,
                    x.Description,
                    x.IsActive,
                    x.CreatedAt,
                    x.UpdatedAt,
                    Convert.ToBase64String(x.RowVersion)
                ))
                .ToArrayAsync(ct);
        return includeInactive
            ? await Load()
            : await _cache.GetOrCreateAsync(PolicyCatalogCache.CoverageTypes, Load);
    }

    public async Task<CoverageTypeResponse> CreateCoverageTypeAsync(
        CreateCoverageTypeRequest r,
        CancellationToken ct
    )
    {
        if (await _db.CoverageTypes.AnyAsync(x => x.Name == r.Name.Trim(), ct))
            throw PolicyServiceException.Conflict(
                "POLICY_COVERAGE_TYPE_EXISTS",
                "Coverage Type already exists."
            );
        var x = CoverageType.Create(r.Name, r.Description, _clock.UtcNow, _ctx.Actor);
        _db.Add(x);
        await Save(ct);
        _cache.RemoveCatalog();
        return x.ToResponse();
    }

    public async Task<CoverageTypeResponse> UpdateCoverageTypeAsync(
        Guid id,
        UpdateCoverageTypeRequest r,
        CancellationToken ct
    )
    {
        var x = await Find(id, ct);
        if (await _db.CoverageTypes.AnyAsync(y => y.Id != id && y.Name == r.Name.Trim(), ct))
            throw PolicyServiceException.Conflict(
                "POLICY_COVERAGE_TYPE_EXISTS",
                "Coverage Type already exists."
            );
        ServiceSupport.OriginalRowVersion(_db, x, r.RowVersion);
        x.Update(r.Name, r.Description, _clock.UtcNow, _ctx.Actor);
        await Save(ct);
        _cache.RemoveCatalog();
        return x.ToResponse();
    }

    public Task<CoverageTypeResponse> ActivateCoverageTypeAsync(
        Guid id,
        RowVersionRequest r,
        CancellationToken ct
    ) => Set(id, r, true, ct);

    public Task<CoverageTypeResponse> DeactivateCoverageTypeAsync(
        Guid id,
        RowVersionRequest r,
        CancellationToken ct
    ) => Set(id, r, false, ct);

    private async Task<CoverageTypeResponse> Set(
        Guid id,
        RowVersionRequest r,
        bool active,
        CancellationToken ct
    )
    {
        var x = await Find(id, ct);
        ServiceSupport.OriginalRowVersion(_db, x, r.RowVersion);
        if (active)
            x.Activate(_clock.UtcNow, _ctx.Actor);
        else
            x.Deactivate(_clock.UtcNow, _ctx.Actor);
        await Save(ct);
        _cache.RemoveCatalog();
        return x.ToResponse();
    }

    private async Task<CoverageType> Find(Guid id, CancellationToken ct) =>
        await _db.CoverageTypes.SingleOrDefaultAsync(x => x.Id == id, ct)
        ?? throw PolicyServiceException.NotFound(
            "POLICY_COVERAGE_TYPE_NOT_FOUND",
            "Coverage Type was not found."
        );

    private async Task Save(CancellationToken ct)
    {
        try
        {
            await _db.SaveChangesAsync(ct);
        }
        catch (DbUpdateConcurrencyException)
        {
            throw ServiceSupport.Concurrency();
        }
    }
}


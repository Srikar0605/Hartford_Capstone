using System.Security.Claims;
using Microsoft.AspNetCore.Http;
using PolicyService.Application.Interfaces;

namespace PolicyService.Infrastructure.Services;

public sealed class RequestContext : IRequestContext
{
    private readonly IHttpContextAccessor _accessor;

    public RequestContext(IHttpContextAccessor accessor) => _accessor = accessor;

    private ClaimsPrincipal User => _accessor.HttpContext?.User ?? new ClaimsPrincipal();
    public Guid UserId =>
        Guid.TryParse(
            User.FindFirstValue(ClaimTypes.NameIdentifier) ?? User.FindFirstValue("sub"),
            out var id
        )
            ? id
            : Guid.Empty;
    public string Actor =>
        User.FindFirstValue(ClaimTypes.Email) ?? User.FindFirstValue("email") ?? UserId.ToString();
    public string CorrelationId => _accessor.HttpContext?.TraceIdentifier ?? string.Empty;
    public IReadOnlyCollection<string> Roles =>
        User.FindAll(ClaimTypes.Role).Select(x => x.Value).ToArray();
    public IReadOnlyCollection<string> Permissions =>
        User.FindAll("permissions").Select(x => x.Value).ToArray();
    public bool IsAuthenticated => User.Identity?.IsAuthenticated == true;
}

public sealed class SystemDateTimeProvider : IDateTimeProvider
{
    public DateTime UtcNow => DateTime.UtcNow;
    public DateOnly UtcToday => DateOnly.FromDateTime(UtcNow);
}


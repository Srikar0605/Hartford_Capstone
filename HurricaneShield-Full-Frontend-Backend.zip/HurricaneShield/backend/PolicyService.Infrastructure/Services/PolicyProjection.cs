using Microsoft.EntityFrameworkCore;
using PolicyService.Application.DTOs.Plans;
using PolicyService.Application.DTOs.Policies;
using PolicyService.Application.DTOs.Quotes;
using PolicyService.Infrastructure.Exceptions;
using PolicyService.Infrastructure.Persistence;

namespace PolicyService.Infrastructure.Services;

internal static class PolicyProjection
{
    internal static async Task<PolicyDetailsResponse> GetDetails(
        PolicyDbContext db,
        Guid id,
        Guid userId,
        bool privileged,
        CancellationToken ct
    )
    {
        var p =
            await db
                .Policies.AsNoTracking()
                .SingleOrDefaultAsync(x => x.Id == id && (privileged || x.AuthUserId == userId), ct)
            ?? throw PolicyServiceException.NotFound("POLICY_NOT_FOUND", "Policy was not found.");
        var plan = await db.InsurancePlans.AsNoTracking().SingleAsync(x => x.Id == p.PlanId, ct);
        var covers = await (
            from pc in db.PlanCoverages.AsNoTracking()
            join c in db.CoverageTypes.AsNoTracking() on pc.CoverageTypeId equals c.Id
            where pc.PlanId == p.PlanId
            select new PlanCoverageResponse(
                c.Id,
                c.Name,
                c.Description,
                pc.CoverageLimit,
                pc.DeductibleAmount
            )
        ).ToArrayAsync(ct);
        var prop = await db.Properties.AsNoTracking().SingleAsync(x => x.PolicyId == id, ct);
        var risk = await db
            .RiskAssessments.AsNoTracking()
            .Where(x => x.PolicyId == id)
            .OrderByDescending(x => x.AssessmentDate)
            .FirstAsync(ct);
        var calc = await db
            .PremiumCalculations.AsNoTracking()
            .Where(x => x.PolicyId == id)
            .OrderByDescending(x => x.CalculatedAt)
            .FirstAsync(ct);
        var breakdown = await db
            .PremiumBreakdowns.AsNoTracking()
            .SingleAsync(x => x.PremiumCalculationId == calc.Id, ct);

        var compliance = await db.ComplianceReviews.AsNoTracking()
            .SingleOrDefaultAsync(x => x.PolicyId == id, ct);

        ComplianceReviewResponse? complianceResponse = compliance == null ? null : new(
            compliance.IsCompliant,
            compliance.ConfidenceScore,
            compliance.Summary,
            System.Text.Json.JsonSerializer.Deserialize<string[]>(compliance.ViolationsJson) ?? Array.Empty<string>(),
            System.Text.Json.JsonSerializer.Deserialize<string[]>(compliance.MissingDiscountsJson) ?? Array.Empty<string>(),
            compliance.RiskAssessment,
            System.Text.Json.JsonSerializer.Deserialize<string[]>(compliance.RecommendedActionsJson) ?? Array.Empty<string>(),
            System.Text.Json.JsonSerializer.Deserialize<string[]>(compliance.CitationsJson) ?? Array.Empty<string>(),
            compliance.CreatedAt,
            compliance.Engine
        );

        return new(
            p.Id,
            p.PolicyNumber,
            p.CustomerId,
            p.PlanId,
            p.Status,
            p.PremiumDue,
            p.CurrentVersionNumber,
            p.PaymentTransactionId,
            p.CreatedAt,
            p.UpdatedAt,
            Convert.ToBase64String(p.RowVersion),
            new PlanDetailsResponse(
                plan.Id,
                plan.PlanCode,
                plan.PlanName,
                plan.Description,
                plan.BasePremium,
                plan.CoverageLimit,
                plan.DeductibleAmount,
                covers
            ),
            new PolicyPropertyResponse(
                prop.Id,
                prop.CustomerPropertyOwnershipId,
                prop.PropertyValue,
                prop.YearBuilt,
                prop.ConstructionType,
                prop.RiskZone,
                prop.StormShutters,
                prop.ImpactResistantWindows,
                prop.ReinforcedRoof,
                prop.EmergencyGenerator,
                prop.HomeInspectionCertification
            ),
            new RiskAssessmentResponse(
                risk.RiskScore,
                risk.RiskLevel,
                DateTime.UtcNow.Year - prop.YearBuilt,
                risk.RiskScore >= 70m,
                Array.Empty<RiskFactorResponse>()
            ),
            new PremiumBreakdownResponse(
                breakdown.BasePremium,
                breakdown.LocationRiskAdjustment,
                breakdown.PropertyRiskAdjustment,
                breakdown.ClaimsHistoryAdjustment,
                breakdown.RiskAdjustment,
                breakdown.DiscountAmount,
                breakdown.FinalPremium
            ),
            complianceResponse,
            p.EffectiveDate,
            p.ExpirationDate,
            p.PreviousPolicyId
        );
    }
}


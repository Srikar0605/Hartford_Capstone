using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using PolicyService.Application.Interfaces;
using PolicyService.Domain.Calculations;
using PolicyService.Infrastructure.Caching;
using PolicyService.Infrastructure.Clients;
using PolicyService.Infrastructure.Configuration;
using PolicyService.Infrastructure.Persistence;
using PolicyService.Infrastructure.Services;

namespace PolicyService.Infrastructure;

public static class DependencyInjection
{
    public static IServiceCollection AddPolicyInfrastructure(
        this IServiceCollection services,
        IConfiguration config
    )
    {
        services.AddDbContext<PolicyDbContext>(o =>
            o.UseSqlServer(config.GetConnectionString("PolicyDb"))
        );
        services.AddMemoryCache();
        services.AddHttpContextAccessor();
        services.AddTransient<ForwardingHandler>();
        services.Configure<CustomerServiceSettings>(
            config.GetSection(CustomerServiceSettings.SectionName)
        );
        services.Configure<ClaimsServiceSettings>(
            config.GetSection(ClaimsServiceSettings.SectionName)
        );
        services.Configure<InternalServicesSettings>(
            config.GetSection(InternalServicesSettings.SectionName)
        );
        services.Configure<PaymentServiceSettings>(
            config.GetSection(PaymentServiceSettings.SectionName)
        );
        services.Configure<CatalogCacheSettings>(
            config.GetSection(CatalogCacheSettings.SectionName)
        );
        services
            .AddHttpClient<ICustomerEligibilityClient, CustomerEligibilityClient>(
                (sp, c) =>
                {
                    var s = sp.GetRequiredService<IOptions<CustomerServiceSettings>>().Value;
                    c.BaseAddress = new Uri(s.BaseUrl);
                    c.Timeout = TimeSpan.FromSeconds(s.TimeoutSeconds);
                }
            )
            .AddHttpMessageHandler<ForwardingHandler>()
            .AddStandardResilienceHandler();
        services
            .AddHttpClient<IClaimsCoverageClient, ClaimsCoverageClient>(
                (sp, c) =>
                {
                    var s = sp.GetRequiredService<IOptions<ClaimsServiceSettings>>().Value;
                    c.BaseAddress = new Uri(s.BaseUrl);
                    c.Timeout = TimeSpan.FromSeconds(s.TimeoutSeconds);
                }
            )
            .AddHttpMessageHandler<ForwardingHandler>()
            .AddStandardResilienceHandler();
        services
            .AddHttpClient<IPaymentClient, PaymentClient>(
                (sp, c) =>
                {
                    var s = sp.GetRequiredService<IOptions<PaymentServiceSettings>>().Value;
                    c.BaseAddress = new Uri(string.IsNullOrWhiteSpace(s.BaseUrl) ? "https://localhost:7005/" : s.BaseUrl);
                    c.Timeout = TimeSpan.FromSeconds(s.TimeoutSeconds);
                }
            )
            .AddHttpMessageHandler<ForwardingHandler>()
            .AddStandardResilienceHandler();
        services.AddScoped<IRequestContext, RequestContext>();
        services.AddSingleton<IDateTimeProvider, SystemDateTimeProvider>();
        services.AddSingleton<IPolicyCatalogCache, PolicyCatalogCache>();
        services.AddSingleton<IRiskAssessmentEngine, RiskAssessmentEngine>();
        services.AddSingleton<IPremiumCalculationEngine, PremiumCalculationEngine>();
        services.AddSingleton<ICoverageValidationEngine, CoverageValidationEngine>();
        services.AddSingleton<IUnderwritingDecisionEngine, UnderwritingDecisionEngine>();
        services.AddScoped<IPlanService, PlanService>();
        services.AddScoped<ICoverageTypeService, CoverageTypeService>();
        services.AddScoped<IQuoteService, QuoteService>();
        services.AddScoped<IPolicyService, Services.PolicyService>();
        services.AddScoped<IUnderwritingService, UnderwritingService>();
        services.AddScoped<IPolicyPaymentService, PolicyPaymentService>();
        services.AddScoped<IPolicyValidationService, PolicyValidationService>();
        
        // Register Automated Risk Zone components
        services.AddHttpClient<IThinkHazardClient, ThinkHazardClient>();
        services.AddHttpClient<IGdacsClient, GdacsClient>();
        services.AddScoped<IRiskZoneEvaluator, PolicyService.Infrastructure.Services.RiskZoneEvaluator>();
        services.AddSingleton<IVectorKnowledgeBase, PolicyService.Infrastructure.Services.InMemoryVectorDb>();
        services.AddHttpClient<IComplianceAgentClient, ComplianceAgentClient>();
        services.AddHttpClient<ICustomerSupportAgentClient, CustomerSupportAgentClient>();
        
        return services;
    }
}


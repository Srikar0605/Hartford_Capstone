using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using PolicyService.Domain.Entities;

namespace PolicyService.Infrastructure.Persistence.Configurations;

/// <summary>
/// Centralized persistence conventions for PolicyService aggregate roots.
/// I standardized key generation (ValueGeneratedNever for explicit GUID assignment),
/// optimistic concurrency tokens (RowVersion), audit property length limits,
/// and global soft-deletion query filters across all entities.
/// </summary>
internal static class ConfigurationDefaults
{
    internal static void Aggregate<TEntity>(EntityTypeBuilder<TEntity> builder)
        where TEntity : PolicyService.Domain.Common.AggregateRoot
    {
        builder.HasKey(entity => entity.Id);

        builder.Property(entity => entity.Id).ValueGeneratedNever();

        builder.Property(entity => entity.CreatedBy).HasMaxLength(200).IsRequired();

        builder.Property(entity => entity.UpdatedBy).HasMaxLength(200);

        builder.Property(entity => entity.DeletedBy).HasMaxLength(200);

        builder.Property(entity => entity.RowVersion).IsRowVersion().IsConcurrencyToken();

        builder.HasQueryFilter(entity => !entity.IsDeleted);
    }
}


public sealed class InsurancePlanConfiguration : IEntityTypeConfiguration<InsurancePlan>
{
    public void Configure(EntityTypeBuilder<InsurancePlan> builder)
    {
        builder.ToTable(
            "InsurancePlans",
            table =>
            {
                table.HasCheckConstraint("CK_InsurancePlans_BasePremium", "[BasePremium] > 0");

                table.HasCheckConstraint("CK_InsurancePlans_CoverageLimit", "[CoverageLimit] > 0");

                table.HasCheckConstraint("CK_InsurancePlans_Deductible", "[DeductibleAmount] >= 0");
            }
        );

        ConfigurationDefaults.Aggregate(builder);

        builder.Property(entity => entity.PlanCode).HasMaxLength(50).IsRequired();

        builder.Property(entity => entity.PlanName).HasMaxLength(150).IsRequired();

        builder.Property(entity => entity.Description).HasMaxLength(1000).IsRequired();

        builder.Property(entity => entity.BasePremium).HasPrecision(18, 2);

        builder.Property(entity => entity.CoverageLimit).HasPrecision(18, 2);

        builder.Property(entity => entity.DeductibleAmount).HasPrecision(18, 2);

        builder.HasIndex(entity => entity.PlanCode).IsUnique();

        builder.HasIndex(entity => new { entity.IsActive, entity.PlanName });

        builder.HasIndex(entity => new { entity.CreatedAt, entity.Id }).IsDescending(true, false);

        builder
            .HasMany(entity => entity.PlanCoverages)
            .WithOne()
            .HasForeignKey(entity => entity.PlanId)
            .OnDelete(DeleteBehavior.Restrict);

        builder
            .Navigation(entity => entity.PlanCoverages)
            .UsePropertyAccessMode(PropertyAccessMode.Field);
    }
}

public sealed class CoverageTypeConfiguration : IEntityTypeConfiguration<CoverageType>
{
    public void Configure(EntityTypeBuilder<CoverageType> builder)
    {
        builder.ToTable("CoverageTypes");

        ConfigurationDefaults.Aggregate(builder);

        builder.Property(entity => entity.Name).HasMaxLength(150).IsRequired();

        builder.Property(entity => entity.Description).HasMaxLength(1000).IsRequired();

        builder.HasIndex(entity => entity.Name).IsUnique();

        builder.HasIndex(entity => new { entity.IsActive, entity.Name });
    }
}

public sealed class PlanCoverageConfiguration : IEntityTypeConfiguration<PlanCoverage>
{
    public void Configure(EntityTypeBuilder<PlanCoverage> builder)
    {
        builder.ToTable(
            "PlanCoverages",
            table =>
            {
                table.HasCheckConstraint("CK_PlanCoverages_Limit", "[CoverageLimit] > 0");

                table.HasCheckConstraint("CK_PlanCoverages_Deductible", "[DeductibleAmount] >= 0");
            }
        );

        builder.HasKey(entity => entity.Id);

        builder.Property(entity => entity.Id).ValueGeneratedNever();

        builder.Property(entity => entity.PlanId).IsRequired();

        builder.Property(entity => entity.CoverageTypeId).IsRequired();

        builder.Property(entity => entity.CoverageLimit).HasPrecision(18, 2).IsRequired();

        builder.Property(entity => entity.DeductibleAmount).HasPrecision(18, 2).IsRequired();

        builder.Property(entity => entity.CreatedAt).IsRequired();

        builder.Property(entity => entity.CreatedBy).HasMaxLength(200).IsRequired();

        builder.HasIndex(entity => new { entity.PlanId, entity.CoverageTypeId }).IsUnique();

        builder
            .HasOne<CoverageType>()
            .WithMany()
            .HasForeignKey(entity => entity.CoverageTypeId)
            .OnDelete(DeleteBehavior.Restrict);
    }
}

public sealed class PolicyConfiguration : IEntityTypeConfiguration<Policy>
{
    public void Configure(EntityTypeBuilder<Policy> builder)
    {
        builder.ToTable(
            "Policies",
            table =>
            {
                table.HasCheckConstraint("CK_Policies_Premium", "[PremiumDue] > 0");

                table.HasCheckConstraint("CK_Policies_Version", "[CurrentVersionNumber] >= 0");
            }
        );

        ConfigurationDefaults.Aggregate(builder);

        builder.Property(entity => entity.PolicyNumber).HasMaxLength(50).IsRequired();

        builder.Property(entity => entity.Status).HasConversion<string>().HasMaxLength(30);

        builder.Property(entity => entity.PremiumDue).HasPrecision(18, 2);

        builder.Property(entity => entity.EffectiveDate).IsRequired(false);

        builder.Property(entity => entity.ExpirationDate).IsRequired(false);

        builder.Property(entity => entity.PreviousPolicyId).IsRequired(false);

        builder.Property(entity => entity.PreviousPolicyVersionNumber).IsRequired(false);

        builder.HasIndex(entity => entity.PolicyNumber).IsUnique();

        builder.HasIndex(entity => new { entity.AuthUserId, entity.Status });

        builder.HasIndex(entity => new { entity.CustomerId, entity.Status });

        builder.HasIndex(entity => new { entity.PlanId, entity.Status });

        builder.HasIndex(entity => new { entity.Status, entity.CreatedAt });

        builder.HasIndex(entity => new { entity.Status, entity.EffectiveDate });

        builder.HasIndex(entity => new { entity.Status, entity.ExpirationDate });

        builder.HasIndex(entity => entity.PreviousPolicyId);

        builder.HasIndex(entity => new { entity.CreatedAt, entity.Id }).IsDescending(true, false);

        builder
            .HasOne<InsurancePlan>()
            .WithMany()
            .HasForeignKey(entity => entity.PlanId)
            .OnDelete(DeleteBehavior.Restrict);
    }
}

public sealed class PropertyConfiguration : IEntityTypeConfiguration<Property>
{
    public void Configure(EntityTypeBuilder<Property> builder)
    {
        builder.ToTable("Properties");

        builder.HasKey(entity => entity.Id);

        builder.Property(entity => entity.Id).ValueGeneratedNever();

        builder.Property(entity => entity.PropertyValue).HasPrecision(18, 2);

        builder
            .Property(entity => entity.ConstructionType)
            .HasConversion<string>()
            .HasMaxLength(40);

        builder.Property(entity => entity.RiskZone).HasConversion<string>().HasMaxLength(10);

        builder.HasIndex(entity => entity.PolicyId).IsUnique();

        builder
            .HasOne<Policy>()
            .WithOne()
            .HasForeignKey<Property>(entity => entity.PolicyId)
            .OnDelete(DeleteBehavior.Restrict);
    }
}

public sealed class RiskAssessmentConfiguration : IEntityTypeConfiguration<RiskAssessment>
{
    public void Configure(EntityTypeBuilder<RiskAssessment> builder)
    {
        builder.ToTable(
            "RiskAssessments",
            table =>
                table.HasCheckConstraint(
                    "CK_RiskAssessments_Score",
                    "[RiskScore] >= 0 AND [RiskScore] <= 100"
                )
        );

        builder.HasKey(entity => entity.Id);

        builder.Property(entity => entity.Id).ValueGeneratedNever();

        builder.Property(entity => entity.RiskScore).HasPrecision(5, 2);

        builder.Property(entity => entity.RiskLevel).HasConversion<string>().HasMaxLength(20);

        builder.Property(entity => entity.FactorDetails).HasColumnType("nvarchar(max)");

        builder.Property(entity => entity.CreatedBy).HasMaxLength(200);

        builder.HasIndex(entity => new { entity.PolicyId, entity.AssessmentDate });

        builder
            .HasOne<Policy>()
            .WithMany()
            .HasForeignKey(entity => entity.PolicyId)
            .OnDelete(DeleteBehavior.Restrict);
    }
}

public sealed class PremiumCalculationConfiguration : IEntityTypeConfiguration<PremiumCalculation>
{
    public void Configure(EntityTypeBuilder<PremiumCalculation> builder)
    {
        builder.ToTable("PremiumCalculations");

        builder.HasKey(entity => entity.Id);

        builder.Property(entity => entity.Id).ValueGeneratedNever();

        builder.Property(entity => entity.Amount).HasPrecision(18, 2);

        builder.HasIndex(entity => new { entity.PolicyId, entity.CalculatedAt });

        builder
            .HasOne<Policy>()
            .WithMany()
            .HasForeignKey(entity => entity.PolicyId)
            .OnDelete(DeleteBehavior.Restrict);
    }
}

public sealed class PremiumBreakdownConfiguration : IEntityTypeConfiguration<PremiumBreakdown>
{
    public void Configure(EntityTypeBuilder<PremiumBreakdown> builder)
    {
        builder.ToTable("PremiumBreakdowns");

        builder.HasKey(entity => entity.Id);

        builder.Property(entity => entity.Id).ValueGeneratedNever();

        foreach (
            var propertyName in new[]
            {
                nameof(PremiumBreakdown.BasePremium),
                nameof(PremiumBreakdown.LocationRiskAdjustment),
                nameof(PremiumBreakdown.PropertyRiskAdjustment),
                nameof(PremiumBreakdown.ClaimsHistoryAdjustment),
                nameof(PremiumBreakdown.RiskAdjustment),
                nameof(PremiumBreakdown.DiscountAmount),
                nameof(PremiumBreakdown.FinalPremium),
            }
        )
        {
            builder.Property(propertyName).HasPrecision(18, 2);
        }

        builder.HasIndex(entity => entity.PremiumCalculationId).IsUnique();

        builder
            .HasOne<PremiumCalculation>()
            .WithOne()
            .HasForeignKey<PremiumBreakdown>(entity => entity.PremiumCalculationId)
            .OnDelete(DeleteBehavior.Restrict);
    }
}

public sealed class PolicyVersionConfiguration : IEntityTypeConfiguration<PolicyVersion>
{
    public void Configure(EntityTypeBuilder<PolicyVersion> builder)
    {
        builder.ToTable("PolicyVersions");

        builder.HasKey(entity => entity.Id);

        builder.Property(entity => entity.Id).ValueGeneratedNever();

        builder.Property(entity => entity.ChangeReason).HasMaxLength(500);

        builder.Property(entity => entity.SnapshotData).HasColumnType("nvarchar(max)");

        builder.Property(entity => entity.CreatedBy).HasMaxLength(200);

        builder.HasIndex(entity => new { entity.PolicyId, entity.VersionNumber }).IsUnique();

        builder
            .HasOne<Policy>()
            .WithMany()
            .HasForeignKey(entity => entity.PolicyId)
            .OnDelete(DeleteBehavior.Restrict);
    }
}

public sealed class PolicyDocumentConfiguration : IEntityTypeConfiguration<PolicyDocument>
{
    public void Configure(EntityTypeBuilder<PolicyDocument> builder)
    {
        builder.ToTable("PolicyDocuments");

        builder.HasKey(entity => entity.Id);

        builder.Property(entity => entity.Id).ValueGeneratedNever();

        builder.Property(entity => entity.DocumentType).HasMaxLength(100);

        builder.Property(entity => entity.FileName).HasMaxLength(260);

        builder.Property(entity => entity.FilePath).HasMaxLength(1000);

        builder.Property(entity => entity.CreatedBy).HasMaxLength(200);

        builder
            .HasOne<Policy>()
            .WithMany()
            .HasForeignKey(entity => entity.PolicyId)
            .OnDelete(DeleteBehavior.Restrict);
    }
}

public sealed class UnderwritingReviewConfiguration : IEntityTypeConfiguration<UnderwritingReview>
{
    public void Configure(EntityTypeBuilder<UnderwritingReview> builder)
    {
        builder.ToTable("UnderwritingReviews");

        ConfigurationDefaults.Aggregate(builder);

        builder.Property(entity => entity.ReviewerDisplay).HasMaxLength(200);

        builder.Property(entity => entity.Status).HasConversion<string>().HasMaxLength(30);

        builder.Property(entity => entity.Decision).HasConversion<string>().HasMaxLength(30);

        builder.HasIndex(entity => new { entity.PolicyId, entity.CreatedAt });

        builder.HasIndex(entity => new { entity.Status, entity.CreatedAt });

        builder
            .HasOne<Policy>()
            .WithMany()
            .HasForeignKey(entity => entity.PolicyId)
            .OnDelete(DeleteBehavior.Restrict);

        builder
            .HasMany(entity => entity.Reasons)
            .WithOne()
            .HasForeignKey(entity => entity.UnderwritingReviewId)
            .OnDelete(DeleteBehavior.Restrict);

        builder
            .Navigation(entity => entity.Reasons)
            .UsePropertyAccessMode(PropertyAccessMode.Field);
    }
}

public sealed class UnderwritingDecisionReasonConfiguration
    : IEntityTypeConfiguration<UnderwritingDecisionReason>
{
    public void Configure(EntityTypeBuilder<UnderwritingDecisionReason> builder)
    {
        builder.ToTable("UnderwritingDecisionReasons");

        builder.HasKey(entity => entity.Id);

        builder.Property(entity => entity.Id).ValueGeneratedNever();

        builder.Property(entity => entity.ReasonCode).HasMaxLength(100);

        builder.Property(entity => entity.ReasonDescription).HasMaxLength(500);
    }
}

public sealed class PolicyLifecycleHistoryConfiguration
    : IEntityTypeConfiguration<PolicyLifecycleHistory>
{
    public void Configure(EntityTypeBuilder<PolicyLifecycleHistory> builder)
    {
        builder.ToTable("PolicyLifecycleHistory");

        builder.HasKey(entity => entity.Id);

        builder.Property(entity => entity.Id).ValueGeneratedNever();

        builder.Property(entity => entity.FromStatus).HasConversion<string>().HasMaxLength(30);

        builder.Property(entity => entity.ToStatus).HasConversion<string>().HasMaxLength(30);

        builder.Property(entity => entity.Reason).HasMaxLength(500);

        builder.Property(entity => entity.ChangedBy).HasMaxLength(200);

        builder.Property(entity => entity.CorrelationId).HasMaxLength(100);

        builder.HasIndex(entity => new { entity.PolicyId, entity.ChangedAt });

        builder
            .HasOne<Policy>()
            .WithMany()
            .HasForeignKey(entity => entity.PolicyId)
            .OnDelete(DeleteBehavior.Restrict);
    }
}

public sealed class IdempotencyRecordConfiguration : IEntityTypeConfiguration<IdempotencyRecord>
{
    public void Configure(EntityTypeBuilder<IdempotencyRecord> builder)
    {
        builder.ToTable("IdempotencyRecords");

        builder.HasKey(entity => entity.Id);

        builder.Property(entity => entity.Id).ValueGeneratedNever();

        builder.Property(entity => entity.Operation).HasConversion<string>().HasMaxLength(50);

        builder.Property(entity => entity.Key).HasMaxLength(200);

        builder.Property(entity => entity.RequestHash).HasMaxLength(128);

        builder.Property(entity => entity.ResponseBody).HasColumnType("nvarchar(max)");

        builder.HasIndex(entity => new { entity.Operation, entity.Key }).IsUnique();

        builder.HasIndex(entity => entity.ExpiresAt);
    }
}

public sealed class ComplianceReviewConfiguration : IEntityTypeConfiguration<ComplianceReview>
{
    public void Configure(EntityTypeBuilder<ComplianceReview> builder)
    {
        builder.ToTable("ComplianceReviews");

        builder.HasKey(entity => entity.Id);

        builder.Property(entity => entity.Id).ValueGeneratedNever();

        builder.Property(entity => entity.PolicyId).IsRequired();

        builder.Property(entity => entity.ConfidenceScore).HasPrecision(5, 2);

        builder.Property(entity => entity.Summary).HasMaxLength(1000).IsRequired();

        builder.Property(entity => entity.Engine).HasMaxLength(30);

        builder.Property(entity => entity.ViolationsJson).HasColumnType("nvarchar(max)");

        builder.Property(entity => entity.MissingDiscountsJson).HasColumnType("nvarchar(max)");

        builder.Property(entity => entity.RiskAssessment).HasColumnType("nvarchar(max)");

        builder.Property(entity => entity.RecommendedActionsJson).HasColumnType("nvarchar(max)");

        builder.Property(entity => entity.CitationsJson).HasColumnType("nvarchar(max)");

        builder.Property(entity => entity.CreatedAt).IsRequired();

        builder.Property(entity => entity.CreatedBy).HasMaxLength(200).IsRequired();

        builder
            .HasOne(entity => entity.Policy)
            .WithOne(p => p.ComplianceReview)
            .HasForeignKey<ComplianceReview>(entity => entity.PolicyId)
            .IsRequired(false)
            .OnDelete(DeleteBehavior.Restrict);
    }
}



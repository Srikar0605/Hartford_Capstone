using Microsoft.EntityFrameworkCore;
using PolicyService.Domain.Entities;

namespace PolicyService.Infrastructure.Persistence;

public sealed class PolicyDbContext : DbContext
{
    public PolicyDbContext(DbContextOptions<PolicyDbContext> options)
        : base(options) { }

    public DbSet<InsurancePlan> InsurancePlans => Set<InsurancePlan>();
    public DbSet<CoverageType> CoverageTypes => Set<CoverageType>();
    public DbSet<PlanCoverage> PlanCoverages => Set<PlanCoverage>();
    public DbSet<Policy> Policies => Set<Policy>();
    public DbSet<Property> Properties => Set<Property>();
    public DbSet<RiskAssessment> RiskAssessments => Set<RiskAssessment>();
    public DbSet<PremiumCalculation> PremiumCalculations => Set<PremiumCalculation>();
    public DbSet<PremiumBreakdown> PremiumBreakdowns => Set<PremiumBreakdown>();
    public DbSet<PolicyVersion> PolicyVersions => Set<PolicyVersion>();
    public DbSet<PolicyDocument> PolicyDocuments => Set<PolicyDocument>();
    public DbSet<UnderwritingReview> UnderwritingReviews => Set<UnderwritingReview>();
    public DbSet<UnderwritingDecisionReason> UnderwritingDecisionReasons =>
        Set<UnderwritingDecisionReason>();
    public DbSet<PolicyLifecycleHistory> PolicyLifecycleHistory => Set<PolicyLifecycleHistory>();
    public DbSet<ComplianceReview> ComplianceReviews => Set<ComplianceReview>();
    public DbSet<IdempotencyRecord> IdempotencyRecords => Set<IdempotencyRecord>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(PolicyDbContext).Assembly);
    }
}


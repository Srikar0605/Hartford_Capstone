using AuthService.Infrastructure.Authentication;
using AuthService.Tests.TestSupport;
using FluentAssertions;
using OtpNet;

namespace AuthService.Tests.Security;

public sealed class MfaTests
{
    [Fact]
    public void MfaService_BuildsMicrosoftAuthenticatorCompatibleUri()
    {
        var service = new MfaService();
        var secret = service.GenerateSecret();
        var uri = service.BuildAuthenticatorUri("USER@Example.com", secret);
        uri.Should()
            .StartWith("otpauth://totp/HurricaneShield:")
            .And.Contain("user%40example.com")
            .And.Contain("digits=6")
            .And.Contain("period=30");
        Base32Encoding.ToBytes(secret).Should().HaveCount(20);
    }

    [Fact]
    public void ChallengeStore_RemovesChallengeAfterFifthFailure()
    {
        var store = new MfaChallengeStore();
        var token = store.Create(Guid.NewGuid());
        for (var i = 0; i < 4; i++)
            store.RecordFailedAttempt(token).Should().BeTrue();
        store.RecordFailedAttempt(token).Should().BeFalse();
        store.TryGetUserId(token, out _).Should().BeFalse();
    }

    [Fact]
    public void ChallengeStore_RemovePreventsReuse()
    {
        var store = new MfaChallengeStore();
        var token = store.Create(Guid.NewGuid());
        store.Remove(token);
        store.TryGetUserId(token, out _).Should().BeFalse();
    }

    [Fact]
    public void SecretProtector_RoundTripsAndDoesNotStorePlaintext()
    {
        var old = Environment.GetEnvironmentVariable("AUTH_MFA_ENCRYPTION_KEY");
        try
        {
            Environment.SetEnvironmentVariable(
                "AUTH_MFA_ENCRYPTION_KEY",
                Convert.ToBase64String(
                    System.Security.Cryptography.RandomNumberGenerator.GetBytes(32)
                )
            );
            var p = new MfaSecretProtector();
            var encrypted = p.Protect("JBSWY3DPEHPK3PXP");
            encrypted.Should().NotContain("JBSWY3DPEHPK3PXP");
            p.Unprotect(encrypted).Should().Be("JBSWY3DPEHPK3PXP");
        }
        finally
        {
            Environment.SetEnvironmentVariable("AUTH_MFA_ENCRYPTION_KEY", old);
        }
    }
}


using AuthService.Infrastructure.Authentication;
using AuthService.Infrastructure.Configuration;
using AuthService.Tests.TestSupport;
using FluentAssertions;
using Microsoft.Extensions.Options;

namespace AuthService.Tests.Security;

public sealed class SecurityServiceTests
{
    [Fact]
    public void PasswordHasher_RoundTripsAndRejectsWrongPassword()
    {
        var user = TestData.CreateUser();
        var service = new PasswordHasherService();
        var hash = service.HashPassword(user, "Password@123");
        hash.Should().NotBe("Password@123");
        service.VerifyPassword(user, hash, "Password@123").Should().BeTrue();
        service.VerifyPassword(user, hash, "wrong").Should().BeFalse();
    }

    [Fact]
    public void RefreshTokenGenerator_ReturnsRawTokenAndStableHash()
    {
        var clock = new FakeDateTimeProvider(TestData.UtcNow);
        var service = new RefreshTokenGenerator(
            Options.Create(new JwtSettings { RefreshTokenLifetimeDays = 7 }),
            clock
        );
        var result = service.Generate();
        result.RawToken.Should().NotBe(result.TokenHash);
        result.TokenHash.Should().HaveLength(64);
        service.HashToken(result.RawToken).Should().Be(result.TokenHash);
        result.ExpiresAt.Should().Be(TestData.UtcNow.AddDays(7));
    }

    [Fact]
    public void PasswordResetTokenGenerator_ProducesFifteenMinuteToken()
    {
        var service = new PasswordResetTokenGenerator(new FakeDateTimeProvider(TestData.UtcNow));
        var result = service.Generate();
        result.RawToken.Should().NotBe(result.TokenHash);
        result.TokenHash.Should().HaveLength(64);
        result.ExpiresAt.Should().Be(TestData.UtcNow.AddMinutes(15));
    }

    [Fact]
    public void RecoveryCodes_AreUniqueAndMatchRequiredFormat()
    {
        var service = new RecoveryCodeService();
        var codes = service.GenerateCodes(10);
        codes.Should().HaveCount(10).And.OnlyHaveUniqueItems();
        codes
            .Should()
            .OnlyContain(c =>
                System.Text.RegularExpressions.Regex.IsMatch(
                    c,
                    "^[A-Z2-9]{4}-[A-Z2-9]{4}-[A-Z2-9]{4}$"
                )
            );
    }

    [Fact]
    public void RecoveryCodeHash_RoundTripsCaseInsensitively()
    {
        var service = new RecoveryCodeService();
        var user = TestData.CreateUser();
        var hash = service.HashCode(user, "ABCD-2345-EFGH");
        service.VerifyCode(user, hash, "abcd-2345-efgh").Should().BeTrue();
    }
}


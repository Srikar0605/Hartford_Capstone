using AuthService.Application.Abstractions.Time;

namespace AuthService.Tests.TestSupport;

public sealed class FakeDateTimeProvider : IDateTimeProvider
{
    public FakeDateTimeProvider(DateTime utcNow) => UtcNow = utcNow;

    public DateTime UtcNow { get; set; }
}


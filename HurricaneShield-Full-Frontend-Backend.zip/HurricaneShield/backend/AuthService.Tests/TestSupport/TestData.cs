using AuthService.Domain.Entities;

namespace AuthService.Tests.TestSupport;

public static class TestData
{
    public static readonly DateTime UtcNow = new(2026, 9, 28, 5, 30, 0, DateTimeKind.Utc);

    public static User CreateUser(
        string email = "customer@example.com",
        string passwordHash = "stored-hash"
    ) => User.Create(email, passwordHash, "Test", "User", UtcNow, "Tests");
}


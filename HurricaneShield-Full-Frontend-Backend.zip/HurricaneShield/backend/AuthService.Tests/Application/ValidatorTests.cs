using AuthService.Application.Commands.Login;
using AuthService.Application.Commands.RegisterUser;
using AuthService.Application.Commands.VerifyMfa;
using FluentAssertions;

namespace AuthService.Tests.Application;

public sealed class ValidatorTests
{
    [Fact]
    public async Task Registration_ValidRequest_Passes() =>
        (
            await new RegisterUserCommandValidator().ValidateAsync(
                new RegisterUserCommand("u@example.com", "Password@123", "A", "B")
            )
        )
            .IsValid.Should()
            .BeTrue();

    [Theory]
    [InlineData("bad", "Password@123")]
    [InlineData("u@example.com", "password")]
    [InlineData("u@example.com", "PASSWORD@123")]
    [InlineData("u@example.com", "Password")]
    public async Task Registration_InvalidInput_Fails(string email, string password) =>
        (
            await new RegisterUserCommandValidator().ValidateAsync(
                new RegisterUserCommand(email, password, "A", "B")
            )
        )
            .IsValid.Should()
            .BeFalse();

    [Fact]
    public async Task Login_MissingPassword_Fails() =>
        (await new LoginCommandValidator().ValidateAsync(new LoginCommand("u@example.com", "")))
            .IsValid.Should()
            .BeFalse();

    [Fact]
    public async Task VerifyMfa_ValidChallengeAndCode_Passes()
    {
        var validator = new VerifyMfaCommandValidator();

        var command = new VerifyMfaCommand("opaque-mfa-challenge-token", "123456");

        var result = await validator.ValidateAsync(command);

        result.IsValid.Should().BeTrue();
    }

    [Theory]
    [InlineData("12345")]
    [InlineData("1234567")]
    [InlineData("abcdef")]
    [InlineData("")]
    public async Task VerifyMfa_InvalidCode_Fails(string verificationCode)
    {
        var validator = new VerifyMfaCommandValidator();

        var command = new VerifyMfaCommand("challenge-token", verificationCode);

        var result = await validator.ValidateAsync(command);

        result.IsValid.Should().BeFalse();
    }

    [Fact]
    public async Task VerifyMfa_MissingChallenge_Fails()
    {
        var validator = new VerifyMfaCommandValidator();

        var command = new VerifyMfaCommand(string.Empty, "123456");

        var result = await validator.ValidateAsync(command);

        result.IsValid.Should().BeFalse();
    }
}


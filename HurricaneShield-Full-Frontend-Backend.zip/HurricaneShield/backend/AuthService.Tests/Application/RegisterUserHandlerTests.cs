using AuthService.Application.Abstractions.Auditing;
using AuthService.Application.Abstractions.Authentication;
using AuthService.Application.Commands.RegisterUser;
using AuthService.Domain.Constants;
using AuthService.Domain.Entities;
using AuthService.Domain.Repositories;
using AuthService.Tests.TestSupport;
using FluentAssertions;
using Moq;
using Shared.Common.Errors;
using Shared.Common.Exceptions;

namespace AuthService.Tests.Application;

public sealed class RegisterUserHandlerTests
{
    private readonly Mock<IUserRepository> users = new();
    private readonly Mock<IRoleRepository> roles = new();
    private readonly Mock<IPasswordHasher> hasher = new();
    private readonly Mock<ISecurityAuditWriter> audits = new();
    private readonly Mock<IUnitOfWork> uow = new();

    [Fact]
    public async Task Handle_DuplicateEmail_ThrowsConflict()
    {
        users
            .Setup(x => x.EmailExistsAsync("u@example.com", It.IsAny<CancellationToken>()))
            .ReturnsAsync(true);
        var h = Create();
        var action = () =>
            h.Handle(new RegisterUserCommand("U@example.com", "Password@123", "A", "B"), default);
        var ex = await action.Should().ThrowAsync<AppException>();
        ex.Which.ErrorCode.Should().Be(ErrorCodes.ResourceConflict);
    }

    [Fact]
    public async Task Handle_ValidRequest_AddsUserCustomerRoleAuditAndSaves()
    {
        users
            .Setup(x => x.EmailExistsAsync("u@example.com", It.IsAny<CancellationToken>()))
            .ReturnsAsync(false);
        roles
            .Setup(x => x.GetByNameAsync(SystemRoles.Customer, It.IsAny<CancellationToken>()))
            .ReturnsAsync(Role.Create(SystemRoles.Customer, "Customer"));
        hasher.Setup(x => x.HashPassword(It.IsAny<User>(), "Password@123")).Returns("safe-hash");
        uow.Setup(x => x.SaveChangesAsync(It.IsAny<CancellationToken>())).ReturnsAsync(3);
        var result = await Create()
            .Handle(new RegisterUserCommand("U@example.com", "Password@123", "A", "B"), default);
        result.UserId.Should().NotBeEmpty();
        users.Verify(
            x =>
                x.AddAsync(
                    It.Is<User>(u => u.Email == "u@example.com" && u.PasswordHash == "safe-hash"),
                    It.IsAny<CancellationToken>()
                ),
            Times.Once
        );
        roles.Verify(
            x => x.AddUserRoleAsync(It.IsAny<UserRole>(), It.IsAny<CancellationToken>()),
            Times.Once
        );
        audits.Verify(
            x =>
                x.WriteAsync(
                    It.Is<SecurityAuditEntry>(a =>
                        a.EventType == SecurityAuditEventTypes.UserRegistered
                    ),
                    It.IsAny<CancellationToken>()
                ),
            Times.Once
        );
        uow.Verify(x => x.SaveChangesAsync(It.IsAny<CancellationToken>()), Times.Once);
    }

    private RegisterUserCommandHandler Create() =>
        new(
            users.Object,
            roles.Object,
            hasher.Object,
            audits.Object,
            uow.Object,
            new FakeDateTimeProvider(TestData.UtcNow)
        );
}


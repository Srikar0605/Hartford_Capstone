using AuthService.Application.Abstractions.Auditing;
using AuthService.Application.Abstractions.Authentication;
using AuthService.Application.Commands.VerifyMfa;
using AuthService.Domain.Repositories;
using FluentAssertions;
using Moq;
using Shared.Common.Errors;
using Shared.Common.Exceptions;

namespace AuthService.Tests.Application;

public sealed class VerifyMfaHandlerTests
{
    [Fact]
    public async Task InvalidChallenge_IsRejectedBeforeUserLookup()
    {
        var challengeStore = new Mock<IMfaChallengeStore>();

        var ignoredUserId = Guid.Empty;

        challengeStore.Setup(store => store.TryGetUserId("bad", out ignoredUserId)).Returns(false);

        var users = new Mock<IUserRepository>();

        var handler = Create(users, challengeStore, new Mock<IMfaService>());

        Func<Task> action = () =>
            handler.Handle(new VerifyMfaCommand("bad", "123456"), CancellationToken.None);

        var exception = await action.Should().ThrowAsync<AppException>();

        exception.Which.ErrorCode.Should().Be(ErrorCodes.AuthInvalidMfaCode);

        users.Verify(
            repository =>
                repository.GetByIdWithMfaAsync(It.IsAny<Guid>(), It.IsAny<CancellationToken>()),
            Times.Never
        );
    }

    private static VerifyMfaCommandHandler Create(
        Mock<IUserRepository> users,
        Mock<IMfaChallengeStore> store,
        Mock<IMfaService> mfa
    ) =>
        new(
            users.Object,
            store.Object,
            mfa.Object,
            new Mock<IMfaSecretProtector>().Object,
            new Mock<IAuthenticationTokenIssuer>().Object,
            new Mock<ISecurityAuditWriter>().Object,
            new Mock<IUnitOfWork>().Object
        );
}


using AuthService.Application.Abstractions.Auditing;
using AuthService.Application.Abstractions.Authentication;
using AuthService.Application.Abstractions.Context;
using AuthService.Application.Commands.Login;
using AuthService.Domain.Entities;
using AuthService.Domain.Repositories;
using AuthService.Tests.TestSupport;
using FluentAssertions;
using Moq;
using Shared.Common.Errors;
using Shared.Common.Exceptions;

namespace AuthService.Tests.Application;

public sealed class LoginHandlerTests
{
    [Fact]
    public async Task Handle_UnknownUser_ThrowsInvalidCredentialsAndAudits()
    {
        var users = new Mock<IUserRepository>();

        users
            .Setup(repository =>
                repository.GetByEmailWithAuthenticationDataAsync(
                    It.IsAny<string>(),
                    It.IsAny<CancellationToken>()
                )
            )
            .ReturnsAsync((User?)null);

        var audits = new Mock<ISecurityAuditWriter>();
        var unitOfWork = new Mock<IUnitOfWork>();

        unitOfWork
            .Setup(work => work.SaveChangesAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(1);

        var handler = Create(
            users,
            audits,
            unitOfWork,
            new Mock<IPasswordHasher>(),
            new Mock<IMfaChallengeStore>()
        );

        Func<Task> action = () =>
            handler.Handle(new LoginCommand("none@example.com", "bad"), CancellationToken.None);

        var exception = await action.Should().ThrowAsync<AppException>();

        exception.Which.ErrorCode.Should().Be(ErrorCodes.AuthInvalidCredentials);

        audits.Verify(
            writer =>
                writer.WriteAsync(It.IsAny<SecurityAuditEntry>(), It.IsAny<CancellationToken>()),
            Times.Once
        );
    }

    [Fact]
    public async Task Handle_WrongPassword_IncrementsFailureAndRecordsActivity()
    {
        var user = TestData.CreateUser();

        var users = new Mock<IUserRepository>();

        users
            .Setup(repository =>
                repository.GetByEmailWithAuthenticationDataAsync(
                    It.IsAny<string>(),
                    It.IsAny<CancellationToken>()
                )
            )
            .ReturnsAsync(user);

        var passwordHasher = new Mock<IPasswordHasher>();

        passwordHasher
            .Setup(hasher => hasher.VerifyPassword(user, user.PasswordHash, "wrong"))
            .Returns(false);

        var unitOfWork = new Mock<IUnitOfWork>();

        unitOfWork
            .Setup(work => work.SaveChangesAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(1);

        var handler = Create(
            users,
            new Mock<ISecurityAuditWriter>(),
            unitOfWork,
            passwordHasher,
            new Mock<IMfaChallengeStore>()
        );

        Func<Task> action = () =>
            handler.Handle(new LoginCommand(user.Email, "wrong"), CancellationToken.None);

        await action.Should().ThrowAsync<AppException>();

        user.FailedLoginAttempts.Should().Be(1);

        users.Verify(
            repository =>
                repository.AddLoginActivityAsync(
                    It.Is<LoginActivity>(activity => !activity.IsSuccessful),
                    It.IsAny<CancellationToken>()
                ),
            Times.Once
        );
    }

    [Fact]
    public async Task Handle_RememberMeTrue_GeneratesTrustedDeviceToken()
    {
        var user = TestData.CreateUser();
        var users = new Mock<IUserRepository>();
        users
            .Setup(r =>
                r.GetByEmailWithAuthenticationDataAsync(user.Email, It.IsAny<CancellationToken>())
            )
            .ReturnsAsync(user);

        var passwordHasher = new Mock<IPasswordHasher>();
        passwordHasher
            .Setup(h => h.VerifyPassword(user, user.PasswordHash, "secret"))
            .Returns(true);

        var trustedStore = new Mock<ITrustedDeviceStore>();
        trustedStore.Setup(s => s.Create(user.Id)).Returns("trusted-token-123");

        var unitOfWork = new Mock<IUnitOfWork>();
        unitOfWork.Setup(w => w.SaveChangesAsync(It.IsAny<CancellationToken>())).ReturnsAsync(1);

        var handler = Create(
            users,
            new Mock<ISecurityAuditWriter>(),
            unitOfWork,
            passwordHasher,
            new Mock<IMfaChallengeStore>(),
            trustedStore
        );

        var result = await handler.Handle(
            new LoginCommand(user.Email, "secret", RememberMe: true),
            CancellationToken.None
        );

        result.Should().NotBeNull();
        result.MfaRequired.Should().BeFalse();
        result.TrustedDeviceToken.Should().Be("trusted-token-123");
    }

    [Fact]
    public async Task Handle_MfaEnabled_WithValidTrustedDevice_BypassesMfa()
    {
        var user = TestData.CreateUser();
        user.SetMfa(UserMfa.CreatePending(user.Id, "encrypted-secret"));
        user.Mfa!.Enable(TestData.UtcNow);

        var users = new Mock<IUserRepository>();
        users
            .Setup(r =>
                r.GetByEmailWithAuthenticationDataAsync(user.Email, It.IsAny<CancellationToken>())
            )
            .ReturnsAsync(user);

        var passwordHasher = new Mock<IPasswordHasher>();
        passwordHasher
            .Setup(h => h.VerifyPassword(user, user.PasswordHash, "secret"))
            .Returns(true);

        var trustedStore = new Mock<ITrustedDeviceStore>();
        trustedStore.Setup(s => s.IsValid("valid-device-token", user.Id)).Returns(true);

        var unitOfWork = new Mock<IUnitOfWork>();
        unitOfWork.Setup(w => w.SaveChangesAsync(It.IsAny<CancellationToken>())).ReturnsAsync(1);

        var handler = Create(
            users,
            new Mock<ISecurityAuditWriter>(),
            unitOfWork,
            passwordHasher,
            new Mock<IMfaChallengeStore>(),
            trustedStore
        );

        var result = await handler.Handle(
            new LoginCommand(user.Email, "secret", TrustedDeviceToken: "valid-device-token"),
            CancellationToken.None
        );

        result.Should().NotBeNull();
        result.MfaRequired.Should().BeFalse();
        result.AccessToken.Should().NotBeNull();
    }

    private static LoginCommandHandler Create(
        Mock<IUserRepository> u,
        Mock<ISecurityAuditWriter> a,
        Mock<IUnitOfWork> w,
        Mock<IPasswordHasher> p,
        Mock<IMfaChallengeStore> c,
        Mock<ITrustedDeviceStore>? t = null
    )
    {
        var jwt = new Mock<IJwtTokenGenerator>();
        jwt.Setup(j => j.GenerateAccessToken(It.IsAny<User>()))
            .Returns(new AccessTokenResult("jwt-token", 900));

        var refresh = new Mock<IRefreshTokenGenerator>();
        refresh
            .Setup(r => r.Generate())
            .Returns(new RefreshTokenResult("raw-token", "token-hash", TestData.UtcNow.AddDays(7)));

        var ctx = new Mock<IRequestContext>();
        ctx.SetupGet(x => x.IpAddress).Returns("127.0.0.1");

        return new LoginCommandHandler(
            u.Object,
            p.Object,
            jwt.Object,
            refresh.Object,
            a.Object,
            ctx.Object,
            w.Object,
            new FakeDateTimeProvider(TestData.UtcNow),
            c.Object,
            (t ?? new Mock<ITrustedDeviceStore>()).Object
        );
    }
}


using AuthService.Domain.Entities;
using AuthService.Tests.TestSupport;
using FluentAssertions;

namespace AuthService.Tests.Domain;

public sealed class TokenEntityTests
{
    [Fact]
    public void RefreshToken_IsActiveBeforeExpiry()
    {
        var t = RefreshToken.Create(
            Guid.NewGuid(),
            "hash",
            TestData.UtcNow.AddDays(7),
            TestData.UtcNow
        );
        t.IsActive(TestData.UtcNow).Should().BeTrue();
    }

    [Fact]
    public void RefreshToken_Revoke_IsIdempotentAndLinksReplacement()
    {
        var t = RefreshToken.Create(
            Guid.NewGuid(),
            "hash",
            TestData.UtcNow.AddDays(7),
            TestData.UtcNow
        );
        var id = Guid.NewGuid();
        t.Revoke(TestData.UtcNow, id);
        t.Revoke(TestData.UtcNow.AddMinutes(1));
        t.RevokedAt.Should().Be(TestData.UtcNow);
        t.ReplacedByTokenId.Should().Be(id);
    }

    [Fact]
    public void RefreshToken_CannotReplaceItself()
    {
        var t = RefreshToken.Create(
            Guid.NewGuid(),
            "hash",
            TestData.UtcNow.AddDays(7),
            TestData.UtcNow
        );
        var action = () => t.Revoke(TestData.UtcNow, t.Id);
        action.Should().Throw<ArgumentException>();
    }

    [Fact]
    public void PasswordResetToken_IsSingleUse()
    {
        var t = PasswordResetToken.Create(
            Guid.NewGuid(),
            "hash",
            TestData.UtcNow.AddMinutes(15),
            TestData.UtcNow,
            "Tests"
        );
        t.MarkAsUsed(TestData.UtcNow);
        t.IsValid(TestData.UtcNow).Should().BeFalse();
        var action = () => t.MarkAsUsed(TestData.UtcNow);
        action.Should().Throw<InvalidOperationException>();
    }

    [Fact]
    public void RecoveryCode_IsSingleUse()
    {
        var c = RecoveryCode.Create(Guid.NewGuid(), "hash", TestData.UtcNow);
        c.MarkAsUsed(TestData.UtcNow);
        c.IsUsed().Should().BeTrue();
        var action = () => c.MarkAsUsed(TestData.UtcNow);
        action.Should().Throw<InvalidOperationException>();
    }

    [Fact]
    public void UserMfa_RequiresConfirmationToEnable()
    {
        var m = UserMfa.CreatePending(Guid.NewGuid(), "encrypted");
        m.IsEnabled.Should().BeFalse();
        m.Enable(TestData.UtcNow);
        m.IsEnabled.Should().BeTrue();
        m.VerifiedAt.Should().Be(TestData.UtcNow);
    }
}


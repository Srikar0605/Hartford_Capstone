using AuthService.Tests.TestSupport;
using FluentAssertions;

namespace AuthService.Tests.Domain;

public sealed class UserTests
{
    [Fact]
    public void Create_NormalizesEmailAndInitializesActiveUser()
    {
        var user = AuthService.Domain.Entities.User.Create(
            "  USER@Example.COM ",
            "hash",
            " John ",
            " Doe ",
            TestData.UtcNow,
            "Tests"
        );
        user.Email.Should().Be("user@example.com");
        user.FirstName.Should().Be("John");
        user.LastName.Should().Be("Doe");
        user.IsActive.Should().BeTrue();
        user.FailedLoginAttempts.Should().Be(0);
        user.IsDeleted.Should().BeFalse();
    }

    [Fact]
    public void RecordFailedLogin_LocksOnFifthAttempt()
    {
        var user = TestData.CreateUser();
        for (var i = 0; i < 5; i++)
            user.RecordFailedLogin(TestData.UtcNow, 5, TimeSpan.FromMinutes(15));
        user.FailedLoginAttempts.Should().Be(5);
        user.IsLocked(TestData.UtcNow).Should().BeTrue();
        user.LockoutEnd.Should().Be(TestData.UtcNow.AddMinutes(15));
    }

    [Fact]
    public void RecordSuccessfulLogin_ClearsFailureState()
    {
        var user = TestData.CreateUser();
        user.RecordFailedLogin(TestData.UtcNow, 1, TimeSpan.FromMinutes(15));
        user.RecordSuccessfulLogin();
        user.FailedLoginAttempts.Should().Be(0);
        user.LockoutEnd.Should().BeNull();
    }

    [Fact]
    public void SoftDelete_DeactivatesAndAuditsDeletion()
    {
        var user = TestData.CreateUser();
        user.SoftDelete(TestData.UtcNow, "admin");
        user.IsDeleted.Should().BeTrue();
        user.IsActive.Should().BeFalse();
        user.DeletedBy.Should().Be("admin");
    }
}


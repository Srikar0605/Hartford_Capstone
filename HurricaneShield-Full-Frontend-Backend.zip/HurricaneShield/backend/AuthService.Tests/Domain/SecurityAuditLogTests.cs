using AuthService.Domain.Constants;
using AuthService.Domain.Entities;
using AuthService.Tests.TestSupport;
using FluentAssertions;

namespace AuthService.Tests.Domain;

public sealed class SecurityAuditLogTests
{
    [Fact]
    public void Create_UserActorWithoutUserId_Throws()
    {
        var action = () =>
            SecurityAuditLog.Create(
                SecurityAuditEventTypes.LoginSucceeded,
                SecurityAuditOutcomes.Succeeded,
                SecurityAuditActorTypes.User,
                null,
                null,
                "description",
                null,
                "correlation",
                null,
                null,
                TestData.UtcNow
            );
        action.Should().Throw<ArgumentException>();
    }

    [Fact]
    public void Create_ValidAnonymousAudit_Succeeds()
    {
        var log = SecurityAuditLog.Create(
            SecurityAuditEventTypes.LoginFailed,
            SecurityAuditOutcomes.Failed,
            SecurityAuditActorTypes.Anonymous,
            null,
            null,
            " description ",
            null,
            " correlation ",
            null,
            null,
            TestData.UtcNow
        );
        log.Description.Should().Be("description");
        log.CorrelationId.Should().Be("correlation");
    }
}


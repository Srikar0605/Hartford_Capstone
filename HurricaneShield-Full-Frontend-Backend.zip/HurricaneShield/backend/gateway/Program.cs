using Ocelot.DependencyInjection;
using Ocelot.Middleware;
using Shared.Exceptions.Extensions;
using Shared.Logging.Extensions;

const string AngularDevelopmentCors = "AngularDevelopmentCors";

var builder = WebApplication.CreateBuilder(args);

builder.Configuration.AddJsonFile("ocelot.json", optional: false, reloadOnChange: true);

builder.Services.AddCors(options =>
{
    options.AddPolicy(
        AngularDevelopmentCors,
        policy =>
        {
            policy.WithOrigins("http://localhost:4200").AllowAnyHeader().AllowAnyMethod();
        }
    );
});

builder.Services.AddOcelot(builder.Configuration);

var app = builder.Build();

app.UseCors(AngularDevelopmentCors);

app.UseCorrelationId();
app.UseGlobalExceptionHandling();
app.UseRequestLogging();

await app.UseOcelot();

await app.RunAsync();


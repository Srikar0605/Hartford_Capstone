# HurricaneShield - schema changes for the "AI engine label" fix.
#
# Adds one nullable column to two tables:
#   PolicyDb.ComplianceReviews.Engine   nvarchar(30) NULL
#   ClaimsDb.AiClaimTriages.Engine      nvarchar(30) NULL
# Existing rows keep NULL (the UI then shows no Gemini / rule-based tag for them).
#
# Run from the backend solution folder (the one that contains PolicyService.API etc.):
#   powershell -ExecutionPolicy Bypass -File .\apply-db-changes.ps1
#
# Needs the EF Core CLI you already use for migrations (dotnet tool install --global dotnet-ef).
# If you can't use dotnet-ef on this machine, run db-changes.sql in SQL Server instead.

$ErrorActionPreference = "Stop"

Write-Host "PolicyService: adding ComplianceReviews.Engine ..." -ForegroundColor Cyan
dotnet ef migrations add AddAiEngineToComplianceReviews `
    --project PolicyService.Infrastructure `
    --startup-project PolicyService.API
dotnet ef database update `
    --project PolicyService.Infrastructure `
    --startup-project PolicyService.API

Write-Host "ClaimsService: adding AiClaimTriages.Engine ..." -ForegroundColor Cyan
dotnet ef migrations add AddAiEngineToClaimTriages `
    --project ClaimsService.Infrastructure `
    --startup-project ClaimsService.API
dotnet ef database update `
    --project ClaimsService.Infrastructure `
    --startup-project ClaimsService.API

Write-Host "Done. No change is needed for CustomerService, AuthService or PaymentService." -ForegroundColor Green

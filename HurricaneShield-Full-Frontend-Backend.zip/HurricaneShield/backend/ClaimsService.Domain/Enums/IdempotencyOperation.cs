namespace ClaimsService.Domain.Enums;

public enum IdempotencyOperation
{
    ClaimSubmission,
    ClaimSettlement,
}


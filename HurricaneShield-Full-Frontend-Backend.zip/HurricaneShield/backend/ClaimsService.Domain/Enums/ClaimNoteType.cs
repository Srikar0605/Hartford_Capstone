namespace ClaimsService.Domain.Enums;

public enum ClaimNoteType
{
    AdditionalInformationRequested,
}


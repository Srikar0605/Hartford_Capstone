namespace ClaimsService.Domain.Enums;

public enum DocumentVerificationStatus
{
    Pending,
    Verified,
    Rejected,
}


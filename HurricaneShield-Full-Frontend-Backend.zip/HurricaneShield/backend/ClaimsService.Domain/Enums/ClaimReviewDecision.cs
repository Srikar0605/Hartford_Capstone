namespace ClaimsService.Domain.Enums;

public enum ClaimReviewDecision
{
    Approved,
    Rejected,
}


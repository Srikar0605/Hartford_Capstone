namespace ClaimsService.Domain.Enums;

public enum ClaimStatus
{
    Submitted,
    UnderReview,
    Approved,
    Rejected,
    PaymentInitiated,
    Closed,
}


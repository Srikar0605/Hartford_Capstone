using ClaimsService.Domain.Exceptions;

namespace ClaimsService.Domain.Common;

internal static class DomainGuard
{
    internal static string Required(string value, string name, int maxLength)
    {
        if (string.IsNullOrWhiteSpace(value))
            throw new DomainRuleException($"{name} is required.");
        var normalized = value.Trim();
        if (normalized.Length > maxLength)
            throw new DomainRuleException($"{name} cannot exceed {maxLength} characters.");
        return normalized;
    }

    internal static DateTime Utc(DateTime value, string name)
    {
        if (value.Kind != DateTimeKind.Utc)
            throw new DomainRuleException($"{name} must be UTC.");
        return value;
    }

    internal static void NonEmpty(Guid value, string name)
    {
        if (value == Guid.Empty)
            throw new DomainRuleException($"{name} is required.");
    }
}


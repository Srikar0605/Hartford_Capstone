namespace ClaimsService.Domain.Models;

public sealed record ClaimSettlementConfirmation(
    Guid TransactionId,
    bool Successful,
    string? FailureReason
);


namespace ClaimsService.Domain.Models;

public sealed record ClaimApprovalReadiness(bool IsReady, IReadOnlyCollection<string> Reasons);


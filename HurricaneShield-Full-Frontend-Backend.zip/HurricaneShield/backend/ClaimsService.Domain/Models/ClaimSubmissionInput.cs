namespace ClaimsService.Domain.Models;

public sealed record ClaimSubmissionInput(
    decimal ClaimAmount,
    DateOnly IncidentDate,
    DateOnly SubmissionDate
);


using ClaimsService.Domain.Common;
using ClaimsService.Domain.Enums;

namespace ClaimsService.Domain.Entities;

public sealed class IdempotencyRecord
{
    public Guid Id { get; private set; }
    public IdempotencyOperation Operation { get; private set; }
    public string Key { get; private set; } = string.Empty;
    public string RequestHash { get; private set; } = string.Empty;
    public int ResponseStatusCode { get; private set; }
    public string ResponseBody { get; private set; } = string.Empty;
    public Guid? ResourceId { get; private set; }
    public DateTime CreatedAt { get; private set; }
    public DateTime ExpiresAt { get; private set; }

    private IdempotencyRecord() { }

    public static IdempotencyRecord Create(
        IdempotencyOperation operation,
        string key,
        string hash,
        int status,
        string body,
        Guid? resourceId,
        DateTime at
    )
    {
        at = DomainGuard.Utc(at, nameof(at));
        return new IdempotencyRecord
        {
            Id = Guid.NewGuid(),
            Operation = operation,
            Key = DomainGuard.Required(key, nameof(key), 200),
            RequestHash = DomainGuard.Required(hash, nameof(hash), 128),
            ResponseStatusCode = status,
            ResponseBody = DomainGuard.Required(body, nameof(body), int.MaxValue),
            ResourceId = resourceId,
            CreatedAt = at,
            ExpiresAt = at.AddHours(24),
        };
    }
}


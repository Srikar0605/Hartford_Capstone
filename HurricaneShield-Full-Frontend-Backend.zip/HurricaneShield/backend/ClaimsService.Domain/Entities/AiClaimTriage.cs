using System.Text.Json;
using ClaimsService.Domain.Common;

namespace ClaimsService.Domain.Entities;

public sealed class AiClaimTriage
{
    public Guid Id { get; private set; }
    public Guid ClaimId { get; private set; }
    public string FraudFlagsJson { get; private set; } = "[]";
    public int ComplexityScore { get; private set; }
    public string Summary { get; private set; } = string.Empty;
    public string Recommendation { get; private set; } = string.Empty;
    public decimal AiConfidence { get; private set; }
    public DateTime TriagedAt { get; private set; }

    /// <summary>"Gemini" when the language model produced the triage, "RuleBased" for the local fallback; null for older rows.</summary>
    public string? Engine { get; private set; }

    public Claim Claim { get; private set; } = null!;

    private AiClaimTriage() { }

    public static AiClaimTriage Create(
        Guid claimId,
        IEnumerable<string> fraudFlags,
        int complexityScore,
        string summary,
        string recommendation,
        decimal aiConfidence,
        DateTime triagedAt,
        string? engine = null
    )
    {
        DomainGuard.NonEmpty(claimId, nameof(claimId));
        return new AiClaimTriage
        {
            Id = Guid.NewGuid(),
            ClaimId = claimId,
            FraudFlagsJson = JsonSerializer.Serialize(fraudFlags),
            ComplexityScore = Math.Clamp(complexityScore, 1, 10),
            Summary = DomainGuard.Required(summary, nameof(summary), 2000),
            Recommendation = DomainGuard.Required(recommendation, nameof(recommendation), 100),
            AiConfidence = aiConfidence,
            TriagedAt = DomainGuard.Utc(triagedAt, nameof(triagedAt)),
            Engine = engine
        };
    }
}


using ClaimsService.Domain.Common;
using ClaimsService.Domain.Exceptions;

namespace ClaimsService.Domain.Entities;

public sealed class ClaimDocument
{
    public Guid Id { get; private set; }
    public Guid ClaimId { get; private set; }
    public string FileName { get; private set; } = string.Empty;
    public string ContentType { get; private set; } = string.Empty;
    public long FileSize { get; private set; }
    public string FilePath { get; private set; } = string.Empty;
    public string DocumentType { get; private set; } = string.Empty;
    public DateTime UploadedAt { get; private set; }
    public string UploadedBy { get; private set; } = string.Empty;

    private ClaimDocument() { }

    public static ClaimDocument Create(
        Guid claimId,
        string fileName,
        string contentType,
        long fileSize,
        string filePath,
        string documentType,
        DateTime uploadedAt,
        string uploadedBy
    )
    {
        DomainGuard.NonEmpty(claimId, nameof(claimId));
        if (fileSize <= 0 || fileSize > 10 * 1024 * 1024)
            throw new DomainRuleException("File size must be between 1 byte and 10 MB.");
        return new ClaimDocument
        {
            Id = Guid.NewGuid(),
            ClaimId = claimId,
            FileName = DomainGuard.Required(fileName, nameof(fileName), 260),
            ContentType = DomainGuard.Required(contentType, nameof(contentType), 100),
            FileSize = fileSize,
            FilePath = DomainGuard.Required(filePath, nameof(filePath), 1000),
            DocumentType = DomainGuard.Required(documentType, nameof(documentType), 100),
            UploadedAt = DomainGuard.Utc(uploadedAt, nameof(uploadedAt)),
            UploadedBy = DomainGuard.Required(uploadedBy, nameof(uploadedBy), 200),
        };
    }
}


using ClaimsService.Domain.Common;
using ClaimsService.Domain.Enums;

namespace ClaimsService.Domain.Entities;

public sealed class ClaimNote
{
    public Guid Id { get; private set; }
    public Guid ClaimId { get; private set; }
    public ClaimNoteType NoteType { get; private set; }
    public string NoteText { get; private set; } = string.Empty;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private ClaimNote() { }

    public static ClaimNote Create(
        Guid claimId,
        ClaimNoteType type,
        string text,
        DateTime at,
        string actor
    )
    {
        DomainGuard.NonEmpty(claimId, nameof(claimId));
        return new ClaimNote
        {
            Id = Guid.NewGuid(),
            ClaimId = claimId,
            NoteType = type,
            NoteText = DomainGuard.Required(text, nameof(text), 2000),
            CreatedAt = DomainGuard.Utc(at, nameof(at)),
            CreatedBy = DomainGuard.Required(actor, nameof(actor), 200),
        };
    }
}


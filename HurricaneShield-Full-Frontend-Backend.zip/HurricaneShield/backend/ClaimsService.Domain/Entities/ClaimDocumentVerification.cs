using ClaimsService.Domain.Common;
using ClaimsService.Domain.Enums;
using ClaimsService.Domain.Exceptions;

namespace ClaimsService.Domain.Entities;

public sealed class ClaimDocumentVerification
{
    public Guid Id { get; private set; }
    public Guid ClaimDocumentId { get; private set; }
    public DocumentVerificationStatus Status { get; private set; }
    public string? Notes { get; private set; }
    public DateTime? VerifiedAt { get; private set; }
    public string? VerifiedBy { get; private set; }

    private ClaimDocumentVerification() { }

    public static ClaimDocumentVerification CreatePending(Guid documentId)
    {
        DomainGuard.NonEmpty(documentId, nameof(documentId));
        return new ClaimDocumentVerification
        {
            Id = Guid.NewGuid(),
            ClaimDocumentId = documentId,
            Status = DocumentVerificationStatus.Pending,
        };
    }

    public void Verify(string? notes, DateTime at, string actor) =>
        Complete(DocumentVerificationStatus.Verified, notes, at, actor);

    public void Reject(string notes, DateTime at, string actor) =>
        Complete(
            DocumentVerificationStatus.Rejected,
            DomainGuard.Required(notes, nameof(notes), 1000),
            at,
            actor
        );

    private void Complete(
        DocumentVerificationStatus status,
        string? notes,
        DateTime at,
        string actor
    )
    {
        if (Status != DocumentVerificationStatus.Pending)
            throw new DomainRuleException("Document verification is already completed.");
        Status = status;
        Notes = notes?.Trim();
        VerifiedAt = DomainGuard.Utc(at, nameof(at));
        VerifiedBy = DomainGuard.Required(actor, nameof(actor), 200);
    }
}


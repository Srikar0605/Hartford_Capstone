using ClaimsService.Domain.Common;
using ClaimsService.Domain.Enums;
using ClaimsService.Domain.Exceptions;

namespace ClaimsService.Domain.Entities;

public sealed class ClaimReview : AggregateRoot
{
    public Guid ClaimId { get; private set; }
    public Guid ReviewerUserId { get; private set; }
    public ClaimReviewDecision? Decision { get; private set; }
    public string? Notes { get; private set; }
    public DateTime? ReviewedAt { get; private set; }

    private ClaimReview() { }

    public static ClaimReview Start(Guid claimId, Guid reviewerUserId, DateTime at, string actor)
    {
        DomainGuard.NonEmpty(claimId, nameof(claimId));
        DomainGuard.NonEmpty(reviewerUserId, nameof(reviewerUserId));
        return new ClaimReview
        {
            Id = Guid.NewGuid(),
            ClaimId = claimId,
            ReviewerUserId = reviewerUserId,
            CreatedAt = DomainGuard.Utc(at, nameof(at)),
            CreatedBy = DomainGuard.Required(actor, nameof(actor), 200),
        };
    }

    public void Complete(ClaimReviewDecision decision, string notes, DateTime at, string actor)
    {
        if (Decision.HasValue)
            throw new DomainRuleException("Claim review is already completed.");
        Decision = decision;
        Notes = DomainGuard.Required(notes, nameof(notes), 1000);
        ReviewedAt = DomainGuard.Utc(at, nameof(at));
        MarkUpdated(at, actor);
    }
}


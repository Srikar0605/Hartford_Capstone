using ClaimsService.Domain.Common;
using ClaimsService.Domain.Enums;

namespace ClaimsService.Domain.Entities;

public sealed class ClaimTimeline
{
    public Guid Id { get; private set; }
    public Guid ClaimId { get; private set; }
    public ClaimStatus? FromStatus { get; private set; }
    public ClaimStatus ToStatus { get; private set; }
    public string Notes { get; private set; } = string.Empty;
    public DateTime ChangedAt { get; private set; }
    public string ChangedBy { get; private set; } = string.Empty;
    public string CorrelationId { get; private set; } = string.Empty;

    private ClaimTimeline() { }

    public static ClaimTimeline Create(
        Guid claimId,
        ClaimStatus? from,
        ClaimStatus to,
        string notes,
        DateTime at,
        string actor,
        string correlationId
    )
    {
        DomainGuard.NonEmpty(claimId, nameof(claimId));
        return new ClaimTimeline
        {
            Id = Guid.NewGuid(),
            ClaimId = claimId,
            FromStatus = from,
            ToStatus = to,
            Notes = DomainGuard.Required(notes, nameof(notes), 1000),
            ChangedAt = DomainGuard.Utc(at, nameof(at)),
            ChangedBy = DomainGuard.Required(actor, nameof(actor), 200),
            CorrelationId = DomainGuard.Required(correlationId, nameof(correlationId), 100),
        };
    }
}


using ClaimsService.Domain.Common;
using ClaimsService.Domain.Enums;
using ClaimsService.Domain.Exceptions;

namespace ClaimsService.Domain.Entities;

/// <summary>
/// Aggregate root representing an insurance loss claim.
/// I modeled this entity around an explicit lifecycle:
/// Submitted -> UnderReview -> Approved / Rejected -> PaymentInitiated -> Closed.
/// At the moment of FNOL submission, we capture snapshots of CustomerDisplayName, CustomerEmail,
/// and PolicyNumber directly on the claim. This intentionally decouples historical claim records
/// from subsequent customer profile name changes or policy updates.
/// </summary>
public sealed class Claim : AggregateRoot
{
    public string ClaimNumber { get; private set; } = string.Empty;
    public Guid AuthUserId { get; private set; }
    public Guid CustomerId { get; private set; }
    public Guid PolicyId { get; private set; }
    public Guid CoverageTypeId { get; private set; }
    public string CoverageTypeName { get; private set; } = string.Empty;
    public ClaimStatus Status { get; private set; }
    public decimal ClaimAmount { get; private set; }
    public DateOnly IncidentDate { get; private set; }
    public string IncidentDescription { get; private set; } = string.Empty;
    public Guid? SettlementTransactionId { get; private set; }
    public string CustomerDisplayName { get; private set; } = string.Empty;
    public string CustomerEmail { get; private set; } = string.Empty;
    public string PolicyNumber { get; private set; } = string.Empty;
    public AiClaimTriage? AiTriage { get; private set; }

    public decimal? AssessedAmount { get; private set; }
    public decimal? ApprovedAmount { get; private set; }
    public decimal? DeductibleApplied { get; private set; }
    public string? AdjustmentReason { get; private set; }

    private Claim() { }

    /// <summary>
    /// Factory for creating and validating a new customer loss claim.
    /// </summary>
    public static Claim Submit(
        string claimNumber,
        Guid authUserId,
        Guid customerId,
        string customerDisplayName,
        string customerEmail,
        Guid policyId,
        string policyNumber,
        Guid coverageTypeId,
        string coverageTypeName,
        decimal claimAmount,
        DateOnly incidentDate,
        string incidentDescription,
        DateTime createdAt,
        string createdBy
    )
    {
        // 1. Run structurally disconnected validations first
        DomainGuard.NonEmpty(authUserId, nameof(authUserId));
        DomainGuard.NonEmpty(customerId, nameof(customerId));
        DomainGuard.NonEmpty(policyId, nameof(policyId));
        DomainGuard.NonEmpty(coverageTypeId, nameof(coverageTypeId));

        if (claimAmount <= 0m)
        {
            throw new DomainRuleException("Claim amount must be greater than zero.");
        }

        // 2. Map and return the initialized Claim instance
        return new Claim
        {
            Id = Guid.NewGuid(),
            ClaimNumber = DomainGuard.Required(claimNumber, nameof(claimNumber), 50),
            AuthUserId = authUserId,
            CustomerId = customerId,
            CustomerDisplayName = DomainGuard.Required(
                customerDisplayName,
                nameof(customerDisplayName),
                200
            ),
            CustomerEmail = DomainGuard.Required(customerEmail, nameof(customerEmail), 320),
            PolicyId = policyId,
            PolicyNumber = DomainGuard.Required(policyNumber, nameof(policyNumber), 50),
            CoverageTypeId = coverageTypeId,
            CoverageTypeName = DomainGuard.Required(
                coverageTypeName,
                nameof(coverageTypeName),
                150
            ),
            Status = ClaimStatus.Submitted,
            ClaimAmount = claimAmount,
            IncidentDate = incidentDate,
            IncidentDescription = DomainGuard.Required(
                incidentDescription,
                nameof(incidentDescription),
                2000
            ),
            CreatedAt = DomainGuard.Utc(createdAt, nameof(createdAt)),
            CreatedBy = DomainGuard.Required(createdBy, nameof(createdBy), 200),
        };
    }


    public void StartReview(DateTime at, string actor) =>
        Transition(ClaimStatus.Submitted, ClaimStatus.UnderReview, at, actor);

    public void AutoApprove(DateTime at, string actor) =>
        Transition(ClaimStatus.Submitted, ClaimStatus.Approved, at, actor);

    public void Approve(DateTime at, string actor) =>
        Approve(ClaimAmount, ClaimAmount, 0m, null, at, actor);

    public void Approve(
        decimal assessedAmount,
        decimal approvedAmount,
        decimal deductibleApplied,
        string? adjustmentReason,
        DateTime at,
        string actor
    )
    {
        if (assessedAmount < 0m)
            throw new ArgumentOutOfRangeException(nameof(assessedAmount), "Assessed amount cannot be negative.");
        if (approvedAmount < 0m)
            throw new ArgumentOutOfRangeException(nameof(approvedAmount), "Approved amount cannot be negative.");
        if (deductibleApplied < 0m)
            throw new ArgumentOutOfRangeException(nameof(deductibleApplied), "Deductible applied cannot be negative.");

        AssessedAmount = assessedAmount;
        ApprovedAmount = approvedAmount;
        DeductibleApplied = deductibleApplied;
        AdjustmentReason = adjustmentReason;

        Transition(ClaimStatus.UnderReview, ClaimStatus.Approved, at, actor);
    }

    public void Reject(DateTime at, string actor) =>
        Transition(ClaimStatus.UnderReview, ClaimStatus.Rejected, at, actor);

    public void MarkPaymentInitiated(Guid transactionId, DateTime at, string actor)
    {
        DomainGuard.NonEmpty(transactionId, nameof(transactionId));
        if (SettlementTransactionId.HasValue && SettlementTransactionId != transactionId)
            throw new DomainRuleException(
                "A different settlement transaction is already assigned."
            );
        if (Status == ClaimStatus.PaymentInitiated && SettlementTransactionId == transactionId)
            return;
        Transition(ClaimStatus.Approved, ClaimStatus.PaymentInitiated, at, actor);
        SettlementTransactionId = transactionId;
    }

    public void ConfirmSettlement(Guid transactionId, DateTime at, string actor)
    {
        DomainGuard.NonEmpty(transactionId, nameof(transactionId));
        if (Status == ClaimStatus.Closed && SettlementTransactionId == transactionId)
            return;
        if (Status != ClaimStatus.PaymentInitiated || SettlementTransactionId != transactionId)
            throw new DomainRuleException(
                "Settlement confirmation does not match the initiated transaction."
            );
        Transition(ClaimStatus.PaymentInitiated, ClaimStatus.Closed, at, actor);
    }

    public void RecordActivity(DateTime at, string actor)
    {
        MarkUpdated(at, actor);
    }

    private void Transition(ClaimStatus expected, ClaimStatus target, DateTime at, string actor)
    {
        if (Status != expected)
            throw new DomainRuleException($"Claim cannot transition from {Status} to {target}.");
        Status = target;
        MarkUpdated(at, actor);
    }
}


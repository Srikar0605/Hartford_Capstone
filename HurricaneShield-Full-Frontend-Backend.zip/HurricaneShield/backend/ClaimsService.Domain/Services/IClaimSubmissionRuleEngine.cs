using ClaimsService.Domain.Models;

namespace ClaimsService.Domain.Services;

public interface IClaimSubmissionRuleEngine
{
    void Validate(ClaimSubmissionInput input);
}


using ClaimsService.Domain.Exceptions;
using ClaimsService.Domain.Models;

namespace ClaimsService.Domain.Services;

public sealed class ClaimSubmissionRuleEngine : IClaimSubmissionRuleEngine
{
    public void Validate(ClaimSubmissionInput input)
    {
        // Guard against negative or zero payouts before doing any processing.
        if (input.ClaimAmount <= 0m)
            throw new DomainRuleException("Claim amount must be greater than zero.");

        // A customer cannot file a claim for an event that hasn't happened yet.
        if (input.IncidentDate > input.SubmissionDate)
            throw new DomainRuleException("Incident date cannot be in the future.");

        // We enforce a strict 90-day reporting window from the date of the storm.
        // Stale claims are notoriously difficult to adjust and carry significantly higher fraud rates.
        if (input.SubmissionDate.DayNumber - input.IncidentDate.DayNumber > 90)
            throw new DomainRuleException("Claim submission window exceeded.");
    }
}


using AuthService.Domain.Common;

namespace AuthService.Domain.Entities;

public sealed class Permission : Entity
{
    private readonly List<RolePermission> _rolePermissions = [];

    private Permission() { }

    private Permission(Guid permissionId, string name, string description)
        : base(permissionId)
    {
        Name = name;
        Description = description;
    }

    public string Name { get; private set; } = string.Empty;

    public string Description { get; private set; } = string.Empty;

    public IReadOnlyCollection<RolePermission> RolePermissions => _rolePermissions.AsReadOnly();

    public static Permission Create(string name, string description)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(name);
        ArgumentException.ThrowIfNullOrWhiteSpace(description);

        return new Permission(Guid.NewGuid(), name.Trim(), description.Trim());
    }
}


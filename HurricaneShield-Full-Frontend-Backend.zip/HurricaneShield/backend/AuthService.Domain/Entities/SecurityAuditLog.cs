using AuthService.Domain.Common;
using AuthService.Domain.Constants;

namespace AuthService.Domain.Entities;

public sealed class SecurityAuditLog : Entity
{
    private SecurityAuditLog() { }

    private SecurityAuditLog(
        Guid securityAuditLogId,
        string eventType,
        string outcome,
        string actorType,
        Guid? actorUserId,
        Guid? targetUserId,
        string description,
        string? changeData,
        string correlationId,
        string? ipAddress,
        string? userAgent,
        DateTime occurredAt
    )
        : base(securityAuditLogId)
    {
        EventType = eventType;
        Outcome = outcome;
        ActorType = actorType;
        ActorUserId = actorUserId;
        TargetUserId = targetUserId;
        Description = description;
        ChangeData = changeData;
        CorrelationId = correlationId;
        IpAddress = ipAddress;
        UserAgent = userAgent;
        OccurredAt = occurredAt;
    }

    public string EventType { get; private set; } = string.Empty;

    public string Outcome { get; private set; } = string.Empty;

    public string ActorType { get; private set; } = string.Empty;

    public Guid? ActorUserId { get; private set; }

    public Guid? TargetUserId { get; private set; }

    public string Description { get; private set; } = string.Empty;

    public string? ChangeData { get; private set; }

    public string CorrelationId { get; private set; } = string.Empty;

    public string? IpAddress { get; private set; }

    public string? UserAgent { get; private set; }

    public DateTime OccurredAt { get; private set; }

    public static SecurityAuditLog Create(
        string eventType,
        string outcome,
        string actorType,
        Guid? actorUserId,
        Guid? targetUserId,
        string description,
        string? changeData,
        string correlationId,
        string? ipAddress,
        string? userAgent,
        DateTime occurredAt
    )
    {
        if (!SecurityAuditEventTypes.IsValid(eventType))
        {
            throw new ArgumentException(
                "The security audit event type is invalid.",
                nameof(eventType)
            );
        }

        if (!SecurityAuditOutcomes.IsValid(outcome))
        {
            throw new ArgumentException("The security audit outcome is invalid.", nameof(outcome));
        }

        if (!SecurityAuditActorTypes.IsValid(actorType))
        {
            throw new ArgumentException(
                "The security audit actor type is invalid.",
                nameof(actorType)
            );
        }

        if (actorType == SecurityAuditActorTypes.User && !actorUserId.HasValue)
        {
            throw new ArgumentException(
                "A user actor requires an actor user ID.",
                nameof(actorUserId)
            );
        }

        ArgumentException.ThrowIfNullOrWhiteSpace(description);

        ArgumentException.ThrowIfNullOrWhiteSpace(correlationId);

        return new SecurityAuditLog(
            Guid.NewGuid(),
            eventType,
            outcome,
            actorType,
            actorUserId,
            targetUserId,
            description.Trim(),
            NormalizeOptionalValue(changeData),
            correlationId.Trim(),
            NormalizeOptionalValue(ipAddress),
            NormalizeOptionalValue(userAgent),
            occurredAt
        );
    }

    private static string? NormalizeOptionalValue(string? value)
    {
        return string.IsNullOrWhiteSpace(value) ? null : value.Trim();
    }
}


using AuthService.Domain.Common;

namespace AuthService.Domain.Entities;

public sealed class RefreshToken : Entity
{
    private RefreshToken() { }

    private RefreshToken(
        Guid refreshTokenId,
        Guid userId,
        string tokenHash,
        DateTime expiresAt,
        DateTime createdAt
    )
        : base(refreshTokenId)
    {
        UserId = userId;
        TokenHash = tokenHash;
        ExpiresAt = expiresAt;
        CreatedAt = createdAt;
    }

    public Guid UserId { get; private set; }

    public string TokenHash { get; private set; } = string.Empty;

    public DateTime ExpiresAt { get; private set; }

    public DateTime CreatedAt { get; private set; }

    public DateTime? RevokedAt { get; private set; }

    public Guid? ReplacedByTokenId { get; private set; }

    public User User { get; private set; } = null!;

    public RefreshToken? ReplacedByToken { get; private set; }

    public bool IsExpired(DateTime utcNow)
    {
        return ExpiresAt <= utcNow;
    }

    public bool IsRevoked()
    {
        return RevokedAt.HasValue;
    }

    public bool IsActive(DateTime utcNow)
    {
        return !IsRevoked() && !IsExpired(utcNow);
    }

    public static RefreshToken Create(
        Guid userId,
        string tokenHash,
        DateTime expiresAt,
        DateTime createdAt
    )
    {
        if (userId == Guid.Empty)
        {
            throw new ArgumentException("User ID cannot be empty.", nameof(userId));
        }

        ArgumentException.ThrowIfNullOrWhiteSpace(tokenHash);

        if (expiresAt <= createdAt)
        {
            throw new ArgumentException(
                "Refresh-token expiration must be later than creation.",
                nameof(expiresAt)
            );
        }

        return new RefreshToken(Guid.NewGuid(), userId, tokenHash, expiresAt, createdAt);
    }

    public void Revoke(DateTime revokedAt, Guid? replacedByTokenId = null)
    {
        if (RevokedAt.HasValue)
        {
            return;
        }

        if (replacedByTokenId == Id)
        {
            throw new ArgumentException(
                "A refresh token cannot replace itself.",
                nameof(replacedByTokenId)
            );
        }

        RevokedAt = revokedAt;
        ReplacedByTokenId = replacedByTokenId;
    }
}


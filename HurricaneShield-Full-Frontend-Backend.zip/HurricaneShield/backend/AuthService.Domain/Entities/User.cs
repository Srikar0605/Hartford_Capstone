using AuthService.Domain.Common;

namespace AuthService.Domain.Entities;

/// <summary>
/// Aggregate root representing an authenticated user account.
/// I encapsulated all security-critical collections (roles, refresh tokens, MFA state, password history)
/// within private backing fields so all authentication side effects (such as failed attempt tracking,
/// account lockouts, and token rotation) must occur through explicit domain methods.
/// </summary>
public sealed class User : AuditableEntity
{
    private readonly List<UserRole> _userRoles = [];
    private readonly List<RefreshToken> _refreshTokens = [];
    private readonly List<RecoveryCode> _recoveryCodes = [];
    private readonly List<PasswordHistory> _passwordHistories = [];
    private readonly List<PasswordResetToken> _passwordResetTokens = [];
    private readonly List<LoginActivity> _loginActivities = [];

    private User() { }

    private User(
        Guid userId,
        string email,
        string passwordHash,
        string firstName,
        string lastName,
        DateTime createdAt,
        string createdBy
    )
        : base(userId)
    {
        Email = email;
        PasswordHash = passwordHash;
        FirstName = firstName;
        LastName = lastName;
        IsActive = true;
        FailedLoginAttempts = 0;
        CreatedAt = createdAt;
        CreatedBy = createdBy;
    }


    public string Email { get; private set; } = string.Empty;

    public string PasswordHash { get; private set; } = string.Empty;

    public string FirstName { get; private set; } = string.Empty;

    public string LastName { get; private set; } = string.Empty;

    public bool IsActive { get; private set; }

    public int FailedLoginAttempts { get; private set; }

    public DateTime? LockoutEnd { get; private set; }

    public UserMfa? Mfa { get; private set; }

    public IReadOnlyCollection<UserRole> UserRoles => _userRoles.AsReadOnly();

    public IReadOnlyCollection<RefreshToken> RefreshTokens => _refreshTokens.AsReadOnly();

    public IReadOnlyCollection<RecoveryCode> RecoveryCodes => _recoveryCodes.AsReadOnly();

    public IReadOnlyCollection<PasswordHistory> PasswordHistories =>
        _passwordHistories.AsReadOnly();

    public IReadOnlyCollection<PasswordResetToken> PasswordResetTokens =>
        _passwordResetTokens.AsReadOnly();

    public IReadOnlyCollection<LoginActivity> LoginActivities => _loginActivities.AsReadOnly();

    public static User Create(
        string email,
        string passwordHash,
        string firstName,
        string lastName,
        DateTime createdAt,
        string createdBy
    )
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(email);
        ArgumentException.ThrowIfNullOrWhiteSpace(passwordHash);
        ArgumentException.ThrowIfNullOrWhiteSpace(firstName);
        ArgumentException.ThrowIfNullOrWhiteSpace(lastName);
        ArgumentException.ThrowIfNullOrWhiteSpace(createdBy);

        return new User(
            Guid.NewGuid(),
            email.Trim().ToLowerInvariant(),
            passwordHash,
            firstName.Trim(),
            lastName.Trim(),
            createdAt,
            createdBy
        );
    }

    public bool IsLocked(DateTime utcNow)
    {
        return LockoutEnd.HasValue && LockoutEnd.Value > utcNow;
    }

    public void RecordFailedLogin(
        DateTime utcNow,
        int maximumFailedAttempts,
        TimeSpan lockoutDuration
    )
    {
        FailedLoginAttempts++;

        if (FailedLoginAttempts >= maximumFailedAttempts)
        {
            LockoutEnd = utcNow.Add(lockoutDuration);
        }
    }

    public void RecordSuccessfulLogin()
    {
        FailedLoginAttempts = 0;
        LockoutEnd = null;
    }

    public void Deactivate(DateTime utcNow, string modifiedBy)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(modifiedBy);

        IsActive = false;
        UpdatedAt = utcNow;
        UpdatedBy = modifiedBy;
    }

    public void Activate(DateTime utcNow, string modifiedBy)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(modifiedBy);

        IsActive = true;
        UpdatedAt = utcNow;
        UpdatedBy = modifiedBy;
    }

    public void ChangePasswordHash(string newPasswordHash, DateTime utcNow, string modifiedBy)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(newPasswordHash);
        ArgumentException.ThrowIfNullOrWhiteSpace(modifiedBy);

        PasswordHash = newPasswordHash;
        UpdatedAt = utcNow;
        UpdatedBy = modifiedBy;
    }

    public void SoftDelete(DateTime utcNow, string deletedBy)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(deletedBy);

        IsActive = false;
        IsDeleted = true;
        DeletedAt = utcNow;
        DeletedBy = deletedBy;
        UpdatedAt = utcNow;
        UpdatedBy = deletedBy;
    }

    public void SetMfa(UserMfa mfa)
    {
        Mfa = mfa;
    }
}


using AuthService.Domain.Common;

namespace AuthService.Domain.Entities;

public sealed class PasswordResetToken : Entity
{
    private PasswordResetToken() { }

    private PasswordResetToken(
        Guid passwordResetTokenId,
        Guid userId,
        string tokenHash,
        DateTime expiresAt,
        DateTime createdAt,
        string createdBy
    )
        : base(passwordResetTokenId)
    {
        UserId = userId;
        TokenHash = tokenHash;
        ExpiresAt = expiresAt;
        CreatedAt = createdAt;
        CreatedBy = createdBy;
    }

    public Guid UserId { get; private set; }

    public string TokenHash { get; private set; } = string.Empty;

    public DateTime ExpiresAt { get; private set; }

    public DateTime? UsedAt { get; private set; }

    public DateTime? RevokedAt { get; private set; }

    public DateTime CreatedAt { get; private set; }

    public string CreatedBy { get; private set; } = string.Empty;

    public User User { get; private set; } = null!;

    public bool IsValid(DateTime utcNow)
    {
        return !UsedAt.HasValue && !RevokedAt.HasValue && ExpiresAt > utcNow;
    }

    public static PasswordResetToken Create(
        Guid userId,
        string tokenHash,
        DateTime expiresAt,
        DateTime createdAt,
        string createdBy
    )
    {
        if (userId == Guid.Empty)
        {
            throw new ArgumentException("User ID cannot be empty.", nameof(userId));
        }

        ArgumentException.ThrowIfNullOrWhiteSpace(tokenHash);
        ArgumentException.ThrowIfNullOrWhiteSpace(createdBy);

        if (expiresAt <= createdAt)
        {
            throw new ArgumentException(
                "Reset-token expiration must be later than creation.",
                nameof(expiresAt)
            );
        }

        return new PasswordResetToken(
            Guid.NewGuid(),
            userId,
            tokenHash,
            expiresAt,
            createdAt,
            createdBy
        );
    }

    public void MarkAsUsed(DateTime usedAt)
    {
        if (UsedAt.HasValue)
        {
            throw new InvalidOperationException("Password reset token has already been used.");
        }

        if (RevokedAt.HasValue)
        {
            throw new InvalidOperationException("A revoked password reset token cannot be used.");
        }

        UsedAt = usedAt;
    }

    public void Revoke(DateTime revokedAt)
    {
        if (!UsedAt.HasValue && !RevokedAt.HasValue)
        {
            RevokedAt = revokedAt;
        }
    }
}


using AuthService.Domain.Common;

namespace AuthService.Domain.Entities;

public sealed class LoginActivity : Entity
{
    private LoginActivity() { }

    private LoginActivity(
        Guid loginActivityId,
        Guid userId,
        string ipAddress,
        bool isSuccessful,
        DateTime occurredAt
    )
        : base(loginActivityId)
    {
        UserId = userId;
        IpAddress = ipAddress;
        IsSuccessful = isSuccessful;
        OccurredAt = occurredAt;
    }

    public Guid UserId { get; private set; }

    public string IpAddress { get; private set; } = string.Empty;

    public bool IsSuccessful { get; private set; }

    public DateTime OccurredAt { get; private set; }

    public User User { get; private set; } = null!;

    public static LoginActivity Create(
        Guid userId,
        string ipAddress,
        bool isSuccessful,
        DateTime occurredAt
    )
    {
        if (userId == Guid.Empty)
        {
            throw new ArgumentException("User ID cannot be empty.", nameof(userId));
        }

        ArgumentException.ThrowIfNullOrWhiteSpace(ipAddress);

        return new LoginActivity(
            Guid.NewGuid(),
            userId,
            ipAddress.Trim(),
            isSuccessful,
            occurredAt
        );
    }
}


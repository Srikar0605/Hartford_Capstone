using AuthService.Domain.Common;

namespace AuthService.Domain.Entities;

public sealed class RecoveryCode : Entity
{
    private RecoveryCode() { }

    private RecoveryCode(Guid recoveryCodeId, Guid userId, string codeHash, DateTime createdAt)
        : base(recoveryCodeId)
    {
        UserId = userId;
        CodeHash = codeHash;
        CreatedAt = createdAt;
    }

    public Guid UserId { get; private set; }

    public string CodeHash { get; private set; } = string.Empty;

    public DateTime? UsedAt { get; private set; }

    public DateTime CreatedAt { get; private set; }

    public User User { get; private set; } = null!;

    public bool IsUsed()
    {
        return UsedAt.HasValue;
    }

    public static RecoveryCode Create(Guid userId, string codeHash, DateTime createdAt)
    {
        if (userId == Guid.Empty)
        {
            throw new ArgumentException("User ID cannot be empty.", nameof(userId));
        }

        ArgumentException.ThrowIfNullOrWhiteSpace(codeHash);

        return new RecoveryCode(Guid.NewGuid(), userId, codeHash, createdAt);
    }

    public void MarkAsUsed(DateTime usedAt)
    {
        if (UsedAt.HasValue)
        {
            throw new InvalidOperationException("Recovery code has already been used.");
        }

        UsedAt = usedAt;
    }
}


using AuthService.Domain.Common;

namespace AuthService.Domain.Entities;

public sealed class RolePermission : Entity
{
    private RolePermission() { }

    private RolePermission(
        Guid rolePermissionId,
        Guid roleId,
        Guid permissionId,
        DateTime createdAt,
        string createdBy
    )
        : base(rolePermissionId)
    {
        RoleId = roleId;
        PermissionId = permissionId;
        CreatedAt = createdAt;
        CreatedBy = createdBy;
    }

    public Guid RoleId { get; private set; }

    public Guid PermissionId { get; private set; }

    public DateTime CreatedAt { get; private set; }

    public string CreatedBy { get; private set; } = string.Empty;

    public Role Role { get; private set; } = null!;

    public Permission Permission { get; private set; } = null!;

    public static RolePermission Create(
        Guid roleId,
        Guid permissionId,
        DateTime createdAt,
        string createdBy
    )
    {
        if (roleId == Guid.Empty)
        {
            throw new ArgumentException("Role ID cannot be empty.", nameof(roleId));
        }

        if (permissionId == Guid.Empty)
        {
            throw new ArgumentException("Permission ID cannot be empty.", nameof(permissionId));
        }

        ArgumentException.ThrowIfNullOrWhiteSpace(createdBy);

        return new RolePermission(Guid.NewGuid(), roleId, permissionId, createdAt, createdBy);
    }
}


using AuthService.Domain.Common;

namespace AuthService.Domain.Entities;

public sealed class PasswordHistory : Entity
{
    private PasswordHistory() { }

    private PasswordHistory(
        Guid passwordHistoryId,
        Guid userId,
        string passwordHash,
        DateTime createdAt
    )
        : base(passwordHistoryId)
    {
        UserId = userId;
        PasswordHash = passwordHash;
        CreatedAt = createdAt;
    }

    public Guid UserId { get; private set; }

    public string PasswordHash { get; private set; } = string.Empty;

    public DateTime CreatedAt { get; private set; }

    public User User { get; private set; } = null!;

    public static PasswordHistory Create(Guid userId, string passwordHash, DateTime createdAt)
    {
        if (userId == Guid.Empty)
        {
            throw new ArgumentException("User ID cannot be empty.", nameof(userId));
        }

        ArgumentException.ThrowIfNullOrWhiteSpace(passwordHash);

        return new PasswordHistory(Guid.NewGuid(), userId, passwordHash, createdAt);
    }
}


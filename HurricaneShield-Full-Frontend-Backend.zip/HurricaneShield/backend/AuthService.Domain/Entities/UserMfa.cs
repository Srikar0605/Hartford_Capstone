using AuthService.Domain.Common;

namespace AuthService.Domain.Entities;

public sealed class UserMfa : Entity
{
    private UserMfa() { }

    private UserMfa(Guid userMfaId, Guid userId, string encryptedSecretKey)
        : base(userMfaId)
    {
        UserId = userId;
        EncryptedSecretKey = encryptedSecretKey;
        IsEnabled = false;
    }

    public Guid UserId { get; private set; }

    public string EncryptedSecretKey { get; private set; } = string.Empty;

    public bool IsEnabled { get; private set; }

    public DateTime? VerifiedAt { get; private set; }

    public User User { get; private set; } = null!;

    public static UserMfa CreatePending(Guid userId, string encryptedSecretKey)
    {
        if (userId == Guid.Empty)
        {
            throw new ArgumentException("User ID cannot be empty.", nameof(userId));
        }

        ArgumentException.ThrowIfNullOrWhiteSpace(encryptedSecretKey);

        return new UserMfa(Guid.NewGuid(), userId, encryptedSecretKey);
    }

    public void Enable(DateTime verifiedAt)
    {
        if (IsEnabled)
        {
            return;
        }

        IsEnabled = true;
        VerifiedAt = verifiedAt;
    }

    public void Disable()
    {
        IsEnabled = false;
        VerifiedAt = null;
    }

    public void ReplaceSecret(string encryptedSecretKey)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(encryptedSecretKey);

        EncryptedSecretKey = encryptedSecretKey;
        IsEnabled = false;
        VerifiedAt = null;
    }
}


using AuthService.Domain.Common;

namespace AuthService.Domain.Entities;

public sealed class UserRole : Entity
{
    private UserRole() { }

    private UserRole(Guid userRoleId, Guid userId, Guid roleId)
        : base(userRoleId)
    {
        UserId = userId;
        RoleId = roleId;
    }

    public Guid UserId { get; private set; }

    public Guid RoleId { get; private set; }

    public User User { get; private set; } = null!;

    public Role Role { get; private set; } = null!;

    public static UserRole Create(Guid userId, Guid roleId)
    {
        if (userId == Guid.Empty)
        {
            throw new ArgumentException("User ID cannot be empty.", nameof(userId));
        }

        if (roleId == Guid.Empty)
        {
            throw new ArgumentException("Role ID cannot be empty.", nameof(roleId));
        }

        return new UserRole(Guid.NewGuid(), userId, roleId);
    }
}


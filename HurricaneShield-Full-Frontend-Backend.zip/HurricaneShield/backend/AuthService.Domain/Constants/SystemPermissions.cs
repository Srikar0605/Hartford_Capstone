namespace AuthService.Domain.Constants;

public static class SystemPermissions
{
    public const string ManageProfile = "Manage Profile";

    public const string PurchasePolicy = "Purchase Policy";

    public const string RenewPolicy = "Renew Policy";

    public const string CancelPolicy = "Cancel Policy";

    public const string SubmitClaims = "Submit Claims";

    public const string ViewPayments = "View Payments";

    public const string ReviewPolicies = "Review Policies";

    public const string ReviewUnderwritingRequests = "Review Underwriting Requests";

    public const string ApprovePolicies = "Approve Policies";

    public const string RejectPolicies = "Reject Policies";

    public const string ReviewClaims = "Review Claims";

    public const string ApproveClaims = "Approve Claims";

    public const string RejectClaims = "Reject Claims";

    public const string VerifyDocuments = "Verify Documents";

    public const string InitiateSettlement = "Initiate Settlement";

    public const string ConfirmClaimSettlements = "Confirm Claim Settlements";

    public const string ManageUsers = "Manage Users";

    public const string ManageRoles = "Manage Roles";

    public const string ManagePlans = "Manage Plans";

    public const string ManagePolicies = "Manage Policies";

    public const string AccessReports = "Access Reports";

    public const string PerformAgentFunctions = "Perform Agent Functions";

    public const string PerformClaimsManagerFunctions = "Perform Claims Manager Functions";
}


namespace AuthService.Domain.Constants;

public static class SecurityAuditEventTypes
{
    public const string UserRegistered = "UserRegistered";

    public const string LoginSucceeded = "LoginSucceeded";

    public const string LoginFailed = "LoginFailed";

    public const string AccountLocked = "AccountLocked";

    public const string PasswordChanged = "PasswordChanged";

    public const string PasswordResetRequested = "PasswordResetRequested";

    public const string PasswordResetCompleted = "PasswordResetCompleted";

    public const string RefreshTokenIssued = "RefreshTokenIssued";

    public const string RefreshTokenRotated = "RefreshTokenRotated";

    public const string RefreshTokenRevoked = "RefreshTokenRevoked";

    public const string RefreshTokenReuseDetected = "RefreshTokenReuseDetected";

    public const string MfaEnrollmentStarted = "MfaEnrollmentStarted";

    public const string MfaEnabled = "MfaEnabled";

    public const string MfaDisabled = "MfaDisabled";

    public const string RecoveryCodeUsed = "RecoveryCodeUsed";

    public const string RoleAssigned = "RoleAssigned";

    public const string RoleRemoved = "RoleRemoved";

    public const string UserActivated = "UserActivated";

    public const string UserDeactivated = "UserDeactivated";

    public const string UserSoftDeleted = "UserSoftDeleted";

    public const string AuthorizationDenied = "AuthorizationDenied";

    public const string AdministratorBootstrapped = "AdministratorBootstrapped";

    public static readonly IReadOnlySet<string> All = new HashSet<string>(StringComparer.Ordinal)
    {
        UserRegistered,
        LoginSucceeded,
        LoginFailed,
        AccountLocked,
        PasswordChanged,
        PasswordResetRequested,
        PasswordResetCompleted,
        RefreshTokenIssued,
        RefreshTokenRotated,
        RefreshTokenRevoked,
        RefreshTokenReuseDetected,
        MfaEnrollmentStarted,
        MfaEnabled,
        MfaDisabled,
        RecoveryCodeUsed,
        RoleAssigned,
        RoleRemoved,
        UserActivated,
        UserDeactivated,
        UserSoftDeleted,
        AuthorizationDenied,
        AdministratorBootstrapped,
    };

    public static bool IsValid(string eventType)
    {
        return !string.IsNullOrWhiteSpace(eventType) && All.Contains(eventType);
    }
}


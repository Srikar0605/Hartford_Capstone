namespace AuthService.Domain.Constants;

public static class SystemRoles
{
    public const string Customer = "Customer";
    public const string Agent = "Agent";
    public const string ClaimsManager = "Claims Manager";
    public const string Administrator = "Administrator";

    public static readonly IReadOnlyCollection<string> All =
    [
        Customer,
        Agent,
        ClaimsManager,
        Administrator,
    ];
}


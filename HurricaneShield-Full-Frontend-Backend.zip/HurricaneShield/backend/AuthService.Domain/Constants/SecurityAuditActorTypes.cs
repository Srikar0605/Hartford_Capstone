namespace AuthService.Domain.Constants;

public static class SecurityAuditActorTypes
{
    public const string User = "User";
    public const string Anonymous = "Anonymous";
    public const string System = "System";
    public const string Bootstrap = "Bootstrap";

    public static readonly IReadOnlySet<string> All = new HashSet<string>(StringComparer.Ordinal)
    {
        User,
        Anonymous,
        System,
        Bootstrap,
    };

    public static bool IsValid(string actorType)
    {
        return !string.IsNullOrWhiteSpace(actorType) && All.Contains(actorType);
    }
}


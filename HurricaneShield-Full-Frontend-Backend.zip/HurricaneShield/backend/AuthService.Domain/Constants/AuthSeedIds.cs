namespace AuthService.Domain.Constants;

public static class AuthSeedIds
{
    public static class Roles
    {
        public static readonly Guid Customer = Guid.Parse("10000000-0000-0000-0000-000000000001");

        public static readonly Guid Agent = Guid.Parse("10000000-0000-0000-0000-000000000002");

        public static readonly Guid ClaimsManager = Guid.Parse(
            "10000000-0000-0000-0000-000000000003"
        );

        public static readonly Guid Administrator = Guid.Parse(
            "10000000-0000-0000-0000-000000000004"
        );
    }

    public static class Permissions
    {
        public static readonly Guid ManageProfile = Guid.Parse(
            "20000000-0000-0000-0000-000000000001"
        );

        public static readonly Guid PurchasePolicy = Guid.Parse(
            "20000000-0000-0000-0000-000000000002"
        );

        public static readonly Guid RenewPolicy = Guid.Parse(
            "20000000-0000-0000-0000-000000000003"
        );

        public static readonly Guid CancelPolicy = Guid.Parse(
            "20000000-0000-0000-0000-000000000004"
        );

        public static readonly Guid SubmitClaims = Guid.Parse(
            "20000000-0000-0000-0000-000000000005"
        );

        public static readonly Guid ViewPayments = Guid.Parse(
            "20000000-0000-0000-0000-000000000006"
        );

        public static readonly Guid ReviewPolicies = Guid.Parse(
            "20000000-0000-0000-0000-000000000007"
        );

        public static readonly Guid ReviewUnderwritingRequests = Guid.Parse(
            "20000000-0000-0000-0000-000000000008"
        );

        public static readonly Guid ApprovePolicies = Guid.Parse(
            "20000000-0000-0000-0000-000000000009"
        );

        public static readonly Guid RejectPolicies = Guid.Parse(
            "20000000-0000-0000-0000-000000000010"
        );

        public static readonly Guid ReviewClaims = Guid.Parse(
            "20000000-0000-0000-0000-000000000011"
        );

        public static readonly Guid ApproveClaims = Guid.Parse(
            "20000000-0000-0000-0000-000000000012"
        );

        public static readonly Guid RejectClaims = Guid.Parse(
            "20000000-0000-0000-0000-000000000013"
        );

        public static readonly Guid VerifyDocuments = Guid.Parse(
            "20000000-0000-0000-0000-000000000014"
        );

        public static readonly Guid InitiateSettlement = Guid.Parse(
            "20000000-0000-0000-0000-000000000015"
        );

        public static readonly Guid ManageUsers = Guid.Parse(
            "20000000-0000-0000-0000-000000000016"
        );

        public static readonly Guid ManageRoles = Guid.Parse(
            "20000000-0000-0000-0000-000000000017"
        );

        public static readonly Guid ManagePlans = Guid.Parse(
            "20000000-0000-0000-0000-000000000018"
        );

        public static readonly Guid ManagePolicies = Guid.Parse(
            "20000000-0000-0000-0000-000000000019"
        );

        public static readonly Guid AccessReports = Guid.Parse(
            "20000000-0000-0000-0000-000000000020"
        );

        public static readonly Guid PerformAgentFunctions = Guid.Parse(
            "20000000-0000-0000-0000-000000000021"
        );

        public static readonly Guid PerformClaimsManagerFunctions = Guid.Parse(
            "20000000-0000-0000-0000-000000000022"
        );
        public static readonly Guid ConfirmClaimSettlements = Guid.Parse(
            "20000000-0000-0000-0000-000000000023"
        );
    }
}


namespace AuthService.Domain.Constants;

public static class SecurityAuditOutcomes
{
    public const string Succeeded = "Succeeded";
    public const string Failed = "Failed";
    public const string Denied = "Denied";

    public static readonly IReadOnlySet<string> All = new HashSet<string>(StringComparer.Ordinal)
    {
        Succeeded,
        Failed,
        Denied,
    };

    public static bool IsValid(string outcome)
    {
        return !string.IsNullOrWhiteSpace(outcome) && All.Contains(outcome);
    }
}


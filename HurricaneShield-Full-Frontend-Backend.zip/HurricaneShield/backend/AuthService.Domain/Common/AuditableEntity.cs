namespace AuthService.Domain.Common;

public abstract class AuditableEntity : Entity
{
    protected AuditableEntity(Guid id)
        : base(id) { }

    protected AuditableEntity() { }

    public DateTime CreatedAt { get; protected set; }

    public string CreatedBy { get; protected set; } = string.Empty;

    public DateTime? UpdatedAt { get; protected set; }

    public string? UpdatedBy { get; protected set; }

    public bool IsDeleted { get; protected set; }

    public DateTime? DeletedAt { get; protected set; }

    public string? DeletedBy { get; protected set; }

    public byte[] RowVersion { get; protected set; } = [];
}


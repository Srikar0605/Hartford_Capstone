using AuthService.Domain.Entities;

namespace AuthService.Domain.Repositories;

public interface IUserRepository
{
    Task<bool> EmailExistsAsync(string email, CancellationToken cancellationToken = default);

    Task<User?> GetByEmailAsync(string email, CancellationToken cancellationToken = default);

    Task<User?> GetByIdAsync(Guid userId, CancellationToken cancellationToken = default);

    Task<User?> GetByIdWithRolesAsync(Guid userId, CancellationToken cancellationToken = default);

    Task<User?> GetByEmailWithAuthenticationDataAsync(
        string email,
        CancellationToken cancellationToken = default
    );

    Task AddAsync(User user, CancellationToken cancellationToken = default);

    Task AddRefreshTokenAsync(
        RefreshToken refreshToken,
        CancellationToken cancellationToken = default
    );

    Task<RefreshToken?> GetRefreshTokenByHashAsync(
        string tokenHash,
        CancellationToken cancellationToken = default
    );

    Task<User?> GetByIdWithMfaAsync(Guid userId, CancellationToken cancellationToken = default);

    Task<User?> GetByEmailWithMfaAndRecoveryCodesAsync(
        string email,
        CancellationToken cancellationToken = default
    );

    Task AddUserMfaAsync(UserMfa userMfa, CancellationToken cancellationToken = default);

    Task AddRecoveryCodesAsync(
        IEnumerable<RecoveryCode> recoveryCodes,
        CancellationToken cancellationToken = default
    );

    Task AddLoginActivityAsync(
        LoginActivity loginActivity,
        CancellationToken cancellationToken = default
    );

    Task<PasswordResetToken?> GetPasswordResetTokenByHashAsync(
        string tokenHash,
        CancellationToken cancellationToken = default
    );

    Task<User?> GetByIdWithPasswordHistoryAsync(
        Guid userId,
        CancellationToken cancellationToken = default
    );

    Task AddPasswordResetTokenAsync(
        PasswordResetToken token,
        CancellationToken cancellationToken = default
    );

    Task AddPasswordHistoryAsync(
        PasswordHistory passwordHistory,
        CancellationToken cancellationToken = default
    );

    Task RevokeActivePasswordResetTokensAsync(
        Guid userId,
        DateTime revokedAt,
        CancellationToken cancellationToken = default
    );

    Task RevokeActiveRefreshTokensAsync(
        Guid userId,
        DateTime revokedAt,
        CancellationToken cancellationToken = default
    );

    Task TrimPasswordHistoryAsync(
        Guid userId,
        int retainedCount,
        CancellationToken cancellationToken = default
    );

    Task<IReadOnlyCollection<LoginActivity>> GetLoginActivityAsync(
        Guid userId,
        CancellationToken cancellationToken = default
    );
}


using AuthService.Domain.Entities;

namespace AuthService.Domain.Repositories;

public interface IRoleRepository
{
    Task<Role?> GetByNameAsync(string roleName, CancellationToken cancellationToken = default);

    Task<Role?> GetByIdAsync(Guid roleId, CancellationToken cancellationToken = default);

    Task<bool> UserHasRoleAsync(
        Guid userId,
        Guid roleId,
        CancellationToken cancellationToken = default
    );

    Task AddUserRoleAsync(UserRole userRole, CancellationToken cancellationToken = default);

    Task<IReadOnlyCollection<string>> GetUserRoleNamesAsync(
        Guid userId,
        CancellationToken cancellationToken = default
    );

    Task<IReadOnlyCollection<UserRole>> GetUserRolesAsync(
        Guid userId,
        CancellationToken cancellationToken = default
    );

    Task<UserRole?> GetUserRoleAsync(
        Guid userId,
        Guid roleId,
        CancellationToken cancellationToken = default
    );

    Task<int> CountUsersInRoleAsync(Guid roleId, CancellationToken cancellationToken = default);

    void RemoveUserRole(UserRole userRole);
}


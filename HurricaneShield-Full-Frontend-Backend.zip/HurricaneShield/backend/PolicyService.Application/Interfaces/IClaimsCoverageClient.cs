using PolicyService.Application.DTOs.Integrations;

namespace PolicyService.Application.Interfaces;

public interface IClaimsCoverageClient
{
    Task<ClaimsCoverageConsumptionResponse> GetConsumedCoverageAsync(
        Guid policyId,
        Guid coverageTypeId,
        CancellationToken cancellationToken
    );

    Task<ClaimHistoryCountResponse> GetClaimHistoryCountAsync(
        IReadOnlyCollection<Guid> policyIds,
        CancellationToken cancellationToken
    );
}


namespace PolicyService.Application.Interfaces;

public interface IDateTimeProvider
{
    DateTime UtcNow { get; }
    DateOnly UtcToday { get; }
}


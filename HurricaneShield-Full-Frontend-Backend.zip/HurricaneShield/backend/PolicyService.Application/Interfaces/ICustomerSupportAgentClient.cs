using PolicyService.Application.DTOs.System;

namespace PolicyService.Application.Interfaces;

public interface ICustomerSupportAgentClient
{
    Task<string> SendMessageAsync(
        IReadOnlyCollection<ChatMessageDto> history,
        string newMessage,
        string? platformContext = null,
        CancellationToken ct = default
    );
}


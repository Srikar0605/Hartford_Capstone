using PolicyService.Application.DTOs.Common;
using PolicyService.Application.DTOs.CoverageTypes;

namespace PolicyService.Application.Interfaces;

public interface ICoverageTypeService
{
    Task<IReadOnlyCollection<CoverageTypeResponse>> GetCoverageTypesAsync(
        bool includeInactive,
        CancellationToken cancellationToken
    );
    Task<CoverageTypeResponse> CreateCoverageTypeAsync(
        CreateCoverageTypeRequest request,
        CancellationToken cancellationToken
    );
    Task<CoverageTypeResponse> UpdateCoverageTypeAsync(
        Guid coverageTypeId,
        UpdateCoverageTypeRequest request,
        CancellationToken cancellationToken
    );
    Task<CoverageTypeResponse> ActivateCoverageTypeAsync(
        Guid coverageTypeId,
        RowVersionRequest request,
        CancellationToken cancellationToken
    );
    Task<CoverageTypeResponse> DeactivateCoverageTypeAsync(
        Guid coverageTypeId,
        RowVersionRequest request,
        CancellationToken cancellationToken
    );
}


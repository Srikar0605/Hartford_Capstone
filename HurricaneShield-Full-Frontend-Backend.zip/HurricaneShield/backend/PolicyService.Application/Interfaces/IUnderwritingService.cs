using PolicyService.Application.DTOs.Common;
using PolicyService.Application.DTOs.Policies;
using PolicyService.Application.DTOs.Underwriting;

namespace PolicyService.Application.Interfaces;

public interface IUnderwritingService
{
    Task<PagedResponse<UnderwritingQueueItemResponse>> GetQueueAsync(
        UnderwritingSearchRequest request,
        CancellationToken cancellationToken
    );
    Task<UnderwritingDetailsResponse> GetReviewDetailsAsync(
        Guid policyId,
        CancellationToken cancellationToken
    );
    Task<PolicyMutationResponse> ApproveAsync(
        Guid policyId,
        ApprovePolicyRequest request,
        CancellationToken cancellationToken
    );
    Task<PolicyMutationResponse> RejectAsync(
        Guid policyId,
        RejectPolicyRequest request,
        CancellationToken cancellationToken
    );
    Task<PolicyMutationResponse> ReviseAsync(
        Guid policyId,
        RevisePolicyRequest request,
        CancellationToken cancellationToken
    );
}


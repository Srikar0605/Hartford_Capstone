namespace PolicyService.Application.Interfaces;

public sealed record RefundIssueRequest(
    Guid PolicyId,
    Guid CustomerId,
    decimal Amount,
    string Reason
);

public sealed record RefundIssueResponse(
    Guid TransactionId,
    Guid PolicyId,
    Guid CustomerId,
    decimal Amount,
    string Status,
    DateTime CreatedAt
);

public interface IPaymentClient
{
    Task<RefundIssueResponse> IssueRefundAsync(
        RefundIssueRequest request,
        string idempotencyKey,
        CancellationToken cancellationToken
    );
}


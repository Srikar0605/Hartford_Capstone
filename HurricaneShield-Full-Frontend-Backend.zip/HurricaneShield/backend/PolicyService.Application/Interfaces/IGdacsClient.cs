namespace PolicyService.Application.Interfaces;

public record GdacsResponse(bool HasActiveAlert);

public interface IGdacsClient
{
    Task<GdacsResponse> GetActiveAlertsAsync(double latitude, double longitude, CancellationToken ct);
}


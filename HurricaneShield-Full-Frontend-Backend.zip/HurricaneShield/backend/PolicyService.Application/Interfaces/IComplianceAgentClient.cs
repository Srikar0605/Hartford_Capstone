using PolicyService.Domain.Models;

namespace PolicyService.Application.Interfaces;

public sealed record ComplianceAgentResponse(
    bool IsCompliant,
    decimal ConfidenceScore,
    string Summary,
    IReadOnlyCollection<string> Violations,
    IReadOnlyCollection<string> MissingDiscounts,
    string RiskAssessment,
    IReadOnlyCollection<string> RecommendedActions,
    IReadOnlyCollection<string> Citations,
    string Engine = AiEngines.RuleBased
);

/// <summary>Which engine produced an AI result, so the UI can label rule-based fallbacks honestly.</summary>
public static class AiEngines
{
    public const string Gemini = "Gemini";
    public const string RuleBased = "RuleBased";
}

public interface IComplianceAgentClient
{
    Task<ComplianceAgentResponse> EvaluatePolicyAsync(
        PropertyRiskInput property,
        decimal requestedCoverage,
        CancellationToken ct
    );
}


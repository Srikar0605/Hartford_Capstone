using PolicyService.Application.DTOs.Common;
using PolicyService.Application.DTOs.Policies;
using PolicyService.Domain.Enums;

namespace PolicyService.Application.Interfaces;

public interface IPolicyService
{
    Task<PolicyApplicationResponse> ApplyAsync(
        CreatePolicyApplicationRequest request,
        string idempotencyKey,
        CancellationToken cancellationToken
    );
    Task<PagedResponse<StaffPolicySummaryResponse>> SearchPoliciesAsync(
        StaffPolicySearchRequest request,
        CancellationToken cancellationToken
    );

    Task<PagedResponse<PolicySummaryResponse>> GetMyPoliciesAsync(
        int page,
        int pageSize,
        PolicyStatus? status,
        CancellationToken cancellationToken
    );

    Task<IReadOnlyCollection<Guid>> GetMyInsuredPropertyIdsAsync(
        CancellationToken cancellationToken
    );
    Task<PolicyDetailsResponse> GetPolicyAsync(Guid policyId, CancellationToken cancellationToken);

    Task<PolicyDetailsResponse> GetStaffPolicyAsync(
        Guid policyId,
        CancellationToken cancellationToken
    );

    Task<IReadOnlyCollection<PolicyVersionResponse>> GetStaffPolicyVersionsAsync(
        Guid policyId,
        CancellationToken cancellationToken
    );

    Task<IReadOnlyCollection<PolicyHistoryResponse>> GetStaffPolicyHistoryAsync(
        Guid policyId,
        CancellationToken cancellationToken
    );
    Task<IReadOnlyCollection<PolicyVersionResponse>> GetPolicyVersionsAsync(
        Guid policyId,
        CancellationToken cancellationToken
    );
    Task<IReadOnlyCollection<PolicyHistoryResponse>> GetPolicyHistoryAsync(
        Guid policyId,
        CancellationToken cancellationToken
    );
    Task<CancellationPreviewResponse> GetCancellationPreviewAsync(
        Guid policyId,
        CancellationToken cancellationToken
    );
    Task<PolicyMutationResponse> CancelAsync(
        Guid policyId,
        PolicyActionRequest request,
        CancellationToken cancellationToken
    );
    Task<PolicyMutationResponse> SuspendAsync(
        Guid policyId,
        PolicyActionRequest request,
        CancellationToken cancellationToken
    );
    Task<PolicyMutationResponse> ReactivateAsync(
        Guid policyId,
        PolicyActionRequest request,
        CancellationToken cancellationToken
    );
    Task<PolicyMutationResponse> ExpireAsync(
        Guid policyId,
        PolicyActionRequest request,
        CancellationToken cancellationToken
    );
    Task<RenewalResponse> BeginRenewalAsync(
        Guid policyId,
        RenewPolicyRequest request,
        string idempotencyKey,
        CancellationToken cancellationToken
    );
    Task<PolicyEndorsementResponse> EndorsePolicyAsync(
        Guid policyId,
        PolicyEndorsementRequest request,
        string idempotencyKey,
        CancellationToken cancellationToken
    );
    Task<RenewalEstimateResponse> EstimateRenewalAsync(
        Guid policyId,
        RenewalEstimateRequest request,
        CancellationToken cancellationToken
    );
}


using PolicyService.Application.DTOs.Integrations;

namespace PolicyService.Application.Interfaces;

public interface ICustomerEligibilityClient
{
    Task<CustomerEligibilityResponse> GetEligibilityAsync(
        Guid customerId,
        CancellationToken cancellationToken
    );

    Task<IReadOnlyCollection<CustomerPropertyResponse>> GetCustomerPropertiesAsync(
        Guid customerId,
        CancellationToken cancellationToken
    );
}


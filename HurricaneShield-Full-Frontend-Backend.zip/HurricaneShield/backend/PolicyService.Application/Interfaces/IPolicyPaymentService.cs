using PolicyService.Application.DTOs.Payments;
using PolicyService.Application.DTOs.Policies;

namespace PolicyService.Application.Interfaces;

public interface IPolicyPaymentService
{
    Task<PremiumValidationResponse> ValidatePremiumAsync(
        Guid policyId,
        Guid authUserId,
        CancellationToken cancellationToken
    );
    Task<PolicyMutationResponse> ConfirmInitialPaymentAsync(
        Guid policyId,
        PaymentConfirmationRequest request,
        CancellationToken cancellationToken
    );
    Task<PolicyMutationResponse> ConfirmRenewalPaymentAsync(
        Guid policyId,
        PaymentConfirmationRequest request,
        CancellationToken cancellationToken
    );
}


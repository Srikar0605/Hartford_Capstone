using PolicyService.Application.DTOs.Quotes;

namespace PolicyService.Application.Interfaces;

public interface IQuoteService
{
    Task<QuoteResponse> CalculateQuoteAsync(
        CalculateQuoteRequest request,
        CancellationToken cancellationToken
    );

    Task<QuoteResponse> CalculateCustomerQuoteAsync(
        CustomerQuoteRequest request,
        CancellationToken cancellationToken
    );

    Task<IReadOnlyCollection<QuoteResponse>> CalculateRecommendationsAsync(
        CalculateRecommendationsRequest request,
        CancellationToken cancellationToken
    );
}


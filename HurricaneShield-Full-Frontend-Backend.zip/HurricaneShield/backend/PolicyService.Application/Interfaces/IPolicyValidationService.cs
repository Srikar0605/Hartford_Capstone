using PolicyService.Application.DTOs.Validation;

namespace PolicyService.Application.Interfaces;

public interface IPolicyValidationService
{
    Task<PolicyValidationResponse> ValidatePolicyAsync(
        Guid policyId,
        Guid authUserId,
        CancellationToken cancellationToken
    );
    Task<CoverageValidationResponse> ValidateCoverageAsync(
        Guid policyId,
        Guid coverageTypeId,
        CancellationToken cancellationToken
    );
    Task<CoverageBalanceResponse> GetCoverageBalanceAsync(
        Guid policyId,
        Guid coverageTypeId,
        CancellationToken cancellationToken
    );
}


namespace PolicyService.Application.Interfaces;

public interface IRequestContext
{
    Guid UserId { get; }
    string Actor { get; }
    string CorrelationId { get; }
    IReadOnlyCollection<string> Roles { get; }
    IReadOnlyCollection<string> Permissions { get; }
    bool IsAuthenticated { get; }
}


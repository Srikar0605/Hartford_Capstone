using PolicyService.Domain.Enums;

namespace PolicyService.Application.Interfaces;

public interface IRiskZoneEvaluator
{
    Task<RiskZone> EvaluateRiskZoneAsync(double latitude, double longitude, CancellationToken ct);
}


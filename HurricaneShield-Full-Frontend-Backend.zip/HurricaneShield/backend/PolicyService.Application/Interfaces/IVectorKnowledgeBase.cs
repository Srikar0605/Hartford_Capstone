namespace PolicyService.Application.Interfaces;

public interface IVectorKnowledgeBase
{
    Task<string> RetrieveContextAsync(string query, int topK = 3, CancellationToken ct = default);
}


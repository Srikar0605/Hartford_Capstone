using PolicyService.Application.DTOs.Common;
using PolicyService.Application.DTOs.Plans;

namespace PolicyService.Application.Interfaces;

public interface IPlanService
{
    Task<IReadOnlyCollection<PlanSummaryResponse>> GetActivePlansAsync(
        CancellationToken cancellationToken
    );
    Task<PlanDetailsResponse> GetPlanDetailsAsync(Guid planId, CancellationToken cancellationToken);
    Task<PagedResponse<PlanAdministrationResponse>> SearchPlansAsync(
        PlanSearchRequest request,
        CancellationToken cancellationToken
    );
    Task<PlanAdministrationResponse> CreatePlanAsync(
        CreatePlanRequest request,
        CancellationToken cancellationToken
    );
    Task<PlanAdministrationResponse> UpdatePlanAsync(
        Guid planId,
        UpdatePlanRequest request,
        CancellationToken cancellationToken
    );
    Task<PlanAdministrationResponse> ActivatePlanAsync(
        Guid planId,
        RowVersionRequest request,
        CancellationToken cancellationToken
    );
    Task<PlanAdministrationResponse> DeactivatePlanAsync(
        Guid planId,
        RowVersionRequest request,
        CancellationToken cancellationToken
    );
    Task<PlanDetailsResponse> ReplacePlanCoveragesAsync(
        Guid planId,
        ReplacePlanCoveragesRequest request,
        CancellationToken cancellationToken
    );
}


namespace PolicyService.Application.Interfaces;

public record ThinkHazardResponse(string HazardLevel); // "High", "Medium", "Low", "VeryLow"

public interface IThinkHazardClient
{
    Task<ThinkHazardResponse> GetRiskLevelAsync(double latitude, double longitude, CancellationToken ct);
}


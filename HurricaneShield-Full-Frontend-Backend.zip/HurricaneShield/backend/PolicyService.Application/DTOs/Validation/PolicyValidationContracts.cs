using PolicyService.Domain.Enums;

namespace PolicyService.Application.DTOs.Validation;

public sealed record PolicyValidationResponse(
    Guid PolicyId,
    string PolicyNumber,
    Guid CustomerId,
    Guid AuthUserId,
    string Status,
    bool IsOwnedByUser,
    bool IsActive,
    DateTime EffectiveDate,
    DateTime ExpirationDate,
    string? Reason
);

public sealed record CoverageValidationResponse(
    Guid PolicyId,
    Guid CoverageTypeId,
    string CoverageName,
    decimal CoverageLimit,
    decimal DeductibleAmount,
    bool IsIncluded,
    string? Reason
);

public sealed record CoverageBalanceResponse(
    Guid PolicyId,
    Guid CoverageTypeId,
    decimal CoverageLimit,
    decimal ConsumedAmount,
    decimal RemainingAmount
);


namespace PolicyService.Application.DTOs.Plans;

public sealed record CreatePlanRequest(
    string PlanCode,
    string PlanName,
    string Description,
    decimal BasePremium,
    decimal CoverageLimit,
    decimal DeductibleAmount
);

public sealed record UpdatePlanRequest(
    string PlanCode,
    string PlanName,
    string Description,
    decimal BasePremium,
    decimal CoverageLimit,
    decimal DeductibleAmount,
    string RowVersion
);

public sealed record PlanSearchRequest(
    string? Search,
    bool? IsActive,
    int Page = 1,
    int PageSize = 20
);

public sealed record PlanSummaryResponse(
    Guid PlanId,
    string PlanCode,
    string PlanName,
    string Description,
    decimal BasePremium,
    decimal CoverageLimit,
    decimal DeductibleAmount
);

public sealed record PlanCoverageResponse(
    Guid CoverageTypeId,
    string CoverageName,
    string CoverageDescription,
    decimal CoverageLimit,
    decimal DeductibleAmount
);

public sealed record PlanDetailsResponse(
    Guid PlanId,
    string PlanCode,
    string PlanName,
    string Description,
    decimal BasePremium,
    decimal CoverageLimit,
    decimal DeductibleAmount,
    IReadOnlyCollection<PlanCoverageResponse> Coverages
);

public sealed record PlanAdministrationResponse(
    Guid PlanId,
    string PlanCode,
    string PlanName,
    string Description,
    decimal BasePremium,
    decimal CoverageLimit,
    decimal DeductibleAmount,
    bool IsActive,
    DateTime CreatedAt,
    DateTime? UpdatedAt,
    string RowVersion
);

public sealed record PlanCoverageAssignmentRequest(
    Guid CoverageTypeId,
    decimal CoverageLimit,
    decimal DeductibleAmount
);

public sealed record ReplacePlanCoveragesRequest(
    IReadOnlyCollection<PlanCoverageAssignmentRequest> Coverages,
    string RowVersion
);


using PolicyService.Application.DTOs.Plans;
using PolicyService.Domain.Enums;

namespace PolicyService.Application.DTOs.Quotes;

public sealed record PropertyRiskRequest(
    Guid? CustomerPropertyOwnershipId,
    decimal PropertyValue,
    int YearBuilt,
    ConstructionType ConstructionType,
    int ClaimsHistoryCount,
    bool StormShutters,
    bool ImpactResistantWindows,
    bool ReinforcedRoof,
    bool EmergencyGenerator,
    bool HomeInspectionCertification
);

public sealed record CalculateQuoteRequest(
    Guid PlanId,
    decimal RequestedCoverage,
    PropertyRiskRequest Property
);

public sealed record CalculateRecommendationsRequest(
    decimal RequestedCoverage,
    PropertyRiskRequest Property
);

public sealed record RiskFactorResponse(string Name, decimal Value);

public sealed record RiskAssessmentResponse(
    decimal RiskScore,
    RiskLevel RiskLevel,
    int PropertyAge,
    bool RequiresManualReview,
    IReadOnlyCollection<RiskFactorResponse> Factors
);

public sealed record PremiumBreakdownResponse(
    decimal BasePremium,
    decimal LocationRiskAdjustment,
    decimal PropertyRiskAdjustment,
    decimal ClaimsHistoryAdjustment,
    decimal RiskAdjustment,
    decimal DiscountAmount,
    decimal FinalPremium
);

public sealed record QuoteResponse(
    PlanSummaryResponse Plan,
    decimal RequestedCoverage,
    PropertyRiskRequest Property,
    RiskAssessmentResponse RiskAssessment,
    PremiumBreakdownResponse Premium,
    string? AssignedRiskZone = null
);


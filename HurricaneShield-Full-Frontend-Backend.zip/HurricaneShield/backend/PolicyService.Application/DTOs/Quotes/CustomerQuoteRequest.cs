namespace PolicyService.Application.DTOs.Quotes;

public sealed record CustomerQuoteRequest(
    Guid CustomerId,
    CalculateQuoteRequest Quote
);


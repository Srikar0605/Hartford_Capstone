namespace PolicyService.Application.DTOs.CoverageTypes;

public sealed record CreateCoverageTypeRequest(string Name, string Description);

public sealed record UpdateCoverageTypeRequest(string Name, string Description, string RowVersion);

public sealed record CoverageTypeResponse(
    Guid CoverageTypeId,
    string Name,
    string Description,
    bool IsActive,
    DateTime CreatedAt,
    DateTime? UpdatedAt,
    string RowVersion
);


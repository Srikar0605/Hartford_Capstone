using PolicyService.Application.DTOs.Plans;
using PolicyService.Application.DTOs.Quotes;
using PolicyService.Domain.Enums;

namespace PolicyService.Application.DTOs.Policies;

public sealed record CreatePolicyApplicationRequest(
    Guid CustomerId,
    Guid PlanId,
    decimal RequestedCoverage,
    PropertyRiskRequest Property
);

public sealed record PolicyApplicationResponse(
    Guid PolicyId,
    string PolicyNumber,
    PolicyStatus Status,
    Guid PlanId,
    decimal PremiumDue,
    decimal RiskScore,
    RiskLevel RiskLevel,
    int CurrentVersionNumber,
    string RowVersion,
    UnderwritingDecision UnderwritingOutcome
);

public sealed record PolicySummaryResponse(
    Guid PolicyId,
    string PolicyNumber,
    Guid PlanId,
    string PlanName,
    PolicyStatus Status,
    decimal PremiumDue,
    int CurrentVersionNumber,
    DateTime CreatedAt,
    string RowVersion,
    DateTime? EffectiveDate = null,
    DateTime? ExpirationDate = null,
    Guid? PreviousPolicyId = null
);

public sealed record PolicyPropertyResponse(
    Guid PropertyId,
    Guid? CustomerPropertyOwnershipId,
    decimal PropertyValue,
    int YearBuilt,
    ConstructionType ConstructionType,
    RiskZone RiskZone,
    bool StormShutters,
    bool ImpactResistantWindows,
    bool ReinforcedRoof,
    bool EmergencyGenerator,
    bool HomeInspectionCertification
);

public sealed record ComplianceReviewResponse(
    bool IsCompliant,
    decimal ConfidenceScore,
    string Summary,
    IReadOnlyCollection<string> Violations,
    IReadOnlyCollection<string> MissingDiscounts,
    string RiskAssessment,
    IReadOnlyCollection<string> RecommendedActions,
    IReadOnlyCollection<string> Citations,
    DateTime CreatedAt,
    string? Engine = null
);

public sealed record PolicyDetailsResponse(
    Guid PolicyId,
    string PolicyNumber,
    Guid CustomerId,
    Guid PlanId,
    PolicyStatus Status,
    decimal PremiumDue,
    int CurrentVersionNumber,
    Guid? PaymentTransactionId,
    DateTime CreatedAt,
    DateTime? UpdatedAt,
    string RowVersion,
    PlanDetailsResponse Plan,
    PolicyPropertyResponse Property,
    RiskAssessmentResponse LatestRiskAssessment,
    PremiumBreakdownResponse LatestPremiumBreakdown,
    ComplianceReviewResponse? ComplianceReview = null,
    DateTime? EffectiveDate = null,
    DateTime? ExpirationDate = null,
    Guid? PreviousPolicyId = null
);

public sealed record PolicyActionRequest(string Reason, string RowVersion);

public sealed record RenewPolicyRequest(
    PropertyRiskRequest Property,
    string Reason,
    string RowVersion
);

public sealed record PolicyEndorsementRequest(
    bool StormShutters,
    bool ImpactResistantWindows,
    bool ReinforcedRoof,
    bool EmergencyGenerator,
    bool HomeInspectionCertification,
    string Reason,
    string RowVersion
);

public sealed record PolicyEndorsementResponse(
    Guid PolicyId,
    string PolicyNumber,
    PolicyStatus Status,
    decimal PremiumDue,
    int CurrentVersionNumber,
    string RowVersion
);

public sealed record RenewalEstimateRequest(string RowVersion);

public sealed record RenewalEstimateResponse(
    Guid PolicyId,
    string PolicyNumber,
    Guid PlanId,
    string PlanName,
    decimal CoverageLimit,
    decimal CurrentPremium,
    decimal EstimatedRenewalPremium,
    decimal DifferenceAmount,
    string ComparisonOutcome,
    decimal TotalMitigationDiscount,
    decimal RiskScore,
    RiskLevel RiskLevel,
    bool ManualReviewRequired,
    PremiumBreakdownResponse Breakdown
);

public sealed record CancellationPreviewResponse(
    Guid PolicyId,
    string PolicyNumber,
    decimal PremiumDue,
    DateTime? EffectiveDate,
    DateTime? ExpirationDate,
    int TotalTermDays,
    int DaysActive,
    int DaysRemaining,
    decimal RefundAmount
);

public sealed record PolicyMutationResponse(
    Guid PolicyId,
    string PolicyNumber,
    PolicyStatus Status,
    decimal PremiumDue,
    int CurrentVersionNumber,
    Guid? PaymentTransactionId,
    string RowVersion
);

public sealed record RenewalResponse(
    Guid PolicyId,
    string PolicyNumber,
    PolicyStatus Status,
    decimal PremiumDue,
    int CurrentVersionNumber,
    decimal RiskScore,
    RiskLevel RiskLevel,
    UnderwritingDecision UnderwritingOutcome,
    string RowVersion
);

public sealed record PolicyVersionResponse(
    Guid PolicyVersionId,
    int VersionNumber,
    string ChangeReason,
    string SnapshotData,
    DateTime CreatedAt,
    string CreatedBy
);

public sealed record PolicyHistoryResponse(
    Guid HistoryId,
    PolicyStatus? FromStatus,
    PolicyStatus ToStatus,
    string Reason,
    DateTime ChangedAt,
    string ChangedBy,
    string CorrelationId
);

public sealed record StaffPolicySearchRequest(
    string? Search,
    PolicyStatus? Status,
    Guid? CustomerId,
    Guid? PlanId,
    DateTime? CreatedFrom,
    DateTime? CreatedTo,
    int Page = 1,
    int PageSize = 20
);

public sealed record StaffPolicySummaryResponse(
    Guid PolicyId,
    string PolicyNumber,
    Guid CustomerId,
    Guid PlanId,
    string PlanName,
    PolicyStatus Status,
    decimal PremiumDue,
    int CurrentVersionNumber,
    DateTime CreatedAt,
    DateTime? UpdatedAt,
    string RowVersion
);


namespace PolicyService.Application.DTOs.Common;

public sealed record RowVersionRequest(string RowVersion);


using PolicyService.Application.DTOs.Policies;
using PolicyService.Application.DTOs.Quotes;
using PolicyService.Domain.Enums;
using PolicyService.Domain.Models;

namespace PolicyService.Application.DTOs.Underwriting;

public sealed record UnderwritingSearchRequest(
    RiskLevel? RiskLevel,
    Guid? PlanId,
    int? MinimumPropertyAge,
    int? MaximumPropertyAge,
    DateTime? SubmittedFrom,
    DateTime? SubmittedTo,
    int Page = 1,
    int PageSize = 20
);

public sealed record UnderwritingQueueItemResponse(
    Guid PolicyId,
    string PolicyNumber,
    Guid CustomerId,
    Guid PlanId,
    string PlanName,
    decimal RiskScore,
    RiskLevel RiskLevel,
    int PropertyAge,
    DateTime SubmittedAt,
    string RowVersion
);

public sealed record UnderwritingDetailsResponse(
    PolicyDetailsResponse Policy,
    Guid UnderwritingReviewId,
    UnderwritingReviewStatus ReviewStatus,
    Guid? ReviewerUserId,
    string? ReviewerDisplay,
    UnderwritingDecision? Decision,
    DateTime? ReviewedAt,
    string ReviewRowVersion
);

public sealed record UnderwritingDecisionReasonRequest(string ReasonCode, string ReasonDescription);

public sealed record ApprovePolicyRequest(
    IReadOnlyCollection<UnderwritingDecisionReasonRequest> Reasons,
    string PolicyRowVersion,
    string ReviewRowVersion
);

public sealed record RejectPolicyRequest(
    IReadOnlyCollection<UnderwritingDecisionReasonRequest> Reasons,
    string PolicyRowVersion,
    string ReviewRowVersion
);

public sealed record RevisePolicyRequest(
    PropertyRiskInput RevisedProperty,
    decimal RequestedCoverage,
    string RevisionReason,
    string PolicyRowVersion,
    string ReviewRowVersion
);


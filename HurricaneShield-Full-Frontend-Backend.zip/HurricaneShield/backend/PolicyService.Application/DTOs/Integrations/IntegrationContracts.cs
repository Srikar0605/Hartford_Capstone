namespace PolicyService.Application.DTOs.Integrations;

public sealed record CustomerEligibilityResponse(
    Guid CustomerId,
    bool IsActive,
    bool IsAgeEligible,
    bool IsEligible,
    IReadOnlyCollection<string> Reasons
);

public sealed record CustomerPropertyResponse(
    Guid PropertyOwnershipId,
    string AddressLine1,
    string? AddressLine2,
    string City,
    string State,
    string PostalCode,
    string Country,
    string OwnershipType,
    int? YearBuilt,
    string? ConstructionType,
    bool StormShutters,
    bool ImpactResistantWindows,
    bool ReinforcedRoof,
    bool EmergencyGenerator,
    bool HomeInspectionCertification,
    double? Latitude,
    double? Longitude
);

public sealed record ClaimsCoverageConsumptionResponse(
    Guid PolicyId,
    Guid CoverageTypeId,
    decimal ConsumedAmount
);

public sealed record ClaimHistoryCountRequest(IReadOnlyCollection<Guid> PolicyIds);

public sealed record ClaimHistoryCountResponse(int Count);


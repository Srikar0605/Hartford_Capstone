namespace PolicyService.Application.DTOs.System;

public sealed record DashboardMetricsResponse(
    BusinessMetrics Business,
    OperationalMetrics Operations
);

// --- Business Metrics ---
public sealed record BusinessMetrics(
    BusinessKpis Kpis,
    IReadOnlyCollection<OperatingMarginData> OperatingMargin,
    IReadOnlyCollection<RiskExposureData> RiskExposure,
    IReadOnlyCollection<PolicyChurnData> PolicyChurn,
    IReadOnlyCollection<ClaimsStatusData> ClaimsStatus
);

public sealed record BusinessKpis(
    decimal GrossWrittenPremium,
    decimal LossRatio, // Target ~65%
    decimal QuoteToBindRatio // e.g. 0.45 for 45%
);

public sealed record OperatingMarginData(
    string Month,
    decimal Gwp,
    decimal ClaimsPaid
);

public sealed record RiskExposureData(
    string RiskZone,
    int PolicyCount
);

public sealed record PolicyChurnData(
    string Month,
    int NewPolicies,
    int CancelledPolicies
);

public sealed record ClaimsStatusData(
    string Status,
    int Count
);


// --- Operational Metrics ---
public sealed record OperationalMetrics(
    OperationalKpis Kpis,
    IReadOnlyCollection<ServiceHealthData> ServiceHealth,
    IReadOnlyCollection<TrafficCorrelationData> TrafficCorrelation
);

public sealed record OperationalKpis(
    int GlobalLatencyMs,
    decimal GlobalErrorRate, // e.g. 0.01 for 1%
    int RequestsPerMinute
);

public sealed record ServiceHealthData(
    string ServiceName,
    int P50Latency,
    int P90Latency,
    int P99Latency,
    decimal ErrorRate,
    int CpuUsagePercent,
    int MemoryMb,
    string Status // "Healthy", "Degraded", "Critical"
);

public sealed record TrafficCorrelationData(
    string TimeLabel,
    int Requests,
    int Errors
);


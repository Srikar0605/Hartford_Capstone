namespace PolicyService.Application.DTOs.System;

public sealed record ChatMessageDto(
    string Role, // "user" or "model"
    string Content
);

public sealed record ChatRequest(
    IReadOnlyCollection<ChatMessageDto> History,
    string NewMessage,
    string? ClientContext = null
);

public sealed record ChatResponse(
    string Reply
);


namespace PolicyService.Application.DTOs.System;

public sealed record ThreatAlertResponse(
    bool IsActive,
    string Source,
    string Title,
    string Message,
    string Severity
);

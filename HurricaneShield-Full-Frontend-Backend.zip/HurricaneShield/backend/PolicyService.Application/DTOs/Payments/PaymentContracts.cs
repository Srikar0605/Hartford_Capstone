namespace PolicyService.Application.DTOs.Payments;

public sealed record PremiumValidationResponse(
    Guid PolicyId,
    Guid CustomerId,
    Guid AuthUserId,
    bool OwnerMatches,
    bool IsPaymentPending,
    decimal PremiumDue,
    string PaymentContext,
    string RowVersion,
    string? Reason
);

public sealed record PaymentConfirmationRequest(
    Guid TransactionId,
    decimal Amount,
    DateTime ProcessedAt,
    string RowVersion
);


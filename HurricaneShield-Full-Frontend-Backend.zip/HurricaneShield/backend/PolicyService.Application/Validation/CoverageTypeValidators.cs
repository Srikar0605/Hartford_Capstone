using FluentValidation;
using PolicyService.Application.DTOs.CoverageTypes;

namespace PolicyService.Application.Validation;

public sealed class CreateCoverageTypeRequestValidator
    : AbstractValidator<CreateCoverageTypeRequest>
{
    public CreateCoverageTypeRequestValidator()
    {
        RuleFor(x => x.Name).NotEmpty().MaximumLength(150);
        RuleFor(x => x.Description).NotEmpty().MaximumLength(1000);
    }
}

public sealed class UpdateCoverageTypeRequestValidator
    : AbstractValidator<UpdateCoverageTypeRequest>
{
    public UpdateCoverageTypeRequestValidator()
    {
        RuleFor(x => x.Name).NotEmpty().MaximumLength(150);
        RuleFor(x => x.Description).NotEmpty().MaximumLength(1000);
        RuleFor(x => x.RowVersion).ValidBase64RowVersion();
    }
}


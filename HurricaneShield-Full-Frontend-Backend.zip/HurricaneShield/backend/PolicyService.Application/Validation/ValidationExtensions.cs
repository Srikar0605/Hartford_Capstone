using FluentValidation;

namespace PolicyService.Application.Validation;

internal static class ValidationExtensions
{
    internal static IRuleBuilderOptions<T, string> ValidBase64RowVersion<T>(
        this IRuleBuilder<T, string> ruleBuilder
    )
    {
        return ruleBuilder
            .NotEmpty()
            .Must(BeEightByteBase64)
            .WithMessage("RowVersion must be a Base64 value representing exactly eight bytes.");
    }

    private static bool BeEightByteBase64(string value)
    {
        if (string.IsNullOrWhiteSpace(value))
            return false;

        try
        {
            return Convert.FromBase64String(value).Length == 8;
        }
        catch (FormatException)
        {
            return false;
        }
    }
}


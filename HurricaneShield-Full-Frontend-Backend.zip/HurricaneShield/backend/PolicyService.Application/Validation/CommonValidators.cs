using FluentValidation;
using PolicyService.Application.DTOs.Common;

namespace PolicyService.Application.Validation;

public sealed class RowVersionRequestValidator : AbstractValidator<RowVersionRequest>
{
    public RowVersionRequestValidator()
    {
        RuleFor(x => x.RowVersion).ValidBase64RowVersion();
    }
}


using FluentValidation;
using PolicyService.Application.DTOs.Underwriting;

namespace PolicyService.Application.Validation;

public sealed class UnderwritingSearchRequestValidator
    : AbstractValidator<UnderwritingSearchRequest>
{
    public UnderwritingSearchRequestValidator()
    {
        RuleFor(x => x.RiskLevel).IsInEnum().When(x => x.RiskLevel.HasValue);
        RuleFor(x => x.PlanId).Must(id => id is null || id != Guid.Empty);
        RuleFor(x => x.MinimumPropertyAge)
            .GreaterThanOrEqualTo(0)
            .When(x => x.MinimumPropertyAge.HasValue);
        RuleFor(x => x.MaximumPropertyAge)
            .GreaterThanOrEqualTo(0)
            .When(x => x.MaximumPropertyAge.HasValue);
        RuleFor(x => x)
            .Must(x =>
                !x.MinimumPropertyAge.HasValue
                || !x.MaximumPropertyAge.HasValue
                || x.MinimumPropertyAge <= x.MaximumPropertyAge
            )
            .WithMessage("Minimum Property age cannot exceed maximum Property age.");
        RuleFor(x => x)
            .Must(x =>
                !x.SubmittedFrom.HasValue
                || !x.SubmittedTo.HasValue
                || x.SubmittedFrom <= x.SubmittedTo
            )
            .WithMessage("SubmittedFrom cannot be after SubmittedTo.");
        RuleFor(x => x.Page).GreaterThanOrEqualTo(1);
        RuleFor(x => x.PageSize).InclusiveBetween(1, 100);
    }
}

public sealed class UnderwritingDecisionReasonRequestValidator
    : AbstractValidator<UnderwritingDecisionReasonRequest>
{
    public UnderwritingDecisionReasonRequestValidator()
    {
        RuleFor(x => x.ReasonCode).NotEmpty().MaximumLength(100);
        RuleFor(x => x.ReasonDescription).NotEmpty().MaximumLength(500);
    }
}

public sealed class ApprovePolicyRequestValidator : AbstractValidator<ApprovePolicyRequest>
{
    public ApprovePolicyRequestValidator()
    {
        RuleFor(x => x.Reasons).NotEmpty();
        RuleForEach(x => x.Reasons).SetValidator(new UnderwritingDecisionReasonRequestValidator());
        RuleFor(x => x.PolicyRowVersion).ValidBase64RowVersion();
        RuleFor(x => x.ReviewRowVersion).ValidBase64RowVersion();
    }
}

public sealed class RejectPolicyRequestValidator : AbstractValidator<RejectPolicyRequest>
{
    public RejectPolicyRequestValidator()
    {
        RuleFor(x => x.Reasons).NotEmpty();
        RuleForEach(x => x.Reasons).SetValidator(new UnderwritingDecisionReasonRequestValidator());
        RuleFor(x => x.PolicyRowVersion).ValidBase64RowVersion();
        RuleFor(x => x.ReviewRowVersion).ValidBase64RowVersion();
    }
}


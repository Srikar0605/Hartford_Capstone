using FluentValidation;
using PolicyService.Application.DTOs.Payments;

namespace PolicyService.Application.Validation;

public sealed class PaymentConfirmationRequestValidator
    : AbstractValidator<PaymentConfirmationRequest>
{
    public PaymentConfirmationRequestValidator()
    {
        RuleFor(x => x.TransactionId).NotEmpty();
        RuleFor(x => x.Amount).GreaterThan(0m);
        RuleFor(x => x.ProcessedAt)
            .Must(value => value.Kind == DateTimeKind.Utc)
            .WithMessage("ProcessedAt must be UTC.");
        RuleFor(x => x.RowVersion).ValidBase64RowVersion();
    }
}


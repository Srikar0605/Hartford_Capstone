using FluentValidation;
using PolicyService.Application.DTOs.Policies;

namespace PolicyService.Application.Validation;

public sealed class CreatePolicyApplicationRequestValidator
    : AbstractValidator<CreatePolicyApplicationRequest>
{
    public CreatePolicyApplicationRequestValidator()
    {
        RuleFor(x => x.CustomerId).NotEmpty();
        RuleFor(x => x.PlanId).NotEmpty();
        RuleFor(x => x.RequestedCoverage).GreaterThan(0m);
        RuleFor(x => x.Property).NotNull().SetValidator(new PropertyRiskRequestValidator());
    }
}

public sealed class PolicyActionRequestValidator : AbstractValidator<PolicyActionRequest>
{
    public PolicyActionRequestValidator()
    {
        RuleFor(x => x.Reason).NotEmpty().MaximumLength(500);
        RuleFor(x => x.RowVersion).ValidBase64RowVersion();
    }
}

public sealed class RenewPolicyRequestValidator : AbstractValidator<RenewPolicyRequest>
{
    public RenewPolicyRequestValidator()
    {
        RuleFor(x => x.Property).NotNull().SetValidator(new PropertyRiskRequestValidator());
        RuleFor(x => x.Reason).NotEmpty().MaximumLength(500);
        RuleFor(x => x.RowVersion).ValidBase64RowVersion();
    }
}

public sealed class PolicyEndorsementRequestValidator : AbstractValidator<PolicyEndorsementRequest>
{
    public PolicyEndorsementRequestValidator()
    {
        RuleFor(x => x.Reason).NotEmpty().MaximumLength(500);
        RuleFor(x => x.RowVersion).ValidBase64RowVersion();
    }
}

public sealed class RenewalEstimateRequestValidator : AbstractValidator<RenewalEstimateRequest>
{
    public RenewalEstimateRequestValidator()
    {
        RuleFor(x => x.RowVersion).ValidBase64RowVersion();
    }
}

public sealed class StaffPolicySearchRequestValidator
    : AbstractValidator<StaffPolicySearchRequest>
{
    public StaffPolicySearchRequestValidator()
    {
        RuleFor(x => x.Search).MaximumLength(100);
        RuleFor(x => x.CustomerId).Must(id => id is null || id != Guid.Empty);
        RuleFor(x => x.PlanId).Must(id => id is null || id != Guid.Empty);
        RuleFor(x => x.Page).GreaterThanOrEqualTo(1);
        RuleFor(x => x.PageSize).InclusiveBetween(1, 100);
        RuleFor(x => x).Must(x => !x.CreatedFrom.HasValue || !x.CreatedTo.HasValue || x.CreatedFrom <= x.CreatedTo)
            .WithMessage("Created From cannot be later than Created To.");
    }
}


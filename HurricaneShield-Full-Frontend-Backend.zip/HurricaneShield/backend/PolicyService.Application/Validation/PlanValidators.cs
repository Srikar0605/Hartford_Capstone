using FluentValidation;
using PolicyService.Application.DTOs.Plans;

namespace PolicyService.Application.Validation;

public sealed class CreatePlanRequestValidator : AbstractValidator<CreatePlanRequest>
{
    public CreatePlanRequestValidator()
    {
        RuleFor(x => x.PlanCode).NotEmpty().MaximumLength(50);
        RuleFor(x => x.PlanName).NotEmpty().MaximumLength(150);
        RuleFor(x => x.Description).NotEmpty().MaximumLength(1000);
        RuleFor(x => x.BasePremium).GreaterThan(0m);
        RuleFor(x => x.CoverageLimit).GreaterThan(0m);
        RuleFor(x => x.DeductibleAmount).GreaterThanOrEqualTo(0m);
    }
}

public sealed class UpdatePlanRequestValidator : AbstractValidator<UpdatePlanRequest>
{
    public UpdatePlanRequestValidator()
    {
        RuleFor(x => x.PlanCode).NotEmpty().MaximumLength(50);
        RuleFor(x => x.PlanName).NotEmpty().MaximumLength(150);
        RuleFor(x => x.Description).NotEmpty().MaximumLength(1000);
        RuleFor(x => x.BasePremium).GreaterThan(0m);
        RuleFor(x => x.CoverageLimit).GreaterThan(0m);
        RuleFor(x => x.DeductibleAmount).GreaterThanOrEqualTo(0m);
        RuleFor(x => x.RowVersion).ValidBase64RowVersion();
    }
}

public sealed class PlanSearchRequestValidator : AbstractValidator<PlanSearchRequest>
{
    public PlanSearchRequestValidator()
    {
        RuleFor(x => x.Search).MaximumLength(150);
        RuleFor(x => x.Page).GreaterThanOrEqualTo(1);
        RuleFor(x => x.PageSize).InclusiveBetween(1, 100);
    }
}

public sealed class PlanCoverageAssignmentRequestValidator
    : AbstractValidator<PlanCoverageAssignmentRequest>
{
    public PlanCoverageAssignmentRequestValidator()
    {
        RuleFor(x => x.CoverageTypeId).NotEmpty();
        RuleFor(x => x.CoverageLimit).GreaterThan(0m);
        RuleFor(x => x.DeductibleAmount).GreaterThanOrEqualTo(0m);
    }
}

public sealed class ReplacePlanCoveragesRequestValidator
    : AbstractValidator<ReplacePlanCoveragesRequest>
{
    public ReplacePlanCoveragesRequestValidator()
    {
        RuleFor(x => x.Coverages).NotNull();
        RuleForEach(x => x.Coverages).SetValidator(new PlanCoverageAssignmentRequestValidator());
        RuleFor(x => x.Coverages)
            .Must(items =>
                items is not null
                && items.Select(x => x.CoverageTypeId).Distinct().Count() == items.Count
            )
            .WithMessage("A Coverage Type can be assigned only once.");
        RuleFor(x => x.RowVersion).ValidBase64RowVersion();
    }
}


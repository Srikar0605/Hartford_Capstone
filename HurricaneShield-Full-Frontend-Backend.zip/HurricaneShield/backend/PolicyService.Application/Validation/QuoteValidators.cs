using FluentValidation;
using PolicyService.Application.DTOs.Quotes;

namespace PolicyService.Application.Validation;

public sealed class PropertyRiskRequestValidator : AbstractValidator<PropertyRiskRequest>
{
    public PropertyRiskRequestValidator()
    {
        RuleFor(x => x.CustomerPropertyOwnershipId)
            .Must(id => id is null || id != Guid.Empty)
            .WithMessage("Customer Property Ownership identifier cannot be empty.");
        RuleFor(x => x.PropertyValue).GreaterThan(0m);
        RuleFor(x => x.YearBuilt).GreaterThanOrEqualTo(1800);
        RuleFor(x => x.ConstructionType).IsInEnum();
        RuleFor(x => x.ClaimsHistoryCount).GreaterThanOrEqualTo(0);
    }
}

public sealed class CalculateQuoteRequestValidator : AbstractValidator<CalculateQuoteRequest>
{
    public CalculateQuoteRequestValidator()
    {
        RuleFor(x => x.PlanId).NotEmpty();
        RuleFor(x => x.RequestedCoverage).GreaterThan(0m);
        RuleFor(x => x.Property).NotNull().SetValidator(new PropertyRiskRequestValidator());
    }
}

public sealed class CalculateRecommendationsRequestValidator : AbstractValidator<CalculateRecommendationsRequest>
{
    public CalculateRecommendationsRequestValidator()
    {
        RuleFor(x => x.RequestedCoverage).GreaterThan(0m);
        RuleFor(x => x.Property).NotNull().SetValidator(new PropertyRiskRequestValidator());
    }
}


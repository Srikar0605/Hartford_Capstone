namespace PolicyService.Application.Authorization;

public static class PolicyAuthorizationPolicies
{
    public const string CustomerAccess = "Policy.CustomerAccess";
    public const string StaffRead = "Policy.StaffRead";
    public const string ManagePlans = "Policy.ManagePlans";
    public const string ManagePolicies = "Policy.ManagePolicies";
    public const string ReviewPolicies = "Policy.ReviewPolicies";
    public const string ApprovePolicies = "Policy.ApprovePolicies";
    public const string RejectPolicies = "Policy.RejectPolicies";
    public const string ConfirmPayments = "Policy.ConfirmPayments";
    public const string ClaimsValidation = "Policy.ClaimsValidation";
}


namespace PolicyService.Application.Authorization;

public static class PolicyRoles
{
    public const string Customer = "Customer";
    public const string Agent = "Agent";
    public const string ClaimsManager = "Claims Manager";
    public const string Administrator = "Administrator";
}


namespace PolicyService.Application.Authorization;

public static class PolicyPermissions
{
    public const string ManagePlans = "Manage Plans";
    public const string ManagePolicies = "Manage Policies";
    public const string ReviewPolicies = "Review Policies";
    public const string ApprovePolicies = "Approve Policies";
    public const string RejectPolicies = "Reject Policies";
    public const string ConfirmPolicyPayments = "Confirm Policy Payments";
}


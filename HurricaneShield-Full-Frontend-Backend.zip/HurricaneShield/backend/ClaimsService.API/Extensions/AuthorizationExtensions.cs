using ClaimsService.Application.Authorization;
using Microsoft.AspNetCore.Authorization;

namespace ClaimsService.API.Extensions;

public static class AuthorizationExtensions
{
    public static IServiceCollection AddClaimsAuthorization(this IServiceCollection services)
    {
        services.AddAuthorization(options =>
        {
            Add(options, ClaimsAuthorizationPolicies.StaffRead, ClaimsPermissions.ReviewClaims);
            Add(options, ClaimsAuthorizationPolicies.Review, ClaimsPermissions.ReviewClaims);
            Add(options, ClaimsAuthorizationPolicies.Approve, ClaimsPermissions.ApproveClaims);
            Add(options, ClaimsAuthorizationPolicies.Reject, ClaimsPermissions.RejectClaims);
            Add(
                options,
                ClaimsAuthorizationPolicies.VerifyDocuments,
                ClaimsPermissions.VerifyDocuments
            );
            Add(
                options,
                ClaimsAuthorizationPolicies.InitiateSettlement,
                ClaimsPermissions.InitiateSettlement
            );
            Add(
                options,
                ClaimsAuthorizationPolicies.PaymentConfirmation,
                ClaimsPermissions.ConfirmSettlement
            );
        });
        return services;
    }

    private static void Add(AuthorizationOptions options, string name, string permission) =>
        options.AddPolicy(
            name,
            policy =>
                policy.RequireAssertion(context =>
                    context.User.IsInRole(ClaimsRoles.Administrator)
                    || context.User.HasClaim("permissions", permission)
                )
        );
}


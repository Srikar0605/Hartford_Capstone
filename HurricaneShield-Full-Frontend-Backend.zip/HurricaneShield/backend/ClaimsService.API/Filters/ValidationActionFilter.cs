using FluentValidation;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Shared.Common.Responses;

namespace ClaimsService.API.Filters;

public sealed class ValidationActionFilter(IServiceProvider services) : IAsyncActionFilter
{
    public async Task OnActionExecutionAsync(
        ActionExecutingContext context,
        ActionExecutionDelegate next
    )
    {
        foreach (var argument in context.ActionArguments.Values.Where(value => value is not null))
        {
            var validatorType = typeof(IValidator<>).MakeGenericType(argument!.GetType());
            if (services.GetService(validatorType) is not IValidator validator)
                continue;
            var result = await validator.ValidateAsync(
                new ValidationContext<object>(argument),
                context.HttpContext.RequestAborted
            );
            if (result.IsValid)
                continue;
            context.Result = new BadRequestObjectResult(
                ApiErrorResponse.Create(
                    "VALIDATION_ERROR",
                    string.Join("; ", result.Errors.Select(e => e.ErrorMessage).Distinct()),
                    context.HttpContext.TraceIdentifier
                )
            );
            return;
        }
        await next();
    }
}


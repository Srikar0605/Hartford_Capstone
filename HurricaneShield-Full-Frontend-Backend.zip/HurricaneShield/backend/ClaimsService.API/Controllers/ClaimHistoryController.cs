using ClaimsService.Infrastructure.Persistence;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Shared.Common.Responses;

namespace ClaimsService.API.Controllers;

[ApiController]
[Route("api/v1/claims/history")]
[Authorize]
public sealed class ClaimHistoryController(ClaimsDbContext db) : ControllerBase
{
    [HttpPost("count")]
    public async Task<IActionResult> Count(
        ClaimHistoryCountRequest request,
        CancellationToken cancellationToken
    )
    {
        var policyIds = request.PolicyIds.Where(x => x != Guid.Empty).Distinct().ToArray();

        if (policyIds.Length == 0)
        {
            return Ok(
                ApiResponse<ClaimHistoryCountResponse>.Succeed(new ClaimHistoryCountResponse(0))
            );
        }

        var count = await db
            .Claims.AsNoTracking()
            .CountAsync(x => policyIds.Contains(x.PolicyId), cancellationToken);

        return Ok(
            ApiResponse<ClaimHistoryCountResponse>.Succeed(new ClaimHistoryCountResponse(count))
        );
    }

    public sealed record ClaimHistoryCountRequest(IReadOnlyCollection<Guid> PolicyIds);

    public sealed record ClaimHistoryCountResponse(int Count);
}


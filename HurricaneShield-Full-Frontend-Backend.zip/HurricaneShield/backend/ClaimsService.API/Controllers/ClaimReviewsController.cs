using ClaimsService.Application.Authorization;
using ClaimsService.Application.DTOs.Reviews;
using ClaimsService.Application.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Shared.Common.Responses;

namespace ClaimsService.API.Controllers;

[ApiController, Route("api/v1/claims"), Authorize]
public sealed class ClaimReviewsController(IClaimReviewService service) : ControllerBase
{
    [HttpGet("{claimId:guid}/review")]
    [Authorize(Policy = ClaimsAuthorizationPolicies.Review)]
    public async Task<IActionResult> GetActiveReview(
        Guid claimId,
        CancellationToken cancellationToken
    )
    {
        var response = await service.GetActiveReviewAsync(claimId, cancellationToken);
        return Ok(ApiResponse<object>.Succeed(response));
    }

    [HttpPost("{claimId:guid}/review"), Authorize(Policy = ClaimsAuthorizationPolicies.Review)]
    public async Task<IActionResult> Start(
        Guid claimId,
        StartClaimReviewRequest request,
        CancellationToken ct
    ) => Ok(ApiResponse<object>.Succeed(await service.StartReviewAsync(claimId, request, ct)));

    [
        HttpPost("{claimId:guid}/request-information"),
        Authorize(Policy = ClaimsAuthorizationPolicies.Review)
    ]
    public async Task<IActionResult> RequestInformation(
        Guid claimId,
        RequestAdditionalInformationRequest request,
        CancellationToken ct
    ) =>
        Ok(
            ApiResponse<object>.Succeed(
                await service.RequestAdditionalInformationAsync(claimId, request, ct)
            )
        );

    [HttpPost("{claimId:guid}/approve"), Authorize(Policy = ClaimsAuthorizationPolicies.Approve)]
    public async Task<IActionResult> Approve(
        Guid claimId,
        ApproveClaimRequest request,
        CancellationToken ct
    ) => Ok(ApiResponse<object>.Succeed(await service.ApproveAsync(claimId, request, ct)));

    [HttpPost("{claimId:guid}/reject"), Authorize(Policy = ClaimsAuthorizationPolicies.Reject)]
    public async Task<IActionResult> Reject(
        Guid claimId,
        RejectClaimRequest request,
        CancellationToken ct
    ) => Ok(ApiResponse<object>.Succeed(await service.RejectAsync(claimId, request, ct)));
}


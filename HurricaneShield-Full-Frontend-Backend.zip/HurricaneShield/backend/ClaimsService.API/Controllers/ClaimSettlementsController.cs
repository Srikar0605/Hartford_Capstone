using ClaimsService.Application.Authorization;
using ClaimsService.Application.DTOs.Settlements;
using ClaimsService.Application.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Shared.Common.Responses;

namespace ClaimsService.API.Controllers;

[ApiController, Route("api/v1/claims"), Authorize]
public sealed class ClaimSettlementsController(IClaimSettlementService service) : ControllerBase
{
    [
        HttpGet("{claimId:guid}/settlement-validation"),
        Authorize(Policy = ClaimsAuthorizationPolicies.PaymentConfirmation)
    ]
    public async Task<IActionResult> Validate(Guid claimId, CancellationToken ct) =>
        Ok(ApiResponse<object>.Succeed(await service.ValidateSettlementAsync(claimId, ct)));

    [
        HttpPost("{claimId:guid}/settlement"),
        Authorize(Policy = ClaimsAuthorizationPolicies.InitiateSettlement)
    ]
    public async Task<IActionResult> Initiate(
        Guid claimId,
        InitiateSettlementRequest request,
        CancellationToken ct
    )
    {
        var key = Request.Headers["X-Idempotency-Key"].FirstOrDefault() ?? string.Empty;
        return Ok(
            ApiResponse<object>.Succeed(await service.InitiateAsync(claimId, request, key, ct))
        );
    }

    [
        HttpPost("{claimId:guid}/settlement-confirmation"),
        Authorize(Policy = ClaimsAuthorizationPolicies.PaymentConfirmation)
    ]
    public async Task<IActionResult> Confirm(
        Guid claimId,
        SettlementConfirmationRequest request,
        CancellationToken ct
    ) => Ok(ApiResponse<object>.Succeed(await service.ConfirmAsync(claimId, request, ct)));
}


using ClaimsService.Application.Authorization;
using ClaimsService.Application.DTOs.Documents;
using ClaimsService.Application.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Shared.Common.Responses;

namespace ClaimsService.API.Controllers;

[ApiController, Route("api/v1/claims/{claimId:guid}/documents"), Authorize]
public sealed class ClaimDocumentsController(IClaimDocumentService service) : ControllerBase
{
    [HttpPost, RequestSizeLimit(10 * 1024 * 1024)]
    public async Task<IActionResult> Upload(
        Guid claimId,
        [FromForm] string documentType,
        IFormFile file,
        CancellationToken ct
    )
    {
        await using var content = file.OpenReadStream();
        var data = await service.UploadAsync(
            claimId,
            new(documentType, file.FileName, file.ContentType, file.Length, content),
            ct
        );
        return StatusCode(
            StatusCodes.Status201Created,
            ApiResponse<ClaimDocumentResponse>.Succeed(data)
        );
    }

    [HttpGet]
    public async Task<IActionResult> List(Guid claimId, CancellationToken ct) =>
        Ok(ApiResponse<object>.Succeed(await service.GetDocumentsAsync(claimId, ct)));

    [HttpGet("{documentId:guid}")]
    public async Task<IActionResult> Download(Guid claimId, Guid documentId, CancellationToken ct)
    {
        var data = await service.DownloadAsync(claimId, documentId, ct);
        return File(data.Content, data.ContentType, data.FileName);
    }

    [
        HttpPost("{documentId:guid}/verify"),
        Authorize(Policy = ClaimsAuthorizationPolicies.VerifyDocuments)
    ]
    public async Task<IActionResult> Verify(
        Guid claimId,
        Guid documentId,
        VerifyClaimDocumentRequest request,
        CancellationToken ct
    ) =>
        Ok(
            ApiResponse<object>.Succeed(await service.VerifyAsync(claimId, documentId, request, ct))
        );
}


using ClaimsService.Domain.Enums;
using ClaimsService.Infrastructure.Persistence;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Shared.Common.Responses;

namespace ClaimsService.API.Controllers;

[ApiController]
[Route("api/v1/claims/coverage-consumption")]
[Authorize]
public sealed class CoverageConsumptionController(ClaimsDbContext db) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> Get(
        [FromQuery] Guid policyId,
        [FromQuery] Guid coverageTypeId,
        CancellationToken cancellationToken
    )
    {
        var consumedAmount =
            await db
                .Claims.AsNoTracking()
                .Where(x =>
                    x.PolicyId == policyId
                    && x.CoverageTypeId == coverageTypeId
                    && (
                        x.Status == ClaimStatus.Approved
                        || x.Status == ClaimStatus.PaymentInitiated
                        || x.Status == ClaimStatus.Closed
                    )
                )
                .SumAsync(x => (decimal?)x.ClaimAmount, cancellationToken)
            ?? 0m;

        var response = new CoverageConsumptionResponse(policyId, coverageTypeId, consumedAmount);

        return Ok(ApiResponse<CoverageConsumptionResponse>.Succeed(response));
    }

    public sealed record CoverageConsumptionResponse(
        Guid PolicyId,
        Guid CoverageTypeId,
        decimal ConsumedAmount
    );
}


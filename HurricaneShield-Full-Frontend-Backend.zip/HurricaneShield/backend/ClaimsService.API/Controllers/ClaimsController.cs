using ClaimsService.Application.Authorization;
using ClaimsService.Application.DTOs.Claims;
using ClaimsService.Application.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Shared.Common.Responses;

namespace ClaimsService.API.Controllers;

/// <summary>
/// REST controller managing FNOL (First Notice of Loss) submissions and claims discovery.
/// In ClaimsService, we follow Simplified Clean Architecture: the controller calls IClaimService
/// directly without MediatR or CQRS dispatching. We enforce idempotency on claim submissions
/// to prevent duplicate claims from being created when users double-click or experience network drops.
/// </summary>
[ApiController, Route("api/v1/claims"), Authorize]
public sealed class ClaimsController(IClaimService service) : ControllerBase
{
    /// <summary>
    /// Submits a First Notice of Loss (FNOL).
    /// Extracts the X-Idempotency-Key header to guarantee idempotency.
    /// </summary>
    [HttpPost, Authorize(Roles = ClaimsRoles.Customer + "," + ClaimsRoles.Administrator)]
    public async Task<IActionResult> Submit(SubmitClaimRequest request, CancellationToken ct)
    {
        var key = Request.Headers["X-Idempotency-Key"].FirstOrDefault() ?? string.Empty;
        var data = await service.SubmitAsync(request, key, ct);
        return StatusCode(
            StatusCodes.Status201Created,
            ApiResponse<ClaimSubmissionResponse>.Succeed(data, "Claim submitted.")
        );
    }

    [HttpGet("me"), Authorize(Roles = ClaimsRoles.Customer + "," + ClaimsRoles.Administrator)]
    public async Task<IActionResult> Mine(
        [FromQuery] ClaimSearchRequest request,
        CancellationToken ct
    ) => Ok(ApiResponse<object>.Succeed(await service.GetMyClaimsAsync(request, ct)));

    [HttpGet, Authorize(Policy = ClaimsAuthorizationPolicies.StaffRead)]
    public async Task<IActionResult> Search(
        [FromQuery] ClaimSearchRequest request,
        CancellationToken ct
    ) => Ok(ApiResponse<object>.Succeed(await service.SearchAsync(request, ct)));

    [HttpGet("{claimId:guid}")]
    public async Task<IActionResult> Get(Guid claimId, CancellationToken ct) =>
        Ok(ApiResponse<object>.Succeed(await service.GetAsync(claimId, ct)));

    [HttpGet("{claimId:guid}/timeline")]
    public async Task<IActionResult> Timeline(Guid claimId, CancellationToken ct) =>
        Ok(ApiResponse<object>.Succeed(await service.GetTimelineAsync(claimId, ct)));
}



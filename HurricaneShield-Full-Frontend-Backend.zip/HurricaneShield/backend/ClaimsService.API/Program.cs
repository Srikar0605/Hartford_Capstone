using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using ClaimsService.API.Extensions;
using ClaimsService.API.Filters;
using ClaimsService.API.Middleware;
using ClaimsService.Application;
using ClaimsService.Infrastructure;
using ClaimsService.Infrastructure.Persistence;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.IdentityModel.Tokens;
using Shared.Common.Responses;
using Shared.Exceptions.Extensions;
using Shared.Logging.Extensions;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddClaimsApplication();

builder.Services.AddClaimsInfrastructure(builder.Configuration);
builder.Services.AddScoped<ValidationActionFilter>();

builder
    .Services.AddControllers(options =>
    {
        options.Filters.Add<ValidationActionFilter>();
    })
    .AddJsonOptions(options =>
    {
        options.JsonSerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;

        options.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());
    });

var jwtSection = builder.Configuration.GetSection("Jwt");

var issuer = jwtSection["Issuer"] ?? throw new InvalidOperationException("Jwt:Issuer is required.");

var audience =
    jwtSection["Audience"] ?? throw new InvalidOperationException("Jwt:Audience is required.");

var signingKey =
    jwtSection["SigningKey"] ?? throw new InvalidOperationException("Jwt:SigningKey is required.");

builder
    .Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.MapInboundClaims = false;

        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidIssuer = issuer,

            ValidateAudience = true,
            ValidAudience = audience,

            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(signingKey)),

            ValidateLifetime = true,
            ClockSkew = TimeSpan.Zero,

            NameClaimType = "sub",
            RoleClaimType = "role",
        };

        options.Events = new JwtBearerEvents
        {
            OnChallenge = async context =>
            {
                context.HandleResponse();

                context.Response.StatusCode = StatusCodes.Status401Unauthorized;

                context.Response.ContentType = "application/json";

                var response = ApiErrorResponse.Create(
                    "AUTH_INVALID_TOKEN",
                    "Access token is missing or invalid.",
                    context.HttpContext.TraceIdentifier
                );

                await context.Response.WriteAsJsonAsync(response);
            },

            OnForbidden = async context =>
            {
                context.Response.StatusCode = StatusCodes.Status403Forbidden;

                context.Response.ContentType = "application/json";

                var response = ApiErrorResponse.Create(
                    "AUTH_FORBIDDEN",
                    "The authenticated user is not authorized for this operation.",
                    context.HttpContext.TraceIdentifier
                );

                await context.Response.WriteAsJsonAsync(response);
            },
        };
    });
builder.Services.AddClaimsAuthorization();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddHealthChecks().AddDbContextCheck<ClaimsDbContext>("claims-db");

var app = builder.Build();

//
// Middleware
//

app.UseCorrelationId();

app.UseRequestLogging();

app.UseGlobalExceptionHandling();

app.UseMiddleware<ClaimsDomainExceptionMiddleware>();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

app.MapHealthChecks("/health");

app.MapHealthChecks(
    "/health-db",
    new HealthCheckOptions { Predicate = registration => registration.Name == "claims-db" }
);

app.Run();

public partial class Program { }


using ClaimsService.Domain.Exceptions;
using Shared.Common.Responses;

namespace ClaimsService.API.Middleware;

public sealed class ClaimsDomainExceptionMiddleware(RequestDelegate next)
{
    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            await next(context);
        }
        catch (DomainRuleException exception)
        {
            context.Response.StatusCode = StatusCodes.Status409Conflict;
            context.Response.ContentType = "application/json";
            await context.Response.WriteAsJsonAsync(
                ApiErrorResponse.Create(
                    "CLAIM_INVALID_STATUS_TRANSITION",
                    exception.Message,
                    context.TraceIdentifier
                )
            );
        }
    }
}


using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PolicyService.API.Contracts;
using PolicyService.Application.Authorization;
using PolicyService.Application.DTOs.Common;
using PolicyService.Application.DTOs.CoverageTypes;
using PolicyService.Application.Interfaces;

namespace PolicyService.API.Controllers;

[Route("api/v1/policies/coverage-types")]
public sealed class CoverageTypesController : PolicyControllerBase
{
    private readonly ICoverageTypeService _service;

    public CoverageTypesController(ICoverageTypeService service) => _service = service;

    [AllowAnonymous, HttpGet]
    public async Task<ActionResult<ApiResponse<IReadOnlyCollection<CoverageTypeResponse>>>> Get(
        [FromQuery] bool includeInactive,
        CancellationToken ct
    )
    {
        if (
            includeInactive
            && !(
                User.IsInRole(PolicyRoles.Administrator)
                || User.HasClaim("permissions", PolicyPermissions.ManagePlans)
            )
        )
            return Forbid();
        return OkEnvelope(await _service.GetCoverageTypesAsync(includeInactive, ct));
    }

    [Authorize(Policy = PolicyAuthorizationPolicies.ManagePlans), HttpPost]
    public async Task<ActionResult<ApiResponse<CoverageTypeResponse>>> Create(
        CreateCoverageTypeRequest request,
        CancellationToken ct
    )
    {
        var result = await _service.CreateCoverageTypeAsync(request, ct);
        return StatusCode(
            StatusCodes.Status201Created,
            ApiResponse<CoverageTypeResponse>.Ok(result, "Coverage Type created.")
        );
    }

    [Authorize(Policy = PolicyAuthorizationPolicies.ManagePlans), HttpPut("{coverageTypeId:guid}")]
    public async Task<ActionResult<ApiResponse<CoverageTypeResponse>>> Update(
        Guid coverageTypeId,
        UpdateCoverageTypeRequest request,
        CancellationToken ct
    ) => OkEnvelope(await _service.UpdateCoverageTypeAsync(coverageTypeId, request, ct));

    [
        Authorize(Policy = PolicyAuthorizationPolicies.ManagePlans),
        HttpPost("{coverageTypeId:guid}/activate")
    ]
    public async Task<ActionResult<ApiResponse<CoverageTypeResponse>>> Activate(
        Guid coverageTypeId,
        RowVersionRequest request,
        CancellationToken ct
    ) => OkEnvelope(await _service.ActivateCoverageTypeAsync(coverageTypeId, request, ct));

    [
        Authorize(Policy = PolicyAuthorizationPolicies.ManagePlans),
        HttpPost("{coverageTypeId:guid}/deactivate")
    ]
    public async Task<ActionResult<ApiResponse<CoverageTypeResponse>>> Deactivate(
        Guid coverageTypeId,
        RowVersionRequest request,
        CancellationToken ct
    ) => OkEnvelope(await _service.DeactivateCoverageTypeAsync(coverageTypeId, request, ct));
}


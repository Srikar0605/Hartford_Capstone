using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PolicyService.API.Contracts;
using PolicyService.Application.Authorization;
using PolicyService.Application.DTOs.Common;
using PolicyService.Application.DTOs.Policies;
using PolicyService.Application.DTOs.Underwriting;
using PolicyService.Application.Interfaces;

namespace PolicyService.API.Controllers;

[Route("api/v1/policies")]
public sealed class UnderwritingController : PolicyControllerBase
{
    private readonly IUnderwritingService _service;

    public UnderwritingController(IUnderwritingService service) => _service = service;

    [Authorize(Policy = PolicyAuthorizationPolicies.ReviewPolicies), HttpGet("underwriting")]
    public async Task<
        ActionResult<ApiResponse<PagedResponse<UnderwritingQueueItemResponse>>>
    > Queue([FromQuery] UnderwritingSearchRequest request, CancellationToken ct) =>
        OkEnvelope(await _service.GetQueueAsync(request, ct));

    [
        Authorize(Policy = PolicyAuthorizationPolicies.ReviewPolicies),
        HttpGet("underwriting/{policyId:guid}")
    ]
    public async Task<ActionResult<ApiResponse<UnderwritingDetailsResponse>>> Details(
        Guid policyId,
        CancellationToken ct
    ) => OkEnvelope(await _service.GetReviewDetailsAsync(policyId, ct));

    [
        Authorize(Policy = PolicyAuthorizationPolicies.ApprovePolicies),
        HttpPost("{policyId:guid}/approve")
    ]
    public async Task<ActionResult<ApiResponse<PolicyMutationResponse>>> Approve(
        Guid policyId,
        ApprovePolicyRequest request,
        CancellationToken ct
    ) => OkEnvelope(await _service.ApproveAsync(policyId, request, ct));

    [
        Authorize(Policy = PolicyAuthorizationPolicies.RejectPolicies),
        HttpPost("{policyId:guid}/reject")
    ]
    public async Task<ActionResult<ApiResponse<PolicyMutationResponse>>> Reject(
        Guid policyId,
        RejectPolicyRequest request,
        CancellationToken ct
    ) => OkEnvelope(await _service.RejectAsync(policyId, request, ct));

    [
        Authorize(Policy = PolicyAuthorizationPolicies.ApprovePolicies),
        HttpPost("{policyId:guid}/revise")
    ]
    public async Task<ActionResult<ApiResponse<PolicyMutationResponse>>> Revise(
        Guid policyId,
        RevisePolicyRequest request,
        CancellationToken ct
    ) => OkEnvelope(await _service.ReviseAsync(policyId, request, ct));
}


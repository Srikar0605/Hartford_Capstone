using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PolicyService.API.Contracts;
using PolicyService.Application.Authorization;
using PolicyService.Application.DTOs.Common;
using PolicyService.Application.DTOs.Policies;
using PolicyService.Application.Interfaces;
using PolicyService.Domain.Enums;

namespace PolicyService.API.Controllers;

/// <summary>
/// Controller managing insurance policy applications, lifecycle transitions, and staff reviews.
/// In PolicyService, we use Simplified Clean Architecture: this controller delegates directly
/// to IPolicyService without MediatR or CQRS layers. We require the X-Idempotency-Key header on applications
/// to prevent duplicate policy creation during network retries.
/// </summary>
[Authorize, Route("api/v1/policies")]
public sealed class PoliciesController : PolicyControllerBase
{
    private readonly IPolicyService _service;

    public PoliciesController(IPolicyService service) => _service = service;

    /// <summary>
    /// Submits a formal policy application for customer property coverage.
    /// Idempotency ensures that clicking submit multiple times never generates duplicate policy records.
    /// </summary>
    [Authorize(Policy = PolicyAuthorizationPolicies.CustomerAccess)]
    [HttpPost]
    public async Task<ActionResult<ApiResponse<PolicyApplicationResponse>>> Apply(
        [FromHeader(Name = "X-Idempotency-Key")] string idempotencyKey,
        [FromBody] CreatePolicyApplicationRequest request,
        CancellationToken cancellationToken
    )
    {
        var result = await _service.ApplyAsync(request, idempotencyKey, cancellationToken);

        return StatusCode(
            StatusCodes.Status201Created,
            ApiResponse<PolicyApplicationResponse>.Ok(result, "Policy application processed.")
        );
    }


    [Authorize(Policy = PolicyAuthorizationPolicies.CustomerAccess), HttpGet("me")]
    public async Task<ActionResult<ApiResponse<PagedResponse<PolicySummaryResponse>>>> Mine(
        [FromQuery] int page = 1,
        [FromQuery] int pageSize = 20,
        [FromQuery] PolicyStatus? status = null,
        CancellationToken ct = default
    ) => OkEnvelope(await _service.GetMyPoliciesAsync(page, pageSize, status, ct));

    [Authorize(Policy = PolicyAuthorizationPolicies.CustomerAccess), HttpGet("me/insured-properties")]
    public async Task<ActionResult<ApiResponse<IReadOnlyCollection<Guid>>>> InsuredProperties(
        CancellationToken ct = default
    ) => OkEnvelope(await _service.GetMyInsuredPropertyIdsAsync(ct));

    [Authorize(Policy = PolicyAuthorizationPolicies.ReviewPolicies)]
    [HttpGet("search")]
    public async Task<ActionResult<ApiResponse<PagedResponse<StaffPolicySummaryResponse>>>> Search(
        [FromQuery] StaffPolicySearchRequest request,
        CancellationToken ct
    ) => OkEnvelope(await _service.SearchPoliciesAsync(request, ct));

    [Authorize(Policy = PolicyAuthorizationPolicies.ReviewPolicies)]
    [HttpGet("staff/{policyId:guid}")]
    public async Task<ActionResult<ApiResponse<PolicyDetailsResponse>>> StaffDetails(
        Guid policyId,
        CancellationToken ct
    ) => OkEnvelope(await _service.GetStaffPolicyAsync(policyId, ct));

    [Authorize(Policy = PolicyAuthorizationPolicies.ReviewPolicies)]
    [HttpGet("staff/{policyId:guid}/versions")]
    public async Task<
        ActionResult<ApiResponse<IReadOnlyCollection<PolicyVersionResponse>>>
    > StaffVersions(Guid policyId, CancellationToken ct) =>
        OkEnvelope(await _service.GetStaffPolicyVersionsAsync(policyId, ct));

    [Authorize(Policy = PolicyAuthorizationPolicies.ReviewPolicies)]
    [HttpGet("staff/{policyId:guid}/history")]
    public async Task<
        ActionResult<ApiResponse<IReadOnlyCollection<PolicyHistoryResponse>>>
    > StaffHistory(Guid policyId, CancellationToken ct) =>
        OkEnvelope(await _service.GetStaffPolicyHistoryAsync(policyId, ct));

    [HttpGet("{policyId:guid}")]
    public async Task<ActionResult<ApiResponse<PolicyDetailsResponse>>> Details(
        Guid policyId,
        CancellationToken ct
    ) => OkEnvelope(await _service.GetPolicyAsync(policyId, ct));

    [
        Authorize(Policy = PolicyAuthorizationPolicies.CustomerAccess),
        HttpGet("{policyId:guid}/versions")
    ]
    public async Task<
        ActionResult<ApiResponse<IReadOnlyCollection<PolicyVersionResponse>>>
    > Versions(Guid policyId, CancellationToken ct) =>
        OkEnvelope(await _service.GetPolicyVersionsAsync(policyId, ct));

    [
        Authorize(Policy = PolicyAuthorizationPolicies.CustomerAccess),
        HttpGet("{policyId:guid}/history")
    ]
    public async Task<
        ActionResult<ApiResponse<IReadOnlyCollection<PolicyHistoryResponse>>>
    > History(Guid policyId, CancellationToken ct) =>
        OkEnvelope(await _service.GetPolicyHistoryAsync(policyId, ct));

    [
        Authorize(Policy = PolicyAuthorizationPolicies.CustomerAccess),
        HttpGet("{policyId:guid}/cancel-preview")
    ]
    public async Task<ActionResult<ApiResponse<CancellationPreviewResponse>>> CancelPreview(
        Guid policyId,
        CancellationToken ct
    ) => OkEnvelope(await _service.GetCancellationPreviewAsync(policyId, ct));

    [
        Authorize(Policy = PolicyAuthorizationPolicies.CustomerAccess),
        HttpPost("{policyId:guid}/cancel")
    ]
    public async Task<ActionResult<ApiResponse<PolicyMutationResponse>>> Cancel(
        Guid policyId,
        PolicyActionRequest request,
        CancellationToken ct
    ) => OkEnvelope(await _service.CancelAsync(policyId, request, ct));

    [
        Authorize(Policy = PolicyAuthorizationPolicies.ManagePolicies),
        HttpPost("{policyId:guid}/suspend")
    ]
    public async Task<ActionResult<ApiResponse<PolicyMutationResponse>>> Suspend(
        Guid policyId,
        PolicyActionRequest request,
        CancellationToken ct
    ) => OkEnvelope(await _service.SuspendAsync(policyId, request, ct));

    [
        Authorize(Policy = PolicyAuthorizationPolicies.ManagePolicies),
        HttpPost("{policyId:guid}/reactivate")
    ]
    public async Task<ActionResult<ApiResponse<PolicyMutationResponse>>> Reactivate(
        Guid policyId,
        PolicyActionRequest request,
        CancellationToken ct
    ) => OkEnvelope(await _service.ReactivateAsync(policyId, request, ct));

    [
        Authorize(Policy = PolicyAuthorizationPolicies.ManagePolicies),
        HttpPost("{policyId:guid}/expire")
    ]
    public async Task<ActionResult<ApiResponse<PolicyMutationResponse>>> Expire(
        Guid policyId,
        PolicyActionRequest request,
        CancellationToken ct
    ) => OkEnvelope(await _service.ExpireAsync(policyId, request, ct));

    [
        Authorize(Policy = PolicyAuthorizationPolicies.CustomerAccess),
        HttpPost("{policyId:guid}/renew")
    ]
    public async Task<ActionResult<ApiResponse<RenewalResponse>>> Renew(
        Guid policyId,
        RenewPolicyRequest request,
        CancellationToken ct
    )
    {
        var key = Request.Headers["X-Idempotency-Key"].ToString();
        return OkEnvelope(await _service.BeginRenewalAsync(policyId, request, key, ct));
    }

    [
        Authorize(Policy = PolicyAuthorizationPolicies.CustomerAccess),
        HttpPost("{policyId:guid}/endorse")
    ]
    public async Task<ActionResult<ApiResponse<PolicyEndorsementResponse>>> Endorse(
        Guid policyId,
        PolicyEndorsementRequest request,
        CancellationToken ct
    )
    {
        var key = Request.Headers["X-Idempotency-Key"].ToString();
        return OkEnvelope(await _service.EndorsePolicyAsync(policyId, request, key, ct));
    }

    [
        Authorize(Policy = PolicyAuthorizationPolicies.CustomerAccess),
        HttpPost("{policyId:guid}/renewal-estimate")
    ]
    public async Task<ActionResult<ApiResponse<RenewalEstimateResponse>>> RenewalEstimate(
        Guid policyId,
        RenewalEstimateRequest request,
        CancellationToken ct
    ) => OkEnvelope(await _service.EstimateRenewalAsync(policyId, request, ct));
}


using Microsoft.AspNetCore.Mvc;
using PolicyService.API.Contracts;

namespace PolicyService.API.Controllers;

[ApiController]
public abstract class PolicyControllerBase : ControllerBase
{
    protected ActionResult<ApiResponse<T>> OkEnvelope<T>(T data, string message = "") =>
        Ok(ApiResponse<T>.Ok(data, message));
}


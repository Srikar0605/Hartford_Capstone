using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PolicyService.API.Contracts;
using PolicyService.Application.Authorization;
using PolicyService.Application.DTOs.Payments;
using PolicyService.Application.DTOs.Policies;
using PolicyService.Application.Interfaces;

namespace PolicyService.API.Controllers;

[Authorize]
[Route("api/v1/policies")]
public sealed class PolicyPaymentsController : PolicyControllerBase
{
    private readonly IPolicyPaymentService _service;

    public PolicyPaymentsController(IPolicyPaymentService service)
    {
        _service = service;
    }

    [Authorize(Policy = PolicyAuthorizationPolicies.CustomerAccess)]
    [HttpGet("{policyId:guid}/premium-validation")]
    public async Task<ActionResult<ApiResponse<PremiumValidationResponse>>> Validate(
        Guid policyId,
        [FromQuery] Guid authUserId,
        CancellationToken cancellationToken
    )
    {
        var authenticatedUserId = GetAuthenticatedUserId();

        var isAdministrator = User.IsInRole("Administrator");

        if (!isAdministrator && authenticatedUserId != authUserId)
        {
            return Forbid();
        }

        var result = await _service.ValidatePremiumAsync(policyId, authUserId, cancellationToken);

        return OkEnvelope(result);
    }

    [Authorize(Policy = PolicyAuthorizationPolicies.CustomerAccess)]
    [HttpPost("{policyId:guid}/payment-confirmation")]
    public async Task<ActionResult<ApiResponse<PolicyMutationResponse>>> Confirm(
        Guid policyId,
        [FromBody] PaymentConfirmationRequest request,
        CancellationToken cancellationToken
    )
    {
        var result = await _service.ConfirmInitialPaymentAsync(
            policyId,
            request,
            cancellationToken
        );

        return OkEnvelope(result);
    }

    [Authorize(Policy = PolicyAuthorizationPolicies.CustomerAccess)]
    [HttpPost("{policyId:guid}/renewal-payment-confirmation")]
    public async Task<ActionResult<ApiResponse<PolicyMutationResponse>>> ConfirmRenewal(
        Guid policyId,
        [FromBody] PaymentConfirmationRequest request,
        CancellationToken cancellationToken
    )
    {
        var result = await _service.ConfirmRenewalPaymentAsync(
            policyId,
            request,
            cancellationToken
        );

        return OkEnvelope(result);
    }

    private Guid GetAuthenticatedUserId()
    {
        var rawUserId = User.FindFirst("sub")?.Value;

        if (!Guid.TryParse(rawUserId, out var userId))
        {
            throw new InvalidOperationException(
                "The authenticated token does not contain a valid sub claim."
            );
        }

        return userId;
    }
}


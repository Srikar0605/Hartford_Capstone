using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PolicyService.API.Contracts;
using PolicyService.Application.Authorization;
using PolicyService.Application.DTOs.Common;
using PolicyService.Application.DTOs.Plans;
using PolicyService.Application.Interfaces;

namespace PolicyService.API.Controllers;

[Route("api/v1/policies")]
public sealed class PlansController : PolicyControllerBase
{
    private readonly IPlanService _service;

    public PlansController(IPlanService service) => _service = service;

    [AllowAnonymous, HttpGet("plans")]
    public async Task<
        ActionResult<ApiResponse<IReadOnlyCollection<PlanSummaryResponse>>>
    > GetActive(CancellationToken ct) => OkEnvelope(await _service.GetActivePlansAsync(ct));

    [AllowAnonymous, HttpGet("plans/{planId:guid}")]
    public async Task<ActionResult<ApiResponse<PlanDetailsResponse>>> GetDetails(
        Guid planId,
        CancellationToken ct
    ) => OkEnvelope(await _service.GetPlanDetailsAsync(planId, ct));

    [Authorize(Policy = PolicyAuthorizationPolicies.ManagePlans), HttpGet("admin/plans")]
    public async Task<ActionResult<ApiResponse<PagedResponse<PlanAdministrationResponse>>>> Search(
        [FromQuery] PlanSearchRequest request,
        CancellationToken ct
    ) => OkEnvelope(await _service.SearchPlansAsync(request, ct));

    [Authorize(Policy = PolicyAuthorizationPolicies.ManagePlans), HttpPost("plans")]
    public async Task<ActionResult<ApiResponse<PlanAdministrationResponse>>> Create(
        CreatePlanRequest request,
        CancellationToken ct
    )
    {
        var result = await _service.CreatePlanAsync(request, ct);
        return CreatedAtAction(
            nameof(GetDetails),
            new { planId = result.PlanId },
            ApiResponse<PlanAdministrationResponse>.Ok(result, "Insurance Plan created.")
        );
    }

    [Authorize(Policy = PolicyAuthorizationPolicies.ManagePlans), HttpPut("plans/{planId:guid}")]
    public async Task<ActionResult<ApiResponse<PlanAdministrationResponse>>> Update(
        Guid planId,
        UpdatePlanRequest request,
        CancellationToken ct
    ) => OkEnvelope(await _service.UpdatePlanAsync(planId, request, ct), "Insurance Plan updated.");

    [
        Authorize(Policy = PolicyAuthorizationPolicies.ManagePlans),
        HttpPost("plans/{planId:guid}/activate")
    ]
    public async Task<ActionResult<ApiResponse<PlanAdministrationResponse>>> Activate(
        Guid planId,
        RowVersionRequest request,
        CancellationToken ct
    ) =>
        OkEnvelope(
            await _service.ActivatePlanAsync(planId, request, ct),
            "Insurance Plan activated."
        );

    [
        Authorize(Policy = PolicyAuthorizationPolicies.ManagePlans),
        HttpPost("plans/{planId:guid}/deactivate")
    ]
    public async Task<ActionResult<ApiResponse<PlanAdministrationResponse>>> Deactivate(
        Guid planId,
        RowVersionRequest request,
        CancellationToken ct
    ) =>
        OkEnvelope(
            await _service.DeactivatePlanAsync(planId, request, ct),
            "Insurance Plan deactivated."
        );

    [
        Authorize(Policy = PolicyAuthorizationPolicies.ManagePlans),
        HttpPut("plans/{planId:guid}/coverages")
    ]
    public async Task<ActionResult<ApiResponse<PlanDetailsResponse>>> ReplaceCoverages(
        Guid planId,
        ReplacePlanCoveragesRequest request,
        CancellationToken ct
    ) =>
        OkEnvelope(
            await _service.ReplacePlanCoveragesAsync(planId, request, ct),
            "Plan Coverages replaced."
        );
}


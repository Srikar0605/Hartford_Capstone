using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PolicyService.API.Contracts;
using PolicyService.Application.Authorization;
using PolicyService.Application.DTOs.Quotes;
using PolicyService.Application.Interfaces;

namespace PolicyService.API.Controllers;

[Route("api/v1/policies")]
public sealed class QuotesController : PolicyControllerBase
{
    private readonly IQuoteService _service;

    public QuotesController(IQuoteService service) => _service = service;

    [AllowAnonymous, HttpPost("quote")]
    public async Task<ActionResult<ApiResponse<QuoteResponse>>> Quote(
        CalculateQuoteRequest request,
        CancellationToken ct
    ) => OkEnvelope(await _service.CalculateQuoteAsync(request, ct));

    [AllowAnonymous, HttpPost("recommendations")]
    public async Task<ActionResult<ApiResponse<IReadOnlyCollection<QuoteResponse>>>> Recommendations(
        CalculateRecommendationsRequest request,
        CancellationToken ct
    ) => OkEnvelope(await _service.CalculateRecommendationsAsync(request, ct));

    [Authorize(Roles = PolicyRoles.Customer), HttpPost("customer-quote")]
    public async Task<ActionResult<ApiResponse<QuoteResponse>>> CustomerQuote(
        CustomerQuoteRequest request,
        CancellationToken ct
    ) => OkEnvelope(await _service.CalculateCustomerQuoteAsync(request, ct));
}


using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PolicyService.API.Contracts;
using PolicyService.Application.Authorization;
using PolicyService.Application.DTOs.Validation;
using PolicyService.Application.Interfaces;

namespace PolicyService.API.Controllers;

[Authorize(Policy = PolicyAuthorizationPolicies.ClaimsValidation), Route("api/v1/policies")]
public sealed class PolicyValidationController : PolicyControllerBase
{
    private readonly IPolicyValidationService _service;

    public PolicyValidationController(IPolicyValidationService service) => _service = service;

    [HttpGet("{policyId:guid}/validation")]
    public async Task<ActionResult<ApiResponse<PolicyValidationResponse>>> Validate(
        Guid policyId,
        [FromQuery] Guid authUserId,
        CancellationToken ct
    ) => OkEnvelope(await _service.ValidatePolicyAsync(policyId, authUserId, ct));

    [HttpGet("{policyId:guid}/coverage/{coverageTypeId:guid}/validation")]
    public async Task<ActionResult<ApiResponse<CoverageValidationResponse>>> ValidateCoverage(
        Guid policyId,
        Guid coverageTypeId,
        CancellationToken ct
    ) => OkEnvelope(await _service.ValidateCoverageAsync(policyId, coverageTypeId, ct));

    [HttpGet("{policyId:guid}/coverage/{coverageTypeId:guid}/balance")]
    public async Task<ActionResult<ApiResponse<CoverageBalanceResponse>>> Balance(
        Guid policyId,
        Guid coverageTypeId,
        CancellationToken ct
    ) => OkEnvelope(await _service.GetCoverageBalanceAsync(policyId, coverageTypeId, ct));
}


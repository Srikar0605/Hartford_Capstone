using System.Security.Claims;
using System.Threading.RateLimiting;
using Microsoft.AspNetCore.RateLimiting;
using PolicyService.API.Contracts;

namespace PolicyService.API.Extensions;

/// <summary>
/// Rate limiting for the public ShieldBot chat endpoint.
/// The endpoint is anonymous and every request costs a language-model call, so each caller gets a
/// small fixed budget per minute: signed-in users are counted by user id, guests by IP address.
/// Uses the rate limiter that ships with ASP.NET Core 8, so no extra package is needed.
/// </summary>
public static class ChatRateLimiting
{
    public const string PolicyName = "shieldbot-chat";

    private const int SignedInRequestsPerMinute = 20;
    private const int GuestRequestsPerMinute = 8;

    public static IServiceCollection AddChatRateLimiting(this IServiceCollection services)
    {
        services.AddRateLimiter(options =>
        {
            options.RejectionStatusCode = StatusCodes.Status429TooManyRequests;

            options.AddPolicy(PolicyName, httpContext =>
            {
                var userId =
                    httpContext.User.FindFirstValue("sub")
                    ?? httpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);

                if (!string.IsNullOrWhiteSpace(userId))
                {
                    return RateLimitPartition.GetFixedWindowLimiter(
                        $"user:{userId}",
                        _ => new FixedWindowRateLimiterOptions
                        {
                            PermitLimit = SignedInRequestsPerMinute,
                            Window = TimeSpan.FromMinutes(1),
                            QueueLimit = 0,
                        }
                    );
                }

                var ip = httpContext.Connection.RemoteIpAddress?.ToString() ?? "unknown";
                return RateLimitPartition.GetFixedWindowLimiter(
                    $"ip:{ip}",
                    _ => new FixedWindowRateLimiterOptions
                    {
                        PermitLimit = GuestRequestsPerMinute,
                        Window = TimeSpan.FromMinutes(1),
                        QueueLimit = 0,
                    }
                );
            });

            options.OnRejected = async (context, ct) =>
            {
                if (context.Lease.TryGetMetadata(MetadataName.RetryAfter, out var retryAfter))
                {
                    context.HttpContext.Response.Headers.RetryAfter = ((int)retryAfter.TotalSeconds).ToString();
                }

                await context.HttpContext.Response.WriteAsJsonAsync(
                    ApiErrorResponse.Create(
                        "CHAT_RATE_LIMITED",
                        "You're sending messages too quickly. Please wait a moment and try again.",
                        context.HttpContext.TraceIdentifier
                    ),
                    ct
                );
            };
        });

        return services;
    }
}

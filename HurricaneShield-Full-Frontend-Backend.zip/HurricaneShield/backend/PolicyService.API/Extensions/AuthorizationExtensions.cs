using Microsoft.AspNetCore.Authorization;
using PolicyService.Application.Authorization;

namespace PolicyService.API.Extensions;

public static class AuthorizationExtensions
{
    public static IServiceCollection AddPolicyAuthorization(this IServiceCollection services)
    {
        services.AddAuthorization(options =>
        {
            options.AddPolicy(
                PolicyAuthorizationPolicies.CustomerAccess,
                p => p.RequireRole(PolicyRoles.Customer, PolicyRoles.Administrator)
            );
            options.AddPolicy(
                PolicyAuthorizationPolicies.StaffRead,
                p =>
                    p.RequireRole(
                        PolicyRoles.Agent,
                        PolicyRoles.ClaimsManager,
                        PolicyRoles.Administrator
                    )
            );
            options.AddPolicy(
                PolicyAuthorizationPolicies.ManagePlans,
                p => RequirePermissionOrAdmin(p, PolicyPermissions.ManagePlans)
            );
            options.AddPolicy(
                PolicyAuthorizationPolicies.ManagePolicies,
                p => RequirePermissionOrAdmin(p, PolicyPermissions.ManagePolicies)
            );
            options.AddPolicy(
                PolicyAuthorizationPolicies.ReviewPolicies,
                p => RequirePermissionOrAdmin(p, PolicyPermissions.ReviewPolicies)
            );
            options.AddPolicy(
                PolicyAuthorizationPolicies.ApprovePolicies,
                p => RequirePermissionOrAdmin(p, PolicyPermissions.ApprovePolicies)
            );
            options.AddPolicy(
                PolicyAuthorizationPolicies.RejectPolicies,
                p => RequirePermissionOrAdmin(p, PolicyPermissions.RejectPolicies)
            );
            options.AddPolicy(
                PolicyAuthorizationPolicies.ConfirmPayments,
                p => RequirePermissionOrAdmin(p, PolicyPermissions.ConfirmPolicyPayments)
            );
            options.AddPolicy(
                PolicyAuthorizationPolicies.ClaimsValidation,
                p =>
                    p.RequireRole(
                        PolicyRoles.Customer,
                        PolicyRoles.ClaimsManager,
                        PolicyRoles.Administrator
                    )
            );
        });
        return services;
    }

    private static void RequirePermissionOrAdmin(
        AuthorizationPolicyBuilder policy,
        string permission
    )
    {
        policy.RequireAuthenticatedUser();
        policy.RequireAssertion(context =>
            context.User.IsInRole(PolicyRoles.Administrator)
            || context.User.HasClaim("permissions", permission)
        );
    }
}


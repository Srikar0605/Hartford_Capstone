namespace PolicyService.API.Contracts;

public sealed record ApiResponse<T>(bool Success, string Message, T Data)
{
    public static ApiResponse<T> Ok(T data, string message = "") => new(true, message, data);
}

public sealed record ApiErrorResponse(
    bool Success,
    string ErrorCode,
    string Message,
    string CorrelationId,
    IReadOnlyDictionary<string, string[]>? Errors = null
)
{
    public static ApiErrorResponse Create(
        string code,
        string message,
        string correlationId,
        IReadOnlyDictionary<string, string[]>? errors = null
    ) => new(false, code, message, correlationId, errors);
}


using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using PolicyService.API.Contracts;
using PolicyService.Domain.Exceptions;
using PolicyService.Infrastructure.Exceptions;

namespace PolicyService.API.Middleware;

public sealed class ExceptionHandlingMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<ExceptionHandlingMiddleware> _logger;

    public ExceptionHandlingMiddleware(
        RequestDelegate next,
        ILogger<ExceptionHandlingMiddleware> logger
    )
    {
        _next = next;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            await _next(context);
        }
        catch (Exception exception)
        {
            var (status, code, message) = exception switch
            {
                PolicyServiceException x => (x.StatusCode, x.ErrorCode, x.Message),
                DomainRuleException x => (
                    StatusCodes.Status409Conflict,
                    "POLICY_INVALID_STATUS_TRANSITION",
                    x.Message
                ),
                DbUpdateConcurrencyException => (
                    StatusCodes.Status409Conflict,
                    "CONCURRENCY_CONFLICT",
                    "The record changed after it was loaded."
                ),
                OperationCanceledException when context.RequestAborted.IsCancellationRequested => (
                    499,
                    "REQUEST_CANCELLED",
                    "The request was cancelled."
                ),
                _ => (
                    StatusCodes.Status500InternalServerError,
                    "INTERNAL_SERVER_ERROR",
                    "An unexpected error occurred."
                ),
            };
            if (status >= 500)
                _logger.LogError(
                    exception,
                    "Policy API request failed. CorrelationId: {CorrelationId}",
                    context.TraceIdentifier
                );
            else
                _logger.LogWarning(
                    exception,
                    "Policy API request rejected. CorrelationId: {CorrelationId}",
                    context.TraceIdentifier
                );
            context.Response.StatusCode = status;
            context.Response.ContentType = "application/json";
            await context.Response.WriteAsync(
                JsonSerializer.Serialize(
                    ApiErrorResponse.Create(code, message, context.TraceIdentifier),
                    new JsonSerializerOptions(JsonSerializerDefaults.Web)
                )
            );
        }
    }
}


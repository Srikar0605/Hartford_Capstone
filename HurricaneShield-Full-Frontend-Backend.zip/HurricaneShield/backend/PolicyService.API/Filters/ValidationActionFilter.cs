using FluentValidation;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using PolicyService.API.Contracts;

namespace PolicyService.API.Filters;

public sealed class ValidationActionFilter : IAsyncActionFilter
{
    private readonly IServiceProvider _services;

    public ValidationActionFilter(IServiceProvider services) => _services = services;

    public async Task OnActionExecutionAsync(
        ActionExecutingContext context,
        ActionExecutionDelegate next
    )
    {
        var failures = new Dictionary<string, List<string>>(StringComparer.OrdinalIgnoreCase);
        foreach (var argument in context.ActionArguments.Values.Where(value => value is not null))
        {
            var validatorType = typeof(IValidator<>).MakeGenericType(argument!.GetType());
            if (_services.GetService(validatorType) is not IValidator validator)
                continue;
            var result = await validator.ValidateAsync(
                new ValidationContext<object>(argument),
                context.HttpContext.RequestAborted
            );
            foreach (var error in result.Errors)
            {
                if (!failures.TryGetValue(error.PropertyName, out var messages))
                {
                    messages = new();
                    failures[error.PropertyName] = messages;
                }
                messages.Add(error.ErrorMessage);
            }
        }
        if (failures.Count > 0)
        {
            context.Result = new BadRequestObjectResult(
                ApiErrorResponse.Create(
                    "VALIDATION_ERROR",
                    "Validation failed for request payload.",
                    context.HttpContext.TraceIdentifier,
                    failures.ToDictionary(x => x.Key, x => x.Value.Distinct().ToArray())
                )
            );
            return;
        }
        await next();
    }
}


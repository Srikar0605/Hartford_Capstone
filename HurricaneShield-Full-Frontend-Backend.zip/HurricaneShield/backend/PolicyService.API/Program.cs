using System.Security.Claims;
using System.Text;
using System.Text.Json.Serialization;
using FluentValidation;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using PolicyService.API.Contracts;
using PolicyService.API.Extensions;
using PolicyService.API.Filters;
using PolicyService.API.Middleware;
using PolicyService.Application.Validation;
using PolicyService.Infrastructure;
using PolicyService.Infrastructure.Persistence;

var builder = WebApplication.CreateBuilder(args);
var jwtSection = builder.Configuration.GetSection("Jwt");
var signingKey =
    jwtSection["SigningKey"] ?? throw new InvalidOperationException("Jwt:SigningKey is required.");

builder
    .Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.MapInboundClaims = false;

        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidIssuer = jwtSection["Issuer"],
            ValidateAudience = true,
            ValidAudience = jwtSection["Audience"],
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(signingKey)),
            ValidateLifetime = true,
            ClockSkew = TimeSpan.Zero,
            NameClaimType = "sub",
            RoleClaimType = "role",
        };
        options.Events = new JwtBearerEvents
        {
            OnChallenge = async context =>
            {
                context.HandleResponse();
                context.Response.StatusCode = 401;
                context.Response.ContentType = "application/json";
                await context.Response.WriteAsJsonAsync(
                    ApiErrorResponse.Create(
                        "AUTH_INVALID_TOKEN",
                        "Authentication is required.",
                        context.HttpContext.TraceIdentifier
                    )
                );
            },
            OnForbidden = async context =>
            {
                context.Response.StatusCode = 403;
                context.Response.ContentType = "application/json";
                await context.Response.WriteAsJsonAsync(
                    ApiErrorResponse.Create(
                        "AUTH_FORBIDDEN",
                        "The authenticated user is not authorized for this operation.",
                        context.HttpContext.TraceIdentifier
                    )
                );
            },
        };
    });

builder.Services.AddPolicyAuthorization();
builder.Services.AddPolicyInfrastructure(builder.Configuration);
builder.Services.AddValidatorsFromAssemblyContaining<CreatePlanRequestValidator>();
builder.Services.AddScoped<ValidationActionFilter>();
builder.Services.AddChatRateLimiting();
builder
    .Services.AddControllers(options => options.Filters.AddService<ValidationActionFilter>())
    .AddJsonOptions(options =>
        options.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter())
    );
builder.Services.AddPolicySwagger();
builder.Services.AddHealthChecks().AddDbContextCheck<PolicyDbContext>("policy-database");

var app = builder.Build();
app.UseMiddleware<CorrelationIdMiddleware>();
app.UseMiddleware<ExceptionHandlingMiddleware>();
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
app.UseHttpsRedirection();
app.UseAuthentication();
app.UseRateLimiter();
app.UseAuthorization();
app.MapControllers();
app.MapHealthChecks("/health");
app.MapHealthChecks(
    "/health/database",
    new Microsoft.AspNetCore.Diagnostics.HealthChecks.HealthCheckOptions
    {
        Predicate = registration => registration.Name == "policy-database",
    }
);
app.Run();

public partial class Program { }


using System.Net.Http.Headers;
using Microsoft.AspNetCore.Http;

namespace ClaimsService.Infrastructure.Clients;

public sealed class ForwardingHandler(IHttpContextAccessor accessor) : DelegatingHandler
{
    protected override Task<HttpResponseMessage> SendAsync(
        HttpRequestMessage request,
        CancellationToken ct
    )
    {
        var h = accessor.HttpContext?.Request.Headers;
        if (h is not null && h.TryGetValue("Authorization", out var auth))
            request.Headers.Authorization = AuthenticationHeaderValue.Parse(auth!);
        var correlation = accessor.HttpContext?.TraceIdentifier;
        if (!string.IsNullOrWhiteSpace(correlation))
            request.Headers.TryAddWithoutValidation("X-Correlation-Id", correlation);
        return base.SendAsync(request, ct);
    }
}


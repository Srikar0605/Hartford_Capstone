using System.Net;
using System.Net.Http.Json;
using ClaimsService.Application.DTOs.Integrations;
using ClaimsService.Application.Interfaces;
using ClaimsService.Infrastructure.Exceptions;
using Shared.Common.Responses;

namespace ClaimsService.Infrastructure.Clients;

public sealed class CustomerClient(HttpClient http) : ICustomerClient
{
    public async Task<CustomerValidationResponse> ValidateCustomerAsync(
        Guid customerId,
        Guid authUserId,
        CancellationToken ct
    ) =>
        await Get<CustomerValidationResponse>(
            $"api/v1/customers/{customerId}/validation?authUserId={authUserId}",
            ct
        );

    // Fixed: Added generic type constraint 'where T : class'
    private async Task<T> Get<T>(string u, CancellationToken ct)
        where T : class
    {
        try
        {
            var r = await http.GetAsync(u, ct);
            if (r.StatusCode == HttpStatusCode.NotFound)
                throw ClaimsServiceException.NotFound("CUSTOMER_NOT_FOUND", "Customer not found.");

            if (!r.IsSuccessStatusCode)
                throw ClaimsServiceException.Unavailable("Customer Service");

            var envelope = await r.Content.ReadFromJsonAsync<ApiResponse<T>>(cancellationToken: ct);
            return envelope?.Data ?? throw ClaimsServiceException.Unavailable("Customer Service");
        }
        catch (HttpRequestException)
        {
            throw ClaimsServiceException.Unavailable("Customer Service");
        }
    }
}

public sealed class PolicyClient(HttpClient http) : IPolicyClient
{
    public Task<PolicyValidationResponse> ValidatePolicyAsync(
        Guid p,
        Guid u,
        CancellationToken ct
    ) => Get<PolicyValidationResponse>($"api/v1/policies/{p}/validation?authUserId={u}", ct);

    public Task<CoverageValidationResponse> ValidateCoverageAsync(
        Guid p,
        Guid c,
        CancellationToken ct
    ) => Get<CoverageValidationResponse>($"api/v1/policies/{p}/coverage/{c}/validation", ct);

    public Task<CoverageBalanceResponse> GetCoverageBalanceAsync(
        Guid p,
        Guid c,
        CancellationToken ct
    ) => Get<CoverageBalanceResponse>($"api/v1/policies/{p}/coverage/{c}/balance", ct);

    // Fixed: Added generic type constraint 'where T : class'
    private async Task<T> Get<T>(string u, CancellationToken ct)
        where T : class
    {
        try
        {
            var r = await http.GetAsync(u, ct);
            if (r.StatusCode == HttpStatusCode.NotFound)
                throw ClaimsServiceException.NotFound(
                    "POLICY_NOT_FOUND",
                    "Policy resource not found."
                );

            if (!r.IsSuccessStatusCode)
                throw ClaimsServiceException.Unavailable("Policy Service");

            var envelope = await r.Content.ReadFromJsonAsync<ApiResponse<T>>(cancellationToken: ct);
            return envelope?.Data ?? throw ClaimsServiceException.Unavailable("Policy Service");
        }
        catch (HttpRequestException)
        {
            throw ClaimsServiceException.Unavailable("Policy Service");
        }
    }
}

public sealed class PaymentClient(HttpClient httpClient) : IPaymentClient
{
    public async Task<PaymentSettlementResponse> CreateSettlementAsync(
        CreateSettlementPaymentRequest request,
        CancellationToken cancellationToken
    )
    {
        try
        {
            using var message = new HttpRequestMessage(
                HttpMethod.Post,
                "api/v1/payments/settlements"
            )
            {
                Content = JsonContent.Create(request),
            };

            message.Headers.TryAddWithoutValidation("X-Idempotency-Key", request.IdempotencyKey);

            using var response = await httpClient.SendAsync(message, cancellationToken);

            if (!response.IsSuccessStatusCode)
            {
                throw ClaimsServiceException.Unavailable("Payment Service");
            }

            var envelope = await response.Content.ReadFromJsonAsync<
                ApiResponse<PaymentSettlementResponse>
            >(cancellationToken: cancellationToken);

            if (envelope is null || !envelope.Success || envelope.Data is null)
            {
                throw ClaimsServiceException.Unavailable("Payment Service");
            }

            return envelope.Data;
        }
        catch (ClaimsServiceException)
        {
            throw;
        }
        catch (HttpRequestException)
        {
            throw ClaimsServiceException.Unavailable("Payment Service");
        }
        catch (TaskCanceledException) when (!cancellationToken.IsCancellationRequested)
        {
            throw ClaimsServiceException.Unavailable("Payment Service");
        }
    }
}


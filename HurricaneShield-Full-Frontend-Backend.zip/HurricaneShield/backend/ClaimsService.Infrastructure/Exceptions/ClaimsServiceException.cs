using Shared.Common.Exceptions;

namespace ClaimsService.Infrastructure.Exceptions;

public sealed class ClaimsServiceException : AppException
{
    public ClaimsServiceException(string errorCode, string message, int statusCode)
        : base(statusCode, errorCode, message) { }

    public static ClaimsServiceException NotFound(string code, string message) =>
        new(code, message, 404);

    public static ClaimsServiceException Conflict(string code, string message) =>
        new(code, message, 409);

    public static ClaimsServiceException Unprocessable(string code, string message) =>
        new(code, message, 422);

    public static ClaimsServiceException Unavailable(string service) =>
        new("SERVICE_UNAVAILABLE", $"{service} is unavailable.", 503);
}


namespace ClaimsService.Infrastructure.Configuration;

public sealed class ServiceEndpointSettings
{
    public string BaseUrl { get; set; } = string.Empty;
    public int TimeoutSeconds { get; set; } = 5;
}

public sealed class ClaimsFileSettings
{
    public string UploadRoot { get; set; } = "App_Data/Claims";
    public long MaximumFileSizeBytes { get; set; } = 10 * 1024 * 1024;
    public string[] AllowedExtensions { get; set; } = [".pdf", ".png", ".jpg", ".jpeg"];
}


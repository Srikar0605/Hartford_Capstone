using ClaimsService.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace ClaimsService.Infrastructure.Persistence;

public sealed class ClaimsDbContext(DbContextOptions<ClaimsDbContext> options) : DbContext(options)
{
    public DbSet<Claim> Claims => Set<Claim>();
    public DbSet<ClaimTimeline> ClaimTimelines => Set<ClaimTimeline>();
    public DbSet<ClaimDocument> ClaimDocuments => Set<ClaimDocument>();
    public DbSet<ClaimDocumentVerification> ClaimDocumentVerifications =>
        Set<ClaimDocumentVerification>();
    public DbSet<ClaimReview> ClaimReviews => Set<ClaimReview>();
    public DbSet<ClaimNote> ClaimNotes => Set<ClaimNote>();
    public DbSet<AiClaimTriage> AiClaimTriages => Set<AiClaimTriage>();
    public DbSet<IdempotencyRecord> IdempotencyRecords => Set<IdempotencyRecord>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        b.ApplyConfigurationsFromAssembly(typeof(ClaimsDbContext).Assembly);
    }
}


using ClaimsService.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace ClaimsService.Infrastructure.Persistence.Configurations;

/// <summary>
/// EF Core mappings for Claims entities.
/// I configured database-level integrity constraints here, including:
/// 1. Check constraints on positive claim amount and maximum 10MB document file size.
/// 2. Filtered unique index on SettlementTransactionId to prevent double-settlement.
/// 3. Strict DeleteBehavior.Restrict across all navigation relationships to prevent cascade deletions.
/// </summary>
internal sealed class ClaimConfiguration : IEntityTypeConfiguration<Claim>
{
    public void Configure(EntityTypeBuilder<Claim> b)
    {
        b.ToTable(
            "Claims",
            table =>
            {
                table.HasCheckConstraint("CK_Claims_ClaimAmount", "[ClaimAmount] > 0");
            }
        );
        b.HasKey(x => x.Id);
        b.Property(x => x.ClaimNumber).HasMaxLength(50).IsRequired();
        b.HasIndex(x => x.ClaimNumber).IsUnique();
        b.Property(x => x.CoverageTypeName).HasMaxLength(150).IsRequired();
        b.Property(x => x.Status).HasConversion<string>().HasMaxLength(30);
        b.Property(x => x.ClaimAmount).HasPrecision(18, 2);
        b.Property(x => x.IncidentDescription).HasMaxLength(2000);
        b.Property(x => x.CreatedBy).HasMaxLength(200);
        b.Property(x => x.UpdatedBy).HasMaxLength(200);
        b.Property(x => x.DeletedBy).HasMaxLength(200);
        b.Property(x => x.RowVersion).IsRowVersion();
        b.HasIndex(x => new { x.AuthUserId, x.Status });
        b.HasIndex(x => x.PolicyId);
        b.HasIndex(x => new { x.CreatedAt, x.Id }).IsDescending(true, false);
        b.HasQueryFilter(x => !x.IsDeleted);

        // Filtered unique index ensuring that a settlement transaction ID is uniquely tied to at most one claim.
        b.HasIndex(x => x.SettlementTransactionId)
            .IsUnique()
            .HasFilter("[SettlementTransactionId] IS NOT NULL");
        b.Property(claim => claim.CustomerDisplayName).HasMaxLength(200).IsRequired();

        b.Property(claim => claim.CustomerEmail).HasMaxLength(320).IsRequired();

        b.Property(claim => claim.PolicyNumber).HasMaxLength(50).IsRequired();

        b.Property(x => x.AssessedAmount).HasPrecision(18, 2);
        b.Property(x => x.ApprovedAmount).HasPrecision(18, 2);
        b.Property(x => x.DeductibleApplied).HasPrecision(18, 2);
        b.Property(x => x.AdjustmentReason).HasMaxLength(1000);
    }
}


internal sealed class TimelineConfiguration : IEntityTypeConfiguration<ClaimTimeline>
{
    public void Configure(EntityTypeBuilder<ClaimTimeline> b)
    {
        b.ToTable("ClaimTimelines");
        b.HasKey(x => x.Id);
        b.Property(x => x.FromStatus).HasConversion<string>().HasMaxLength(30);
        b.Property(x => x.ToStatus).HasConversion<string>().HasMaxLength(30);
        b.Property(x => x.Notes).HasMaxLength(1000);
        b.Property(x => x.ChangedBy).HasMaxLength(200);
        b.Property(x => x.CorrelationId).HasMaxLength(100);
        b.HasIndex(x => new { x.ClaimId, x.ChangedAt });
        b.HasOne<Claim>()
            .WithMany()
            .HasForeignKey(x => x.ClaimId)
            .OnDelete(DeleteBehavior.Restrict);
    }
}

internal sealed class DocumentConfiguration : IEntityTypeConfiguration<ClaimDocument>
{
    public void Configure(EntityTypeBuilder<ClaimDocument> b)
    {
        b.ToTable(
            "ClaimDocuments",
            table =>
            {
                table.HasCheckConstraint(
                    "CK_ClaimDocuments_FileSize",
                    "[FileSize] > 0 AND [FileSize] <= 10485760"
                );
            }
        );
        b.HasKey(x => x.Id);
        b.Property(x => x.FileName).HasMaxLength(260);
        b.Property(x => x.ContentType).HasMaxLength(100);
        b.Property(x => x.FilePath).HasMaxLength(1000);
        b.Property(x => x.DocumentType).HasMaxLength(100);
        b.Property(x => x.UploadedBy).HasMaxLength(200);
        b.HasIndex(x => new { x.ClaimId, x.UploadedAt });
        b.HasOne<Claim>()
            .WithMany()
            .HasForeignKey(x => x.ClaimId)
            .OnDelete(DeleteBehavior.Restrict);
    }
}

internal sealed class VerificationConfiguration
    : IEntityTypeConfiguration<ClaimDocumentVerification>
{
    public void Configure(EntityTypeBuilder<ClaimDocumentVerification> builder)
    {
        builder.ToTable("ClaimDocumentVerifications");

        builder.HasKey(x => x.Id);

        builder.Property(x => x.Status).HasConversion<string>().HasMaxLength(30).IsRequired();

        builder.Property(x => x.Notes).HasMaxLength(1000);

        builder.Property(x => x.VerifiedBy).HasMaxLength(200);

        builder.HasIndex(x => x.ClaimDocumentId).IsUnique();

        builder
            .HasOne<ClaimDocument>()
            .WithOne()
            .HasForeignKey<ClaimDocumentVerification>(x => x.ClaimDocumentId)
            .OnDelete(DeleteBehavior.Restrict);
    }
}

internal sealed class ReviewConfiguration : IEntityTypeConfiguration<ClaimReview>
{
    public void Configure(EntityTypeBuilder<ClaimReview> b)
    {
        b.ToTable("ClaimReviews");
        b.HasKey(x => x.Id);
        b.Property(x => x.Decision).HasConversion<string>().HasMaxLength(30);
        b.Property(x => x.Notes).HasMaxLength(1000);
        b.Property(x => x.CreatedBy).HasMaxLength(200);
        b.Property(x => x.UpdatedBy).HasMaxLength(200);
        b.Property(x => x.DeletedBy).HasMaxLength(200);
        b.Property(x => x.RowVersion).IsRowVersion();
        b.HasIndex(x => x.ClaimId).IsUnique();
        b.HasIndex(x => x.ReviewerUserId);
        b.HasQueryFilter(x => !x.IsDeleted);
        b.HasOne<Claim>()
            .WithMany()
            .HasForeignKey(x => x.ClaimId)
            .OnDelete(DeleteBehavior.Restrict);
    }
}

internal sealed class NoteConfiguration : IEntityTypeConfiguration<ClaimNote>
{
    public void Configure(EntityTypeBuilder<ClaimNote> b)
    {
        b.ToTable("ClaimNotes");
        b.HasKey(x => x.Id);
        b.Property(x => x.NoteType).HasConversion<string>().HasMaxLength(50);
        b.Property(x => x.NoteText).HasMaxLength(2000);
        b.Property(x => x.CreatedBy).HasMaxLength(200);
        b.HasIndex(x => new { x.ClaimId, x.CreatedAt });
        b.HasOne<Claim>()
            .WithMany()
            .HasForeignKey(x => x.ClaimId)
            .OnDelete(DeleteBehavior.Restrict);
    }
}

internal sealed class IdempotencyConfiguration : IEntityTypeConfiguration<IdempotencyRecord>
{
    public void Configure(EntityTypeBuilder<IdempotencyRecord> b)
    {
        b.ToTable("IdempotencyRecords");
        b.HasKey(x => x.Id);
        b.Property(x => x.Operation).HasConversion<string>().HasMaxLength(50);
        b.Property(x => x.Key).HasMaxLength(200);
        b.Property(x => x.RequestHash).HasMaxLength(128);
        b.Property(x => x.ResponseBody).HasColumnType("nvarchar(max)");
        b.HasIndex(x => new { x.Operation, x.Key }).IsUnique();
        b.HasIndex(x => x.ExpiresAt);
    }
}

internal sealed class AiClaimTriageConfiguration : IEntityTypeConfiguration<AiClaimTriage>
{
    public void Configure(EntityTypeBuilder<AiClaimTriage> b)
    {
        b.ToTable("AiClaimTriages");
        b.HasKey(x => x.Id);
        b.Property(x => x.Id).ValueGeneratedNever();
        b.Property(x => x.ClaimId).IsRequired();
        b.Property(x => x.FraudFlagsJson).HasColumnType("nvarchar(max)");
        b.Property(x => x.ComplexityScore).IsRequired();
        b.Property(x => x.Summary).HasMaxLength(2000).IsRequired();
        b.Property(x => x.Recommendation).HasMaxLength(100).IsRequired();
        b.Property(x => x.AiConfidence).HasPrecision(5, 2);
        b.Property(x => x.TriagedAt).IsRequired();
        b.Property(x => x.Engine).HasMaxLength(30);

        b.HasOne(x => x.Claim)
            .WithOne(c => c.AiTriage)
            .HasForeignKey<AiClaimTriage>(x => x.ClaimId)
            .IsRequired(false)
            .OnDelete(DeleteBehavior.Restrict);
    }
}


using ClaimsService.Application.DTOs.Documents;
using ClaimsService.Application.Interfaces;
using ClaimsService.Domain.Entities;
using ClaimsService.Domain.Enums;
using ClaimsService.Infrastructure.Exceptions;
using ClaimsService.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace ClaimsService.Infrastructure.Services;

public sealed class ClaimDocumentService(
    ClaimsDbContext db,
    IRequestContext ctx,
    IDateTimeProvider clock,
    IClaimFileStorage storage
) : IClaimDocumentService
{
    public async Task<ClaimDocumentResponse> UploadAsync(
        Guid claimId,
        UploadClaimDocumentRequest r,
        CancellationToken ct
    )
    {
        var claim = await Owned(claimId, ct);
        var path = await storage.SaveAsync(claimId, r.FileName, r.ContentType, r.Content, ct);
        var d = ClaimDocument.Create(
            claimId,
            r.FileName,
            r.ContentType,
            r.FileSize,
            path,
            r.DocumentType,
            clock.UtcNow,
            ctx.Actor
        );
        var v = ClaimDocumentVerification.CreatePending(d.Id);
        db.AddRange(d, v);
        await ServiceSupport.Save(db, ct);
        return Map(d, v);
    }

    public async Task<IReadOnlyCollection<ClaimDocumentResponse>> GetDocumentsAsync(
        Guid id,
        CancellationToken ct
    )
    {
        await Owned(id, ct);

        // 1. Fetch all documents for the claim in a single query
        var docs = await db
            .ClaimDocuments.AsNoTracking()
            .Where(x => x.ClaimId == id)
            .OrderBy(x => x.UploadedAt)
            .ThenBy(x => x.Id)
            .ToArrayAsync(ct);

        if (docs.Length == 0)
        {
            return Array.Empty<ClaimDocumentResponse>();
        }

        // 2. Extract document IDs to bound the next query
        var docIds = docs.Select(x => x.Id).ToArray();

        // 3. Fetch all matching verifications in a single query and group by ClaimDocumentId
        // Note: If you only need the latest verification per document and your DB supports it,
        // an alternative is EF Core projection. This approach pulls the data to memory safely.
        var verifications = await db
            .ClaimDocumentVerifications.AsNoTracking()
            .Where(x => docIds.Contains(x.ClaimDocumentId))
            .OrderByDescending(x => x.VerifiedAt)
            .ToDictionaryAsync(x => x.ClaimDocumentId, ct);

        // 4. Map the results in-memory
        var result = new List<ClaimDocumentResponse>(docs.Length);
        foreach (var d in docs)
        {
            if (verifications.TryGetValue(d.Id, out var v))
            {
                result.Add(Map(d, v));
            }
        }

        return result;
    }

    public async Task<ClaimDocumentContentResponse> DownloadAsync(
        Guid claimId,
        Guid docId,
        CancellationToken ct
    )
    {
        await Owned(claimId, ct);
        var d =
            await db
                .ClaimDocuments.AsNoTracking()
                .SingleOrDefaultAsync(x => x.Id == docId && x.ClaimId == claimId, ct)
            ?? throw ClaimsServiceException.NotFound(
                "CLAIM_DOCUMENT_NOT_FOUND",
                "Document not found."
            );
        return await storage.OpenReadAsync(d.FilePath, d.FileName, d.ContentType, ct);
    }

    public async Task<DocumentVerificationResponse> VerifyAsync(
        Guid claimId,
        Guid docId,
        VerifyClaimDocumentRequest r,
        CancellationToken ct
    )
    {
        var claim =
            await db.Claims.SingleOrDefaultAsync(x => x.Id == claimId, ct)
            ?? throw ClaimsServiceException.NotFound("CLAIM_NOT_FOUND", "Claim not found.");

        ServiceSupport.OriginalRowVersion(db, claim, r.ClaimRowVersion);

        // Force an EF Core update track on the claim
        claim.RecordActivity(clock.UtcNow, ctx.Actor);

        var d =
            await db
                .ClaimDocuments.AsNoTracking()
                .SingleOrDefaultAsync(x => x.Id == docId && x.ClaimId == claimId, ct)
            ?? throw ClaimsServiceException.NotFound(
                "CLAIM_DOCUMENT_NOT_FOUND",
                "Document not found."
            );

        var v = await db.ClaimDocumentVerifications.SingleAsync(x => x.ClaimDocumentId == d.Id, ct);

        if (r.Status == DocumentVerificationStatus.Verified)
        {
            v.Verify(r.Notes, clock.UtcNow, ctx.Actor);
        }
        else
        {
            v.Reject(r.Notes!, clock.UtcNow, ctx.Actor);
        }

        await ServiceSupport.Save(db, ct);

        return new DocumentVerificationResponse(
            d.Id,
            v.Status,
            v.Notes,
            v.VerifiedAt,
            v.VerifiedBy
        );
    }

    private async Task<Claim> Owned(Guid id, CancellationToken ct)
    {
        var c =
            await db.Claims.AsNoTracking().SingleOrDefaultAsync(x => x.Id == id, ct)
            ?? throw ClaimsServiceException.NotFound("CLAIM_NOT_FOUND", "Claim not found.");
        if (
            !ctx.IsInRole("Claims Manager")
            && !ctx.IsInRole("Administrator")
            && c.AuthUserId != ctx.UserId
        )
            throw ClaimsServiceException.NotFound("CLAIM_NOT_FOUND", "Claim not found.");
        return c;
    }

    private static ClaimDocumentResponse Map(ClaimDocument d, ClaimDocumentVerification v) =>
        new(
            d.Id,
            d.ClaimId,
            d.FileName,
            d.ContentType,
            d.FileSize,
            d.DocumentType,
            d.UploadedAt,
            d.UploadedBy,
            v.Status,
            v.Notes,
            v.VerifiedAt,
            v.VerifiedBy
        );
}


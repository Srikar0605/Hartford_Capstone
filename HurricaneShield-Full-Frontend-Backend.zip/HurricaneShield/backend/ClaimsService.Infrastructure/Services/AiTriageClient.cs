﻿using System.Text.Json;
using ClaimsService.Application.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace ClaimsService.Infrastructure.Services;

public sealed class AiTriageClient : IAiTriageClient
{
    private readonly ILogger<AiTriageClient> _logger;
    private readonly IConfiguration _config;
    private readonly HttpClient _httpClient;

    public AiTriageClient(
        ILogger<AiTriageClient> logger,
        IConfiguration config,
        HttpClient httpClient
    )
    {
        _logger = logger;
        _config = config;
        _httpClient = httpClient;
    }

    public async Task<TriageAgentResponse> TriageClaimAsync(
        string incidentDescription,
        decimal claimAmount,
        string coverageTypeName,
        CancellationToken ct = default
    )
    {
        _logger.LogInformation(
            "Triaging Claim with AI Agent. Amount: {Amount}, Coverage: {Coverage}",
            claimAmount,
            coverageTypeName
        );

        var useVertexAi = _config.GetValue<bool>("Gemini:UseVertexAi")
            || string.Equals(Environment.GetEnvironmentVariable("GOOGLE_GENAI_USE_VERTEXAI"), "true", StringComparison.OrdinalIgnoreCase);

        var geminiApiKey = _config["Gemini:ApiKey"] ?? Environment.GetEnvironmentVariable("GEMINI_API_KEY");

        if (useVertexAi)
        {
            try
            {
                return (await CallVertexAiClaimsAsync(incidentDescription, claimAmount, coverageTypeName, ct)) with { Engine = AiEngines.Gemini };
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Live Vertex AI Enterprise call for claims triage failed. Falling back to local triage engine.");
            }
        }
        else if (!string.IsNullOrWhiteSpace(geminiApiKey))
        {
            try
            {
                return (await CallLiveGeminiModelAsync(incidentDescription, claimAmount, coverageTypeName, geminiApiKey, ct)) with { Engine = AiEngines.Gemini };
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Live Gemini API call for claims triage failed. Falling back to local triage engine.");
            }
        }

        return EvaluateLocally(incidentDescription, claimAmount, coverageTypeName) with { Engine = AiEngines.RuleBased };
    }

    private async Task<TriageAgentResponse> CallVertexAiClaimsAsync(
        string incidentDescription,
        decimal claimAmount,
        string coverageTypeName,
        CancellationToken ct
    )
    {
        var project = _config["Gemini:ProjectId"] 
            ?? Environment.GetEnvironmentVariable("GOOGLE_CLOUD_PROJECT") 
            ?? "higsbx-indintq326sbx";

        var location = _config["Gemini:Location"] 
            ?? Environment.GetEnvironmentVariable("GOOGLE_CLOUD_LOCATION") 
            ?? "global";

        var model = _config["Gemini:Model"] ?? "gemini-3.5-flash";

        var endpoint = $"https://aiplatform.googleapis.com/v1/projects/{project}/locations/{location}/publishers/google/models/{model}:generateContent";

        var credential = await Google.Apis.Auth.OAuth2.GoogleCredential.GetApplicationDefaultAsync();
        if (credential.IsCreateScopedRequired)
        {
            credential = credential.CreateScoped("https://www.googleapis.com/auth/cloud-platform");
        }
        var token = await credential.UnderlyingCredential.GetAccessTokenForRequestAsync(cancellationToken: ct);

        var systemInstruction = @"You are HurricaneShield's Autonomous Claims Triage Agent. You operate headlessly.
Your objective is to evaluate First Notice of Loss (FNOL) narratives against the requested claim amount, looking for fraud indicators and assessing complexity.
Return strict, parsable JSON matching the requested schema.";

        var prompt = $@"
Evaluate the following insurance loss claim:
- Coverage Type: {coverageTypeName}
- Requested Claim Amount: ₹{claimAmount:N2}
- Incident Description: {incidentDescription}

Determine fraud flags, complexity (1-10), summary, recommendation ('Auto-Approve' or 'Require Adjuster'), and confidence score.
";

        var payload = new
        {
            system_instruction = new
            {
                parts = new[] { new { text = systemInstruction } }
            },
            contents = new[]
            {
                new
                {
                    role = "user",
                    parts = new[] { new { text = prompt } }
                }
            },
            generationConfig = new
            {
                response_mime_type = "application/json"
            }
        };

        using var requestMessage = new HttpRequestMessage(HttpMethod.Post, endpoint)
        {
            Content = new StringContent(JsonSerializer.Serialize(payload), System.Text.Encoding.UTF8, "application/json")
        };

        requestMessage.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);

        using var response = await _httpClient.SendAsync(requestMessage, ct);
        response.EnsureSuccessStatusCode();

        var responseJson = await response.Content.ReadAsStringAsync(ct);
        using var doc = JsonDocument.Parse(responseJson);

        var candidateText = doc.RootElement
            .GetProperty("candidates")[0]
            .GetProperty("content")
            .GetProperty("parts")[0]
            .GetProperty("text")
            .GetString();

        if (string.IsNullOrWhiteSpace(candidateText))
        {
            throw new InvalidOperationException("Gemini returned an empty response.");
        }

        var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
        return JsonSerializer.Deserialize<TriageAgentResponse>(candidateText, options)
            ?? throw new InvalidOperationException("Failed to deserialize Gemini triage response.");
    }

    private async Task<TriageAgentResponse> CallLiveGeminiModelAsync(
        string incidentDescription,
        decimal claimAmount,
        string coverageTypeName,
        string apiKey,
        CancellationToken ct
    )
    {
        var model = _config["Gemini:Model"] ?? "gemini-3.5-flash";
        var endpoint = $"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={apiKey}";

        var systemInstruction = @"You are HurricaneShield's Autonomous Claims Triage Agent. You operate headlessly.
Your objective is to evaluate First Notice of Loss (FNOL) narratives against the requested claim amount, looking for fraud indicators and assessing complexity.
Return strict, parsable JSON matching the requested schema.";

        var prompt = $@"
Evaluate the following insurance loss claim:
- Coverage Type: {coverageTypeName}
- Requested Claim Amount: ₹{claimAmount:N2}
- Incident Description: {incidentDescription}

Determine fraud flags, complexity (1-10), summary, recommendation ('Auto-Approve' or 'Require Adjuster'), and confidence score.
";

        var payload = new
        {
            system_instruction = new
            {
                parts = new[] { new { text = systemInstruction } }
            },
            contents = new[]
            {
                new
                {
                    role = "user",
                    parts = new[] { new { text = prompt } }
                }
            },
            generationConfig = new
            {
                response_mime_type = "application/json"
            }
        };

        using var requestMessage = new HttpRequestMessage(HttpMethod.Post, endpoint)
        {
            Content = new StringContent(JsonSerializer.Serialize(payload), System.Text.Encoding.UTF8, "application/json")
        };

        using var response = await _httpClient.SendAsync(requestMessage, ct);
        response.EnsureSuccessStatusCode();

        var responseJson = await response.Content.ReadAsStringAsync(ct);
        using var doc = JsonDocument.Parse(responseJson);

        var candidateText = doc.RootElement
            .GetProperty("candidates")[0]
            .GetProperty("content")
            .GetProperty("parts")[0]
            .GetProperty("text")
            .GetString();

        if (string.IsNullOrWhiteSpace(candidateText))
        {
            throw new InvalidOperationException("Gemini returned an empty response.");
        }

        var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
        return JsonSerializer.Deserialize<TriageAgentResponse>(candidateText, options)
            ?? throw new InvalidOperationException("Failed to deserialize Gemini triage response.");
    }

    private static TriageAgentResponse EvaluateLocally(
        string incidentDescription,
        decimal claimAmount,
        string coverageTypeName
    )
    {
        var fraudFlags = new List<string>();
        int complexity = 2;
        var descLower = incidentDescription.ToLowerInvariant();

        // Fraud heuristic: extreme damage claims with nominal amounts (or vice versa)
        if ((descLower.Contains("roof blown off") || descLower.Contains("total loss") || descLower.Contains("collapsed")) && claimAmount < 5_000m)
        {
            fraudFlags.Add($"Significant anomaly: Narrative describes catastrophic damage, but claimed amount is only ₹{claimAmount:N2}. Potential fraudulent quote probing.");
        }
        else if (descLower.Contains("food") && claimAmount > 50_000m)
        {
            fraudFlags.Add($"Significant anomaly: Food spoilage claims rarely exceed ₹25,000, but claimed amount is ₹{claimAmount:N2}.");
        }

        // Complexity assessment
        if (descLower.Contains("total loss") || descLower.Contains("foundation") || descLower.Contains("structural"))
        {
            complexity = 9;
        }
        else if (descLower.Contains("water") || descLower.Contains("flood") || descLower.Contains("interior"))
        {
            complexity = 6;
        }
        else if (descLower.Contains("roof") || descLower.Contains("shingles") || descLower.Contains("siding"))
        {
            complexity = 4;
        }
        else if (descLower.Contains("window") || descLower.Contains("fence") || descLower.Contains("food"))
        {
            complexity = 2;
        }

        if (claimAmount > 100_000m)
        {
            complexity = Math.Max(complexity, 5);
        }

        bool canAutoApprove = fraudFlags.Count == 0 && complexity <= 3 && claimAmount <= 50_000m;
        string recommendation = canAutoApprove ? "Auto-Approve" : "Require Adjuster";
        decimal confidence = canAutoApprove ? 96.5m : 91.0m;

        string summary = canAutoApprove
            ? $"Standard low-complexity {coverageTypeName} loss (₹{claimAmount:N2}) consistent with reported single-issue incident narrative. Eligible for Straight-Through Processing."
            : $"Claim requires field adjuster review. Severity/complexity index is {complexity}/10 with requested indemnity of ₹{claimAmount:N2}.";

        return new TriageAgentResponse(
            fraudFlags,
            complexity,
            summary,
            recommendation,
            confidence
        );
    }
}


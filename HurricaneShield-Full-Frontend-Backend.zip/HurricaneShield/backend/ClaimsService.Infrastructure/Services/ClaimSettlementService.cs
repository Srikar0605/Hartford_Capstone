﻿using ClaimsService.Application.DTOs.Claims;
using ClaimsService.Application.DTOs.Integrations;
using ClaimsService.Application.DTOs.Settlements;
using ClaimsService.Application.Interfaces;
using ClaimsService.Domain.Entities;
using ClaimsService.Domain.Enums;
using ClaimsService.Infrastructure.Exceptions;
using ClaimsService.Infrastructure.Persistence;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;

namespace ClaimsService.Infrastructure.Services;

public sealed class ClaimSettlementService(
    ClaimsDbContext db,
    IRequestContext context,
    IDateTimeProvider clock,
    IPaymentClient payment
) : IClaimSettlementService
{
    public async Task<SettlementValidationResponse> ValidateSettlementAsync(
        Guid claimId,
        CancellationToken cancellationToken
    )
    {
        var claim =
            await db
                .Claims.AsNoTracking()
                .SingleOrDefaultAsync(value => value.Id == claimId, cancellationToken)
            ?? throw ClaimsServiceException.NotFound("CLAIM_NOT_FOUND", "Claim not found.");

        var payableAmount = claim.ApprovedAmount ?? claim.ClaimAmount;
        var eligible =
            claim.Status == ClaimStatus.Approved 
            && claim.SettlementTransactionId is null 
            && payableAmount > 0m;

        string? reason = null;
        if (claim.Status != ClaimStatus.Approved)
            reason = "Claim is not approved.";
        else if (claim.SettlementTransactionId is not null)
            reason = "Claim already has a settlement transaction.";
        else if (payableAmount <= 0m)
            reason = "Approved settlement amount is ₹0.00 after deductible.";

        return new SettlementValidationResponse(
            claim.Id,
            claim.ClaimNumber,
            claim.Status == ClaimStatus.Approved,
            eligible,
            payableAmount,
            claim.CustomerId,
            claim.PolicyId,
            reason
        );
    }

    public async Task<SettlementInitiationResponse> InitiateAsync(
        Guid claimId,
        InitiateSettlementRequest request,
        string idempotencyKey,
        CancellationToken cancellationToken
    )
    {
        if (string.IsNullOrWhiteSpace(idempotencyKey))
        {
            throw new ClaimsServiceException(
                "IDEMPOTENCY_KEY_REQUIRED",
                "X-Idempotency-Key is required.",
                StatusCodes.Status400BadRequest
            );
        }

        var requestHash = ServiceSupport.Hash(new { ClaimId = claimId, Request = request });

        var existingRecord = await db
            .IdempotencyRecords.AsNoTracking()
            .SingleOrDefaultAsync(
                record =>
                    record.Operation == IdempotencyOperation.ClaimSettlement
                    && record.Key == idempotencyKey
                    && record.ExpiresAt > clock.UtcNow,
                cancellationToken
            );

        if (existingRecord is not null)
        {
            if (existingRecord.RequestHash != requestHash)
            {
                throw ClaimsServiceException.Conflict(
                    "IDEMPOTENCY_KEY_REUSED",
                    "Idempotency key was reused."
                );
            }

            return ServiceSupport.FromJson<SettlementInitiationResponse>(
                existingRecord.ResponseBody
            );
        }

        var claim =
            await db.Claims.SingleOrDefaultAsync(value => value.Id == claimId, cancellationToken)
            ?? throw ClaimsServiceException.NotFound("CLAIM_NOT_FOUND", "Claim not found.");

        ServiceSupport.OriginalRowVersion(db, claim, request.ClaimRowVersion);

        var payableAmount = claim.ApprovedAmount ?? claim.ClaimAmount;

        if (claim.Status != ClaimStatus.Approved || claim.SettlementTransactionId.HasValue)
        {
            throw ClaimsServiceException.Conflict(
                "CLAIM_SETTLEMENT_ALREADY_EXISTS",
                "Claim is not eligible or already has a settlement."
            );
        }

        if (payableAmount <= 0m)
        {
            throw ClaimsServiceException.Unprocessable(
                "SETTLEMENT_AMOUNT_ZERO",
                "No settlement payment is due because the approved payout is ₹0.00 after deductible."
            );
        }

        var paymentResult = await payment.CreateSettlementAsync(
            new CreateSettlementPaymentRequest(
                claim.Id,
                claim.CustomerId,
                claim.PolicyId,
                claim.AuthUserId,
                payableAmount,
                idempotencyKey
            ),
            cancellationToken
        );

        var statusBeforePayment = claim.Status;

        claim.MarkPaymentInitiated(paymentResult.TransactionId, clock.UtcNow, context.Actor);

        db.ClaimTimelines.Add(
            ClaimTimeline.Create(
                claim.Id,
                statusBeforePayment,
                claim.Status,
                "Settlement payment initiated.",
                clock.UtcNow,
                context.Actor,
                context.CorrelationId
            )
        );

        /*
         * Payment processes synchronously and returns its final fake-gateway
         * result. If Payment already succeeded, close the Claim here.
         *
         * The Payment-to-Claims callback remains necessary for a transaction
         * that initially failed and later succeeds through Payment retry.
         */
        if (string.Equals(paymentResult.Status, "Success", StringComparison.OrdinalIgnoreCase))
        {
            var statusBeforeConfirmation = claim.Status;

            claim.ConfirmSettlement(paymentResult.TransactionId, clock.UtcNow, context.Actor);

            if (statusBeforeConfirmation != claim.Status)
            {
                db.ClaimTimelines.Add(
                    ClaimTimeline.Create(
                        claim.Id,
                        statusBeforeConfirmation,
                        claim.Status,
                        "Settlement confirmed from successful payment response.",
                        clock.UtcNow,
                        context.Actor,
                        context.CorrelationId
                    )
                );
            }
        }

        var response = new SettlementInitiationResponse(
            claim.Id,
            claim.ClaimNumber,
            paymentResult.TransactionId,
            payableAmount,
            claim.Status,
            ServiceSupport.Rv(claim.RowVersion)
        );

        db.IdempotencyRecords.Add(
            IdempotencyRecord.Create(
                IdempotencyOperation.ClaimSettlement,
                idempotencyKey,
                requestHash,
                StatusCodes.Status200OK,
                ServiceSupport.Json(response),
                claim.Id,
                clock.UtcNow
            )
        );

        await ServiceSupport.Save(db, cancellationToken);

        return response with
        {
            RowVersion = ServiceSupport.Rv(claim.RowVersion),
        };
    }

    public async Task<ClaimMutationResponse> ConfirmAsync(
        Guid claimId,
        SettlementConfirmationRequest request,
        CancellationToken cancellationToken
    )
    {
        var claim =
            await db.Claims.SingleOrDefaultAsync(value => value.Id == claimId, cancellationToken)
            ?? throw ClaimsServiceException.NotFound("CLAIM_NOT_FOUND", "Claim not found.");

        if (!request.Successful)
        {
            return new ClaimMutationResponse(
                claim.Id,
                claim.ClaimNumber,
                claim.Status,
                claim.SettlementTransactionId,
                ServiceSupport.Rv(claim.RowVersion)
            );
        }

        var previousStatus = claim.Status;

        claim.ConfirmSettlement(request.TransactionId, clock.UtcNow, context.Actor);

        if (previousStatus != claim.Status)
        {
            db.ClaimTimelines.Add(
                ClaimTimeline.Create(
                    claim.Id,
                    previousStatus,
                    claim.Status,
                    "Settlement confirmed.",
                    clock.UtcNow,
                    context.Actor,
                    context.CorrelationId
                )
            );
        }

        await ServiceSupport.Save(db, cancellationToken);

        return new ClaimMutationResponse(
            claim.Id,
            claim.ClaimNumber,
            claim.Status,
            claim.SettlementTransactionId,
            ServiceSupport.Rv(claim.RowVersion)
        );
    }
}


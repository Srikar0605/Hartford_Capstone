﻿using ClaimsService.Application.DTOs.Claims;
using ClaimsService.Application.DTOs.Reviews;
using ClaimsService.Application.Interfaces;
using ClaimsService.Domain.Entities;
using ClaimsService.Domain.Enums;
using ClaimsService.Infrastructure.Exceptions;
using ClaimsService.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace ClaimsService.Infrastructure.Services;

/// <summary>
/// Service managing adjuster reviews and claim adjudication decisions.
/// Handles adjuster assignment, requests for additional loss documentation, and claim approvals or rejections.
/// Enforces dual-row concurrency checks across both the Claim aggregate root and the active ClaimReview
/// record simultaneously to prevent race conditions during multi-adjuster reviews.
/// </summary>
public sealed class ClaimReviewService(
    ClaimsDbContext db,
    IRequestContext ctx,
    IDateTimeProvider clock,
    IPolicyClient policy
) : IClaimReviewService
{
    public async Task<ClaimReviewResponse> StartReviewAsync(
        Guid id,
        StartClaimReviewRequest r,
        CancellationToken ct
    )
    {
        var c = await Tracked(id, ct);
        ServiceSupport.OriginalRowVersion(db, c, r.ClaimRowVersion);
        var from = c.Status;
        c.StartReview(clock.UtcNow, ctx.Actor);
        var review = ClaimReview.Start(c.Id, ctx.UserId, clock.UtcNow, ctx.Actor);
        db.ClaimReviews.Add(review);
        db.ClaimTimelines.Add(
            ClaimTimeline.Create(
                c.Id,
                from,
                c.Status,
                "Claim review started.",
                clock.UtcNow,
                ctx.Actor,
                ctx.CorrelationId
            )
        );
        await ServiceSupport.Save(db, ct);
        return new(
            review.Id,
            c.Id,
            review.ReviewerUserId,
            review.Decision,
            review.Notes,
            review.CreatedAt,
            review.ReviewedAt,
            ServiceSupport.Rv(review.RowVersion)
        );
    }


    public async Task<ClaimNoteResponse> RequestAdditionalInformationAsync(
        Guid id,
        RequestAdditionalInformationRequest r,
        CancellationToken ct
    )
    {
        var c = await Tracked(id, ct);
        ServiceSupport.OriginalRowVersion(db, c, r.ClaimRowVersion);

        if (c.Status != ClaimStatus.UnderReview)
        {
            throw ClaimsServiceException.Conflict(
                "CLAIM_INVALID_STATUS_TRANSITION",
                "Claim must be under review."
            );
        }

        // Record the activity on the claim to trigger EF Core update tracking
        c.RecordActivity(clock.UtcNow, ctx.Actor);

        var n = ClaimNote.Create(
            c.Id,
            ClaimNoteType.AdditionalInformationRequested,
            r.Note,
            clock.UtcNow,
            ctx.Actor
        );

        db.ClaimNotes.Add(n);

        await ServiceSupport.Save(db, ct);

        return new ClaimNoteResponse(n.Id, n.NoteType, n.NoteText, n.CreatedAt, n.CreatedBy);
    }

    public async Task<ClaimMutationResponse> ApproveAsync(
        Guid id,
        ApproveClaimRequest r,
        CancellationToken ct
    )
    {
        if (r.AssessedAmount <= 0m)
        {
            throw ClaimsServiceException.Unprocessable(
                "INVALID_ASSESSED_AMOUNT",
                "Assessed loss amount must be greater than zero."
            );
        }

        var c = await Tracked(id, ct);
        var review =
            await db.ClaimReviews.SingleOrDefaultAsync(
                x => x.ClaimId == id && !x.Decision.HasValue,
                ct
            )
            ?? throw ClaimsServiceException.NotFound(
                "CLAIM_REVIEW_NOT_FOUND",
                "Claim review not found."
            );

        ServiceSupport.OriginalRowVersion(db, c, r.ClaimRowVersion);
        ServiceSupport.OriginalRowVersion(db, review, r.ReviewRowVersion);

        var docs = await db
            .ClaimDocuments.Where(x => x.ClaimId == id)
            .Select(x => x.Id)
            .ToArrayAsync(ct);
        if (docs.Length == 0)
            throw ClaimsServiceException.Unprocessable(
                "CLAIM_DOCUMENTS_REQUIRED",
                "At least one document is required."
            );
        var verified = await db
            .ClaimDocumentVerifications.Where(x =>
                docs.Contains(x.ClaimDocumentId)
                && x.Status == DocumentVerificationStatus.Verified
            )
            .Select(x => x.ClaimDocumentId)
            .Distinct()
            .CountAsync(ct);
        if (verified != docs.Length)
            throw ClaimsServiceException.Unprocessable(
                "CLAIM_DOCUMENTS_NOT_VERIFIED",
                "All documents must be verified."
            );

        // --- STRICT RULE-BASED SETTLEMENT ADJUDICATION ---
        // Fetch active policy terms: Deductible and Coverage Limit
        var coverage = await policy.ValidateCoverageAsync(c.PolicyId, c.CoverageTypeId, ct);
        var deductible = coverage.DeductibleAmount;
        var limit = coverage.CoverageLimit;

        var assessed = r.AssessedAmount ?? c.ClaimAmount;
        if (assessed <= 0m)
        {
            throw ClaimsServiceException.Unprocessable(
                "INVALID_ASSESSED_AMOUNT",
                "Assessed loss amount must be greater than zero."
            );
        }

        // Apply deductible and cap at coverage limit
        var approvedAmount = Math.Min(limit, Math.Max(0m, assessed - deductible));

        var from = c.Status;
        c.Approve(assessed, approvedAmount, deductible, r.AdjustmentReason, clock.UtcNow, ctx.Actor);
        review.Complete(ClaimReviewDecision.Approved, r.Notes, clock.UtcNow, ctx.Actor);

        db.ClaimTimelines.Add(
            ClaimTimeline.Create(
                c.Id,
                from,
                c.Status,
                $"Claim approved by adjuster. Assessed Loss: ₹{assessed:N2}, Deductible Applied: ₹{deductible:N2}, Approved Settlement: ₹{approvedAmount:N2}.",
                clock.UtcNow,
                ctx.Actor,
                ctx.CorrelationId
            )
        );

        await ServiceSupport.Save(db, ct);

        return new ClaimMutationResponse(
            c.Id,
            c.ClaimNumber,
            c.Status,
            c.SettlementTransactionId,
            ServiceSupport.Rv(c.RowVersion)
        );
    }

    public Task<ClaimMutationResponse> RejectAsync(
        Guid id,
        RejectClaimRequest r,
        CancellationToken ct
    ) => CompleteReject(id, r.Reason, r.ClaimRowVersion, r.ReviewRowVersion, ct);

    private async Task<ClaimMutationResponse> CompleteReject(
        Guid id,
        string notes,
        string claimRv,
        string reviewRv,
        CancellationToken ct
    )
    {
        var c = await Tracked(id, ct);
        var review =
            await db.ClaimReviews.SingleOrDefaultAsync(
                x => x.ClaimId == id && !x.Decision.HasValue,
                ct
            )
            ?? throw ClaimsServiceException.NotFound(
                "CLAIM_REVIEW_NOT_FOUND",
                "Claim review not found."
            );
        ServiceSupport.OriginalRowVersion(db, c, claimRv);
        ServiceSupport.OriginalRowVersion(db, review, reviewRv);
        
        var from = c.Status;
        c.Reject(clock.UtcNow, ctx.Actor);
        review.Complete(ClaimReviewDecision.Rejected, notes, clock.UtcNow, ctx.Actor);

        db.ClaimTimelines.Add(
            ClaimTimeline.Create(
                c.Id,
                from,
                c.Status,
                notes,
                clock.UtcNow,
                ctx.Actor,
                ctx.CorrelationId
            )
        );
        await ServiceSupport.Save(db, ct);
        return new(
            c.Id,
            c.ClaimNumber,
            c.Status,
            c.SettlementTransactionId,
            ServiceSupport.Rv(c.RowVersion)
        );
    }

    private async Task<Claim> Tracked(Guid id, CancellationToken ct) =>
        await db.Claims.SingleOrDefaultAsync(x => x.Id == id, ct)
        ?? throw ClaimsServiceException.NotFound("CLAIM_NOT_FOUND", "Claim not found.");

    public async Task<ClaimReviewResponse> GetActiveReviewAsync(
        Guid claimId,
        CancellationToken cancellationToken
    )
    {
        var claimExists = await db
            .Claims.AsNoTracking()
            .AnyAsync(claim => claim.Id == claimId, cancellationToken);
        if (!claimExists)
        {
            throw ClaimsServiceException.NotFound("CLAIM_NOT_FOUND", "Claim not found.");
        }
        var review = await db
            .ClaimReviews.AsNoTracking()
            .SingleOrDefaultAsync(
                item => item.ClaimId == claimId && !item.Decision.HasValue,
                cancellationToken
            );
        if (review is null)
        {
            throw ClaimsServiceException.NotFound(
                "CLAIM_REVIEW_NOT_FOUND",
                "Active Claim review was not found."
            );
        }
        return new ClaimReviewResponse(
            review.Id,
            review.ClaimId,
            review.ReviewerUserId,
            review.Decision,
            review.Notes,
            review.CreatedAt,
            review.ReviewedAt,
            ServiceSupport.Rv(review.RowVersion)
        );
    }
}


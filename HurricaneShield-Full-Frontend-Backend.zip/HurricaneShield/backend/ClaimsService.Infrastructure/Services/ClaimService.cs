using ClaimsService.Application.DTOs.Claims;
using ClaimsService.Application.DTOs.Common;
using ClaimsService.Application.DTOs.Reviews;
using ClaimsService.Application.DTOs.Timeline;
using ClaimsService.Application.Interfaces;
using ClaimsService.Domain.Entities;
using ClaimsService.Domain.Enums;
using ClaimsService.Domain.Models;
using ClaimsService.Domain.Services;
using ClaimsService.Infrastructure.Exceptions;
using ClaimsService.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace ClaimsService.Infrastructure.Services;

public sealed class ClaimService(
    ClaimsDbContext db,
    IRequestContext ctx,
    IDateTimeProvider clock,
    IClaimNumberGenerator numbers,
    IClaimSubmissionRuleEngine rules,
    ICustomerClient customer,
    IPolicyClient policy,
    IAiTriageClient aiTriage
) : IClaimService
{
    public async Task<ClaimSubmissionResponse> SubmitAsync(
        SubmitClaimRequest r,
        string key,
        CancellationToken ct
    )
    {
        // 1. Idempotency Check:
        // We require an idempotency key from the frontend to guarantee that if a user double-clicks
        // the submit button or their network times out, we don't spawn duplicate claims in the database.
        if (string.IsNullOrWhiteSpace(key))
            throw new ClaimsServiceException(
                "IDEMPOTENCY_KEY_REQUIRED",
                "X-Idempotency-Key is required.",
                400
            );

        var hash = ServiceSupport.Hash(r);
        var existing = await db
            .IdempotencyRecords.AsNoTracking()
            .SingleOrDefaultAsync(
                x =>
                    x.Operation == IdempotencyOperation.ClaimSubmission
                    && x.Key == key
                    && x.ExpiresAt > clock.UtcNow,
                ct
            );

        // If we've already processed this exact key, replay the saved response immediately.
        if (existing is not null)
        {
            if (existing.RequestHash != hash)
                throw ClaimsServiceException.Conflict(
                    "IDEMPOTENCY_KEY_REUSED",
                    "Idempotency key was reused with another request."
                );
            return ServiceSupport.FromJson<ClaimSubmissionResponse>(existing.ResponseBody);
        }

        // Validate basic domain invariants (positive amount, not in future, within 90 days)
        rules.Validate(new ClaimSubmissionInput(r.ClaimAmount, r.IncidentDate, clock.UtcToday));

        // 2. Customer Eligibility Verification:
        // We call CustomerService via HTTP to make sure the customer account is active and matches the caller.
        var cv = await customer.ValidateCustomerAsync(r.CustomerId, ctx.UserId, ct);
        if (!cv.Exists || !cv.IsActive || !cv.IsOwnedByCaller)
            throw ClaimsServiceException.Unprocessable(
                "CUSTOMER_NOT_ELIGIBLE",
                string.Join("; ", cv.Reasons)
            );

        // Build the display name from available identity fields
        var customerDisplayName = string.Join(
                " ",
                new[] { cv.FirstName, cv.LastName }.Where(value =>
                    !string.IsNullOrWhiteSpace(value)
                )
            )
            .Trim();

        // Validate that identity details are present
        if (string.IsNullOrWhiteSpace(customerDisplayName) || string.IsNullOrWhiteSpace(cv.Email))
        {
            throw ClaimsServiceException.Unavailable("Customer Service");
        }

        // 3. Policy Validation:
        // Call PolicyService to ensure the policy is active and belongs to this user.
        var pv = await policy.ValidatePolicyAsync(r.PolicyId, ctx.UserId, ct);
        if (!pv.IsOwnedByUser || !pv.IsActive || pv.CustomerId != r.CustomerId)
            throw ClaimsServiceException.Unprocessable(
                "CLAIM_POLICY_INVALID",
                "Policy is not active and owned by the caller."
            );

        // --- BUSINESS RULE 1: Date of Loss Coverage Window ---
        // A customer cannot file a claim for damage that happened before they bought the policy or after it expired.
        // We use an EXCLUSIVE expiration boundary so an incident at the exact term transition belongs only to the successor.
        var effectiveDate = DateOnly.FromDateTime(pv.EffectiveDate);
        var expirationDate = DateOnly.FromDateTime(pv.ExpirationDate);
        if (r.IncidentDate < effectiveDate || r.IncidentDate >= expirationDate)
        {
            throw ClaimsServiceException.Unprocessable(
                "CLAIM_DATE_INVALID",
                "The incident date falls outside the active policy coverage period."
            );
        }

        // Confirm the specific coverage type (e.g. Roof, Windstorm) is actually part of their purchased plan.
        var coverage = await policy.ValidateCoverageAsync(r.PolicyId, r.CoverageTypeId, ct);
        if (!coverage.IsIncluded)
            throw ClaimsServiceException.Unprocessable(
                "CLAIM_COVERAGE_INVALID",
                "Coverage is not available."
            );

        // --- BUSINESS RULE 2: Deductible Floor ---
        // If the total damage is less than the deductible, the insurer pays nothing. We reject the claim upfront.
        if (r.ClaimAmount <= coverage.DeductibleAmount)
        {
            throw ClaimsServiceException.Unprocessable(
                "CLAIM_BELOW_DEDUCTIBLE",
                "The requested claim amount does not exceed the coverage deductible."
            );
        }

        // --- BUSINESS RULE 3: Active Claim Concurrency ---
        // Prevent opening a duplicate claim for the same coverage type while an existing one is still in progress.
        var hasActiveClaim = await db.Claims.AnyAsync(
            c => c.PolicyId == r.PolicyId 
                && c.CoverageTypeId == r.CoverageTypeId 
                && c.Status != ClaimStatus.Closed 
                && c.Status != ClaimStatus.Rejected,
            ct
        );
        if (hasActiveClaim)
        {
            throw ClaimsServiceException.Conflict(
                "CLAIM_ALREADY_ACTIVE",
                "An unresolved claim already exists for this coverage type."
            );
        }

        // --- BUSINESS RULE 4: Annual Velocity Limit ---
        // Limit policyholders to a maximum of 3 claims per policy year to curb fraud and abuse.
        var annualClaimCount = await db.Claims.CountAsync(
            c => c.PolicyId == r.PolicyId,
            ct
        );
        if (annualClaimCount >= 3)
        {
            throw ClaimsServiceException.Unprocessable(
                "CLAIM_FREQUENCY_EXCEEDED",
                "Maximum annual claim frequency limit reached."
            );
        }

        // --- BUSINESS RULE 5: Remaining Aggregate Coverage Limit ---
        // Make sure the requested amount doesn't exceed what's left on their annual coverage limit.
        var balance = await policy.GetCoverageBalanceAsync(r.PolicyId, r.CoverageTypeId, ct);
        if (r.ClaimAmount > balance.RemainingAmount)
            throw ClaimsServiceException.Unprocessable(
                "CLAIM_AMOUNT_EXCEEDS_REMAINING_COVERAGE",
                "Claim amount exceeds remaining coverage."
            );

        // Updated submission call capturing customer and policy snapshot details
        var c = Claim.Submit(
            numbers.Generate(clock.UtcNow),
            ctx.UserId,
            r.CustomerId,
            customerDisplayName,
            cv.Email,
            r.PolicyId,
            pv.PolicyNumber,
            r.CoverageTypeId,
            coverage.CoverageName,
            r.ClaimAmount,
            r.IncidentDate,
            r.IncidentDescription,
            clock.UtcNow,
            ctx.Actor
        );
        db.Claims.Add(c);

        // --- AUTONOMOUS AI CLAIMS TRIAGE & STP EVALUATION ---
        var triageResult = await aiTriage.TriageClaimAsync(
            r.IncidentDescription,
            r.ClaimAmount,
            coverage.CoverageName,
            ct
        );

        var triageEntity = AiClaimTriage.Create(
            c.Id,
            triageResult.FraudFlags,
            triageResult.ComplexityScore,
            triageResult.Summary,
            triageResult.Recommendation,
            triageResult.AiConfidence,
            clock.UtcNow,
            triageResult.Engine
        );
        db.AiClaimTriages.Add(triageEntity);

        // Check Straight-Through Processing (STP) Auto-Approval eligibility:
        bool isStpEligible = triageResult.Recommendation == "Auto-Approve" 
                      && triageResult.FraudFlags.Count == 0 
                      && r.ClaimAmount <= 5_000m;

        if (isStpEligible)
        {
            // Human-in-the-Loop (HIL) Guardrail: Do not automatically approve.
            // Keep in Submitted state and flag as STP-eligible for rapid one-click adjuster confirmation.
            db.ClaimTimelines.Add(
                ClaimTimeline.Create(
                    c.Id,
                    null,
                    ClaimStatus.Submitted,
                    $"Autonomous AI Triage: Claim is eligible for Straight-Through Processing (Confidence: {triageResult.AiConfidence}%). Awaiting human adjuster confirmation.",
                    clock.UtcNow,
                    "system-ai",
                    ctx.CorrelationId
                )
            );
        }
        else
        {
            db.ClaimTimelines.Add(
                ClaimTimeline.Create(
                    c.Id,
                    null,
                    ClaimStatus.Submitted,
                    $"Claim submitted. AI Triage routed to adjuster queue (Complexity: {triageResult.ComplexityScore}/10).",
                    clock.UtcNow,
                    ctx.Actor,
                    ctx.CorrelationId
                )
            );
        }
        var response = new ClaimSubmissionResponse(
            c.Id,
            c.ClaimNumber,
            c.Status,
            c.CreatedAt,
            ServiceSupport.Rv(c.RowVersion)
        );
        db.IdempotencyRecords.Add(
            IdempotencyRecord.Create(
                IdempotencyOperation.ClaimSubmission,
                key,
                hash,
                201,
                ServiceSupport.Json(response),
                c.Id,
                clock.UtcNow
            )
        );
        await ServiceSupport.Save(db, ct);
        return response with { RowVersion = ServiceSupport.Rv(c.RowVersion) };
    }

    public async Task<PagedResponse<ClaimSummaryResponse>> GetMyClaimsAsync(
        ClaimSearchRequest r,
        CancellationToken ct
    ) => await Query(r, db.Claims.AsNoTracking().Where(x => x.AuthUserId == ctx.UserId), ct);

    public async Task<PagedResponse<ClaimSummaryResponse>> SearchAsync(
        ClaimSearchRequest r,
        CancellationToken ct
    ) => await Query(r, db.Claims.AsNoTracking(), ct);

    private static async Task<PagedResponse<ClaimSummaryResponse>> Query(
        ClaimSearchRequest r,
        IQueryable<Claim> q,
        CancellationToken ct
    )
    {
        if (r.Status.HasValue)
            q = q.Where(x => x.Status == r.Status);
        if (r.PolicyId.HasValue)
            q = q.Where(x => x.PolicyId == r.PolicyId);
        if (r.FromIncidentDate.HasValue)
            q = q.Where(x => x.IncidentDate >= r.FromIncidentDate);
        if (r.ToIncidentDate.HasValue)
            q = q.Where(x => x.IncidentDate <= r.ToIncidentDate);
        var total = await q.CountAsync(ct);
        var items = await q.OrderByDescending(x => x.CreatedAt)
            .ThenBy(x => x.Id)
            .Skip((r.Page - 1) * r.PageSize)
            .Take(r.PageSize)
            .Select(claim => new ClaimSummaryResponse(
                claim.Id,
                claim.ClaimNumber,
                claim.CustomerId,
                claim.CustomerDisplayName,
                claim.CustomerEmail,
                claim.PolicyId,
                claim.PolicyNumber,
                claim.CoverageTypeId,
                claim.CoverageTypeName,
                claim.ClaimAmount,
                claim.IncidentDate,
                claim.Status,
                claim.CreatedAt,
                Convert.ToBase64String(claim.RowVersion)
            ))
            .ToArrayAsync(ct);
        return new(items, r.Page, r.PageSize, total);
    }

    public async Task<ClaimDetailsResponse> GetAsync(Guid id, CancellationToken ct)
    {
        var c = await OwnedRead(id, ct);
        var documents = await db
            .ClaimDocuments.AsNoTracking()
            .Where(x => x.ClaimId == id)
            .OrderBy(x => x.UploadedAt)
            .Select(x => new ClaimsService.Application.DTOs.Documents.ClaimDocumentResponse(
                x.Id,
                x.ClaimId,
                x.FileName,
                x.ContentType,
                x.FileSize,
                x.DocumentType,
                x.UploadedAt,
                x.UploadedBy,
                db.ClaimDocumentVerifications.Where(v => v.ClaimDocumentId == x.Id)
                    .OrderByDescending(v => v.VerifiedAt)
                    .Select(v => v.Status)
                    .FirstOrDefault(),
                db.ClaimDocumentVerifications.Where(v => v.ClaimDocumentId == x.Id)
                    .OrderByDescending(v => v.VerifiedAt)
                    .Select(v => v.Notes)
                    .FirstOrDefault(),
                db.ClaimDocumentVerifications.Where(v => v.ClaimDocumentId == x.Id)
                    .OrderByDescending(v => v.VerifiedAt)
                    .Select(v => v.VerifiedAt)
                    .FirstOrDefault(),
                db.ClaimDocumentVerifications.Where(v => v.ClaimDocumentId == x.Id)
                    .OrderByDescending(v => v.VerifiedAt)
                    .Select(v => v.VerifiedBy)
                    .FirstOrDefault()
            ))
            .ToArrayAsync(ct);

        var timeline = await GetTimelineAsync(id, ct);

        var notes = await db
            .ClaimNotes.AsNoTracking()
            .Where(x => x.ClaimId == id)
            .OrderByDescending(x => x.CreatedAt)
            .Select(x => new ClaimNoteResponse(
                x.Id,
                x.NoteType,
                x.NoteText,
                x.CreatedAt,
                x.CreatedBy
            ))
            .ToArrayAsync(ct);

        var triage = await db.AiClaimTriages.AsNoTracking()
            .SingleOrDefaultAsync(x => x.ClaimId == id, ct);

        AiClaimTriageResponse? triageResponse = triage == null ? null : new(
            System.Text.Json.JsonSerializer.Deserialize<string[]>(triage.FraudFlagsJson) ?? Array.Empty<string>(),
            triage.ComplexityScore,
            triage.Summary,
            triage.Recommendation,
            triage.AiConfidence,
            triage.TriagedAt,
            triage.Engine
        );

        return new ClaimDetailsResponse(
            c.Id,
            c.ClaimNumber,
            c.CustomerId,
            c.CustomerDisplayName, // Added snapshot property mapping
            c.CustomerEmail, // Added snapshot property mapping
            c.PolicyId,
            c.PolicyNumber, // Added snapshot property mapping
            c.CoverageTypeId,
            c.CoverageTypeName,
            c.ClaimAmount,
            c.IncidentDate,
            c.IncidentDescription,
            c.Status,
            c.SettlementTransactionId,
            c.CreatedAt,
            c.UpdatedAt,
            documents,
            timeline,
            notes,
            ServiceSupport.Rv(c.RowVersion),
            triageResponse,
            c.AssessedAmount,
            c.ApprovedAmount,
            c.DeductibleApplied,
            c.AdjustmentReason
        );
    }

    public async Task<IReadOnlyCollection<ClaimTimelineResponse>> GetTimelineAsync(
        Guid id,
        CancellationToken ct
    )
    {
        await OwnedRead(id, ct);
        return await db
            .ClaimTimelines.AsNoTracking()
            .Where(x => x.ClaimId == id)
            .OrderBy(x => x.ChangedAt)
            .ThenBy(x => x.Id)
            .Select(x => new ClaimTimelineResponse(
                x.Id,
                x.FromStatus,
                x.ToStatus,
                x.Notes,
                x.ChangedAt,
                x.ChangedBy,
                x.CorrelationId
            ))
            .ToArrayAsync(ct);
    }

    private async Task<Claim> OwnedRead(Guid id, CancellationToken ct)
    {
        var c =
            await db.Claims.AsNoTracking().SingleOrDefaultAsync(x => x.Id == id, ct)
            ?? throw ClaimsServiceException.NotFound("CLAIM_NOT_FOUND", "Claim not found.");
        if (
            !ctx.IsInRole("Claims Manager")
            && !ctx.IsInRole("Administrator")
            && c.AuthUserId != ctx.UserId
        )
            throw ClaimsServiceException.NotFound("CLAIM_NOT_FOUND", "Claim not found.");
        return c;
    }
}


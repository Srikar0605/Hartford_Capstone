using System.Security.Claims;
using ClaimsService.Application.Interfaces;
using Microsoft.AspNetCore.Http;

namespace ClaimsService.Infrastructure.Services;

public sealed class RequestContext(IHttpContextAccessor accessor) : IRequestContext
{
    private ClaimsPrincipal User => accessor.HttpContext?.User ?? new ClaimsPrincipal();
    public Guid UserId =>
        Guid.TryParse(
            User.FindFirstValue("sub") ?? User.FindFirstValue(ClaimTypes.NameIdentifier),
            out var id
        )
            ? id
            : Guid.Empty;
    public string Actor =>
        User.FindFirstValue(ClaimTypes.Email) ?? User.Identity?.Name ?? UserId.ToString();
    public string CorrelationId => accessor.HttpContext?.TraceIdentifier ?? string.Empty;

    public bool IsInRole(string role) => User.IsInRole(role);

    public bool HasPermission(string permission) =>
        User.Claims.Any(c => c.Type == "permissions" && c.Value == permission);
}

public sealed class SystemDateTimeProvider : IClaimsDateTimeProvider
{
    public DateTime UtcNow => DateTime.UtcNow;
    public DateOnly UtcToday => DateOnly.FromDateTime(DateTime.UtcNow);
}

public interface IClaimsDateTimeProvider : IDateTimeProvider { }

public sealed class ClaimNumberGenerator : IClaimNumberGenerator
{
    public string Generate(DateTime utcNow) =>
        $"CLM-{utcNow:yyyy}-{Guid.NewGuid():N}"[..22].ToUpperInvariant();
}


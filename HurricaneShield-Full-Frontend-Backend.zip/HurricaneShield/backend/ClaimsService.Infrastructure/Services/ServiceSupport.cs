using ClaimsService.Infrastructure.Exceptions;
using ClaimsService.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace ClaimsService.Infrastructure.Services;

using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

internal static class ServiceSupport
{
    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web);

    internal static string Json<T>(T value)
    {
        return JsonSerializer.Serialize(value, JsonOptions);
    }

    internal static T FromJson<T>(string json)
    {
        return JsonSerializer.Deserialize<T>(json, JsonOptions)
            ?? throw new InvalidOperationException($"Unable to deserialize {typeof(T).Name}.");
    }

    internal static string Hash<T>(T value)
    {
        return Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(Json(value))));
    }

    internal static void OriginalRowVersion<T>(ClaimsDbContext db, T entity, string text)
        where T : class
    {
        byte[] value;
        try
        {
            value = Convert.FromBase64String(text);
        }
        catch
        {
            throw new ClaimsServiceException("VALIDATION_ERROR", "Invalid RowVersion.", 400);
        }
        if (value.Length != 8)
            throw new ClaimsServiceException("VALIDATION_ERROR", "Invalid RowVersion.", 400);
        db.Entry(entity).Property("RowVersion").OriginalValue = value;
    }

    internal static async Task Save(ClaimsDbContext db, CancellationToken ct)
    {
        try
        {
            await db.SaveChangesAsync(ct);
        }
        catch (DbUpdateConcurrencyException)
        {
            throw ClaimsServiceException.Conflict(
                "CONCURRENCY_CONFLICT",
                "The record changed after it was loaded."
            );
        }
        catch (DbUpdateException e)
            when (e.InnerException?.Message.Contains("UNIQUE", StringComparison.OrdinalIgnoreCase)
                == true
            )
        {
            throw ClaimsServiceException.Conflict(
                "DUPLICATE_RESOURCE",
                "A duplicate record already exists."
            );
        }
    }

    internal static string Rv(byte[] value) => Convert.ToBase64String(value);
}


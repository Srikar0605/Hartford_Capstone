using ClaimsService.Application.Interfaces;
using ClaimsService.Domain.Services;
using ClaimsService.Infrastructure.Clients;
using ClaimsService.Infrastructure.Configuration;
using ClaimsService.Infrastructure.FileStorage;
using ClaimsService.Infrastructure.Persistence;
using ClaimsService.Infrastructure.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace ClaimsService.Infrastructure;

public static class DependencyInjection
{
    public static IServiceCollection AddClaimsInfrastructure(
        this IServiceCollection services,
        IConfiguration configuration
    )
    {
        var connectionString =
            configuration.GetConnectionString("ClaimsDb")
            ?? throw new InvalidOperationException("ConnectionStrings:ClaimsDb is required.");

        services.AddDbContext<ClaimsDbContext>(options => options.UseSqlServer(connectionString));

        services.AddHttpContextAccessor();

        services.AddSingleton<IDateTimeProvider, SystemDateTimeProvider>();

        services.AddSingleton<IClaimNumberGenerator, ClaimNumberGenerator>();

        services.AddSingleton<IClaimSubmissionRuleEngine, ClaimSubmissionRuleEngine>();

        services.AddScoped<IRequestContext, RequestContext>();

        services.AddScoped<IClaimFileStorage, LocalClaimFileStorage>();

        services.AddScoped<IClaimService, ClaimService>();

        services.AddScoped<IClaimDocumentService, ClaimDocumentService>();

        services.AddScoped<IClaimReviewService, ClaimReviewService>();

        services.AddScoped<IClaimSettlementService, ClaimSettlementService>();

        services.AddHttpClient<IAiTriageClient, AiTriageClient>();

        services.Configure<ClaimsFileSettings>(configuration.GetSection("ClaimsFiles"));

        services.AddTransient<ForwardingHandler>();

        AddClient<CustomerClient, ICustomerClient>(services, configuration, "Services:Customer");

        AddClient<PolicyClient, IPolicyClient>(services, configuration, "Services:Policy");

        AddClient<PaymentClient, IPaymentClient>(services, configuration, "Services:Payment");

        return services;
    }

    private static void AddClient<TImplementation, TInterface>(
        IServiceCollection services,
        IConfiguration configuration,
        string sectionName
    )
        where TImplementation : class, TInterface
        where TInterface : class
    {
        var settings =
            configuration.GetSection(sectionName).Get<ServiceEndpointSettings>()
            ?? throw new InvalidOperationException(
                $"Configuration section '{sectionName}' is missing."
            );

        if (string.IsNullOrWhiteSpace(settings.BaseUrl))
        {
            throw new InvalidOperationException($"{sectionName}:BaseUrl is required.");
        }

        services
            .AddHttpClient<TInterface, TImplementation>(client =>
            {
                client.BaseAddress = new Uri(settings.BaseUrl);

                client.Timeout = TimeSpan.FromSeconds(settings.TimeoutSeconds);
            })
            .AddHttpMessageHandler<ForwardingHandler>()
            .AddStandardResilienceHandler();
    }
}


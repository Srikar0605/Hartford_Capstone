using ClaimsService.Application.DTOs.Documents;
using ClaimsService.Application.Interfaces;
using ClaimsService.Infrastructure.Configuration;
using ClaimsService.Infrastructure.Exceptions;
using Microsoft.Extensions.Options;

namespace ClaimsService.Infrastructure.FileStorage;

public sealed class LocalClaimFileStorage : IClaimFileStorage
{
    private readonly ClaimsFileSettings s;
    private readonly string root;

    public LocalClaimFileStorage(IOptions<ClaimsFileSettings> o)
    {
        s = o.Value;

        root =
            Path.GetFullPath(s.UploadRoot)
                .TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar)
            + Path.DirectorySeparatorChar;

        Directory.CreateDirectory(root);
    }

    public async Task<string> SaveAsync(
        Guid claimId,
        string fileName,
        string contentType,
        Stream content,
        CancellationToken ct
    )
    {
        var ext = Path.GetExtension(Path.GetFileName(fileName));
        if (!s.AllowedExtensions.Contains(ext, StringComparer.OrdinalIgnoreCase))
            throw new ClaimsServiceException(
                "CLAIM_DOCUMENT_TYPE_INVALID",
                "File type is not allowed.",
                422
            );

        var dir = Path.Combine(root, claimId.ToString("N"));
        Directory.CreateDirectory(dir);

        var path = Path.Combine(dir, $"{Guid.NewGuid():N}{ext.ToLowerInvariant()}");
        await using var output = File.Create(path);
        await content.CopyToAsync(output, ct);

        return path;
    }

    public Task<ClaimDocumentContentResponse> OpenReadAsync(
        string path,
        string name,
        string type,
        CancellationToken ct
    )
    {
        var full = Path.GetFullPath(path);

        if (!full.StartsWith(root, StringComparison.OrdinalIgnoreCase) || !File.Exists(full))
            throw ClaimsServiceException.NotFound(
                "CLAIM_DOCUMENT_NOT_FOUND",
                "Document not found."
            );

        return Task.FromResult(new ClaimDocumentContentResponse(name, type, File.OpenRead(full)));
    }
}


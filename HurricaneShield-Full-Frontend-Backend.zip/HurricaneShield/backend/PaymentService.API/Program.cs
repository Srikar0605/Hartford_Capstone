using System.Text;
using System.Text.Json.Serialization;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.IdentityModel.Tokens;
using PaymentService.API.Extensions;
using PaymentService.API.Filters;
using PaymentService.API.Middleware;
using PaymentService.Application;
using PaymentService.Infrastructure;
using PaymentService.Infrastructure.Persistence;
using Shared.Exceptions.Extensions;
using Shared.Logging.Extensions;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddPaymentApplication();
builder.Services.AddPaymentInfrastructure(builder.Configuration);
builder.Services.AddPaymentAuthorization();
builder.Services.AddScoped<ValidationActionFilter>();
builder
    .Services.AddControllers(options => options.Filters.Add<ValidationActionFilter>())
    .AddJsonOptions(options =>
        options.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter())
    );

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddPaymentSwagger();
builder
    .Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.MapInboundClaims = false;

        var jwt = builder.Configuration.GetSection("Jwt");
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidIssuer = jwt["Issuer"],
            ValidateAudience = true,
            ValidAudience = jwt["Audience"],
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new SymmetricSecurityKey(
                Encoding.UTF8.GetBytes(
                    string.IsNullOrWhiteSpace(jwt["SigningKey"])
                        ? throw new InvalidOperationException("Jwt:SigningKey is required.")
                        : jwt["SigningKey"]!
                )
            ),
            ClockSkew = TimeSpan.Zero,
            ValidateLifetime = true,
            NameClaimType = "sub",
            RoleClaimType = "role",
        };
    });

builder.Services.AddHealthChecks().AddDbContextCheck<PaymentDbContext>("payment-db");

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseGlobalExceptionHandling();
app.UseMiddleware<PaymentServiceExceptionMiddleware>();
app.UseMiddleware<PaymentDomainExceptionMiddleware>();
app.UseCorrelationId();
app.UseRequestLogging();
app.UseHttpsRedirection();
app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();
app.MapHealthChecks("/health");
app.MapHealthChecks(
    "/health-db",
    new HealthCheckOptions { Predicate = registration => registration.Name == "payment-db" }
);

app.Run();

public partial class Program { }


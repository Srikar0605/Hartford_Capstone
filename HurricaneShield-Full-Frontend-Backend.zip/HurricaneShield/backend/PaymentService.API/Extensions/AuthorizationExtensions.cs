using PaymentService.Application.Authorization;

namespace PaymentService.API.Extensions;

public static class AuthorizationExtensions
{
    public static IServiceCollection AddPaymentAuthorization(this IServiceCollection services)
    {
        services.AddAuthorization(options =>
        {
            options.AddPolicy(
                PaymentAuthorizationPolicies.CustomerAccess,
                policy => policy.RequireRole(PaymentRoles.Customer, PaymentRoles.Administrator)
            );

            AddPermissionPolicy(
                options,
                PaymentAuthorizationPolicies.ProcessPremium,
                PaymentPermissions.ProcessPremium,
                PaymentRoles.Customer
            );

            AddPermissionPolicy(
                options,
                PaymentAuthorizationPolicies.ProcessSettlement,
                PaymentPermissions.ProcessSettlement,
                PaymentRoles.ClaimsManager
            );

            options.AddPolicy(
                PaymentAuthorizationPolicies.AdministratorRead,
                policy => policy.RequireRole(PaymentRoles.Administrator)
            );

            options.AddPolicy(
                PaymentAuthorizationPolicies.Retry,
                policy =>
                    policy.RequireRole(
                        PaymentRoles.Customer,
                        PaymentRoles.ClaimsManager,
                        PaymentRoles.Administrator
                    )
            );

            AddPermissionPolicy(
                options,
                PaymentAuthorizationPolicies.ValidateTransaction,
                PaymentPermissions.ValidateTransactions
            );
        });

        return services;
    }

    private static void AddPermissionPolicy(
        Microsoft.AspNetCore.Authorization.AuthorizationOptions options,
        string policyName,
        string permission,
        params string[] acceptedRoles
    )
    {
        options.AddPolicy(
            policyName,
            policy =>
                policy.RequireAssertion(context =>
                    context.User.IsInRole(PaymentRoles.Administrator)
                    || acceptedRoles.Any(context.User.IsInRole)
                    || context.User.HasClaim("permissions", permission)
                )
        );
    }
}


using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PaymentService.Application.Authorization;
using PaymentService.Application.DTOs.Premiums;
using PaymentService.Application.Interfaces;
using Shared.Common.Responses;

namespace PaymentService.API.Controllers;

/// <summary>
/// Controller handling policy premium payment processing.
/// In PaymentService, we use Simplified Clean Architecture: the controller directly calls
/// the application service (IPremiumPaymentService) rather than dispatching through MediatR.
/// We extract the X-Idempotency-Key header on every request to ensure users are never charged twice.
/// </summary>
[ApiController]
[Route("api/v1/payments")]
[Authorize]
public sealed class PremiumPaymentsController(IPremiumPaymentService service) : ControllerBase
{
    [HttpPost("premium")]
    [Authorize(Policy = PaymentAuthorizationPolicies.ProcessPremium)]
    public async Task<IActionResult> Process(
        ProcessPremiumPaymentRequest request,
        CancellationToken cancellationToken
    )
    {
        // Extract the caller's idempotency key from request headers.
        var idempotencyKey = Request.Headers["X-Idempotency-Key"].FirstOrDefault() ?? string.Empty;
        var result = await service.ProcessAsync(request, idempotencyKey, cancellationToken);
        return Ok(
            ApiResponse<PremiumPaymentResponse>.Succeed(result, "Premium payment processed.")
        );
    }
}



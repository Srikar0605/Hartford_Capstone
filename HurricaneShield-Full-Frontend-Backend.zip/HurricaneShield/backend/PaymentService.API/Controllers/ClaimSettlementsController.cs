using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PaymentService.Application.Authorization;
using PaymentService.Application.DTOs.Settlements;
using PaymentService.Application.Interfaces;
using Shared.Common.Responses;

namespace PaymentService.API.Controllers;

[ApiController]
[Route("api/v1/payments")]
[Authorize]
public sealed class ClaimSettlementsController(IClaimSettlementService service) : ControllerBase
{
    [HttpPost("settlements")]
    [Authorize(Policy = PaymentAuthorizationPolicies.ProcessSettlement)]
    public async Task<IActionResult> Process(
        ProcessClaimSettlementRequest request,
        CancellationToken cancellationToken
    )
    {
        var idempotencyKey = Request.Headers["X-Idempotency-Key"].FirstOrDefault() ?? string.Empty;
        var result = await service.ProcessAsync(request, idempotencyKey, cancellationToken);
        return Ok(
            ApiResponse<ClaimSettlementResponse>.Succeed(result, "Claim settlement processed.")
        );
    }

    [HttpGet("settlements/{transactionId:guid}")]
    [Authorize(Roles = PaymentRoles.ClaimsManager + "," + PaymentRoles.Administrator)]
    public async Task<IActionResult> Get(Guid transactionId, CancellationToken cancellationToken)
    {
        var result = await service.GetSettlementAsync(transactionId, cancellationToken);
        return Ok(ApiResponse<object>.Succeed(result));
    }
}


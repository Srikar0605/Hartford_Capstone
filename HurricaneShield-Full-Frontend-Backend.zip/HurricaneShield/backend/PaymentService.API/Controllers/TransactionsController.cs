using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PaymentService.Application.Authorization;
using PaymentService.Application.DTOs.Transactions;
using PaymentService.Application.Interfaces;
using PaymentService.Domain.Enums;
using Shared.Common.Responses;

namespace PaymentService.API.Controllers;

[ApiController]
[Route("api/v1/payments")]
[Authorize]
public sealed class TransactionsController(
    ITransactionService transactions,
    IPremiumPaymentService premiums,
    IClaimSettlementService settlements
) : ControllerBase
{
    [HttpGet("{transactionId:guid}")]
    public async Task<IActionResult> Get(Guid transactionId, CancellationToken cancellationToken)
    {
        var result = await transactions.GetAsync(transactionId, cancellationToken);
        return Ok(ApiResponse<object>.Succeed(result));
    }

    [HttpGet("me")]
    [Authorize(Policy = PaymentAuthorizationPolicies.CustomerAccess)]
    public async Task<IActionResult> Mine(
        [FromQuery] TransactionSearchRequest request,
        CancellationToken cancellationToken
    )
    {
        var result = await transactions.GetMyTransactionsAsync(request, cancellationToken);
        return Ok(ApiResponse<object>.Succeed(result));
    }

    [HttpGet("transactions")]
    [Authorize(Policy = PaymentAuthorizationPolicies.AdministratorRead)]
    public async Task<IActionResult> Search(
        [FromQuery] TransactionSearchRequest request,
        CancellationToken cancellationToken
    )
    {
        var result = await transactions.SearchAsync(request, cancellationToken);
        return Ok(ApiResponse<object>.Succeed(result));
    }

    [HttpPost("{transactionId:guid}/retry")]
    [Authorize(Policy = PaymentAuthorizationPolicies.Retry)]
    public async Task<IActionResult> Retry(
        Guid transactionId,
        RetryPaymentRequest request,
        CancellationToken cancellationToken
    )
    {
        var validation = await transactions.ValidateAsync(transactionId, cancellationToken);
        var result = validation.Type switch
        {
            PaymentType.Premium => await premiums.RetryAsync(
                transactionId,
                request,
                cancellationToken
            ),
            PaymentType.ClaimSettlement => await settlements.RetryAsync(
                transactionId,
                request,
                cancellationToken
            ),
            _ => throw new InvalidOperationException("Unsupported payment type."),
        };

        return Ok(ApiResponse<object>.Succeed(result, "Payment retry processed."));
    }

    [HttpGet("validate/{transactionId:guid}")]
    [Authorize(Policy = PaymentAuthorizationPolicies.ValidateTransaction)]
    public async Task<IActionResult> Validate(
        Guid transactionId,
        CancellationToken cancellationToken
    )
    {
        var result = await transactions.ValidateAsync(transactionId, cancellationToken);
        return Ok(ApiResponse<TransactionValidationResponse>.Succeed(result));
    }
}


using System.Security.Cryptography;
using System.Text;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PaymentService.Application.DTOs.Requests;
using PaymentService.Application.DTOs.Responses;
using PaymentService.Application.Interfaces;
using Shared.Common.Responses;

namespace PaymentService.API.Controllers;

/// <summary>
/// Refunds are issued by PolicyService when a customer cancels a policy (pro-rated premium).
/// That call forwards the customer's own token, so a signed-in token alone is not enough here:
/// the caller must be an Administrator or present the internal service key that only
/// PolicyService knows. Without this check any customer could post a refund of any amount.
/// </summary>
[ApiController]
[Route("api/v1/payments/refund")]
public sealed class RefundsController(IRefundService refundService, IConfiguration configuration)
    : ControllerBase
{
    internal const string InternalServiceKeyHeader = "X-Internal-Service-Key";

    [HttpPost]
    [Authorize]
    public async Task<ActionResult<ApiResponse<RefundResponse>>> ProcessRefund(
        [FromBody] RefundProcessingRequest request,
        CancellationToken ct
    )
    {
        if (!User.IsInRole("Administrator") && !HasValidInternalServiceKey())
        {
            return Forbid();
        }

        var key = Request.Headers["X-Idempotency-Key"].ToString();
        var response = await refundService.ProcessRefundAsync(request, key, ct);
        return Ok(ApiResponse<RefundResponse>.Succeed(response, "Refund processed."));
    }

    private bool HasValidInternalServiceKey()
    {
        var expected = configuration["InternalServices:ApiKey"];
        var supplied = Request.Headers[InternalServiceKeyHeader].ToString();

        if (string.IsNullOrWhiteSpace(expected) || string.IsNullOrEmpty(supplied))
        {
            return false;
        }

        // Constant-time comparison so the key can't be guessed from response timing.
        return CryptographicOperations.FixedTimeEquals(
            Encoding.UTF8.GetBytes(expected),
            Encoding.UTF8.GetBytes(supplied)
        );
    }
}

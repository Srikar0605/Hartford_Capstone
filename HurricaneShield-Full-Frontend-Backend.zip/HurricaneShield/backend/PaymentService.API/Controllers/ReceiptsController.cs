using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PaymentService.Application.Interfaces;
using Shared.Common.Responses;

namespace PaymentService.API.Controllers;

[ApiController]
[Route("api/v1/payments")]
[Authorize]
public sealed class ReceiptsController(IReceiptService service) : ControllerBase
{
    [HttpGet("{transactionId:guid}/receipt")]
    public async Task<IActionResult> Get(Guid transactionId, CancellationToken cancellationToken)
    {
        var result = await service.GetByTransactionAsync(transactionId, cancellationToken);
        return Ok(ApiResponse<object>.Succeed(result));
    }
}


using PaymentService.Infrastructure.Exceptions;
using Shared.Common.Responses;

namespace PaymentService.API.Middleware;

public sealed class PaymentServiceExceptionMiddleware(RequestDelegate next)
{
    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            await next(context);
        }
        catch (PaymentServiceException exception)
        {
            context.Response.StatusCode = exception.StatusCode;
            context.Response.ContentType = "application/json";
            await context.Response.WriteAsJsonAsync(
                ApiErrorResponse.Create(
                    exception.ErrorCode,
                    exception.Message,
                    context.TraceIdentifier
                )
            );
        }
    }
}


using PaymentService.Domain.Exceptions;
using Shared.Common.Responses;

namespace PaymentService.API.Middleware;

public sealed class PaymentDomainExceptionMiddleware(RequestDelegate next)
{
    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            await next(context);
        }
        catch (DomainRuleException exception)
        {
            context.Response.StatusCode = StatusCodes.Status409Conflict;
            context.Response.ContentType = "application/json";
            await context.Response.WriteAsJsonAsync(
                ApiErrorResponse.Create(
                    "PAYMENT_INVALID_STATE",
                    exception.Message,
                    context.TraceIdentifier
                )
            );
        }
    }
}


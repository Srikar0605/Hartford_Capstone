using ClaimsService.Application.DTOs.Documents;
using ClaimsService.Domain.Enums;
using FluentValidation;

namespace ClaimsService.Application.Validation;

public sealed class UploadClaimDocumentRequestValidator
    : AbstractValidator<UploadClaimDocumentRequest>
{
    private static readonly HashSet<string> Allowed = new(StringComparer.OrdinalIgnoreCase)
    {
        ".pdf",
        ".png",
        ".jpg",
        ".jpeg",
    };

    public UploadClaimDocumentRequestValidator()
    {
        RuleFor(x => x.DocumentType).NotEmpty().MaximumLength(100);
        RuleFor(x => x.FileName)
            .NotEmpty()
            .MaximumLength(260)
            .Must(name => Allowed.Contains(Path.GetExtension(name)))
            .WithMessage("File extension is not allowed.");
        RuleFor(x => x.ContentType).NotEmpty().MaximumLength(100);
        RuleFor(x => x.FileSize).InclusiveBetween(1, 10 * 1024 * 1024);
        RuleFor(x => x.Content)
            .NotNull()
            .Must(stream => stream.CanRead)
            .WithMessage("File content must be readable.");
    }
}

public sealed class VerifyClaimDocumentRequestValidator
    : AbstractValidator<VerifyClaimDocumentRequest>
{
    public VerifyClaimDocumentRequestValidator()
    {
        RuleFor(x => x.Status)
            .Must(x =>
                x is DocumentVerificationStatus.Verified or DocumentVerificationStatus.Rejected
            );
        RuleFor(x => x.Notes)
            .NotEmpty()
            .MaximumLength(1000)
            .When(x => x.Status == DocumentVerificationStatus.Rejected);
        RuleFor(x => x.ClaimRowVersion).ValidRowVersion();
    }
}


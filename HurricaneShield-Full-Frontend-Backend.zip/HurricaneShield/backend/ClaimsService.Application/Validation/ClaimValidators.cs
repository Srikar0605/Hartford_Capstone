using ClaimsService.Application.DTOs.Claims;
using FluentValidation;

namespace ClaimsService.Application.Validation;

public sealed class SubmitClaimRequestValidator : AbstractValidator<SubmitClaimRequest>
{
    public SubmitClaimRequestValidator()
    {
        RuleFor(x => x.CustomerId).NotEmpty();
        RuleFor(x => x.PolicyId).NotEmpty();
        RuleFor(x => x.CoverageTypeId).NotEmpty();
        RuleFor(x => x.ClaimAmount).GreaterThan(0m);
        RuleFor(x => x.IncidentDescription).NotEmpty().MaximumLength(2000);
    }
}

public sealed class ClaimSearchRequestValidator : AbstractValidator<ClaimSearchRequest>
{
    public ClaimSearchRequestValidator()
    {
        RuleFor(x => x.Page).GreaterThanOrEqualTo(1);
        RuleFor(x => x.PageSize).InclusiveBetween(1, 100);
        RuleFor(x => x)
            .Must(x =>
                !x.FromIncidentDate.HasValue
                || !x.ToIncidentDate.HasValue
                || x.FromIncidentDate <= x.ToIncidentDate
            )
            .WithMessage("FromIncidentDate cannot be after ToIncidentDate.");
    }
}


using ClaimsService.Application.DTOs.Reviews;
using FluentValidation;

namespace ClaimsService.Application.Validation;

public sealed class StartClaimReviewRequestValidator : AbstractValidator<StartClaimReviewRequest>
{
    public StartClaimReviewRequestValidator() => RuleFor(x => x.ClaimRowVersion).ValidRowVersion();
}

public sealed class ApproveClaimRequestValidator : AbstractValidator<ApproveClaimRequest>
{
    public ApproveClaimRequestValidator()
    {
        RuleFor(x => x.Notes).NotEmpty().MaximumLength(1000);
        RuleFor(x => x.ClaimRowVersion).ValidRowVersion();
        RuleFor(x => x.ReviewRowVersion).ValidRowVersion();
    }
}

public sealed class RejectClaimRequestValidator : AbstractValidator<RejectClaimRequest>
{
    public RejectClaimRequestValidator()
    {
        RuleFor(x => x.Reason).NotEmpty().MaximumLength(1000);
        RuleFor(x => x.ClaimRowVersion).ValidRowVersion();
        RuleFor(x => x.ReviewRowVersion).ValidRowVersion();
    }
}

public sealed class RequestAdditionalInformationRequestValidator
    : AbstractValidator<RequestAdditionalInformationRequest>
{
    public RequestAdditionalInformationRequestValidator()
    {
        RuleFor(x => x.Note).NotEmpty().MaximumLength(2000);
        RuleFor(x => x.ClaimRowVersion).ValidRowVersion();
    }
}


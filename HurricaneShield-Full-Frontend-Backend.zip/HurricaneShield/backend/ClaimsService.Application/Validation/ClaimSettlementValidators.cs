using ClaimsService.Application.DTOs.Settlements;
using FluentValidation;

namespace ClaimsService.Application.Validation;

public sealed class InitiateSettlementRequestValidator
    : AbstractValidator<InitiateSettlementRequest>
{
    public InitiateSettlementRequestValidator() =>
        RuleFor(x => x.ClaimRowVersion).ValidRowVersion();
}

public sealed class SettlementConfirmationRequestValidator
    : AbstractValidator<SettlementConfirmationRequest>
{
    public SettlementConfirmationRequestValidator()
    {
        RuleFor(x => x.TransactionId).NotEmpty();
        RuleFor(x => x.FailureReason).NotEmpty().MaximumLength(1000).When(x => !x.Successful);
    }
}


namespace ClaimsService.Application.Authorization;

public static class ClaimsRoles
{
    public const string Customer = "Customer";
    public const string ClaimsManager = "Claims Manager";
    public const string Administrator = "Administrator";
}


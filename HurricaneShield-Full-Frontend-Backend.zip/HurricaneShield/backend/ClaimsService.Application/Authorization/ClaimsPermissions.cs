namespace ClaimsService.Application.Authorization;

public static class ClaimsPermissions
{
    public const string ReviewClaims = "Review Claims";
    public const string ApproveClaims = "Approve Claims";
    public const string RejectClaims = "Reject Claims";
    public const string VerifyDocuments = "Verify Documents";
    public const string InitiateSettlement = "Initiate Settlement";
    public const string ConfirmSettlement = "Confirm Claim Settlements";
}


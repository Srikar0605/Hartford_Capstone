namespace ClaimsService.Application.Authorization;

public static class ClaimsAuthorizationPolicies
{
    public const string CustomerAccess = "Claims.CustomerAccess";
    public const string StaffRead = "Claims.StaffRead";
    public const string Review = "Claims.Review";
    public const string Approve = "Claims.Approve";
    public const string Reject = "Claims.Reject";
    public const string VerifyDocuments = "Claims.VerifyDocuments";
    public const string InitiateSettlement = "Claims.InitiateSettlement";
    public const string PaymentConfirmation = "Claims.PaymentConfirmation";
}


using ClaimsService.Domain.Enums;

namespace ClaimsService.Application.DTOs.Documents;

public sealed record UploadClaimDocumentRequest(
    string DocumentType,
    string FileName,
    string ContentType,
    long FileSize,
    Stream Content
);

public sealed record VerifyClaimDocumentRequest(
    DocumentVerificationStatus Status,
    string? Notes,
    string ClaimRowVersion
);

public sealed record ClaimDocumentResponse(
    Guid DocumentId,
    Guid ClaimId,
    string FileName,
    string ContentType,
    long FileSize,
    string DocumentType,
    DateTime UploadedAt,
    string UploadedBy,
    DocumentVerificationStatus VerificationStatus,
    string? VerificationNotes,
    DateTime? VerifiedAt,
    string? VerifiedBy
);

public sealed record ClaimDocumentContentResponse(
    string FileName,
    string ContentType,
    Stream Content
);

public sealed record DocumentVerificationResponse(
    Guid DocumentId,
    DocumentVerificationStatus Status,
    string? Notes,
    DateTime? VerifiedAt,
    string? VerifiedBy
);


using ClaimsService.Domain.Enums;

namespace ClaimsService.Application.DTOs.Claims;

public sealed record SubmitClaimRequest(
    Guid CustomerId,
    Guid PolicyId,
    Guid CoverageTypeId,
    decimal ClaimAmount,
    DateOnly IncidentDate,
    string IncidentDescription
);

public sealed record ClaimSearchRequest(
    int Page = 1,
    int PageSize = 20,
    ClaimStatus? Status = null,
    Guid? PolicyId = null,
    DateOnly? FromIncidentDate = null,
    DateOnly? ToIncidentDate = null
);

public sealed record ClaimSummaryResponse(
    Guid ClaimId,
    string ClaimNumber,
    Guid CustomerId,
    string CustomerDisplayName,
    string CustomerEmail,
    Guid PolicyId,
    string PolicyNumber,
    Guid CoverageTypeId,
    string CoverageTypeName,
    decimal ClaimAmount,
    DateOnly IncidentDate,
    ClaimStatus Status,
    DateTime CreatedAt,
    string RowVersion
);

public sealed record AiClaimTriageResponse(
    IReadOnlyCollection<string> FraudFlags,
    int ComplexityScore,
    string Summary,
    string Recommendation,
    decimal AiConfidence,
    DateTime TriagedAt,
    string? Engine = null
);

public sealed record ClaimDetailsResponse(
    Guid ClaimId,
    string ClaimNumber,
    Guid CustomerId,
    string CustomerDisplayName,
    string CustomerEmail,
    Guid PolicyId,
    string PolicyNumber,
    Guid CoverageTypeId,
    string CoverageTypeName,
    decimal ClaimAmount,
    DateOnly IncidentDate,
    string IncidentDescription,
    ClaimStatus Status,
    Guid? SettlementTransactionId,
    DateTime CreatedAt,
    DateTime? UpdatedAt,
    IReadOnlyCollection<Documents.ClaimDocumentResponse> Documents,
    IReadOnlyCollection<Timeline.ClaimTimelineResponse> Timeline,
    IReadOnlyCollection<Reviews.ClaimNoteResponse> Notes,
    string RowVersion,
    AiClaimTriageResponse? AiTriage = null,
    decimal? AssessedAmount = null,
    decimal? ApprovedAmount = null,
    decimal? DeductibleApplied = null,
    string? AdjustmentReason = null
);

public sealed record ClaimSubmissionResponse(
    Guid ClaimId,
    string ClaimNumber,
    ClaimStatus Status,
    DateTime SubmittedAt,
    string RowVersion
);

public sealed record ClaimMutationResponse(
    Guid ClaimId,
    string ClaimNumber,
    ClaimStatus Status,
    Guid? SettlementTransactionId,
    string RowVersion
);


using ClaimsService.Domain.Enums;

namespace ClaimsService.Application.DTOs.Settlements;

public sealed record InitiateSettlementRequest(string ClaimRowVersion);

public sealed record SettlementInitiationResponse(
    Guid ClaimId,
    string ClaimNumber,
    Guid TransactionId,
    decimal Amount,
    ClaimStatus Status,
    string RowVersion
);

public sealed record SettlementConfirmationRequest(
    Guid TransactionId,
    bool Successful,
    string? FailureReason
);

public sealed record SettlementValidationResponse(
    Guid ClaimId,
    string ClaimNumber,
    bool IsApproved,
    bool CanSettle,
    decimal SettlementAmount,
    Guid CustomerId,
    Guid PolicyId,
    string? Reason
);


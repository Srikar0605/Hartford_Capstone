namespace ClaimsService.Application.DTOs.Integrations;

public sealed record CustomerValidationResponse(
    Guid CustomerId,
    bool Exists,
    bool IsActive,
    bool IsOwnedByCaller,
    string? FirstName,
    string? LastName,
    string? Email,
    IReadOnlyCollection<string> Reasons
);

public sealed record PolicyValidationResponse(
    Guid PolicyId,
    string PolicyNumber,
    Guid CustomerId,
    Guid AuthUserId,
    string Status,
    bool IsOwnedByUser,
    bool IsActive,
    DateTime EffectiveDate,
    DateTime ExpirationDate,
    string? Reason
);

public sealed record CoverageValidationResponse(
    Guid PolicyId,
    Guid CoverageTypeId,
    string CoverageName,
    decimal CoverageLimit,
    decimal DeductibleAmount,
    bool IsIncluded,
    string? Reason
);

public sealed record CoverageBalanceResponse(
    Guid PolicyId,
    Guid CoverageTypeId,
    decimal CoverageLimit,
    decimal ConsumedAmount,
    decimal RemainingAmount
);

public sealed record CreateSettlementPaymentRequest(
    Guid ClaimId,
    Guid CustomerId,
    Guid PolicyId,
    Guid AuthUserId,
    decimal Amount,
    string IdempotencyKey
);

public sealed record PaymentSettlementResponse(
    Guid TransactionId,
    string TransactionNumber,
    string Status,
    decimal Amount
);


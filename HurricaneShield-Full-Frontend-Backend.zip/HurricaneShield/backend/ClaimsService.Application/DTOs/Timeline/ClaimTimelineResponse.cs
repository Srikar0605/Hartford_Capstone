using ClaimsService.Domain.Enums;

namespace ClaimsService.Application.DTOs.Timeline;

public sealed record ClaimTimelineResponse(
    Guid TimelineId,
    ClaimStatus? FromStatus,
    ClaimStatus ToStatus,
    string Notes,
    DateTime ChangedAt,
    string ChangedBy,
    string CorrelationId
);


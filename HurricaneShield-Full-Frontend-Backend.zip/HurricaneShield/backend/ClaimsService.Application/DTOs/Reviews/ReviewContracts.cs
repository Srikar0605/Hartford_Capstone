using ClaimsService.Domain.Enums;

namespace ClaimsService.Application.DTOs.Reviews;

public sealed record StartClaimReviewRequest(string ClaimRowVersion);

public sealed record ApproveClaimRequest(
    string Notes,
    string ClaimRowVersion,
    string ReviewRowVersion,
    decimal? AssessedAmount = null,
    string? AdjustmentReason = null
);

public sealed record RejectClaimRequest(
    string Reason,
    string ClaimRowVersion,
    string ReviewRowVersion
);

public sealed record RequestAdditionalInformationRequest(string Note, string ClaimRowVersion);

public sealed record ClaimReviewResponse(
    Guid ReviewId,
    Guid ClaimId,
    Guid ReviewerUserId,
    ClaimReviewDecision? Decision,
    string? Notes,
    DateTime CreatedAt,
    DateTime? ReviewedAt,
    string RowVersion
);

public sealed record ClaimNoteResponse(
    Guid NoteId,
    ClaimNoteType NoteType,
    string NoteText,
    DateTime CreatedAt,
    string CreatedBy
);


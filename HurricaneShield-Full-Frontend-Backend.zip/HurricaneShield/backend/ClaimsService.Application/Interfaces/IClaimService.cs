using ClaimsService.Application.DTOs.Claims;
using ClaimsService.Application.DTOs.Common;
using ClaimsService.Application.DTOs.Timeline;

namespace ClaimsService.Application.Interfaces;

public interface IClaimService
{
    Task<ClaimSubmissionResponse> SubmitAsync(
        SubmitClaimRequest request,
        string idempotencyKey,
        CancellationToken cancellationToken
    );
    Task<PagedResponse<ClaimSummaryResponse>> GetMyClaimsAsync(
        ClaimSearchRequest request,
        CancellationToken cancellationToken
    );
    Task<PagedResponse<ClaimSummaryResponse>> SearchAsync(
        ClaimSearchRequest request,
        CancellationToken cancellationToken
    );
    Task<ClaimDetailsResponse> GetAsync(Guid claimId, CancellationToken cancellationToken);
    Task<IReadOnlyCollection<ClaimTimelineResponse>> GetTimelineAsync(
        Guid claimId,
        CancellationToken cancellationToken
    );
}


using ClaimsService.Application.DTOs.Documents;
using ClaimsService.Application.DTOs.Integrations;

namespace ClaimsService.Application.Interfaces;

public interface ICustomerClient
{
    Task<CustomerValidationResponse> ValidateCustomerAsync(
        Guid customerId,
        Guid authUserId,
        CancellationToken cancellationToken
    );
}

public interface IPolicyClient
{
    Task<PolicyValidationResponse> ValidatePolicyAsync(
        Guid policyId,
        Guid authUserId,
        CancellationToken cancellationToken
    );
    Task<CoverageValidationResponse> ValidateCoverageAsync(
        Guid policyId,
        Guid coverageTypeId,
        CancellationToken cancellationToken
    );
    Task<CoverageBalanceResponse> GetCoverageBalanceAsync(
        Guid policyId,
        Guid coverageTypeId,
        CancellationToken cancellationToken
    );
}

public interface IPaymentClient
{
    Task<PaymentSettlementResponse> CreateSettlementAsync(
        CreateSettlementPaymentRequest request,
        CancellationToken cancellationToken
    );
}

public interface IClaimFileStorage
{
    Task<string> SaveAsync(
        Guid claimId,
        string fileName,
        string contentType,
        Stream content,
        CancellationToken cancellationToken
    );
    Task<ClaimDocumentContentResponse> OpenReadAsync(
        string filePath,
        string downloadFileName,
        string contentType,
        CancellationToken cancellationToken
    );
}


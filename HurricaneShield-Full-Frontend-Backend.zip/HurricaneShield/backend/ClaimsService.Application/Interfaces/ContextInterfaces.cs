namespace ClaimsService.Application.Interfaces;

public interface IRequestContext
{
    Guid UserId { get; }
    string Actor { get; }
    string CorrelationId { get; }
    bool IsInRole(string role);
    bool HasPermission(string permission);
}

public interface IDateTimeProvider
{
    DateTime UtcNow { get; }
    DateOnly UtcToday { get; }
}

public interface IClaimNumberGenerator
{
    string Generate(DateTime utcNow);
}


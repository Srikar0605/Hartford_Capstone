namespace ClaimsService.Application.Interfaces;

public sealed record TriageAgentResponse(
    IReadOnlyCollection<string> FraudFlags,
    int ComplexityScore,
    string Summary,
    string Recommendation,
    decimal AiConfidence,
    string Engine = AiEngines.RuleBased
);

/// <summary>Which engine produced an AI result, so the UI can label rule-based fallbacks honestly.</summary>
public static class AiEngines
{
    public const string Gemini = "Gemini";
    public const string RuleBased = "RuleBased";
}

public interface IAiTriageClient
{
    Task<TriageAgentResponse> TriageClaimAsync(
        string incidentDescription,
        decimal claimAmount,
        string coverageTypeName,
        CancellationToken ct = default
    );
}


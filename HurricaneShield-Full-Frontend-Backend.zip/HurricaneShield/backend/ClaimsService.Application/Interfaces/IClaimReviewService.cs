using ClaimsService.Application.DTOs.Claims;
using ClaimsService.Application.DTOs.Reviews;

namespace ClaimsService.Application.Interfaces;

public interface IClaimReviewService
{
    Task<ClaimReviewResponse> GetActiveReviewAsync(
        Guid claimId,
        CancellationToken cancellationToken
    );
    Task<ClaimReviewResponse> StartReviewAsync(
        Guid claimId,
        StartClaimReviewRequest request,
        CancellationToken cancellationToken
    );
    Task<ClaimNoteResponse> RequestAdditionalInformationAsync(
        Guid claimId,
        RequestAdditionalInformationRequest request,
        CancellationToken cancellationToken
    );
    Task<ClaimMutationResponse> ApproveAsync(
        Guid claimId,
        ApproveClaimRequest request,
        CancellationToken cancellationToken
    );
    Task<ClaimMutationResponse> RejectAsync(
        Guid claimId,
        RejectClaimRequest request,
        CancellationToken cancellationToken
    );
}


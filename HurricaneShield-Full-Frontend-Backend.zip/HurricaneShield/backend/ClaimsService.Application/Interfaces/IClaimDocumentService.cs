using ClaimsService.Application.DTOs.Documents;

namespace ClaimsService.Application.Interfaces;

public interface IClaimDocumentService
{
    Task<ClaimDocumentResponse> UploadAsync(
        Guid claimId,
        UploadClaimDocumentRequest request,
        CancellationToken cancellationToken
    );
    Task<IReadOnlyCollection<ClaimDocumentResponse>> GetDocumentsAsync(
        Guid claimId,
        CancellationToken cancellationToken
    );
    Task<ClaimDocumentContentResponse> DownloadAsync(
        Guid claimId,
        Guid documentId,
        CancellationToken cancellationToken
    );
    Task<DocumentVerificationResponse> VerifyAsync(
        Guid claimId,
        Guid documentId,
        VerifyClaimDocumentRequest request,
        CancellationToken cancellationToken
    );
}


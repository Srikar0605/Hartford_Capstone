using ClaimsService.Application.DTOs.Claims;
using ClaimsService.Application.DTOs.Settlements;

namespace ClaimsService.Application.Interfaces;

public interface IClaimSettlementService
{
    Task<SettlementValidationResponse> ValidateSettlementAsync(
        Guid claimId,
        CancellationToken cancellationToken
    );
    Task<SettlementInitiationResponse> InitiateAsync(
        Guid claimId,
        InitiateSettlementRequest request,
        string idempotencyKey,
        CancellationToken cancellationToken
    );
    Task<ClaimMutationResponse> ConfirmAsync(
        Guid claimId,
        SettlementConfirmationRequest request,
        CancellationToken cancellationToken
    );
}


using AuthService.Application.Abstractions.Auditing;
using AuthService.Application.Abstractions.Authentication;
using AuthService.Application.Abstractions.Context;
using AuthService.Application.Abstractions.Time;
using AuthService.Domain.Constants;
using AuthService.Domain.Entities;
using AuthService.Domain.Repositories;
using MediatR;
using Shared.Common.Errors;
using Shared.Common.Exceptions;

namespace AuthService.Application.Commands.Login;

/// <summary>
/// MediatR handler processing user login requests.
/// I designed this handler with strict security considerations:
/// 1. Anti-enumeration: returns identical invalid credential errors for non-existent and inactive accounts.
/// 2. Brute-force protection: enforces exponential/fixed lockouts after maximum failed attempts.
/// 3. Step-up MFA: intercepts valid logins if TOTP is configured, issuing a temporary challenge instead of JWTs.
/// 4. Comprehensive audit trails: records structured events in SecurityAuditLog for compliance tracking.
/// </summary>
public sealed class LoginCommandHandler : IRequestHandler<LoginCommand, LoginResult>
{
    private readonly IUserRepository _userRepository;

    private readonly IPasswordHasher _passwordHasher;
    private readonly IJwtTokenGenerator _jwtTokenGenerator;
    private readonly IRefreshTokenGenerator _refreshTokenGenerator;
    private readonly ISecurityAuditWriter _auditWriter;
    private readonly IRequestContext _requestContext;
    private readonly IUnitOfWork _unitOfWork;
    private readonly IDateTimeProvider _dateTimeProvider;
    private readonly IMfaChallengeStore _mfaChallengeStore;
    private readonly ITrustedDeviceStore _trustedDeviceStore;

    public LoginCommandHandler(
        IUserRepository userRepository,
        IPasswordHasher passwordHasher,
        IJwtTokenGenerator jwtTokenGenerator,
        IRefreshTokenGenerator refreshTokenGenerator,
        ISecurityAuditWriter auditWriter,
        IRequestContext requestContext,
        IUnitOfWork unitOfWork,
        IDateTimeProvider dateTimeProvider,
        IMfaChallengeStore mfaChallengeStore,
        ITrustedDeviceStore trustedDeviceStore
    )
    {
        _userRepository = userRepository;
        _passwordHasher = passwordHasher;
        _jwtTokenGenerator = jwtTokenGenerator;
        _refreshTokenGenerator = refreshTokenGenerator;
        _auditWriter = auditWriter;
        _requestContext = requestContext;
        _unitOfWork = unitOfWork;
        _dateTimeProvider = dateTimeProvider;
        _mfaChallengeStore = mfaChallengeStore;
        _trustedDeviceStore = trustedDeviceStore;
    }

    public async Task<LoginResult> Handle(LoginCommand request, CancellationToken cancellationToken)
    {
        var utcNow = _dateTimeProvider.UtcNow;

        var user = await _userRepository.GetByEmailWithAuthenticationDataAsync(
            request.Email,
            cancellationToken
        );

        if (user is null || !user.IsActive)
        {
            await WriteUnknownLoginFailureAsync(cancellationToken);

            await _unitOfWork.SaveChangesAsync(cancellationToken);

            throw InvalidCredentials();
        }

        if (user.IsLocked(utcNow))
        {
            await WriteAuditAsync(
                user.Id,
                SecurityAuditEventTypes.LoginFailed,
                SecurityAuditOutcomes.Denied,
                "Login was denied because the account is locked.",
                cancellationToken
            );

            await _unitOfWork.SaveChangesAsync(cancellationToken);

            throw new AppException(423, ErrorCodes.AuthAccountLocked, "User account is locked.");
        }

        var passwordIsValid = _passwordHasher.VerifyPassword(
            user,
            user.PasswordHash,
            request.Password
        );

        if (!passwordIsValid)
        {
            user.RecordFailedLogin(
                utcNow,
                LoginPolicy.MaximumFailedAttempts,
                LoginPolicy.LockoutDuration
            );

            await AddLoginActivityAsync(user.Id, false, utcNow, cancellationToken);

            var accountLocked = user.IsLocked(utcNow);

            await WriteAuditAsync(
                user.Id,
                accountLocked
                    ? SecurityAuditEventTypes.AccountLocked
                    : SecurityAuditEventTypes.LoginFailed,
                SecurityAuditOutcomes.Failed,
                accountLocked
                    ? "Account was locked after repeated failed login attempts."
                    : "Login failed because invalid credentials were supplied.",
                cancellationToken
            );

            await _unitOfWork.SaveChangesAsync(cancellationToken);

            if (accountLocked)
            {
                throw new AppException(
                    423,
                    ErrorCodes.AuthAccountLocked,
                    "User account is locked."
                );
            }

            throw InvalidCredentials();
        }

        user.RecordSuccessfulLogin();

        if (_passwordHasher.NeedsRehash(user, user.PasswordHash, request.Password))
        {
            var upgradedHash = _passwordHasher.HashPassword(user, request.Password);

            user.ChangePasswordHash(upgradedHash, utcNow, "PasswordHashUpgrade");
        }

        await AddLoginActivityAsync(user.Id, true, utcNow, cancellationToken);

        var isTrustedDevice = _trustedDeviceStore.IsValid(request.TrustedDeviceToken, user.Id);

        if (user.Mfa?.IsEnabled == true && !isTrustedDevice)
        {
            await WriteAuditAsync(
                user.Id,
                SecurityAuditEventTypes.LoginSucceeded,
                SecurityAuditOutcomes.Succeeded,
                "Primary credentials were verified and MFA is required.",
                cancellationToken
            );

            await _unitOfWork.SaveChangesAsync(cancellationToken);

            var challengeToken = _mfaChallengeStore.Create(user.Id);

            return LoginResult.RequireMfa(challengeToken);
        }

        EnforceActiveRefreshTokenLimit(user, utcNow);

        var refreshResult = _refreshTokenGenerator.Generate();

        var refreshToken = RefreshToken.Create(
            user.Id,
            refreshResult.TokenHash,
            refreshResult.ExpiresAt,
            utcNow
        );

        await _userRepository.AddRefreshTokenAsync(refreshToken, cancellationToken);

        var accessResult = _jwtTokenGenerator.GenerateAccessToken(user);

        await WriteAuditAsync(
            user.Id,
            SecurityAuditEventTypes.LoginSucceeded,
            SecurityAuditOutcomes.Succeeded,
            "Login completed successfully.",
            cancellationToken
        );

        await _auditWriter.WriteAsync(
            new SecurityAuditEntry(
                SecurityAuditEventTypes.RefreshTokenIssued,
                SecurityAuditOutcomes.Succeeded,
                SecurityAuditActorTypes.User,
                user.Id,
                user.Id,
                "A refresh token was issued."
            ),
            cancellationToken
        );

        await _unitOfWork.SaveChangesAsync(cancellationToken);

        string? newTrustedDeviceToken = null;
        if (request.RememberMe)
        {
            newTrustedDeviceToken = _trustedDeviceStore.Create(user.Id);
        }

        return LoginResult.Authenticated(
            accessResult.AccessToken,
            refreshResult.RawToken,
            accessResult.ExpiresIn,
            newTrustedDeviceToken
        );
    }

    private void EnforceActiveRefreshTokenLimit(User user, DateTime utcNow)
    {
        var activeTokens = user
            .RefreshTokens.Where(token => token.IsActive(utcNow))
            .OrderBy(token => token.CreatedAt)
            .ToList();

        while (activeTokens.Count >= 5)
        {
            var oldestToken = activeTokens[0];

            oldestToken.Revoke(utcNow);

            activeTokens.RemoveAt(0);
        }
    }

    private Task AddLoginActivityAsync(
        Guid userId,
        bool isSuccessful,
        DateTime occurredAt,
        CancellationToken cancellationToken
    )
    {
        var activity = LoginActivity.Create(
            userId,
            _requestContext.IpAddress ?? "Unknown",
            isSuccessful,
            occurredAt
        );

        return _userRepository.AddLoginActivityAsync(activity, cancellationToken);
    }

    private Task WriteAuditAsync(
        Guid userId,
        string eventType,
        string outcome,
        string description,
        CancellationToken cancellationToken
    )
    {
        return _auditWriter.WriteAsync(
            new SecurityAuditEntry(
                eventType,
                outcome,
                SecurityAuditActorTypes.User,
                userId,
                userId,
                description
            ),
            cancellationToken
        );
    }

    private Task WriteUnknownLoginFailureAsync(CancellationToken cancellationToken)
    {
        return _auditWriter.WriteAsync(
            new SecurityAuditEntry(
                SecurityAuditEventTypes.LoginFailed,
                SecurityAuditOutcomes.Failed,
                SecurityAuditActorTypes.Anonymous,
                null,
                null,
                "Login failed because invalid credentials were supplied."
            ),
            cancellationToken
        );
    }

    private static AppException InvalidCredentials()
    {
        return new AppException(
            401,
            ErrorCodes.AuthInvalidCredentials,
            "Invalid username or password."
        );
    }
}


using FluentValidation;

namespace AuthService.Application.Commands.Login;

public sealed class LoginCommandValidator : AbstractValidator<LoginCommand>
{
    public LoginCommandValidator()
    {
        RuleFor(command => command.Email).NotEmpty().EmailAddress().MaximumLength(255);

        RuleFor(command => command.Password).NotEmpty();
    }
}


namespace AuthService.Application.Commands.Login;

internal static class LoginPolicy
{
    public const int MaximumFailedAttempts = 5;

    public static readonly TimeSpan LockoutDuration = TimeSpan.FromMinutes(15);
}


using MediatR;

namespace AuthService.Application.Commands.Login;

public sealed record LoginCommand(
    string Email,
    string Password,
    bool RememberMe = false,
    string? TrustedDeviceToken = null
) : IRequest<LoginResult>;


namespace AuthService.Application.Commands.Login;

public sealed record LoginResult(
    bool MfaRequired,
    string? MfaChallengeToken,
    string? AccessToken,
    string? RefreshToken,
    int? ExpiresIn,
    string? TrustedDeviceToken = null
)
{
    public static LoginResult RequireMfa(string challengeToken)
    {
        return new LoginResult(true, challengeToken, null, null, null);
    }

    public static LoginResult Authenticated(
        string accessToken,
        string refreshToken,
        int expiresIn,
        string? trustedDeviceToken = null
    )
    {
        return new LoginResult(false, null, accessToken, refreshToken, expiresIn, trustedDeviceToken);
    }
}


using FluentValidation;

namespace AuthService.Application.Commands.Logout;

public sealed class LogoutCommandValidator : AbstractValidator<LogoutCommand>
{
    public LogoutCommandValidator()
    {
        RuleFor(command => command.RefreshToken).NotEmpty();

        RuleFor(command => command.AuthenticatedUserId).NotEmpty();
    }
}


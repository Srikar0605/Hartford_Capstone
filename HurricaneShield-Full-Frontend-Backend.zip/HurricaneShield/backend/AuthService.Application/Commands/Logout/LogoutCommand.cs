using MediatR;

namespace AuthService.Application.Commands.Logout;

public sealed record LogoutCommand(string RefreshToken, Guid AuthenticatedUserId) : IRequest;


using AuthService.Application.Abstractions.Auditing;
using AuthService.Application.Abstractions.Authentication;
using AuthService.Application.Abstractions.Time;
using AuthService.Domain.Constants;
using AuthService.Domain.Repositories;
using MediatR;
using Shared.Common.Errors;
using Shared.Common.Exceptions;

namespace AuthService.Application.Commands.Logout;

public sealed class LogoutCommandHandler : IRequestHandler<LogoutCommand>
{
    private readonly IUserRepository _userRepository;
    private readonly IRefreshTokenGenerator _refreshTokenGenerator;
    private readonly ISecurityAuditWriter _auditWriter;
    private readonly IUnitOfWork _unitOfWork;
    private readonly IDateTimeProvider _dateTimeProvider;

    public LogoutCommandHandler(
        IUserRepository userRepository,
        IRefreshTokenGenerator refreshTokenGenerator,
        ISecurityAuditWriter auditWriter,
        IUnitOfWork unitOfWork,
        IDateTimeProvider dateTimeProvider
    )
    {
        _userRepository = userRepository;
        _refreshTokenGenerator = refreshTokenGenerator;
        _auditWriter = auditWriter;
        _unitOfWork = unitOfWork;
        _dateTimeProvider = dateTimeProvider;
    }

    public async Task Handle(LogoutCommand request, CancellationToken cancellationToken)
    {
        var tokenHash = _refreshTokenGenerator.HashToken(request.RefreshToken);

        var refreshToken = await _userRepository.GetRefreshTokenByHashAsync(
            tokenHash,
            cancellationToken
        );

        if (refreshToken is null || refreshToken.UserId != request.AuthenticatedUserId)
        {
            throw new AppException(401, ErrorCodes.AuthInvalidToken, "Refresh token is invalid.");
        }

        var utcNow = _dateTimeProvider.UtcNow;

        if (!refreshToken.IsRevoked())
        {
            refreshToken.Revoke(utcNow);

            await _auditWriter.WriteAsync(
                new SecurityAuditEntry(
                    SecurityAuditEventTypes.RefreshTokenRevoked,
                    SecurityAuditOutcomes.Succeeded,
                    SecurityAuditActorTypes.User,
                    request.AuthenticatedUserId,
                    request.AuthenticatedUserId,
                    "A refresh token was revoked during logout."
                ),
                cancellationToken
            );

            await _unitOfWork.SaveChangesAsync(cancellationToken);
        }
    }
}


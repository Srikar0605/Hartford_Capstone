using MediatR;

namespace AuthService.Application.Commands.VerifyMfa;

public sealed record VerifyMfaCommand(string MfaChallengeToken, string VerificationCode)
    : IRequest<VerifyMfaResult>;


using AuthService.Application.Abstractions.Auditing;
using AuthService.Application.Abstractions.Authentication;
using AuthService.Application.Abstractions.Time;
using AuthService.Domain.Constants;
using AuthService.Domain.Repositories;
using MediatR;
using Shared.Common.Errors;
using Shared.Common.Exceptions;

namespace AuthService.Application.Commands.VerifyMfa;

public sealed record VerifyRecoveryCodeCommand(string Email, string RecoveryCode)
    : IRequest<VerifyRecoveryCodeResult>;

public sealed record VerifyRecoveryCodeResult(
    string AccessToken,
    string RefreshToken,
    int ExpiresIn
);

public sealed class VerifyRecoveryCodeCommandHandler
    : IRequestHandler<VerifyRecoveryCodeCommand, VerifyRecoveryCodeResult>
{
    private readonly IUserRepository _userRepository;
    private readonly IRecoveryCodeService _recoveryCodeService;
    private readonly IAuthenticationTokenIssuer _tokenIssuer;
    private readonly ISecurityAuditWriter _auditWriter;
    private readonly IUnitOfWork _unitOfWork;
    private readonly IDateTimeProvider _dateTimeProvider;

    public VerifyRecoveryCodeCommandHandler(
        IUserRepository userRepository,
        IRecoveryCodeService recoveryCodeService,
        IAuthenticationTokenIssuer tokenIssuer,
        ISecurityAuditWriter auditWriter,
        IUnitOfWork unitOfWork,
        IDateTimeProvider dateTimeProvider
    )
    {
        _userRepository = userRepository;
        _recoveryCodeService = recoveryCodeService;
        _tokenIssuer = tokenIssuer;
        _auditWriter = auditWriter;
        _unitOfWork = unitOfWork;
        _dateTimeProvider = dateTimeProvider;
    }

    public async Task<VerifyRecoveryCodeResult> Handle(
        VerifyRecoveryCodeCommand request,
        CancellationToken cancellationToken
    )
    {
        var user = await _userRepository.GetByEmailWithMfaAndRecoveryCodesAsync(
            request.Email,
            cancellationToken
        );

        if (user?.Mfa?.IsEnabled != true)
        {
            throw InvalidRecoveryCode();
        }

        var matchingCode = user
            .RecoveryCodes.Where(code => !code.IsUsed())
            .FirstOrDefault(code =>
                _recoveryCodeService.VerifyCode(user, code.CodeHash, request.RecoveryCode)
            );

        if (matchingCode is null)
        {
            throw InvalidRecoveryCode();
        }

        matchingCode.MarkAsUsed(_dateTimeProvider.UtcNow);

        var tokens = await _tokenIssuer.IssueAsync(user, cancellationToken);

        await _auditWriter.WriteAsync(
            new SecurityAuditEntry(
                SecurityAuditEventTypes.RecoveryCodeUsed,
                SecurityAuditOutcomes.Succeeded,
                SecurityAuditActorTypes.User,
                user.Id,
                user.Id,
                "A recovery code was used for authentication."
            ),
            cancellationToken
        );

        await _unitOfWork.SaveChangesAsync(cancellationToken);

        return new VerifyRecoveryCodeResult(
            tokens.AccessToken,
            tokens.RefreshToken,
            tokens.ExpiresIn
        );
    }

    private static AppException InvalidRecoveryCode()
    {
        return new AppException(
            401,
            ErrorCodes.AuthRecoveryCodeInvalid,
            "Recovery code is invalid or has already been used."
        );
    }
}


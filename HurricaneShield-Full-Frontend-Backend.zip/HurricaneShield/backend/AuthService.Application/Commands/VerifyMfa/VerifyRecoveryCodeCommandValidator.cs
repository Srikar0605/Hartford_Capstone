using FluentValidation;

namespace AuthService.Application.Commands.VerifyMfa;

public sealed class VerifyRecoveryCodeCommandValidator
    : AbstractValidator<VerifyRecoveryCodeCommand>
{
    public VerifyRecoveryCodeCommandValidator()
    {
        RuleFor(command => command.Email).NotEmpty().EmailAddress().MaximumLength(255);

        RuleFor(command => command.RecoveryCode)
            .NotEmpty()
            .Matches("^[A-Za-z2-9]{4}-[A-Za-z2-9]{4}-[A-Za-z2-9]{4}$");
    }
}


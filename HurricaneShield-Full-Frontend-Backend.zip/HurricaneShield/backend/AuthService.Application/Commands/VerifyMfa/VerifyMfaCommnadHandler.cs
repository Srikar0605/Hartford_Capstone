using AuthService.Application.Abstractions.Auditing;
using AuthService.Application.Abstractions.Authentication;
using AuthService.Domain.Constants;
using AuthService.Domain.Repositories;
using MediatR;
using Shared.Common.Errors;
using Shared.Common.Exceptions;

namespace AuthService.Application.Commands.VerifyMfa;

public sealed class VerifyMfaCommandHandler : IRequestHandler<VerifyMfaCommand, VerifyMfaResult>
{
    private readonly IUserRepository _userRepository;
    private readonly IMfaChallengeStore _challengeStore;
    private readonly IMfaService _mfaService;
    private readonly IMfaSecretProtector _secretProtector;
    private readonly IAuthenticationTokenIssuer _tokenIssuer;
    private readonly ISecurityAuditWriter _auditWriter;
    private readonly IUnitOfWork _unitOfWork;

    public VerifyMfaCommandHandler(
        IUserRepository userRepository,
        IMfaChallengeStore challengeStore,
        IMfaService mfaService,
        IMfaSecretProtector secretProtector,
        IAuthenticationTokenIssuer tokenIssuer,
        ISecurityAuditWriter auditWriter,
        IUnitOfWork unitOfWork
    )
    {
        _userRepository = userRepository;
        _challengeStore = challengeStore;
        _mfaService = mfaService;
        _secretProtector = secretProtector;
        _tokenIssuer = tokenIssuer;
        _auditWriter = auditWriter;
        _unitOfWork = unitOfWork;
    }

    public async Task<VerifyMfaResult> Handle(
        VerifyMfaCommand request,
        CancellationToken cancellationToken
    )
    {
        var challengeIsValid = _challengeStore.TryGetUserId(
            request.MfaChallengeToken,
            out var userId
        );

        if (!challengeIsValid)
        {
            throw InvalidCode();
        }

        var user = await _userRepository.GetByIdWithMfaAsync(userId, cancellationToken);

        if (user is null || !user.IsActive || user.Mfa?.IsEnabled != true)
        {
            _challengeStore.Remove(request.MfaChallengeToken);

            throw InvalidCode();
        }

        var secret = _secretProtector.Unprotect(user.Mfa.EncryptedSecretKey);

        var codeIsValid = _mfaService.VerifyCode(secret, request.VerificationCode);

        if (!codeIsValid)
        {
            _challengeStore.RecordFailedAttempt(request.MfaChallengeToken);

            await _auditWriter.WriteAsync(
                new SecurityAuditEntry(
                    SecurityAuditEventTypes.LoginFailed,
                    SecurityAuditOutcomes.Failed,
                    SecurityAuditActorTypes.User,
                    user.Id,
                    user.Id,
                    "MFA verification failed."
                ),
                cancellationToken
            );

            await _unitOfWork.SaveChangesAsync(cancellationToken);

            throw InvalidCode();
        }

        _challengeStore.Remove(request.MfaChallengeToken);

        var tokens = await _tokenIssuer.IssueAsync(user, cancellationToken);

        await _auditWriter.WriteAsync(
            new SecurityAuditEntry(
                SecurityAuditEventTypes.LoginSucceeded,
                SecurityAuditOutcomes.Succeeded,
                SecurityAuditActorTypes.User,
                user.Id,
                user.Id,
                "MFA verification completed successfully."
            ),
            cancellationToken
        );

        await _auditWriter.WriteAsync(
            new SecurityAuditEntry(
                SecurityAuditEventTypes.RefreshTokenIssued,
                SecurityAuditOutcomes.Succeeded,
                SecurityAuditActorTypes.User,
                user.Id,
                user.Id,
                "A refresh token was issued after MFA verification."
            ),
            cancellationToken
        );

        await _unitOfWork.SaveChangesAsync(cancellationToken);

        return new VerifyMfaResult(tokens.AccessToken, tokens.RefreshToken, tokens.ExpiresIn);
    }

    private static AppException InvalidCode()
    {
        return new AppException(401, ErrorCodes.AuthInvalidMfaCode, "MFA code is invalid.");
    }
}


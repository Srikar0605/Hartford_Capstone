namespace AuthService.Application.Commands.VerifyMfa;

public sealed record VerifyMfaResult(string AccessToken, string RefreshToken, int ExpiresIn);


using FluentValidation;

namespace AuthService.Application.Commands.VerifyMfa;

public sealed class VerifyMfaCommandValidator : AbstractValidator<VerifyMfaCommand>
{
    public VerifyMfaCommandValidator()
    {
        RuleFor(command => command.MfaChallengeToken).NotEmpty();

        RuleFor(command => command.VerificationCode).NotEmpty().Length(6).Matches("^[0-9]{6}$");
    }
}


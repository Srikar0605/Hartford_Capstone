namespace AuthService.Application.Commands.RefreshAccessToken;

public sealed record RefreshAccessTokenResult(
    string AccessToken,
    string RefreshToken,
    int ExpiresIn
);


using FluentValidation;

namespace AuthService.Application.Commands.ConfirmMfa;

public sealed class ConfirmMfaCommandValidator : AbstractValidator<ConfirmMfaCommand>
{
    public ConfirmMfaCommandValidator()
    {
        RuleFor(command => command.UserId).NotEmpty();

        RuleFor(command => command.VerificationCode).NotEmpty().Length(6).Matches("^[0-9]{6}$");
    }
}


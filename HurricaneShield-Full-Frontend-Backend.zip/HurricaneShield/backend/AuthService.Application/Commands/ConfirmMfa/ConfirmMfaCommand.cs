using MediatR;

namespace AuthService.Application.Commands.ConfirmMfa;

public sealed record ConfirmMfaCommand(Guid UserId, string VerificationCode)
    : IRequest<ConfirmMfaResult>;


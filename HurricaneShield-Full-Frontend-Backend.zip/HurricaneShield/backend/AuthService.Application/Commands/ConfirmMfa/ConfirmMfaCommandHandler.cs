using AuthService.Application.Abstractions.Auditing;
using AuthService.Application.Abstractions.Authentication;
using AuthService.Application.Abstractions.Time;
using AuthService.Domain.Constants;
using AuthService.Domain.Entities;
using AuthService.Domain.Repositories;
using MediatR;
using Shared.Common.Errors;
using Shared.Common.Exceptions;

namespace AuthService.Application.Commands.ConfirmMfa;

public sealed class ConfirmMfaCommandHandler : IRequestHandler<ConfirmMfaCommand, ConfirmMfaResult>
{
    private const int RecoveryCodeCount = 10;

    private readonly IUserRepository _userRepository;
    private readonly IMfaService _mfaService;
    private readonly IMfaSecretProtector _secretProtector;
    private readonly IRecoveryCodeService _recoveryCodeService;
    private readonly ISecurityAuditWriter _auditWriter;
    private readonly IUnitOfWork _unitOfWork;
    private readonly IDateTimeProvider _dateTimeProvider;

    public ConfirmMfaCommandHandler(
        IUserRepository userRepository,
        IMfaService mfaService,
        IMfaSecretProtector secretProtector,
        IRecoveryCodeService recoveryCodeService,
        ISecurityAuditWriter auditWriter,
        IUnitOfWork unitOfWork,
        IDateTimeProvider dateTimeProvider
    )
    {
        _userRepository = userRepository;
        _mfaService = mfaService;
        _secretProtector = secretProtector;
        _recoveryCodeService = recoveryCodeService;
        _auditWriter = auditWriter;
        _unitOfWork = unitOfWork;
        _dateTimeProvider = dateTimeProvider;
    }

    public async Task<ConfirmMfaResult> Handle(
        ConfirmMfaCommand request,
        CancellationToken cancellationToken
    )
    {
        var user = await _userRepository.GetByIdWithMfaAsync(request.UserId, cancellationToken);

        if (user?.Mfa is null)
        {
            throw InvalidCode();
        }

        var secret = _secretProtector.Unprotect(user.Mfa.EncryptedSecretKey);

        if (!_mfaService.VerifyCode(secret, request.VerificationCode))
        {
            throw InvalidCode();
        }

        var utcNow = _dateTimeProvider.UtcNow;

        user.Mfa.Enable(utcNow);

        var rawCodes = _recoveryCodeService.GenerateCodes(RecoveryCodeCount);

        var recoveryCodes = rawCodes
            .Select(rawCode =>
                RecoveryCode.Create(user.Id, _recoveryCodeService.HashCode(user, rawCode), utcNow)
            )
            .ToArray();

        await _userRepository.AddRecoveryCodesAsync(recoveryCodes, cancellationToken);

        await _auditWriter.WriteAsync(
            new SecurityAuditEntry(
                SecurityAuditEventTypes.MfaEnabled,
                SecurityAuditOutcomes.Succeeded,
                SecurityAuditActorTypes.User,
                user.Id,
                user.Id,
                "MFA enrollment was confirmed."
            ),
            cancellationToken
        );

        await _unitOfWork.SaveChangesAsync(cancellationToken);

        return new ConfirmMfaResult(rawCodes);
    }

    private static AppException InvalidCode()
    {
        return new AppException(401, ErrorCodes.AuthInvalidMfaCode, "MFA code is invalid.");
    }
}


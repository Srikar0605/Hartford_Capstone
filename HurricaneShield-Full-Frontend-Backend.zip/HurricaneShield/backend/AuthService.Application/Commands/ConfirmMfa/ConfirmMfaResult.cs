namespace AuthService.Application.Commands.ConfirmMfa;

public sealed record ConfirmMfaResult(IReadOnlyCollection<string> RecoveryCodes);


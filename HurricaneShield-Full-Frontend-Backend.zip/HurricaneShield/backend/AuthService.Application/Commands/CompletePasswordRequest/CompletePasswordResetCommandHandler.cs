using AuthService.Application.Abstractions.Auditing;
using AuthService.Application.Abstractions.Authentication;
using AuthService.Application.Abstractions.Time;
using AuthService.Domain.Constants;
using AuthService.Domain.Entities;
using AuthService.Domain.Repositories;
using MediatR;
using Shared.Common.Errors;
using Shared.Common.Exceptions;

namespace AuthService.Application.Commands.CompletePasswordReset;

public sealed class CompletePasswordResetCommandHandler
    : IRequestHandler<CompletePasswordResetCommand>
{
    private const int PasswordHistoryDepth = 3;

    private readonly IUserRepository _userRepository;
    private readonly IPasswordResetTokenGenerator _tokenGenerator;
    private readonly IPasswordHasher _passwordHasher;
    private readonly ISecurityAuditWriter _auditWriter;
    private readonly IUnitOfWork _unitOfWork;
    private readonly IDateTimeProvider _dateTimeProvider;

    public CompletePasswordResetCommandHandler(
        IUserRepository userRepository,
        IPasswordResetTokenGenerator tokenGenerator,
        IPasswordHasher passwordHasher,
        ISecurityAuditWriter auditWriter,
        IUnitOfWork unitOfWork,
        IDateTimeProvider dateTimeProvider
    )
    {
        _userRepository = userRepository;
        _tokenGenerator = tokenGenerator;
        _passwordHasher = passwordHasher;
        _auditWriter = auditWriter;
        _unitOfWork = unitOfWork;
        _dateTimeProvider = dateTimeProvider;
    }

    public async Task Handle(
        CompletePasswordResetCommand request,
        CancellationToken cancellationToken
    )
    {
        var utcNow = _dateTimeProvider.UtcNow;

        var tokenHash = _tokenGenerator.HashToken(request.Token);

        var resetToken = await _userRepository.GetPasswordResetTokenByHashAsync(
            tokenHash,
            cancellationToken
        );

        if (resetToken is null || !resetToken.IsValid(utcNow))
        {
            throw new AppException(
                401,
                ErrorCodes.AuthInvalidToken,
                "Password reset token is invalid or expired."
            );
        }

        var user = resetToken.User;

        if (_passwordHasher.VerifyPassword(user, user.PasswordHash, request.NewPassword))
        {
            throw PasswordReuse();
        }

        var recentHistory = user
            .PasswordHistories.OrderByDescending(history => history.CreatedAt)
            .Take(PasswordHistoryDepth);

        foreach (var history in recentHistory)
        {
            if (_passwordHasher.VerifyPassword(user, history.PasswordHash, request.NewPassword))
            {
                throw PasswordReuse();
            }
        }

        await _userRepository.AddPasswordHistoryAsync(
            PasswordHistory.Create(user.Id, user.PasswordHash, utcNow),
            cancellationToken
        );

        var newHash = _passwordHasher.HashPassword(user, request.NewPassword);

        user.ChangePasswordHash(newHash, utcNow, "PasswordReset");

        user.RecordSuccessfulLogin();

        resetToken.MarkAsUsed(utcNow);

        await _userRepository.RevokeActiveRefreshTokensAsync(user.Id, utcNow, cancellationToken);

        await _userRepository.TrimPasswordHistoryAsync(
            user.Id,
            PasswordHistoryDepth,
            cancellationToken
        );

        await _auditWriter.WriteAsync(
            new SecurityAuditEntry(
                SecurityAuditEventTypes.PasswordResetCompleted,
                SecurityAuditOutcomes.Succeeded,
                SecurityAuditActorTypes.Anonymous,
                null,
                user.Id,
                "Password reset completed successfully."
            ),
            cancellationToken
        );

        await _unitOfWork.SaveChangesAsync(cancellationToken);
    }

    private static AppException PasswordReuse()
    {
        return new AppException(
            400,
            ErrorCodes.AuthPasswordReuseNotAllowed,
            "Password cannot match a recent password."
        );
    }
}


using MediatR;

namespace AuthService.Application.Commands.CompletePasswordReset;

public sealed record CompletePasswordResetCommand(string Token, string NewPassword) : IRequest;


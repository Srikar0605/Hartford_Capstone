namespace AuthService.Application.Commands.RequestPasswordReset;

public sealed record RequestPasswordResetResult(string? DevelopmentToken);


using AuthService.Application.Abstractions.Auditing;
using AuthService.Application.Abstractions.Authentication;
using AuthService.Application.Abstractions.Services;
using AuthService.Application.Abstractions.Time;
using AuthService.Domain.Constants;
using AuthService.Domain.Entities;
using AuthService.Domain.Repositories;
using MediatR;

namespace AuthService.Application.Commands.RequestPasswordReset;

public sealed class RequestPasswordResetCommandHandler
    : IRequestHandler<RequestPasswordResetCommand, RequestPasswordResetResult>
{
    private readonly IUserRepository _userRepository;
    private readonly IPasswordResetTokenGenerator _tokenGenerator;
    private readonly IPasswordResetNotifier _notifier;
    private readonly ISecurityAuditWriter _auditWriter;
    private readonly IUnitOfWork _unitOfWork;
    private readonly IDateTimeProvider _dateTimeProvider;

    public RequestPasswordResetCommandHandler(
        IUserRepository userRepository,
        IPasswordResetTokenGenerator tokenGenerator,
        IPasswordResetNotifier notifier,
        ISecurityAuditWriter auditWriter,
        IUnitOfWork unitOfWork,
        IDateTimeProvider dateTimeProvider
    )
    {
        _userRepository = userRepository;
        _tokenGenerator = tokenGenerator;
        _notifier = notifier;
        _auditWriter = auditWriter;
        _unitOfWork = unitOfWork;
        _dateTimeProvider = dateTimeProvider;
    }

    public async Task<RequestPasswordResetResult> Handle(
        RequestPasswordResetCommand request,
        CancellationToken cancellationToken
    )
    {
        var user = await _userRepository.GetByEmailAsync(request.Email, cancellationToken);

        if (user is null || !user.IsActive)
        {
            return new RequestPasswordResetResult(null);
        }

        var utcNow = _dateTimeProvider.UtcNow;

        await _userRepository.RevokeActivePasswordResetTokensAsync(
            user.Id,
            utcNow,
            cancellationToken
        );

        var generatedToken = _tokenGenerator.Generate();

        await _userRepository.AddPasswordResetTokenAsync(
            PasswordResetToken.Create(
                user.Id,
                generatedToken.TokenHash,
                generatedToken.ExpiresAt,
                utcNow,
                "PasswordResetRequest"
            ),
            cancellationToken
        );

        await _auditWriter.WriteAsync(
            new SecurityAuditEntry(
                SecurityAuditEventTypes.PasswordResetRequested,
                SecurityAuditOutcomes.Succeeded,
                SecurityAuditActorTypes.Anonymous,
                null,
                user.Id,
                "A password reset was requested."
            ),
            cancellationToken
        );

        await _unitOfWork.SaveChangesAsync(cancellationToken);

        await _notifier.SendAsync(user.Email, generatedToken.RawToken, cancellationToken);

        return new RequestPasswordResetResult(generatedToken.RawToken);
    }
}


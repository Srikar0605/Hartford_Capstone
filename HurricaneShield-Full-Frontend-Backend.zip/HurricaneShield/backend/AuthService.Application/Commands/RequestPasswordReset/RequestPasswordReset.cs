using MediatR;

namespace AuthService.Application.Commands.RequestPasswordReset;

public sealed record RequestPasswordResetCommand(string Email)
    : IRequest<RequestPasswordResetResult>;


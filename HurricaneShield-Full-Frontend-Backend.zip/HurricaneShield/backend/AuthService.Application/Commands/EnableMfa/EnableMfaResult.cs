namespace AuthService.Application.Commands.EnableMfa;

public sealed record EnableMfaResult(string QrCodeUrl, string ManualSecret);


using AuthService.Application.Abstractions.Auditing;
using AuthService.Application.Abstractions.Authentication;
using AuthService.Domain.Constants;
using AuthService.Domain.Entities;
using AuthService.Domain.Repositories;
using MediatR;
using Shared.Common.Errors;
using Shared.Common.Exceptions;

namespace AuthService.Application.Commands.EnableMfa;

public sealed class EnableMfaCommandHandler : IRequestHandler<EnableMfaCommand, EnableMfaResult>
{
    private readonly IUserRepository _userRepository;
    private readonly IMfaService _mfaService;
    private readonly IMfaSecretProtector _secretProtector;
    private readonly ISecurityAuditWriter _auditWriter;
    private readonly IUnitOfWork _unitOfWork;

    public EnableMfaCommandHandler(
        IUserRepository userRepository,
        IMfaService mfaService,
        IMfaSecretProtector secretProtector,
        ISecurityAuditWriter auditWriter,
        IUnitOfWork unitOfWork
    )
    {
        _userRepository = userRepository;
        _mfaService = mfaService;
        _secretProtector = secretProtector;
        _auditWriter = auditWriter;
        _unitOfWork = unitOfWork;
    }

    public async Task<EnableMfaResult> Handle(
        EnableMfaCommand request,
        CancellationToken cancellationToken
    )
    {
        var user = await _userRepository.GetByIdWithMfaAsync(request.UserId, cancellationToken);

        if (user is null || !user.IsActive)
        {
            throw Unauthorized();
        }

        var secret = _mfaService.GenerateSecret();

        var encryptedSecret = _secretProtector.Protect(secret);

        if (user.Mfa is null)
        {
            await _userRepository.AddUserMfaAsync(
                UserMfa.CreatePending(user.Id, encryptedSecret),
                cancellationToken
            );
        }
        else
        {
            user.Mfa.ReplaceSecret(encryptedSecret);
        }

        await _auditWriter.WriteAsync(
            new SecurityAuditEntry(
                SecurityAuditEventTypes.MfaEnrollmentStarted,
                SecurityAuditOutcomes.Succeeded,
                SecurityAuditActorTypes.User,
                user.Id,
                user.Id,
                "MFA enrollment was started."
            ),
            cancellationToken
        );

        await _unitOfWork.SaveChangesAsync(cancellationToken);

        return new EnableMfaResult(_mfaService.BuildAuthenticatorUri(user.Email, secret), secret);
    }

    private static AppException Unauthorized()
    {
        return new AppException(401, ErrorCodes.AuthInvalidToken, "Authenticated user is invalid.");
    }
}


using MediatR;

namespace AuthService.Application.Commands.EnableMfa;

public sealed record EnableMfaCommand(Guid UserId) : IRequest<EnableMfaResult>;


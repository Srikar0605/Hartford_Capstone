using FluentValidation;

namespace AuthService.Application.Commands.AssignUserRole;

public sealed class AssignUserRoleCommandValidator : AbstractValidator<AssignUserRoleCommand>
{
    public AssignUserRoleCommandValidator()
    {
        RuleFor(command => command.ActorUserId).NotEmpty();

        RuleFor(command => command.TargetUserId).NotEmpty();

        RuleFor(command => command.RoleName).NotEmpty().MaximumLength(100);
    }
}


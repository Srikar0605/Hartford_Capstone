using AuthService.Application.Abstractions.Auditing;
using AuthService.Domain.Constants;
using AuthService.Domain.Entities;
using AuthService.Domain.Repositories;
using MediatR;
using Shared.Common.Errors;
using Shared.Common.Exceptions;

namespace AuthService.Application.Commands.AssignUserRole;

public sealed class AssignUserRoleCommandHandler(
    IUserRepository userRepository,
    IRoleRepository roleRepository,
    ISecurityAuditWriter auditWriter,
    IUnitOfWork unitOfWork
) : IRequestHandler<AssignUserRoleCommand>
{
    public async Task Handle(
        AssignUserRoleCommand request,
        CancellationToken cancellationToken
    )
    {
        if (!SystemRoles.All.Contains(request.RoleName, StringComparer.Ordinal))
            throw new RequestValidationException();

        var targetUser = await userRepository.GetByIdAsync(
            request.TargetUserId,
            cancellationToken
        );

        if (targetUser is null)
            throw new AppException(404, ErrorCodes.InvalidRequest, "Target user was not found.");

        var selectedRole = await roleRepository.GetByNameAsync(
            request.RoleName,
            cancellationToken
        );

        if (selectedRole is null)
            throw new AppException(404, ErrorCodes.InvalidRequest, "Role was not found.");

        var currentUserRoles = await roleRepository.GetUserRolesAsync(
            targetUser.Id,
            cancellationToken
        );

        if (currentUserRoles.Count == 1 && currentUserRoles.Single().RoleId == selectedRole.Id)
            return;

        var administratorRole = await roleRepository.GetByNameAsync(
            SystemRoles.Administrator,
            cancellationToken
        );

        if (administratorRole is null)
            throw new InvalidOperationException("The Administrator role was not found.");

        var replacingAdministrator =
            request.RoleName != SystemRoles.Administrator
            && currentUserRoles.Any(userRole => userRole.RoleId == administratorRole.Id);

        if (replacingAdministrator)
        {
            var administratorCount = await roleRepository.CountUsersInRoleAsync(
                administratorRole.Id,
                cancellationToken
            );

            if (administratorCount <= 1)
                throw new AppException(
                    409,
                    ErrorCodes.ResourceConflict,
                    "The final Administrator role cannot be replaced."
                );
        }

        var previousRoleNames = await roleRepository.GetUserRoleNamesAsync(
            targetUser.Id,
            cancellationToken
        );

        await unitOfWork.ExecuteInTransactionAsync(
            async transactionCancellationToken =>
            {
                foreach (var currentUserRole in currentUserRoles)
                    roleRepository.RemoveUserRole(currentUserRole);

                await roleRepository.AddUserRoleAsync(
                    UserRole.Create(targetUser.Id, selectedRole.Id),
                    transactionCancellationToken
                );

                await auditWriter.WriteAsync(
                    new SecurityAuditEntry(
                        SecurityAuditEventTypes.RoleAssigned,
                        SecurityAuditOutcomes.Succeeded,
                        SecurityAuditActorTypes.User,
                        request.ActorUserId,
                        targetUser.Id,
                        "The user's system role was replaced.",
                        new
                        {
                            change = "RoleReplaced",
                            previousRoles = previousRoleNames,
                            assignedRole = selectedRole.Name,
                        }
                    ),
                    transactionCancellationToken
                );
            },
            cancellationToken
        );
    }
}


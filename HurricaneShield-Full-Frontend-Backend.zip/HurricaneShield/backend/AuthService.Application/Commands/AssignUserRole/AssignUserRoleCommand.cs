using MediatR;

namespace AuthService.Application.Commands.AssignUserRole;

public sealed record AssignUserRoleCommand(Guid ActorUserId, Guid TargetUserId, string RoleName)
    : IRequest;


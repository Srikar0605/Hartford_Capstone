using PaymentService.Application.DTOs.Settlements;
using PaymentService.Application.DTOs.Transactions;

namespace PaymentService.Application.Interfaces;

public interface IClaimSettlementService
{
    Task<ClaimSettlementResponse> ProcessAsync(
        ProcessClaimSettlementRequest request,
        string idempotencyKey,
        CancellationToken cancellationToken
    );

    Task<TransactionDetailsResponse> RetryAsync(
        Guid transactionId,
        RetryPaymentRequest request,
        CancellationToken cancellationToken
    );

    Task<TransactionDetailsResponse> GetSettlementAsync(
        Guid transactionId,
        CancellationToken cancellationToken
    );
}


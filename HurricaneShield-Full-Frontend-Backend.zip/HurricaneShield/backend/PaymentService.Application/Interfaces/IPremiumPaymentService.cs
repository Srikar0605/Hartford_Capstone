using PaymentService.Application.DTOs.Premiums;
using PaymentService.Application.DTOs.Transactions;

namespace PaymentService.Application.Interfaces;

public interface IPremiumPaymentService
{
    Task<PremiumPaymentResponse> ProcessAsync(
        ProcessPremiumPaymentRequest request,
        string idempotencyKey,
        CancellationToken cancellationToken
    );

    Task<TransactionDetailsResponse> RetryAsync(
        Guid transactionId,
        RetryPaymentRequest request,
        CancellationToken cancellationToken
    );
}


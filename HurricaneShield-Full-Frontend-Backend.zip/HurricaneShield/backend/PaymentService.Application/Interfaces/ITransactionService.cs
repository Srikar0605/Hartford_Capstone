using PaymentService.Application.DTOs.Common;
using PaymentService.Application.DTOs.Transactions;

namespace PaymentService.Application.Interfaces;

public interface ITransactionService
{
    Task<TransactionDetailsResponse> GetAsync(
        Guid transactionId,
        CancellationToken cancellationToken
    );

    Task<PagedResponse<TransactionSummaryResponse>> GetMyTransactionsAsync(
        TransactionSearchRequest request,
        CancellationToken cancellationToken
    );

    Task<PagedResponse<TransactionSummaryResponse>> SearchAsync(
        TransactionSearchRequest request,
        CancellationToken cancellationToken
    );

    Task<TransactionValidationResponse> ValidateAsync(
        Guid transactionId,
        CancellationToken cancellationToken
    );
}


namespace PaymentService.Application.Interfaces;

public interface IRequestContext
{
    Guid UserId { get; }
    string Actor { get; }
    string CorrelationId { get; }
    bool IsInRole(string role);
    bool HasPermission(string permission);
}

public interface IDateTimeProvider
{
    DateTime UtcNow { get; }
}

public interface ITransactionNumberGenerator
{
    string Generate(DateTime utcNow);
}

public interface IReceiptNumberGenerator
{
    string Generate(DateTime utcNow);
}


using PaymentService.Application.DTOs.Requests;
using PaymentService.Application.DTOs.Responses;

namespace PaymentService.Application.Interfaces;

public interface IRefundService
{
    Task<RefundResponse> ProcessRefundAsync(
        RefundProcessingRequest request,
        string idempotencyKey,
        CancellationToken cancellationToken
    );
}


using PaymentService.Application.DTOs.Receipts;

namespace PaymentService.Application.Interfaces;

public interface IReceiptService
{
    Task<PaymentReceiptResponse> GetByTransactionAsync(
        Guid transactionId,
        CancellationToken cancellationToken
    );
}


using PaymentService.Application.DTOs.Integrations;
using PaymentService.Domain.Models;

namespace PaymentService.Application.Interfaces;

public interface IPolicyClient
{
    Task<PolicyPremiumValidationResponse> ValidatePremiumAsync(
        Guid policyId,
        Guid authUserId,
        CancellationToken cancellationToken
    );
    Task ConfirmPaymentAsync(
        Guid policyId,
        string paymentContext,
        PolicyPaymentConfirmationRequest request,
        CancellationToken cancellationToken
    );
}

public interface IClaimsClient
{
    Task<ClaimSettlementValidationResponse> ValidateSettlementAsync(
        Guid claimId,
        CancellationToken cancellationToken
    );
    Task ConfirmSettlementAsync(
        Guid claimId,
        ClaimSettlementConfirmationRequest request,
        CancellationToken cancellationToken
    );
}

public interface IPaymentGateway
{
    Task<PaymentGatewayResult> ProcessAsync(
        PaymentGatewayRequest request,
        CancellationToken cancellationToken
    );
}


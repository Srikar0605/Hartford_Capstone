using FluentValidation;

namespace PaymentService.Application.Validation;

internal static class ValidationExtensions
{
    internal static IRuleBuilderOptions<T, string> ValidRowVersion<T>(
        this IRuleBuilder<T, string> rule
    )
    {
        return rule.NotEmpty()
            .Must(value =>
            {
                try
                {
                    return Convert.FromBase64String(value).Length == 8;
                }
                catch (FormatException)
                {
                    return false;
                }
            })
            .WithMessage("RowVersion must be a Base64 string representing exactly eight bytes.");
    }
}


using FluentValidation;
using PaymentService.Application.DTOs.Transactions;

namespace PaymentService.Application.Validation;

public sealed class TransactionSearchRequestValidator : AbstractValidator<TransactionSearchRequest>
{
    public TransactionSearchRequestValidator()
    {
        RuleFor(x => x.Page).GreaterThanOrEqualTo(1);
        RuleFor(x => x.PageSize).InclusiveBetween(1, 100);
        RuleFor(x => x)
            .Must(x => !x.From.HasValue || !x.To.HasValue || x.From <= x.To)
            .WithMessage("From cannot be after To.");
    }
}


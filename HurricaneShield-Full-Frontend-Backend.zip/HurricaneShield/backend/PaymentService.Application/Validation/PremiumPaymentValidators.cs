using FluentValidation;
using PaymentService.Application.DTOs.Premiums;

namespace PaymentService.Application.Validation;

public sealed class ProcessPremiumPaymentRequestValidator
    : AbstractValidator<ProcessPremiumPaymentRequest>
{
    public ProcessPremiumPaymentRequestValidator()
    {
        RuleFor(x => x.PolicyId).NotEmpty();
        RuleFor(x => x.Amount).GreaterThan(0m);
    }
}


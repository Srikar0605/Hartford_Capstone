using FluentValidation;
using PaymentService.Application.DTOs.Transactions;

namespace PaymentService.Application.Validation;

public sealed class RetryPaymentRequestValidator : AbstractValidator<RetryPaymentRequest>
{
    public RetryPaymentRequestValidator()
    {
        RuleFor(x => x.RowVersion).ValidRowVersion();
    }
}


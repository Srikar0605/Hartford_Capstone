using FluentValidation;
using PaymentService.Application.DTOs.Settlements;

namespace PaymentService.Application.Validation;

public sealed class ProcessClaimSettlementRequestValidator
    : AbstractValidator<ProcessClaimSettlementRequest>
{
    public ProcessClaimSettlementRequestValidator()
    {
        RuleFor(x => x.ClaimId).NotEmpty();
        RuleFor(x => x.CustomerId).NotEmpty();
        RuleFor(x => x.PolicyId).NotEmpty();
        RuleFor(x => x.Amount).GreaterThan(0m);
    }
}


using PaymentService.Domain.Enums;

namespace PaymentService.Application.DTOs.Premiums;

public sealed record ProcessPremiumPaymentRequest(
    Guid PolicyId,
    decimal Amount,
    bool SimulateFailure = false
);

public sealed record PremiumPaymentResponse(
    Guid TransactionId,
    string TransactionNumber,
    Guid PolicyId,
    decimal Amount,
    PaymentStatus Status,
    string? FailureReason,
    string? ReceiptNumber,
    DateTime TransactionDate,
    string RowVersion
);


using PaymentService.Domain.Enums;

namespace PaymentService.Application.DTOs.Transactions;

public sealed record TransactionSearchRequest(
    int Page = 1,
    int PageSize = 20,
    PaymentType? Type = null,
    PaymentStatus? Status = null,
    Guid? CustomerId = null,
    Guid? PolicyId = null,
    Guid? ClaimId = null,
    DateTime? From = null,
    DateTime? To = null
);

public sealed record TransactionSummaryResponse(
    Guid TransactionId,
    string TransactionNumber,
    PaymentType Type,
    decimal Amount,
    PaymentStatus Status,
    DateTime TransactionDate,
    string RowVersion
);

public sealed record PaymentAttemptResponse(
    Guid RequestId,
    string RequestType,
    DateTime RequestedAt,
    string ResponseCode,
    PaymentStatus ResponseStatus,
    string ResponseMessage,
    DateTime ProcessedAt
);

public sealed record TransactionDetailsResponse(
    Guid TransactionId,
    string TransactionNumber,
    PaymentType Type,
    Guid? CustomerId,
    Guid? PolicyId,
    Guid? ClaimId,
    decimal Amount,
    PaymentStatus Status,
    string? FailureReason,
    DateTime TransactionDate,
    IReadOnlyCollection<PaymentAttemptResponse> Attempts,
    string? ReceiptNumber,
    string RowVersion
);

public sealed record RetryPaymentRequest(bool SimulateFailure, string RowVersion);

public sealed record TransactionValidationResponse(
    Guid TransactionId,
    string TransactionNumber,
    PaymentType Type,
    PaymentStatus Status,
    decimal Amount,
    Guid? PolicyId,
    Guid? ClaimId,
    bool IsSuccessful
);


using PaymentService.Domain.Enums;

namespace PaymentService.Application.DTOs.Settlements;

public sealed record ProcessClaimSettlementRequest(
    Guid ClaimId,
    Guid CustomerId,
    Guid PolicyId,
    decimal Amount,
    bool SimulateFailure = false,
    Guid? AuthUserId = null
);

public sealed record ClaimSettlementResponse(
    Guid TransactionId,
    string TransactionNumber,
    Guid ClaimId,
    decimal Amount,
    PaymentStatus Status,
    string? FailureReason,
    string? ReceiptNumber,
    DateTime TransactionDate,
    string RowVersion
);


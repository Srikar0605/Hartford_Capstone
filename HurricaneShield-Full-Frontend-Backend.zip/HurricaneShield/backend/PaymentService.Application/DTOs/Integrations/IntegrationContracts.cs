namespace PaymentService.Application.DTOs.Integrations;

public sealed record PolicyPremiumValidationResponse(
    Guid PolicyId,
    Guid CustomerId,
    Guid AuthUserId,
    bool OwnerMatches,
    bool IsPaymentPending,
    decimal PremiumDue,
    string PaymentContext,
    string RowVersion,
    string? Reason
);

public sealed record PolicyPaymentConfirmationRequest(
    Guid TransactionId,
    decimal Amount,
    DateTime ProcessedAt,
    string RowVersion
);

public sealed record ClaimSettlementValidationResponse(
    Guid ClaimId,
    string ClaimNumber,
    bool IsApproved,
    bool CanSettle,
    decimal SettlementAmount,
    Guid CustomerId,
    Guid PolicyId,
    string? Reason
);

public sealed record ClaimSettlementConfirmationRequest(
    Guid TransactionId,
    bool Successful,
    string? FailureReason
);


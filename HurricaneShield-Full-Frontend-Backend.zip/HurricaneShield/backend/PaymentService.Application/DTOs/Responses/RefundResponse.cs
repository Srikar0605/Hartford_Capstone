namespace PaymentService.Application.DTOs.Responses;

public sealed record RefundResponse(
    Guid TransactionId,
    Guid PolicyId,
    Guid CustomerId,
    decimal Amount,
    string Status,
    DateTime CreatedAt
);


namespace PaymentService.Application.DTOs.Receipts;

public sealed record PaymentReceiptResponse(
    Guid ReceiptId,
    Guid TransactionId,
    string TransactionNumber,
    string ReceiptNumber,
    decimal Amount,
    DateTime GeneratedAt,
    string CreatedBy
);


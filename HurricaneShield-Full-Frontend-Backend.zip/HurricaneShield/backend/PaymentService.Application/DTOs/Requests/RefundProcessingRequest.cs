namespace PaymentService.Application.DTOs.Requests;

public sealed record RefundProcessingRequest(
    Guid PolicyId,
    Guid CustomerId,
    decimal Amount,
    string Reason
);


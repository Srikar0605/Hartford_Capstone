namespace PaymentService.Application.Authorization;

public static class PaymentAuthorizationPolicies
{
    public const string CustomerAccess = "Payments.CustomerAccess";
    public const string ProcessPremium = "Payments.ProcessPremium";
    public const string ProcessSettlement = "Payments.ProcessSettlement";
    public const string AdministratorRead = "Payments.AdministratorRead";
    public const string Retry = "Payments.Retry";
    public const string ValidateTransaction = "Payments.ValidateTransaction";
}


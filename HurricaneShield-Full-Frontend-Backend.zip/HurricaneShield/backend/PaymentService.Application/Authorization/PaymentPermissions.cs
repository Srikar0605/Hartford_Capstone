namespace PaymentService.Application.Authorization;

public static class PaymentPermissions
{
    public const string ProcessPremium = "Process Premium Payment";
    public const string ProcessSettlement = "Process Claim Settlement";
    public const string ViewTransactions = "View Payment Transactions";
    public const string RetryPayments = "Retry Payments";
    public const string ValidateTransactions = "Validate Payment Transactions";
}


namespace PaymentService.Application.Authorization;

public static class PaymentRoles
{
    public const string Customer = "Customer";
    public const string ClaimsManager = "Claims Manager";
    public const string Administrator = "Administrator";
}


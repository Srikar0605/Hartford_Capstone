using CustomerService.Domain.Entities;

namespace CustomerService.Domain.Repositories;

public interface ICustomerRepository
{
    Task<bool> AuthUserExistsAsync(Guid authUserId, CancellationToken cancellationToken = default);

    Task<bool> EmailExistsAsync(string email, CancellationToken cancellationToken = default);

    Task<Customer?> GetByAuthUserIdForUpdateAsync(
        Guid authUserId,
        CancellationToken cancellationToken = default
    );

    Task<Customer?> GetByAuthUserIdWithDetailsAsync(
        Guid authUserId,
        CancellationToken cancellationToken = default
    );

    Task<Customer?> GetByIdForUpdateAsync(
        Guid customerId,
        CancellationToken cancellationToken = default
    );

    Task<Customer?> GetByIdWithDetailsAsync(
        Guid customerId,
        CancellationToken cancellationToken = default
    );

    Task AddAsync(Customer customer, CancellationToken cancellationToken = default);
    void SetOriginalRowVersion(Customer customer, byte[] rowVersion);
    Task AddHistoryAsync(CustomerHistory history, CancellationToken cancellationToken = default);

    Task<Customer?> GetWithAddressesForUpdateAsync(
        Guid authUserId,
        CancellationToken cancellationToken = default
    );

    void RemoveAddress(Address address);

    Task<Customer?> GetWithEmergencyContactsForUpdateAsync(
        Guid authUserId,
        CancellationToken cancellationToken = default
    );

    void RemoveEmergencyContact(EmergencyContact emergencyContact);

    Task<Customer?> GetWithPropertiesForUpdateAsync(
        Guid authUserId,
        CancellationToken cancellationToken = default
    );

    void RemovePropertyOwnership(PropertyOwnership propertyOwnership);
}


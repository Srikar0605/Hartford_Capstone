using CustomerService.Domain.Common;

namespace CustomerService.Domain.Entities;

public sealed class Address : AuditableEntity
{
    private Address() { }

    private Address(
        Guid id,
        Guid customerId,
        string addressLine1,
        string? addressLine2,
        string city,
        string state,
        string postalCode,
        string country,
        DateTime createdAt,
        string createdBy
    )
        : base(id, createdAt, createdBy)
    {
        if (customerId == Guid.Empty)
        {
            throw new ArgumentException("Customer identifier is required.", nameof(customerId));
        }

        CustomerId = customerId;

        SetAddress(addressLine1, addressLine2, city, state, postalCode, country);
    }

    public Guid CustomerId { get; private set; }

    public string AddressLine1 { get; private set; } = string.Empty;

    public string? AddressLine2 { get; private set; }

    public string City { get; private set; } = string.Empty;

    public string State { get; private set; } = string.Empty;

    public string PostalCode { get; private set; } = string.Empty;

    public string Country { get; private set; } = string.Empty;

    public Customer Customer { get; private set; } = null!;

    public static Address Create(
        Guid customerId,
        string addressLine1,
        string? addressLine2,
        string city,
        string state,
        string postalCode,
        string country,
        DateTime createdAt,
        string createdBy
    )
    {
        return new Address(
            Guid.NewGuid(),
            customerId,
            addressLine1,
            addressLine2,
            city,
            state,
            postalCode,
            country,
            createdAt,
            createdBy
        );
    }

    public void Update(
        string addressLine1,
        string? addressLine2,
        string city,
        string state,
        string postalCode,
        string country,
        DateTime updatedAt,
        string updatedBy
    )
    {
        SetAddress(addressLine1, addressLine2, city, state, postalCode, country);

        MarkUpdated(updatedAt, updatedBy);
    }

    private void SetAddress(
        string addressLine1,
        string? addressLine2,
        string city,
        string state,
        string postalCode,
        string country
    )
    {
        AddressLine1 = RequireValue(addressLine1, nameof(addressLine1));

        AddressLine2 = string.IsNullOrWhiteSpace(addressLine2) ? null : addressLine2.Trim();

        City = RequireValue(city, nameof(city));
        State = RequireValue(state, nameof(state));
        PostalCode = RequireValue(postalCode, nameof(postalCode));
        Country = RequireValue(country, nameof(country));
    }
}


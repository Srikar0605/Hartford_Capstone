using CustomerService.Domain.Common;

namespace CustomerService.Domain.Entities;

public sealed class CustomerHistory : Entity
{
    private CustomerHistory() { }

    private CustomerHistory(
        Guid id,
        Guid customerId,
        string changeType,
        string changeData,
        DateTime changedAt,
        string changedBy,
        string correlationId
    )
        : base(id)
    {
        if (customerId == Guid.Empty)
        {
            throw new ArgumentException("Customer identifier is required.", nameof(customerId));
        }

        CustomerId = customerId;
        ChangeType = Required(changeType, nameof(changeType));
        ChangeData = Required(changeData, nameof(changeData));
        ChangedAt = changedAt;
        ChangedBy = Required(changedBy, nameof(changedBy));
        CorrelationId = Required(correlationId, nameof(correlationId));
    }

    public Guid CustomerId { get; private set; }

    public string ChangeType { get; private set; } = string.Empty;

    public string ChangeData { get; private set; } = string.Empty;

    public DateTime ChangedAt { get; private set; }

    public string ChangedBy { get; private set; } = string.Empty;

    public string CorrelationId { get; private set; } = string.Empty;

    public static CustomerHistory Create(
        Guid customerId,
        string changeType,
        string changeData,
        DateTime changedAt,
        string changedBy,
        string correlationId
    )
    {
        return new CustomerHistory(
            Guid.NewGuid(),
            customerId,
            changeType,
            changeData,
            changedAt,
            changedBy,
            correlationId
        );
    }

    private static string Required(string value, string parameterName)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            throw new ArgumentException($"{parameterName} is required.", parameterName);
        }

        return value.Trim();
    }
}


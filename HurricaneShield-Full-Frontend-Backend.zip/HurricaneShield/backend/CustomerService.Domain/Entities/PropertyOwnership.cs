using CustomerService.Domain.Common;
using CustomerService.Domain.Constants;

namespace CustomerService.Domain.Entities;

public sealed class PropertyOwnership : AuditableEntity
{
    private PropertyOwnership() { }

    private PropertyOwnership(
        Guid id,
        Guid customerId,
        string addressLine1,
        string? addressLine2,
        string city,
        string state,
        string postalCode,
        string country,
        string ownershipType,
        DateOnly acquiredOn,
        bool isPrimaryResidence,
        DateTime createdAt,
        string createdBy,
        int? yearBuilt = null,
        string? constructionType = null,
        string? riskZone = null,
        bool stormShutters = false,
        bool impactResistantWindows = false,
        bool reinforcedRoof = false,
        bool emergencyGenerator = false,
        bool homeInspectionCertification = false,
        double? latitude = null,
        double? longitude = null
    )
        : base(id, createdAt, createdBy)
    {
        if (customerId == Guid.Empty)
        {
            throw new ArgumentException("Customer identifier is required.", nameof(customerId));
        }

        CustomerId = customerId;

        SetDetails(
            addressLine1,
            addressLine2,
            city,
            state,
            postalCode,
            country,
            ownershipType,
            acquiredOn,
            isPrimaryResidence,
            yearBuilt,
            constructionType,
            riskZone,
            stormShutters,
            impactResistantWindows,
            reinforcedRoof,
            emergencyGenerator,
            homeInspectionCertification,
            latitude,
            longitude
        );
    }

    public Guid CustomerId { get; private set; }

    public string AddressLine1 { get; private set; } = string.Empty;

    public string? AddressLine2 { get; private set; }

    public string City { get; private set; } = string.Empty;

    public string State { get; private set; } = string.Empty;

    public string PostalCode { get; private set; } = string.Empty;

    public string Country { get; private set; } = string.Empty;

    public string OwnershipType { get; private set; } = string.Empty;

    public DateOnly AcquiredOn { get; private set; }

    public bool IsPrimaryResidence { get; private set; }

    public int? YearBuilt { get; private set; }

    public string? ConstructionType { get; private set; }

    public string? RiskZone { get; private set; }

    public bool StormShutters { get; private set; }

    public bool ImpactResistantWindows { get; private set; }

    public bool ReinforcedRoof { get; private set; }

    public bool EmergencyGenerator { get; private set; }

    public bool HomeInspectionCertification { get; private set; }

    public double? Latitude { get; private set; }

    public double? Longitude { get; private set; }

    public Customer Customer { get; private set; } = null!;

    public static PropertyOwnership Create(
        Guid customerId,
        string addressLine1,
        string? addressLine2,
        string city,
        string state,
        string postalCode,
        string country,
        string ownershipType,
        DateOnly acquiredOn,
        bool isPrimaryResidence,
        DateTime createdAt,
        string createdBy,
        int? yearBuilt = null,
        string? constructionType = null,
        string? riskZone = null,
        bool stormShutters = false,
        bool impactResistantWindows = false,
        bool reinforcedRoof = false,
        bool emergencyGenerator = false,
        bool homeInspectionCertification = false,
        double? latitude = null,
        double? longitude = null
    )
    {
        return new PropertyOwnership(
            Guid.NewGuid(),
            customerId,
            addressLine1,
            addressLine2,
            city,
            state,
            postalCode,
            country,
            ownershipType,
            acquiredOn,
            isPrimaryResidence,
            createdAt,
            createdBy,
            yearBuilt,
            constructionType,
            riskZone,
            stormShutters,
            impactResistantWindows,
            reinforcedRoof,
            emergencyGenerator,
            homeInspectionCertification,
            latitude,
            longitude
        );
    }

    public void Update(
        string addressLine1,
        string? addressLine2,
        string city,
        string state,
        string postalCode,
        string country,
        string ownershipType,
        DateOnly acquiredOn,
        bool isPrimaryResidence,
        DateTime updatedAt,
        string updatedBy,
        int? yearBuilt = null,
        string? constructionType = null,
        string? riskZone = null,
        bool stormShutters = false,
        bool impactResistantWindows = false,
        bool reinforcedRoof = false,
        bool emergencyGenerator = false,
        bool homeInspectionCertification = false,
        double? latitude = null,
        double? longitude = null
    )
    {
        SetDetails(
            addressLine1,
            addressLine2,
            city,
            state,
            postalCode,
            country,
            ownershipType,
            acquiredOn,
            isPrimaryResidence,
            yearBuilt,
            constructionType,
            riskZone,
            stormShutters,
            impactResistantWindows,
            reinforcedRoof,
            emergencyGenerator,
            homeInspectionCertification,
            latitude,
            longitude
        );

        MarkUpdated(updatedAt, updatedBy);
    }

    private void SetDetails(
        string addressLine1,
        string? addressLine2,
        string city,
        string state,
        string postalCode,
        string country,
        string ownershipType,
        DateOnly acquiredOn,
        bool isPrimaryResidence,
        int? yearBuilt = null,
        string? constructionType = null,
        string? riskZone = null,
        bool stormShutters = false,
        bool impactResistantWindows = false,
        bool reinforcedRoof = false,
        bool emergencyGenerator = false,
        bool homeInspectionCertification = false,
        double? latitude = null,
        double? longitude = null
    )
    {
        if (!OwnershipTypes.All.Contains(ownershipType, StringComparer.Ordinal))
        {
            throw new ArgumentException("Ownership type is invalid.", nameof(ownershipType));
        }

        AddressLine1 = RequireValue(addressLine1, nameof(addressLine1));

        AddressLine2 = string.IsNullOrWhiteSpace(addressLine2) ? null : addressLine2.Trim();

        City = RequireValue(city, nameof(city));
        State = RequireValue(state, nameof(state));

        PostalCode = RequireValue(postalCode, nameof(postalCode));

        Country = RequireValue(country, nameof(country));

        OwnershipType = ownershipType;
        AcquiredOn = acquiredOn;
        IsPrimaryResidence = isPrimaryResidence;
        YearBuilt = yearBuilt;
        ConstructionType = string.IsNullOrWhiteSpace(constructionType) ? null : constructionType.Trim();
        RiskZone = string.IsNullOrWhiteSpace(riskZone) ? null : riskZone.Trim();
        StormShutters = stormShutters;
        ImpactResistantWindows = impactResistantWindows;
        ReinforcedRoof = reinforcedRoof;
        EmergencyGenerator = emergencyGenerator;
        HomeInspectionCertification = homeInspectionCertification;
        Latitude = latitude;
        Longitude = longitude;
    }

    public void SetPrimaryResidence(bool isPrimaryResidence, DateTime updatedAt, string updatedBy)
    {
        IsPrimaryResidence = isPrimaryResidence;

        MarkUpdated(updatedAt, updatedBy);
    }
}


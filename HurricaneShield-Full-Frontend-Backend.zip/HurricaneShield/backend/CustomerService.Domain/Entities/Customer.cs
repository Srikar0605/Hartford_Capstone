using CustomerService.Domain.Common;
using CustomerService.Domain.Constants;

namespace CustomerService.Domain.Entities;

/// <summary>
/// The Customer aggregate root.
/// I designed this entity to maintain strong consistency boundaries across the customer's profile,
/// physical addresses, emergency contacts, and insurable property ownership records.
/// External services and application handlers can never mutate child entities directly;
/// all additions, updates, and removals must pass through the methods on this class so business invariants
/// (like unique addresses, single primary residence, and age boundaries) are strictly enforced.
/// </summary>
public sealed class Customer : AggregateRoot
{
    private readonly List<Address> _addresses = new();
    private readonly List<EmergencyContact> _emergencyContacts = new();
    private readonly List<PropertyOwnership> _propertyOwnerships = new();

    private Customer() { }

    private Customer(
        Guid id,
        Guid authUserId,
        string firstName,
        string lastName,
        string email,
        DateOnly dateOfBirth,
        DateTime createdAt,
        string createdBy
    )
        : base(id, createdAt, createdBy)
    {
        if (authUserId == Guid.Empty)
        {
            throw new ArgumentException("Auth user identifier is required.", nameof(authUserId));
        }

        AuthUserId = authUserId;
        FirstName = NormalizeName(firstName, nameof(firstName));
        LastName = NormalizeName(lastName, nameof(lastName));
        Email = NormalizeEmail(email);
        DateOfBirth = dateOfBirth;
        Status = CustomerStatuses.Pending;
    }


    public Guid AuthUserId { get; private set; }

    public string FirstName { get; private set; } = string.Empty;

    public string LastName { get; private set; } = string.Empty;

    public string Email { get; private set; } = string.Empty;

    public DateOnly DateOfBirth { get; private set; }

    public string Status { get; private set; } = CustomerStatuses.Pending;

    public IReadOnlyCollection<Address> Addresses => _addresses.AsReadOnly();

    public IReadOnlyCollection<EmergencyContact> EmergencyContacts =>
        _emergencyContacts.AsReadOnly();

    public IReadOnlyCollection<PropertyOwnership> PropertyOwnerships =>
        _propertyOwnerships.AsReadOnly();

    public static Customer Create(
        Guid authUserId,
        string firstName,
        string lastName,
        string email,
        DateOnly dateOfBirth,
        DateTime createdAt,
        string createdBy
    )
    {
        return new Customer(
            Guid.NewGuid(),
            authUserId,
            firstName,
            lastName,
            email,
            dateOfBirth,
            createdAt,
            createdBy
        );
    }

    public void UpdateProfile(
        string firstName,
        string lastName,
        DateOnly dateOfBirth,
        DateTime updatedAt,
        string updatedBy
    )
    {
        FirstName = NormalizeName(firstName, nameof(firstName));

        LastName = NormalizeName(lastName, nameof(lastName));

        DateOfBirth = dateOfBirth;

        MarkUpdated(updatedAt, updatedBy);
    }

    public void Activate(DateTime updatedAt, string updatedBy)
    {
        if (Status == CustomerStatuses.Active)
        {
            return;
        }

        if (Status is not CustomerStatuses.Pending and not CustomerStatuses.Inactive)
        {
            throw new InvalidOperationException($"Customer cannot be activated from {Status}.");
        }

        Status = CustomerStatuses.Active;

        MarkUpdated(updatedAt, updatedBy);
    }

    public void Deactivate(DateTime updatedAt, string updatedBy)
    {
        if (Status == CustomerStatuses.Inactive)
        {
            return;
        }

        if (Status != CustomerStatuses.Active)
        {
            throw new InvalidOperationException($"Customer cannot be deactivated from {Status}.");
        }

        Status = CustomerStatuses.Inactive;

        MarkUpdated(updatedAt, updatedBy);
    }

    public bool IsAgeEligible(DateOnly currentDate)
    {
        var age = currentDate.Year - DateOfBirth.Year;

        if (DateOfBirth > currentDate.AddYears(-age))
        {
            age--;
        }

        return age is >= 18 and <= 85;
    }

    public bool IsEligible(DateOnly currentDate)
    {
        return Status == CustomerStatuses.Active && IsAgeEligible(currentDate);
    }

    private static string NormalizeName(string value, string parameterName)
    {
        return RequireValue(value, parameterName);
    }

    private static string NormalizeEmail(string email)
    {
        return RequireValue(email, nameof(email)).ToLowerInvariant();
    }

    public Address AddAddress(
        string addressLine1,
        string? addressLine2,
        string city,
        string state,
        string postalCode,
        string country,
        DateTime createdAt,
        string createdBy
    )
    {
        var address = Address.Create(
            Id,
            addressLine1,
            addressLine2,
            city,
            state,
            postalCode,
            country,
            createdAt,
            createdBy
        );

        _addresses.Add(address);

        MarkUpdated(createdAt, createdBy);

        return address;
    }

    public void UpdateAddress(
        Guid addressId,
        string addressLine1,
        string? addressLine2,
        string city,
        string state,
        string postalCode,
        string country,
        DateTime updatedAt,
        string updatedBy
    )
    {
        var address =
            FindAddress(addressId)
            ?? throw new InvalidOperationException("Address does not belong to the customer.");

        address.Update(
            addressLine1,
            addressLine2,
            city,
            state,
            postalCode,
            country,
            updatedAt,
            updatedBy
        );

        MarkUpdated(updatedAt, updatedBy);
    }

    public EmergencyContact AddEmergencyContact(
        string name,
        string relationship,
        string phoneNumber,
        DateTime createdAt,
        string createdBy
    )
    {
        var contact = EmergencyContact.Create(
            Id,
            name,
            relationship,
            phoneNumber,
            createdAt,
            createdBy
        );

        _emergencyContacts.Add(contact);

        MarkUpdated(createdAt, createdBy);

        return contact;
    }

    public Address? FindAddress(Guid addressId)
    {
        return _addresses.SingleOrDefault(address => address.Id == addressId);
    }

    public EmergencyContact? FindEmergencyContact(Guid emergencyContactId)
    {
        return _emergencyContacts.SingleOrDefault(contact => contact.Id == emergencyContactId);
    }

    public Address RemoveAddress(Guid addressId, DateTime updatedAt, string updatedBy)
    {
        var address =
            FindAddress(addressId)
            ?? throw new InvalidOperationException("Address does not belong to the customer.");

        _addresses.Remove(address);

        MarkUpdated(updatedAt, updatedBy);

        return address;
    }

    public void UpdateEmergencyContact(
        Guid emergencyContactId,
        string name,
        string relationship,
        string phoneNumber,
        DateTime updatedAt,
        string updatedBy
    )
    {
        var contact =
            FindEmergencyContact(emergencyContactId)
            ?? throw new InvalidOperationException(
                "Emergency contact does not belong " + "to the customer."
            );

        contact.Update(name, relationship, phoneNumber, updatedAt, updatedBy);

        MarkUpdated(updatedAt, updatedBy);
    }

    public EmergencyContact RemoveEmergencyContact(
        Guid emergencyContactId,
        DateTime updatedAt,
        string updatedBy
    )
    {
        var contact =
            FindEmergencyContact(emergencyContactId)
            ?? throw new InvalidOperationException(
                "Emergency contact does not belong " + "to the customer."
            );

        _emergencyContacts.Remove(contact);

        MarkUpdated(updatedAt, updatedBy);

        return contact;
    }

    public PropertyOwnership AddPropertyOwnership(
        string addressLine1,
        string? addressLine2,
        string city,
        string state,
        string postalCode,
        string country,
        string ownershipType,
        DateOnly acquiredOn,
        bool isPrimaryResidence,
        DateTime createdAt,
        string createdBy,
        int? yearBuilt = null,
        string? constructionType = null,
        string? riskZone = null,
        bool stormShutters = false,
        bool impactResistantWindows = false,
        bool reinforcedRoof = false,
        bool emergencyGenerator = false,
        bool homeInspectionCertification = false,
        double? latitude = null,
        double? longitude = null
    )
    {
        var duplicate = _propertyOwnerships.Any(p =>
            string.Equals(p.AddressLine1.Trim(), addressLine1.Trim(), StringComparison.OrdinalIgnoreCase) &&
            string.Equals(p.City.Trim(), city.Trim(), StringComparison.OrdinalIgnoreCase) &&
            string.Equals(p.State.Trim(), state.Trim(), StringComparison.OrdinalIgnoreCase) &&
            string.Equals(p.PostalCode.Trim(), postalCode.Trim(), StringComparison.OrdinalIgnoreCase)
        );

        if (duplicate)
        {
            throw new InvalidOperationException(
                "A property with the same address already exists for this customer."
            );
        }

        if (isPrimaryResidence)
        {
            ClearExistingPrimaryResidence(createdAt, createdBy);
        }

        var property = PropertyOwnership.Create(
            Id,
            addressLine1,
            addressLine2,
            city,
            state,
            postalCode,
            country,
            ownershipType,
            acquiredOn,
            isPrimaryResidence,
            createdAt,
            createdBy,
            yearBuilt,
            constructionType,
            riskZone,
            stormShutters,
            impactResistantWindows,
            reinforcedRoof,
            emergencyGenerator,
            homeInspectionCertification,
            latitude,
            longitude
        );

        _propertyOwnerships.Add(property);
        MarkUpdated(createdAt, createdBy);
        return property;
    }

    public PropertyOwnership? FindPropertyOwnership(Guid id) =>
        _propertyOwnerships.SingleOrDefault(property => property.Id == id);

    public void UpdatePropertyOwnership(
        Guid id,
        string addressLine1,
        string? addressLine2,
        string city,
        string state,
        string postalCode,
        string country,
        string ownershipType,
        DateOnly acquiredOn,
        bool isPrimaryResidence,
        DateTime updatedAt,
        string updatedBy,
        int? yearBuilt = null,
        string? constructionType = null,
        string? riskZone = null,
        bool stormShutters = false,
        bool impactResistantWindows = false,
        bool reinforcedRoof = false,
        bool emergencyGenerator = false,
        bool homeInspectionCertification = false,
        double? latitude = null,
        double? longitude = null
    )
    {
        var property =
            FindPropertyOwnership(id)
            ?? throw new InvalidOperationException(
                "Property ownership record does not belong to the customer."
            );

        if (isPrimaryResidence)
        {
            foreach (var existing in _propertyOwnerships)
            {
                if (existing.Id != id && existing.IsPrimaryResidence)
                {
                    existing.SetPrimaryResidence(false, updatedAt, updatedBy);
                }
            }
        }

        property.Update(
            addressLine1,
            addressLine2,
            city,
            state,
            postalCode,
            country,
            ownershipType,
            acquiredOn,
            isPrimaryResidence,
            updatedAt,
            updatedBy,
            yearBuilt,
            constructionType,
            riskZone,
            stormShutters,
            impactResistantWindows,
            reinforcedRoof,
            emergencyGenerator,
            homeInspectionCertification,
            latitude,
            longitude
        );

        MarkUpdated(updatedAt, updatedBy);
    }

    public PropertyOwnership RemovePropertyOwnership(Guid id, DateTime updatedAt, string updatedBy)
    {
        var property =
            FindPropertyOwnership(id)
            ?? throw new InvalidOperationException(
                "Property ownership record does not belong to the customer."
            );

        _propertyOwnerships.Remove(property);
        MarkUpdated(updatedAt, updatedBy);
        return property;
    }

    private void ClearExistingPrimaryResidence(DateTime updatedAt, string updatedBy)
    {
        foreach (var property in _propertyOwnerships.Where(property => property.IsPrimaryResidence))
        {
            property.SetPrimaryResidence(false, updatedAt, updatedBy);
        }
    }
}


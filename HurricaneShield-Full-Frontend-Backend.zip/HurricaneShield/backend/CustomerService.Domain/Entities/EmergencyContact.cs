using CustomerService.Domain.Common;

namespace CustomerService.Domain.Entities;

public sealed class EmergencyContact : AuditableEntity
{
    private EmergencyContact() { }

    private EmergencyContact(
        Guid id,
        Guid customerId,
        string name,
        string relationship,
        string phoneNumber,
        DateTime createdAt,
        string createdBy
    )
        : base(id, createdAt, createdBy)
    {
        if (customerId == Guid.Empty)
        {
            throw new ArgumentException("Customer identifier is required.", nameof(customerId));
        }

        CustomerId = customerId;

        SetDetails(name, relationship, phoneNumber);
    }

    public Guid CustomerId { get; private set; }

    public string Name { get; private set; } = string.Empty;

    public string Relationship { get; private set; } = string.Empty;

    public string PhoneNumber { get; private set; } = string.Empty;

    public Customer Customer { get; private set; } = null!;

    public static EmergencyContact Create(
        Guid customerId,
        string name,
        string relationship,
        string phoneNumber,
        DateTime createdAt,
        string createdBy
    )
    {
        return new EmergencyContact(
            Guid.NewGuid(),
            customerId,
            name,
            relationship,
            phoneNumber,
            createdAt,
            createdBy
        );
    }

    public void Update(
        string name,
        string relationship,
        string phoneNumber,
        DateTime updatedAt,
        string updatedBy
    )
    {
        SetDetails(name, relationship, phoneNumber);

        MarkUpdated(updatedAt, updatedBy);
    }

    private void SetDetails(string name, string relationship, string phoneNumber)
    {
        Name = RequireValue(name, nameof(name));

        Relationship = RequireValue(relationship, nameof(relationship));

        PhoneNumber = RequireValue(phoneNumber, nameof(phoneNumber));
    }
}


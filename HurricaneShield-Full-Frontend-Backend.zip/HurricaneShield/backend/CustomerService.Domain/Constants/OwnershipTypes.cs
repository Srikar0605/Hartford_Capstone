namespace CustomerService.Domain.Constants;

public static class OwnershipTypes
{
    public const string Owned = "Owned";

    public const string Mortgaged = "Mortgaged";

    public const string CoOwned = "CoOwned";

    public static readonly IReadOnlyCollection<string> All = new[] { Owned, Mortgaged, CoOwned };
}


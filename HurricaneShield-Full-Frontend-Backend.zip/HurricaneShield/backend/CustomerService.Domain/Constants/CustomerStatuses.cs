namespace CustomerService.Domain.Constants;

public static class CustomerStatuses
{
    public const string Pending = "Pending";

    public const string Active = "Active";

    public const string Inactive = "Inactive";

    public static readonly IReadOnlyCollection<string> All = new[] { Pending, Active, Inactive };
}


namespace CustomerService.Domain.Constants;

public static class CustomerHistoryTypes
{
    public const string ProfileCreated = "ProfileCreated";

    public const string ProfileUpdated = "ProfileUpdated";

    public const string Activated = "Activated";

    public const string Deactivated = "Deactivated";

    public const string AddressAdded = "AddressAdded";

    public const string AddressUpdated = "AddressUpdated";

    public const string AddressRemoved = "AddressRemoved";

    public const string EmergencyContactAdded = "EmergencyContactAdded";

    public const string EmergencyContactUpdated = "EmergencyContactUpdated";

    public const string EmergencyContactRemoved = "EmergencyContactRemoved";

    public const string PropertyAdded = "PropertyAdded";

    public const string PropertyUpdated = "PropertyUpdated";

    public const string PropertyRemoved = "PropertyRemoved";
}


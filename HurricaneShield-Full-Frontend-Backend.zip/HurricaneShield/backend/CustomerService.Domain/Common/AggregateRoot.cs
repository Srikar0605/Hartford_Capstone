namespace CustomerService.Domain.Common;

public abstract class AggregateRoot : AuditableEntity
{
    protected AggregateRoot(Guid id, DateTime createdAt, string createdBy)
        : base(id, createdAt, createdBy) { }

    protected AggregateRoot() { }

    public bool IsDeleted { get; protected set; }

    public DateTime? DeletedAt { get; protected set; }

    public string? DeletedBy { get; protected set; }

    public byte[] RowVersion { get; private set; } = Array.Empty<byte>();

    public void SoftDelete(DateTime deletedAt, string deletedBy)
    {
        if (IsDeleted)
        {
            return;
        }

        IsDeleted = true;
        DeletedAt = deletedAt;
        DeletedBy = RequireValue(deletedBy, nameof(deletedBy));

        MarkUpdated(deletedAt, deletedBy);
    }
}


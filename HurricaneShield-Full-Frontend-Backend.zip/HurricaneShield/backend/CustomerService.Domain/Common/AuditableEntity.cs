namespace CustomerService.Domain.Common;

public abstract class AuditableEntity : Entity
{
    protected AuditableEntity(Guid id, DateTime createdAt, string createdBy)
        : base(id)
    {
        CreatedAt = createdAt;
        CreatedBy = RequireValue(createdBy, nameof(createdBy));
    }

    protected AuditableEntity() { }

    public DateTime CreatedAt { get; protected set; }

    public string CreatedBy { get; protected set; } = string.Empty;

    public DateTime? UpdatedAt { get; protected set; }

    public string? UpdatedBy { get; protected set; }

    protected void MarkUpdated(DateTime updatedAt, string updatedBy)
    {
        UpdatedAt = updatedAt;
        UpdatedBy = RequireValue(updatedBy, nameof(updatedBy));
    }

    protected static string RequireValue(string value, string parameterName)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            throw new ArgumentException($"{parameterName} is required.", parameterName);
        }

        return value.Trim();
    }
}


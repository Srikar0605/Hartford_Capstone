
import { ChangeDetectionStrategy, Component, computed, input } from '@angular/core';

export type StatusBadgeTone =
  | 'success'
  | 'warning'
  | 'review'
  | 'danger'
  | 'info'
  | 'neutral';

const STATUS_TONES: Readonly<Record<string, StatusBadgeTone>> = {
  Active: 'success', Success: 'success', Approved: 'success', Verified: 'success', Closed: 'success', Completed: 'success',
  Pending: 'warning', PaymentPending: 'warning', Submitted: 'warning', Draft: 'warning', PaymentInitiated: 'warning',
  UnderReview: 'review', Underwriting: 'review', ManualReview: 'review',
  Failed: 'danger', Rejected: 'danger', Cancelled: 'danger', Suspended: 'danger',
  Inactive: 'neutral', Expired: 'neutral', Renewed: 'info',
  Healthy: 'success', Up: 'success', Online: 'success', Degraded: 'warning', Unhealthy: 'danger', Down: 'danger', Offline: 'danger',
  AutoApproved: 'success', Declined: 'danger', Reversed: 'danger', Refunded: 'info', Processing: 'warning',
};

@Component({
  selector: 'app-status-badge',
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl:
  './status-badge.component.html',
})
export class StatusBadgeComponent {
  readonly status = input.required<string>();
  readonly text = input<string>();
  readonly tone = input<StatusBadgeTone>();

  readonly label = computed(() => this.text() ?? this.humanize(this.status()));
  /** In-flight states (pending, under review…) get a softly pulsing dot. */
  readonly live = computed(() => {
    const tone = this.tone() ?? STATUS_TONES[this.status()] ?? 'neutral';
    return tone === 'warning' || tone === 'review';
  });
  readonly classes = computed(() => {
    const tone = this.tone() ?? STATUS_TONES[this.status()] ?? 'neutral';
    const tones: Record<StatusBadgeTone, string> = {
      success: 'bg-emerald-50 text-emerald-800 ring-emerald-700/15',
      warning: 'bg-amber-50 text-amber-800 ring-amber-700/20',
      review: 'bg-violet-50 text-violet-800 ring-violet-700/15',
      danger: 'bg-orange-50 text-orange-800 ring-orange-700/20',
      info: 'bg-sky-50 text-sky-800 ring-sky-700/15',
      neutral: 'bg-slate-100 text-slate-700 ring-slate-500/20',
    };
    return `inline-flex items-center gap-1.5 whitespace-nowrap rounded-full px-2.5 py-1 text-xs font-bold ring-1 ring-inset ${tones[tone]}`;
  });

  private humanize(value: string): string {
    return (value ?? '').replace(/([a-z])([A-Z])/g, '$1 $2').replace(/_/g, ' ');
  }
}

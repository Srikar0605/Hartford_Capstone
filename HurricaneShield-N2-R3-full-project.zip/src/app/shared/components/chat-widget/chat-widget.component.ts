
import { CommonModule } from '@angular/common';
import {
  AfterViewChecked,
  Component,
  ElementRef,
  ViewChild,
  inject,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { ChatService } from '../../../core/services/chat.service';
import { IconComponent } from '../icon/icon.component';

@Component({
  selector: 'app-chat-widget',
  standalone: true,
  imports: [CommonModule, FormsModule, IconComponent],
  templateUrl: './chat-widget.component.html',
})
export class ChatWidgetComponent implements AfterViewChecked {
  protected readonly chat = inject(ChatService);
  private readonly sanitizer = inject(DomSanitizer);

  @ViewChild('scrollContainer') private scrollContainer?: ElementRef<HTMLDivElement>;

  userInput = '';

  private shouldScroll = false;

  formatMessage(content: string): SafeHtml {
    if (!content) return '';

    // Step 1: Escape HTML to avoid XSS
    let escaped = content
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');

    // Step 2: Inline code (`code`)
    escaped = escaped.replace(/`([^`]+)`/g, '<code class="rounded bg-slate-100 px-1 py-0.5 font-mono text-[11px] text-brand-700">$1</code>');

    // Step 3: Bold (**text** or __text__)
    escaped = escaped.replace(/\*\*(.*?)\*\*/g, '<strong class="font-bold text-slate-900">$1</strong>');
    escaped = escaped.replace(/__(.*?)__/g, '<strong class="font-bold text-slate-900">$1</strong>');

    // Step 4: Italic (*text* or _text_)
    escaped = escaped.replace(/(?<!\*)\*(?!\*)(.*?)(?<!\*)\*(?!\*)/g, '<em class="italic">$1</em>');

    // Step 5: Process lines for lists and paragraphs
    const lines = escaped.split('\n');
    const output: string[] = [];
    let inList = false;
    let listType = '';

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();

      const bulletMatch = line.match(/^(\*|-|•)\s+(.*)/);
      const numberMatch = line.match(/^(\d+)\.\s+(.*)/);

      if (bulletMatch) {
        if (!inList || listType !== 'ul') {
          if (inList) output.push(`</${listType}>`);
          output.push('<ul class="my-2 space-y-1.5 pl-0.5">');
          inList = true;
          listType = 'ul';
        }
        output.push(
          `<li class="flex items-start gap-2 text-xs sm:text-sm leading-relaxed"><span class="text-brand-600 font-bold shrink-0 mt-0.5">•</span><span>${bulletMatch[2]}</span></li>`
        );
      } else if (numberMatch) {
        if (!inList || listType !== 'ol') {
          if (inList) output.push(`</${listType}>`);
          output.push('<ol class="my-2 space-y-1.5 pl-0.5">');
          inList = true;
          listType = 'ol';
        }
        output.push(
          `<li class="flex items-start gap-2 text-xs sm:text-sm leading-relaxed"><span class="text-brand-600 font-semibold shrink-0 mt-0.5">${numberMatch[1]}.</span><span>${numberMatch[2]}</span></li>`
        );
      } else {
        if (inList) {
          output.push(`</${listType}>`);
          inList = false;
          listType = '';
        }
        if (line.length > 0) {
          output.push(`<p class="my-1.5 text-xs sm:text-sm leading-relaxed">${line}</p>`);
        }
      }
    }

    if (inList) {
      output.push(`</${listType}>`);
    }

    return this.sanitizer.bypassSecurityTrustHtml(output.join(''));
  }

  onSendMessage(): void {
    if (!this.userInput.trim() || this.chat.isTyping()) {
      return;
    }

    const text = this.userInput;
    this.userInput = '';
    this.chat.sendMessage(text);
    this.shouldScroll = true;
  }

  ngAfterViewChecked(): void {
    if (this.shouldScroll && this.scrollContainer) {
      this.scrollToBottom();
      this.shouldScroll = false;
    }
  }

  scrollToBottom(): void {
    try {
      if (this.scrollContainer) {
        this.scrollContainer.nativeElement.scrollTop =
          this.scrollContainer.nativeElement.scrollHeight;
      }
    } catch {
      // Ignore scroll errors
    }
  }

  toggle(): void {
    this.chat.toggleOpen();
    if (this.chat.isOpen()) {
      this.shouldScroll = true;
    }
  }
}


import type {
  ConstructionType,
  PolicyStatus,
  RiskLevel,
  RiskZone,
  UnderwritingDecision,
  UnderwritingReviewStatus,
} from '../../core/constants/statuses';
import type { ApiDateTime, Guid, RowVersion } from '../../core/models/api.models';
import type { PageRequest } from '../../core/models/pagination.models';

export interface PlanSearchRequest extends PageRequest {
  search?: string;
  isActive?: boolean;
}

export interface CustomerQuoteRequest {
  customerId: Guid;
  quote: CalculateQuoteRequest;
}

export interface PlanSummaryResponse {
  planId: Guid;
  planCode: string;
  planName: string;
  description: string;
  basePremium: number;
  coverageLimit: number;
  deductibleAmount: number;
}

export interface PlanCoverageResponse {
  coverageTypeId: Guid;
  coverageName: string;
  coverageDescription: string;
  coverageLimit: number;
  deductibleAmount: number;
}

export interface PlanDetailsResponse extends PlanSummaryResponse {
  coverages: PlanCoverageResponse[];
}

export interface PlanAdministrationResponse extends PlanSummaryResponse {
  isActive: boolean;
  createdAt: ApiDateTime;
  updatedAt: ApiDateTime | null;
  rowVersion: RowVersion;
}

export interface CreatePlanRequest {
  planCode: string;
  planName: string;
  description: string;
  basePremium: number;
  coverageLimit: number;
  deductibleAmount: number;
}

export interface UpdatePlanRequest extends CreatePlanRequest {
  rowVersion: RowVersion;
}

export interface PlanCoverageAssignmentRequest {
  coverageTypeId: Guid;
  coverageLimit: number;
  deductibleAmount: number;
}

export interface ReplacePlanCoveragesRequest {
  coverages: PlanCoverageAssignmentRequest[];
  rowVersion: RowVersion;
}

export interface CreateCoverageTypeRequest {
  name: string;
  description: string;
}

export interface UpdateCoverageTypeRequest extends CreateCoverageTypeRequest {
  rowVersion: RowVersion;
}

export interface CoverageTypeResponse {
  coverageTypeId: Guid;
  name: string;
  description: string;
  isActive: boolean;
  createdAt: ApiDateTime;
  updatedAt: ApiDateTime | null;
  rowVersion: RowVersion;
}

export interface PropertyRiskRequest {
  customerPropertyOwnershipId: Guid | null;
  propertyValue: number;
  yearBuilt: number;
  constructionType: ConstructionType;
  claimsHistoryCount: number;
  stormShutters: boolean;
  impactResistantWindows: boolean;
  reinforcedRoof: boolean;
  emergencyGenerator: boolean;
  homeInspectionCertification: boolean;
}

export interface CalculateQuoteRequest {
  planId: Guid;
  requestedCoverage: number;
  property: PropertyRiskRequest;
}

export interface CalculateRecommendationsRequest {
  requestedCoverage: number;
  property: PropertyRiskRequest;
}

export interface RiskFactorResponse {
  name: string;
  value: number;
}

export interface RiskAssessmentResponse {
  riskScore: number;
  riskLevel: RiskLevel;
  propertyAge: number;
  requiresManualReview: boolean;
  factors: RiskFactorResponse[];
}

export interface PremiumBreakdownResponse {
  basePremium: number;
  locationRiskAdjustment: number;
  propertyRiskAdjustment: number;
  claimsHistoryAdjustment: number;
  riskAdjustment: number;
  discountAmount: number;
  finalPremium: number;
}

export interface QuoteResponse {
  plan: PlanSummaryResponse;
  requestedCoverage: number;
  property: PropertyRiskRequest;
  riskAssessment: RiskAssessmentResponse;
  premium: PremiumBreakdownResponse;
  assignedRiskZone?: string;
}

export interface CreatePolicyApplicationRequest extends CalculateQuoteRequest {
  customerId: Guid;
}

export interface PlanSearchRequest
  extends PageRequest {
  search?: string;
  isActive?: boolean;
}

export interface MyPoliciesRequest
  extends PageRequest {
  status?: PolicyStatus;
}

export interface PolicyApplicationResponse {
  policyId: Guid;
  policyNumber: string;
  status: PolicyStatus;
  premiumDue: number;
  riskScore: number;
  riskLevel: RiskLevel;
  currentVersionNumber: number;
  rowVersion: RowVersion;
  underwritingOutcome: UnderwritingDecision;
}

export interface PolicySummaryResponse {
  policyId: Guid;
  policyNumber: string;
  planId: Guid;
  planName: string;
  status: PolicyStatus;
  premiumDue: number;
  currentVersionNumber: number;
  createdAt: ApiDateTime;
  effectiveDate?: ApiDateTime | null;
  expirationDate?: ApiDateTime | null;
  previousPolicyId?: Guid | null;
  rowVersion: RowVersion;
}

export interface PolicyPropertyResponse {
  propertyId: Guid;
  customerPropertyOwnershipId: Guid | null;
  propertyValue: number;
  yearBuilt: number;
  constructionType: ConstructionType;
  riskZone: RiskZone;
  stormShutters: boolean;
  impactResistantWindows: boolean;
  reinforcedRoof: boolean;
  emergencyGenerator: boolean;
  homeInspectionCertification: boolean;
}

export interface ComplianceReviewResponse {
  isCompliant: boolean;
  confidenceScore: number;
  summary: string;
  violations: string[];
  missingDiscounts: string[];
  riskAssessment: string;
  recommendedActions: string[];
  citations: string[];
  createdAt: ApiDateTime;
}

export interface PolicyDetailsResponse {
  policyId: Guid;
  policyNumber: string;
  customerId: Guid;
  planId: Guid;
  status: PolicyStatus;
  premiumDue: number;
  currentVersionNumber: number;
  paymentTransactionId: Guid | null;
  createdAt: ApiDateTime;
  updatedAt: ApiDateTime | null;
  effectiveDate?: ApiDateTime | null;
  expirationDate?: ApiDateTime | null;
  previousPolicyId?: Guid | null;
  previousPolicyVersionNumber?: number | null;
  rowVersion: RowVersion;
  plan: PlanDetailsResponse;
  property: PolicyPropertyResponse;
  latestRiskAssessment: RiskAssessmentResponse;
  latestPremiumBreakdown: PremiumBreakdownResponse;
  complianceReview?: ComplianceReviewResponse | null;
}

export interface PolicyActionRequest {
  reason: string;
  rowVersion: RowVersion;
}

export interface CancellationPreviewResponse {
  policyId: Guid;
  policyNumber: string;
  premiumDue: number;
  effectiveDate: ApiDateTime | null;
  expirationDate: ApiDateTime | null;
  totalTermDays: number;
  daysActive: number;
  daysRemaining: number;
  refundAmount: number;
}

export interface RenewPolicyRequest {
  property: PropertyRiskRequest;
  reason: string;
  rowVersion: RowVersion;
}

export interface PolicyEndorsementRequest {
  stormShutters: boolean;
  impactResistantWindows: boolean;
  reinforcedRoof: boolean;
  emergencyGenerator: boolean;
  homeInspectionCertification: boolean;
  reason: string;
  rowVersion: RowVersion;
}

export interface PolicyEndorsementResponse {
  policyId: Guid;
  policyNumber: string;
  status: PolicyStatus;
  premiumDue: number;
  currentVersionNumber: number;
  rowVersion: RowVersion;
}

export interface RenewalEstimateRequest {
  rowVersion: RowVersion;
}

export interface RenewalEstimateResponse {
  policyId: Guid;
  policyNumber: string;
  planId: Guid;
  planName: string;
  coverageLimit: number;
  currentPremium: number;
  estimatedRenewalPremium: number;
  differenceAmount: number;
  comparisonOutcome: 'Increase' | 'Saving' | 'NoChange';
  totalMitigationDiscount: number;
  riskScore: number;
  riskLevel: RiskLevel;
  manualReviewRequired: boolean;
  breakdown: PremiumBreakdownResponse;
}

export interface PolicyMutationResponse {
  policyId: Guid;
  policyNumber: string;
  status: PolicyStatus;
  premiumDue: number;
  currentVersionNumber: number;
  paymentTransactionId: Guid | null;
  rowVersion: RowVersion;
}

export interface RenewalResponse {
  policyId: Guid;
  policyNumber: string;
  status: PolicyStatus;
  premiumDue: number;
  currentVersionNumber: number;
  riskScore: number;
  riskLevel: RiskLevel;
  underwritingOutcome: UnderwritingDecision;
  rowVersion: RowVersion;
}

export interface PolicyVersionResponse {
  policyVersionId: Guid;
  versionNumber: number;
  changeReason: string;
  snapshotData: string;
  createdAt: ApiDateTime;
  createdBy: string;
}

export interface PolicyHistoryResponse {
  historyId: Guid;
  fromStatus: PolicyStatus | null;
  toStatus: PolicyStatus;
  reason: string;
  changedAt: ApiDateTime;
  changedBy: string;
  correlationId: string;
}

export interface UnderwritingSearchRequest extends PageRequest {
  riskLevel?: RiskLevel;
  planId?: Guid;
  minimumPropertyAge?: number;
  maximumPropertyAge?: number;
  submittedFrom?: ApiDateTime;
  submittedTo?: ApiDateTime;
}

export interface UnderwritingQueueItemResponse {
  policyId: Guid;
  policyNumber: string;
  customerId: Guid;
  planId: Guid;
  planName: string;
  riskScore: number;
  riskLevel: RiskLevel;
  propertyAge: number;
  submittedAt: ApiDateTime;
  rowVersion: RowVersion;
}

export interface UnderwritingDetailsResponse {
  policy: PolicyDetailsResponse;
  underwritingReviewId: Guid;
  reviewStatus: UnderwritingReviewStatus;
  reviewerUserId: Guid | null;
  reviewerDisplay: string | null;
  decision: UnderwritingDecision | null;
  reviewedAt: ApiDateTime | null;
  reviewRowVersion: RowVersion;
}

export interface UnderwritingDecisionReasonRequest {
  reasonCode: string;
  reasonDescription: string;
}

export interface ApprovePolicyRequest {
  reasons: UnderwritingDecisionReasonRequest[];
  policyRowVersion: RowVersion;
  reviewRowVersion: RowVersion;
}

export type RejectPolicyRequest = ApprovePolicyRequest;

export interface StaffPolicySearchRequest extends PageRequest {
  search?: string;
  status?: PolicyStatus;
  customerId?: Guid;
  planId?: Guid;
  createdFrom?: ApiDateTime;
  createdTo?: ApiDateTime;
}

export interface StaffPolicySummaryResponse {
  policyId: Guid;
  policyNumber: string;
  customerId: Guid;
  planId: Guid;
  planName: string;
  status: PolicyStatus;
  premiumDue: number;
  currentVersionNumber: number;
  createdAt: ApiDateTime;
  updatedAt: ApiDateTime | null;
  rowVersion: RowVersion;
}


export const CUSTOMER_STATUSES = ['Inactive', 'Active'] as const;
export type CustomerStatus = (typeof CUSTOMER_STATUSES)[number];

export const POLICY_STATUSES = [
  'Draft',
  'Submitted',
  'Underwriting',
  'Approved',
  'PaymentPending',
  'Active',
  'Suspended',
  'Cancelled',
  'Expired',
  'Renewed',
] as const;
export type PolicyStatus = (typeof POLICY_STATUSES)[number];

export const CLAIM_STATUSES = [
  'Submitted',
  'UnderReview',
  'Approved',
  'Rejected',
  'PaymentInitiated',
  'Closed',
] as const;
export type ClaimStatus = (typeof CLAIM_STATUSES)[number];

export const DOCUMENT_VERIFICATION_STATUSES = [
  'Pending',
  'Verified',
  'Rejected',
] as const;
export type DocumentVerificationStatus =
  (typeof DOCUMENT_VERIFICATION_STATUSES)[number];

export const PAYMENT_STATUSES = ['Pending', 'Success', 'Failed'] as const;
export type PaymentStatus = (typeof PAYMENT_STATUSES)[number];

export const PAYMENT_TYPES = ['Premium', 'ClaimSettlement', 'Refund'] as const;
export type PaymentType = (typeof PAYMENT_TYPES)[number];

export const RISK_LEVELS = ['Low', 'Medium', 'High', 'Extreme'] as const;
export type RiskLevel = (typeof RISK_LEVELS)[number];

export const RISK_ZONES = ['A', 'B', 'C', 'D'] as const;
export type RiskZone = (typeof RISK_ZONES)[number];

export const CONSTRUCTION_TYPES = [
  'ReinforcedConcrete',
  'Concrete',
  'Masonry',
  'WoodFrame',
  'Other',
] as const;
export type ConstructionType = (typeof CONSTRUCTION_TYPES)[number];

export const UNDERWRITING_DECISIONS = [
  'Approved',
  'ManualReview',
  'Rejected',
] as const;
export type UnderwritingDecision = (typeof UNDERWRITING_DECISIONS)[number];

export const UNDERWRITING_REVIEW_STATUSES = ['Pending', 'Completed'] as const;
export type UnderwritingReviewStatus =
  (typeof UNDERWRITING_REVIEW_STATUSES)[number];

export const CLAIM_REVIEW_DECISIONS = ['Approved', 'Rejected'] as const;
export type ClaimReviewDecision = (typeof CLAIM_REVIEW_DECISIONS)[number];

export const CLAIM_NOTE_TYPES = ['AdditionalInformationRequested'] as const;
export type ClaimNoteType = (typeof CLAIM_NOTE_TYPES)[number];

export const OWNERSHIP_TYPES = ['Owned', 'Mortgaged', 'CoOwned'] as const;
export type OwnershipType = (typeof OWNERSHIP_TYPES)[number];

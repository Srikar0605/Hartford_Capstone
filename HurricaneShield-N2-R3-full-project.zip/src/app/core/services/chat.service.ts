
import { HttpClient } from '@angular/common/http';
import { Injectable, inject, signal } from '@angular/core';
import { forkJoin, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { apiUrl } from './api-url';
import { AuthStore } from '../auth/auth.store';
import type { ChatApiRequest, ChatApiResponse, ChatMessage } from '../models/chat.models';
import type { ApiResponse } from '../models/api.models';

@Injectable({
  providedIn: 'root',
})
export class ChatService {
  private readonly http = inject(HttpClient);
  private readonly authStore = inject(AuthStore);

  readonly isOpen = signal<boolean>(false);
  readonly isTyping = signal<boolean>(false);

  readonly messages = signal<ChatMessage[]>([
    {
      id: 'welcome-1',
      role: 'model',
      content:
        "Hello! I'm ShieldBot, your HurricaneShield virtual assistant. How can I help you today with quotes, coverage, claims, or storm preparation?",
      timestamp: new Date(),
    },
  ]);

  toggleOpen(): void {
    this.isOpen.update((v) => !v);
  }

  setOpen(open: boolean): void {
    this.isOpen.set(open);
  }

  sendMessage(text: string): void {
    const trimmed = text.trim();
    if (!trimmed || this.isTyping()) {
      return;
    }

    const userMsg: ChatMessage = {
      id: `usr-${Date.now()}`,
      role: 'user',
      content: trimmed,
      timestamp: new Date(),
    };

    // Optimistically add the user's message
    this.messages.update((msgs) => [...msgs, userMsg]);
    this.isTyping.set(true);

    const historyPayload = this.messages()
      .slice(0, -1) // Exclude current user message from history
      .map((m) => ({
        role: m.role,
        content: m.content,
      }));

    if (this.authStore.isAuthenticated()) {
      // Gather real-time context from Sister Services in parallel
      const profile$ = this.http
        .get<any>(apiUrl('/gateway/customers/api/v1/customers/me'))
        .pipe(catchError(() => of(null)));

      const claims$ = this.http
        .get<any>(apiUrl('/gateway/claims/api/v1/claims/me'))
        .pipe(catchError(() => of(null)));

      const payments$ = this.http
        .get<any>(apiUrl('/gateway/payments/api/v1/payments/me'))
        .pipe(catchError(() => of(null)));

      forkJoin({ profile: profile$, claims: claims$, payments: payments$ }).subscribe({
        next: ({ profile, claims, payments }) => {
          let clientContext = '';
          if (profile?.data) {
            const p = profile.data;
            clientContext += `• Customer Profile: ${p.firstName ?? ''} ${p.lastName ?? ''} (${p.email ?? ''}), Phone: ${p.phoneNumber ?? 'N/A'}\n`;
          }
          if (claims?.data?.items && claims.data.items.length > 0) {
            clientContext += `• Customer Claims on Record (${claims.data.items.length} total):\n`;
            for (const c of claims.data.items) {
              clientContext += `  - Claim ${c.claimNumber}: Status: ${c.status}, Amount: ₹${c.claimAmount}, Incident Date: ${c.incidentDate}, Desc: ${c.incidentDescription ?? 'N/A'}\n`;
            }
          } else {
            clientContext += `• Customer Claims: No claims filed yet.\n`;
          }
          if (payments?.data?.items && payments.data.items.length > 0) {
            clientContext += `• Customer Payments & Settlements (${payments.data.items.length} total):\n`;
            for (const pay of payments.data.items.slice(0, 5)) {
              clientContext += `  - ${pay.transactionNumber}: ${pay.type} of ₹${pay.amount} (${pay.status}) on ${pay.createdAt}\n`;
            }
          } else {
            clientContext += `• Customer Payments: No payment transactions recorded.\n`;
          }

          const request: ChatApiRequest = {
            history: historyPayload,
            newMessage: trimmed,
            clientContext: clientContext.trim(),
          };

          this.executeChatCall(request);
        },
        error: () => {
          const request: ChatApiRequest = {
            history: historyPayload,
            newMessage: trimmed,
          };
          this.executeChatCall(request);
        },
      });
    } else {
      // Guest mode: send directly without authenticated context
      const request: ChatApiRequest = {
        history: historyPayload,
        newMessage: trimmed,
      };
      this.executeChatCall(request);
    }
  }

  private executeChatCall(request: ChatApiRequest): void {
    this.http
      .post<ApiResponse<ChatApiResponse>>(
        apiUrl('/gateway/policies/api/v1/system/chat'),
        request
      )
      .subscribe({
        next: (res) => {
          this.isTyping.set(false);
          const reply = res.data?.reply ?? "I'm sorry, I couldn't process your request. Please try again.";
          const botMsg: ChatMessage = {
            id: `bot-${Date.now()}`,
            role: 'model',
            content: reply,
            timestamp: new Date(),
          };
          this.messages.update((msgs) => [...msgs, botMsg]);
        },
        error: () => {
          this.isTyping.set(false);
          const errorMsg: ChatMessage = {
            id: `bot-${Date.now()}`,
            role: 'model',
            content:
              'I am currently experiencing connection difficulties. Please feel free to reach out to customer care at 1-800-555-0199.',
            timestamp: new Date(),
          };
          this.messages.update((msgs) => [...msgs, errorMsg]);
        },
      });
  }
}

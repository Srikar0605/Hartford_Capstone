
import {
  HttpErrorResponse,
  type HttpInterceptorFn,
} from '@angular/common/http';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { catchError, throwError } from 'rxjs';

import { AuthStore } from '../auth/auth.store';
import type { ApiErrorResponse, FrontendErrorState } from '../models/error.models';
import { NotificationService } from '../services/notification.service';

/**
 * I designed ApiClientError to normalize error responses across our microservices.
 * Whether the error came from an ASP.NET ProblemDetails payload, our custom ApiResponse envelope,
 * or a raw network failure, components receive a predictable error shape with extracted validation errors.
 */
export class ApiClientError extends Error implements FrontendErrorState {
  constructor(
    message: string,
    readonly errorCode: string | null,
    readonly correlationId: string | null,
    readonly status: number | null,
    readonly validationErrors: Record<string, string[]> = {},
  ) {
    super(message);
    this.name = 'ApiClientError';
  }
}

/**
 * Global HTTP error handling interceptor.
 * I centralized status-specific side effects here so individual components don't have to duplicate
 * logic for redirecting on expired sessions (401), unauthorized roles (403), or displaying toast alerts.
 */
export const errorInterceptor: HttpInterceptorFn = (request, next) => {
  const authStore = inject(AuthStore);
  const notifications = inject(NotificationService);
  const router = inject(Router);

  return next(request).pipe(
    catchError((error: unknown) => {
      const clientError = toApiClientError(error);

      // On 401 Unauthorized, wipe stored tokens and route to login (unless we are already attempting a login).
      if (clientError.status === 401) {
        authStore.clearSession();
        if (!request.url.includes('/auth/login')) {
          void router.navigateByUrl('/auth/login');
        }
      } else if (clientError.status === 403) {
        // 403 Forbidden indicates the user is logged in, but lacks permissions/roles for the requested resource.
        void router.navigateByUrl('/access-denied');
      }

      // We show toast notifications for all errors except 401/403, which are already handled by navigation redirects.
      // Notice we pass clientError.correlationId so users can quote the trace ID when reporting bugs to support.
      if (clientError.status !== 401 && clientError.status !== 403) {
        notifications.error(
          errorTitle(clientError.status),
          clientError.message,
          clientError.correlationId,
        );
      }

      return throwError(() => clientError);
    }),
  );
};

/**
 * Unpacks diverse error structures into our standardized ApiClientError model.
 * It searches both the JSON body and response headers for the X-Correlation-ID so
 * distributed logs can be queried easily in Serilog/Seq.
 */
function toApiClientError(error: unknown): ApiClientError {
  if (error instanceof ApiClientError) {
    return error;
  }

  if (!(error instanceof HttpErrorResponse)) {
    return new ApiClientError(
      'An unexpected error occurred.',
      null,
      null,
      null,
    );
  }

  const body = isApiErrorResponse(error.error) ? error.error : null;
  const validationErrors = body?.errors ?? {};
  const message = body?.message || fallbackMessage(error.status);

  return new ApiClientError(
    message,
    body?.errorCode ?? null,
    body?.correlationId ?? error.headers?.get('X-Correlation-Id') ?? null,
    error.status,
    validationErrors,
  );
}

/**
 * Type guard to verify if the backend returned our standardized error envelope.
 */
function isApiErrorResponse(value: unknown): value is ApiErrorResponse {
  if (!value || typeof value !== 'object') {
    return false;
  }

  const candidate = value as Partial<ApiErrorResponse>;
  return (
    candidate.success === false &&
    typeof candidate.errorCode === 'string' &&
    typeof candidate.message === 'string' &&
    typeof candidate.correlationId === 'string'
  );
}

/**
 * Fallback user-friendly copy when the backend doesn't return a custom message.
 */
function fallbackMessage(status: number): string {
  switch (status) {
    case 0:
      return 'The backend could not be reached. Confirm that the Gateway is running.';
    case 400:
      return 'The request could not be processed. Review the entered information.';
    case 401:
      return 'The session is no longer valid. Sign in again.';
    case 403:
      return 'The account is not authorized for this operation.';
    case 404:
      return 'The requested resource is unavailable.';
    case 409:
      return 'The operation conflicts with the current resource state.';
    case 422:
      return 'The operation does not satisfy the current business rules.';
    case 503:
      return 'A required service is temporarily unavailable.';
    default:
      return 'Something went wrong while processing the request.';
  }
}

function errorTitle(status: number | null): string {
  switch (status) {
    case 409:
      return 'Action could not be completed';
    case 422:
      return 'Action not allowed';
    case 503:
    case 0:
      return 'Service unavailable';
    default:
      return 'Request failed';
  }
}
